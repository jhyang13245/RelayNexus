# 빈손 ~가호 없는 최약체로 소환됐지만, 쓰러뜨린 적의 가호는 내 것이 된다~ Cortex 작품

최종 공개된 산문이 정사다. 사용자 요청은 확정 사실이 아니며 세계와 인과 안에서 수용·우회·제한한다.
현재 사건 목표를 기본 비트부터 자연스럽게 진행한다. 기본 3비트, 최소 2비트부터 조기 종결, 연장 최대 2비트. 미충족 지적은 연장 구간에서 검토한다.
원본이 허용한 미충족 전개로 수습되면 대체 종결로 전환한다. 수습되지 않은 의무만 최후 안전장치로 다음 사건 첫 문단에 이월한다. 포기·대체된 목표를 다시 강제하지 않는다.
사건별 예정 날짜·시작 시각·종료 시각·시간창은 사용하지 않는다. 지정된 후속사건을 우선하고, 미지정이면 사건 배열 순서로 진행한다.
구체적 시간 경과는 현재 공개 본문과 현재 제공된 사건 설명에 따라 집필한다. 다음 사건 설명을 진입 전에 미리 읽거나 미래 시간표에 맞추지 않는다.
작품 근거 없는 24시간 이상 도약은 사용자 요청과 작가 임의 전개 모두 현재 문맥에서 인과적으로 흡수한다. 자정을 넘는 것 자체는 금지가 아니다.
현재 제공된 작품 스토리가 명시한 하루 이상 경과는 그대로 따른다. 3일 뒤·17년 뒤·10년 혼수상태 같은 작가의 서사 문장을 보존한다.
24시간 미만이라도 진행 중인 위험·전투·긴박성을 무너뜨리는 도약은 자연스럽게 중단·단축한다. 꿈·환상은 최후의 수단이다.
새 사건을 처음 읽었을 때 시간대가 이미 지났다면 현재 시각부터 가까운 다음 시간대까지 필요한 일상을 짧게 연결해 해당 비트에서 시작한다. 별도 대기 비트를 요구하지 않는다.
이미 지난 마감·기회는 설득력 있는 지연·상황 변화·대체 기회와 그 결과로 수습한다. 공개한 본문·출발·종료 사실과 시간은 정사이며 24시간 상한으로 되감거나 취소하지 않는다.
작가는 현재 사건·이전 두 사건 원문과 오래된 요약을 읽고, 판정관은 현재·이전 두 사건의 공개 원문만 읽는다. 계약은 달성 기준이지 사실의 증거가 아니다.
첫 문단은 장면을 여는 자연스러운 산문으로 쓴다. 상태표·추천답변·선택지·내부 판정 기록을 산문 출력에 강제하지 않는다. 모델 배정과 호출 횟수는 엔진이 관리한다.

~~~json
{
  "package": {
    "packageVersion": "1.5",
    "engineVersion": "2.4",
    "projectId": "RN-DRAFT",
    "title": "빈손 ~가호 없는 최약체로 소환됐지만, 쓰러뜨린 적의 가호는 내 것이 된다~",
    "difficulty": "HARD",
    "randomSeed": 420001285,
    "generatedAt": "2026-10-08T01:53:41.122Z",
    "packageTarget": "cortex",
    "format": "DANCHEONG_CORTEX_PACK_V1",
    "minimumTargetVersion": "1.42.0",
    "integrationTarget": {
      "engine": "dancheong-cortex",
      "cortexBaseVersion": "1.42.0",
      "minimumNexusVersion": "1.23.0",
      "minimumExtensionRevision": "1.3.0"
    },
    "protagonistInvariants": [
      {
        "ref": "invariant:survival",
        "label": "강시우 · 주인공의 생존",
        "severity": "HARD",
        "description": "[대상 캐릭터: 강시우 / siwoo] 주인공은 죽지 않는다.",
        "characterId": "siwoo",
        "characterName": "강시우"
      },
      {
        "ref": "invariant:mobility",
        "label": "강시우 · 보행·자립 이동 능력",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 강시우 / siwoo] 이동·추격·잠입이 필요한 사건이 남아 있다.",
        "characterId": "siwoo",
        "characterName": "강시우"
      },
      {
        "ref": "invariant:senses",
        "label": "강시우 · 시각·청각",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 강시우 / siwoo] 단서 관찰과 대화가 사건의 기본 수단이다.",
        "characterId": "siwoo",
        "characterName": "강시우"
      },
      {
        "ref": "invariant:identity",
        "label": "강시우 · 자기 기억과 인격의 연속성",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 강시우 / siwoo] 전면적 기억 상실이나 인격 교체로 확정되지 않는다.",
        "characterId": "siwoo",
        "characterName": "강시우"
      },
      {
        "ref": "invariant:rine-survival",
        "label": "리네의 생존",
        "severity": "HARD",
        "description": "[대상 캐릭터: 리네 / rine] 리네는 죽지 않는다.",
        "characterId": "rine",
        "characterName": "리네"
      },
      {
        "ref": "invariant:estelle-survival",
        "label": "에스텔의 생존",
        "severity": "HARD",
        "description": "[대상 캐릭터: 에스텔 / estelle] 에스텔은 죽지 않는다.",
        "characterId": "estelle",
        "characterName": "에스텔"
      },
      {
        "ref": "invariant:tio-survival",
        "label": "티오의 생존",
        "severity": "HARD",
        "description": "[대상 캐릭터: 티오 / tio] 티오는 죽지 않는다.",
        "characterId": "tio",
        "characterName": "티오"
      },
      {
        "ref": "invariant:selene-until-unmask",
        "label": "가면이 깨지기 전 셀레네",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 셀레네 / selene] 셀레네는 「가면 아래」 사건 전에 죽지 않는다.",
        "characterId": "selene",
        "characterName": "셀레네"
      },
      {
        "ref": "invariant:isolde-survival",
        "label": "이졸데의 생존",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 이졸데 / isolde] 이졸데는 1부에서 죽지 않는다.",
        "characterId": "isolde",
        "characterName": "이졸데"
      },
      {
        "ref": "invariant:kyle-survival",
        "label": "카일의 생존",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 카일 / kyle] 카일은 1부에서 죽지 않는다.",
        "characterId": "kyle",
        "characterName": "카일"
      },
      {
        "ref": "invariant:gregor-until-duel",
        "label": "결전 전 그레고르의 지위",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 그레고르 / gregor] 그레고르는 「대주교 그레고르」 사건 전에 죽거나 실각하지 않는다.",
        "characterId": "gregor",
        "characterName": "그레고르"
      },
      {
        "ref": "invariant:rosalind-until-inquiry",
        "label": "마지막 심문 전 로잘린",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 로잘린 / rosalind] 로잘린은 「로잘린의 마지막 심문」 전에 죽지 않는다.",
        "characterId": "rosalind",
        "characterName": "로잘린"
      },
      {
        "ref": "invariant:oss-death",
        "label": "오스의 죽음",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 오스 / oss] 오스는 「빈 가면」 사건에서 죽으며 되살아나지 않는다.",
        "characterId": "oss",
        "characterName": "오스"
      },
      {
        "ref": "invariant:hanbaek-hidden",
        "label": "빈손의 왕의 침묵",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 빈손의 왕 / hanbaek] 빈손의 왕은 「우물 밑의 목소리」 사건 전에 본문에 직접 등장하거나 말을 걸지 않는다.",
        "characterId": "hanbaek",
        "characterName": "빈손의 왕"
      }
    ]
  },
  "protagonistInvariants": [
    {
      "ref": "invariant:survival",
      "label": "강시우 · 주인공의 생존",
      "severity": "HARD",
      "description": "[대상 캐릭터: 강시우 / siwoo] 주인공은 죽지 않는다.",
      "characterId": "siwoo",
      "characterName": "강시우"
    },
    {
      "ref": "invariant:mobility",
      "label": "강시우 · 보행·자립 이동 능력",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 강시우 / siwoo] 이동·추격·잠입이 필요한 사건이 남아 있다.",
      "characterId": "siwoo",
      "characterName": "강시우"
    },
    {
      "ref": "invariant:senses",
      "label": "강시우 · 시각·청각",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 강시우 / siwoo] 단서 관찰과 대화가 사건의 기본 수단이다.",
      "characterId": "siwoo",
      "characterName": "강시우"
    },
    {
      "ref": "invariant:identity",
      "label": "강시우 · 자기 기억과 인격의 연속성",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 강시우 / siwoo] 전면적 기억 상실이나 인격 교체로 확정되지 않는다.",
      "characterId": "siwoo",
      "characterName": "강시우"
    },
    {
      "ref": "invariant:rine-survival",
      "label": "리네의 생존",
      "severity": "HARD",
      "description": "[대상 캐릭터: 리네 / rine] 리네는 죽지 않는다.",
      "characterId": "rine",
      "characterName": "리네"
    },
    {
      "ref": "invariant:estelle-survival",
      "label": "에스텔의 생존",
      "severity": "HARD",
      "description": "[대상 캐릭터: 에스텔 / estelle] 에스텔은 죽지 않는다.",
      "characterId": "estelle",
      "characterName": "에스텔"
    },
    {
      "ref": "invariant:tio-survival",
      "label": "티오의 생존",
      "severity": "HARD",
      "description": "[대상 캐릭터: 티오 / tio] 티오는 죽지 않는다.",
      "characterId": "tio",
      "characterName": "티오"
    },
    {
      "ref": "invariant:selene-until-unmask",
      "label": "가면이 깨지기 전 셀레네",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 셀레네 / selene] 셀레네는 「가면 아래」 사건 전에 죽지 않는다.",
      "characterId": "selene",
      "characterName": "셀레네"
    },
    {
      "ref": "invariant:isolde-survival",
      "label": "이졸데의 생존",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 이졸데 / isolde] 이졸데는 1부에서 죽지 않는다.",
      "characterId": "isolde",
      "characterName": "이졸데"
    },
    {
      "ref": "invariant:kyle-survival",
      "label": "카일의 생존",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 카일 / kyle] 카일은 1부에서 죽지 않는다.",
      "characterId": "kyle",
      "characterName": "카일"
    },
    {
      "ref": "invariant:gregor-until-duel",
      "label": "결전 전 그레고르의 지위",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 그레고르 / gregor] 그레고르는 「대주교 그레고르」 사건 전에 죽거나 실각하지 않는다.",
      "characterId": "gregor",
      "characterName": "그레고르"
    },
    {
      "ref": "invariant:rosalind-until-inquiry",
      "label": "마지막 심문 전 로잘린",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 로잘린 / rosalind] 로잘린은 「로잘린의 마지막 심문」 전에 죽지 않는다.",
      "characterId": "rosalind",
      "characterName": "로잘린"
    },
    {
      "ref": "invariant:oss-death",
      "label": "오스의 죽음",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 오스 / oss] 오스는 「빈 가면」 사건에서 죽으며 되살아나지 않는다.",
      "characterId": "oss",
      "characterName": "오스"
    },
    {
      "ref": "invariant:hanbaek-hidden",
      "label": "빈손의 왕의 침묵",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 빈손의 왕 / hanbaek] 빈손의 왕은 「우물 밑의 목소리」 사건 전에 본문에 직접 등장하거나 말을 걸지 않는다.",
      "characterId": "hanbaek",
      "characterName": "빈손의 왕"
    }
  ],
  "disclosure": {
    "protectedTerms": [
      "한백"
    ]
  },
  "importInstruction": {
    "command": "/패키지불러오기",
    "rules": [
      "최종 공개된 산문이 정사다. 사용자 요청은 확정 사실이 아니며 세계와 인과 안에서 수용·우회·제한한다.\n현재 사건 목표를 기본 비트부터 자연스럽게 진행한다. 기본 3비트, 최소 2비트부터 조기 종결, 연장 최대 2비트. 미충족 지적은 연장 구간에서 검토한다.\n원본이 허용한 미충족 전개로 수습되면 대체 종결로 전환한다. 수습되지 않은 의무만 최후 안전장치로 다음 사건 첫 문단에 이월한다. 포기·대체된 목표를 다시 강제하지 않는다.\n사건별 예정 날짜·시작 시각·종료 시각·시간창은 사용하지 않는다. 지정된 후속사건을 우선하고, 미지정이면 사건 배열 순서로 진행한다.\n구체적 시간 경과는 현재 공개 본문과 현재 제공된 사건 설명에 따라 집필한다. 다음 사건 설명을 진입 전에 미리 읽거나 미래 시간표에 맞추지 않는다.\n작품 근거 없는 24시간 이상 도약은 사용자 요청과 작가 임의 전개 모두 현재 문맥에서 인과적으로 흡수한다. 자정을 넘는 것 자체는 금지가 아니다.\n현재 제공된 작품 스토리가 명시한 하루 이상 경과는 그대로 따른다. 3일 뒤·17년 뒤·10년 혼수상태 같은 작가의 서사 문장을 보존한다.\n24시간 미만이라도 진행 중인 위험·전투·긴박성을 무너뜨리는 도약은 자연스럽게 중단·단축한다. 꿈·환상은 최후의 수단이다.\n새 사건을 처음 읽었을 때 시간대가 이미 지났다면 현재 시각부터 가까운 다음 시간대까지 필요한 일상을 짧게 연결해 해당 비트에서 시작한다. 별도 대기 비트를 요구하지 않는다.\n이미 지난 마감·기회는 설득력 있는 지연·상황 변화·대체 기회와 그 결과로 수습한다. 공개한 본문·출발·종료 사실과 시간은 정사이며 24시간 상한으로 되감거나 취소하지 않는다.\n작가는 현재 사건·이전 두 사건 원문과 오래된 요약을 읽고, 판정관은 현재·이전 두 사건의 공개 원문만 읽는다. 계약은 달성 기준이지 사실의 증거가 아니다.\n첫 문단은 장면을 여는 자연스러운 산문으로 쓴다. 상태표·추천답변·선택지·내부 판정 기록을 산문 출력에 강제하지 않는다. 모델 배정과 호출 횟수는 엔진이 관리한다.",
      "비공개 GM 설정과 아직 공개되지 않은 정보는 산문에 직접 노출하지 않는다.",
      "장소·인물·사건 참조는 패키지 연결용이며 산문 안의 모든 실체를 별도 장부에 등록하도록 강제하지 않는다."
    ]
  },
  "scenario": {
    "title": "빈손 ~가호 없는 최약체로 소환됐지만, 쓰러뜨린 적의 가호는 내 것이 된다~",
    "genre": "이세계 소환 판타지 · 라이트노벨 · 성장 · 다크 판타지",
    "worldType": "이세계(소환형 판타지)",
    "startDate": "2026-10-20",
    "startLocation": "왕도 에르딘 바깥 고리, 빈민가 「잿골목」",
    "tone": "웃기고 설레는 이세계 성장물로 시작해, 힘의 대가와 세계의 거짓이 드러나며 짙어지는 다크 판타지",
    "playStyle": "지능형 정사 전개 · 사건·인과·자율 세계 시뮬레이션",
    "author": "",
    "notes": "지음 지능형 정사 모드용 단일 루트 작품(1부, 5권 구성). 사건 75개, 분기 4회, 인물 23명. 메인 히로인은 에스텔, 리네는 늘 곁에 있는 주요 히로인. 설계 문서는 works/empty-hand/README.md.",
    "difficultyProfile": {
      "difficulty": "HARD",
      "protagonistProtection": "none",
      "resourceTracking": "strict",
      "hiddenInformation": "strict",
      "retroactivePreparation": "forbidden",
      "npcAutonomy": "full",
      "failureMitigation": "none",
      "deathEnabled": true,
      "warningLevel": "observational_only",
      "relationVolatility": "realistic",
      "clockAdvanceSeverity": "strict"
    }
  },
  "worldCanon": {
    "overview": "[세계]\n에르딘 왕국. 왕도 에르딘을 중심으로 한 대륙 서쪽의 오래된 나라. 이 세계의 모든 사람은 열 살이 되는 해 별의 대성당에서 열리는 '별의 의식'에서 '가호' 하나를 받는다. 가호는 불꽃을 다루거나, 피부를 쇳덩이로 만들거나, 상처를 고치는 것 같은 타고난 능력이다. 사람마다 가호를 담는 자리는 단 하나뿐이다. 의식에 나가려면 '의식 헌금'을 내야 해서, 가난한 집은 몇 달씩 돈을 모은다. 의식에서는 일곱 성인 중 첫째인 '별의 성인'의 후손, 아스트레아 공작가의 '별읽기 무녀'가 아이의 가슴속에 켜진 빛을 읽어 받은 가호를 선포한다. 무녀가 읽은 것은 곧 별의 뜻이다.\n\n[가호와 계급]\n가호의 세기는 곧 신분이다. 강한 가호를 받은 자는 귀족과 기사가 되고, 약한 가호는 평민의 생업이 된다. 가호를 받지 못한 자는 '빈손'이라 불린다. 빈손은 땅을 가질 수 없고, 품삯은 가호자의 절반, 길드에서는 최하 '돌 등급', 법정에서는 증언의 무게가 절반이다. 가게 앞에 '빈손 사절' 팻말이 걸리기도 한다. 빈손들은 왕도 바깥 고리의 빈민가 '잿골목'에서 세탁·하수구 청소·짐꾼 일로 살아간다. 수인(짐승의 귀와 꼬리를 가진 종족)은 의식에서 가호를 받지 못해 '태생 빈손'이라 불리며 노예로 팔리기도 한다. 엘프는 이제 거의 남지 않았다.\n\n[별의 우물과 마수]\n사람이 죽으면 가호는 별의 대성당 깊은 곳의 '별의 우물'로 돌아가, 다음 의식에서 다른 아이에게 내려진다고 성좌교는 가르친다. 우물로 돌아가지 못한 떠돌이 가호가 짐승에게 붙으면 '마수'가 된다. 마수는 그 가호의 힘을 쓴다. 모험가 길드는 마수 토벌로 먹고산다.\n\n[성좌교와 경전]\n성좌교는 별의 우물과 의식을 관장하는 국교이며 대주교 그레고르가 이끈다. 왕실은 이름만 남았다는 말이 돈다. 경전에는 300년 전의 폭군 '빈손의 왕' 이야기가 있다. 가호가 없던 그는 남의 가호를 빼앗아 모으며 왕이 되려 했고, 일곱 성인에게 쓰러졌다. 경전은 경고한다. \"가호를 빼앗는 손이 다시 나타나면, 그 손을 불태우라.\" 성좌교에는 등록되지 않은 가호를 찾아 회수하는 비밀 집행자 '빈 가면'이 있다는 소문이 돈다.\n\n[알려진 가호들]\n〈철피〉 피부를 열 호흡 동안 쇳덩이처럼 굳힌다. 끝나면 숨이 차오른다.\n〈어둠눈〉 어둠 속을 희미한 새벽처럼 본다. 강한 빛에는 눈이 부신다.\n〈미끄럼〉 자기 몸이나 손댄 바닥을 미끈하게 만든다. 붙잡히지 않지만 자기도 미끄러질 수 있다.\n〈바람발〉 열 걸음 남짓을 바람처럼 내달린다.\n〈메아리〉 1분 안에 들은 소리를 스무 걸음 안의 원하는 곳에서 다시 낸다.\n〈자물쇠 손〉 손을 댄 자물쇠를 연다. 마법 봉인에는 듣지 않는다.\n〈독 이빨〉 송곳니나 손끝에서 마비 독이 배어 나온다. 상처를 내야 통한다.\n〈거미줄〉 손끝에서 끈끈한 실을 쏜다. 불에 약하다.\n〈무게 바꾸기〉 자기 몸을 깃털처럼 가볍게, 또는 바위처럼 무겁게 한다.\n〈뼈 칼날〉 팔뚝에서 뼈 칼날이 돋는다. 부러지면 다시 돋을 때까지 아프다.\n〈불꽃 왕관〉 머리 위에 불꽃 고리가 떠오르고, 검과 손에 화염을 두르며 불꽃을 날린다. 귀족가의 강한 가호.\n〈치유의 손〉 남의 상처를 손으로 쓸어 닫는다. 자기 상처는 고치지 못하고, 쓸수록 지친다.\n〈굳힘〉 눈을 마주친 상대를 한 호흡 동안 멈추게 한다. 1분에 한 번.\n〈빛 방패〉 손바닥 앞에 빛의 방패를 세운다. 성기사들이 흔히 받는다.\n〈거짓말 냄새〉 거짓말을 냄새로 맡는다.\n그 밖에도 수많은 가호가 있으며, 마수도 저마다 하나의 가호를 지닌다.\n\n[장소]\n왕도는 상층 구역(귀족·별의 대성당·왕궁), 중층 구역(상인·모험가 길드·투기장), 바깥 고리의 잿골목으로 나뉜다. 잿골목 지하에는 무너진 옛 예배당과 하수도가 얽혀 있고, 중층 구역 뒷골목에는 장물과 정보를 사고파는 '그림자 시장'이 있다. 투기장에서는 노예와 빈손이 가호자들과 싸운다. 성벽 밖에는 마수가 사는 숲과 동쪽 늪이 있다.",
    "history": "",
    "politics": "",
    "economy": "",
    "technology": "",
    "society": "",
    "military": "",
    "religionIdeology": "",
    "transportCommunication": "",
    "currencyPrices": "",
    "supernatural": "",
    "impossibilities": "",
    "fixedCanon": "1. 이 세계 사람은 가호 자리가 하나뿐이다. 주인공의 그릇만 예외다.\n2. 주인공의 힘은 '쓰러뜨린 상대, 또는 스스로 내어 준 상대의 가호를 가져오는 것' 하나뿐이다(「건네는 손」 이후에는 가져온 가호를 건넬 수도 있다). 다른 능력을 새로 만들어 내지 않는다.\n3. 가호를 빼앗긴 사람은 빈손이 된다. 이 결과를 가볍게 넘기지 않는다.\n4. 그릇이 가득 차면 하나를 놓아야 새 가호를 가져올 수 있다.\n5. 죽은 사람은 되살아나지 않는다. 〈치유의 손〉은 죽음을 되돌리지 못한다.\n6. 수인과 엘프는 가호를 가질 수 없다.\n7. 이 세계에는 상태창이 없다.\n8. 주인공은 무적이 아니다. 강한 가호자 여럿을 정면으로 이기지 못하며, 꾀와 동료와 가호의 조합으로 싸운다.",
    "aiFillConstraints": ""
  },
  "player": {
    "id": "siwoo",
    "name": "강시우",
    "role": "주인공",
    "age": "",
    "gender": "",
    "origin": "",
    "status": "",
    "occupation": "",
    "affiliation": "",
    "appearance": "열아홉 살 한국인 남자. 키 172cm, 마른 체형에 구부정한 자세. 덥수룩한 검은 머리, 잠이 부족한 눈 밑 그늘, 의외로 날카로운 눈매. 남색 교복 바지와 흰 셔츠, 넥타이 위에 검은 롱패딩, 낡은 운동화, 형광펜 자국이 묻은 손가락. 가호를 쓸 때 눈동자에 그 가호의 빛깔이 잠깐 비친다.",
    "personality": "",
    "values": "",
    "speechStyle": "",
    "skills": "",
    "weaknesses": "",
    "goals": "",
    "assets": "",
    "inventory": "",
    "relationships": "",
    "publicInfo": "열아홉 살 재수생. 작년 수능을 망치고 올해도 모의고사 등급이 제자리라 새벽까지 독서실에 붙어 살던 중이었다. 체력은 평균 이하, 싸움은 해 본 적 없고 겁도 많다. 대신 입이 살아 있고 잔머리와 관찰력이 좋으며, 게임과 웹소설을 많이 읽어 '이세계'나 '스킬 조합' 감각이 빠르다. 남이 억울한 꼴을 보면 앞뒤 안 가리고 끼어들었다가 후회하는 타입. 속으로 딴죽을 끊임없이 건다.\n가진 것: 수험생 백팩(문제집, 샤프, 형광펜 세 자루), 배터리 41%의 스마트폰(손전등, 카메라), 교복 위 롱패딩.\n이 세계에서 그는 가호가 없는 빈손이다. 단 하나, 처음에는 그 자신도 모르는 힘이 있다. 쓰러뜨린 상대의 가호를 손을 뻗어 가져올 수 있다.",
    "hiddenInfo": "주인공을 부른 것은 리네가 그린 분필 동그라미다(「놓은 것이 가는 곳」에서 공개). 그의 영혼에는 이 세계 사람처럼 자리가 하나만 있는 것이 아니라 넓힐 수 있는 그릇이 있다. 300년 전 빈손의 왕과 같은 체질이다. 독서실에서 들린 \"누구라도 좋아. 제발. 빼앗을 수 있는 사람을\"은 리네의 기도였다. 그는 조선 시대 동전 '상평통보'를 교과서 사진으로 본 적이 있다.",
    "importance": "protagonist",
    "imageOnFirstAppearance": true,
    "visualLock": true,
    "visualAnchor": "열아홉 살 한국인 남자. 키 172cm, 마른 체형에 구부정한 자세. 덥수룩한 검은 머리, 잠이 부족한 눈 밑 그늘, 의외로 날카로운 눈매. 남색 교복 바지와 흰 셔츠, 넥타이 위에 검은 롱패딩, 낡은 운동화, 형광펜 자국이 묻은 손가락. 가호를 쓸 때 눈동자에 그 가호의 빛깔이 잠깐 비친다.",
    "imageFallback": "generate_anime",
    "images": [
      {
        "id": "IMG_siwoo",
        "fileName": "siwoo.webp",
        "mimeType": "image/webp",
        "label": "강시우",
        "isPrimary": true,
        "addedAt": "2026-10-07T00:00:00.000Z",
        "byteLength": 157310,
        "sha256": "6919e7905149198f153ea90873ad68f8054e197fedc51115f5c76293ea9512fa",
        "imageOptimization": {
          "profile": "screen_v1",
          "width": 1088,
          "height": 608,
          "originalBytes": 157310
        },
        "assetPath": "assets/characters/siwoo/01_siwoo.webp",
        "assetRef": "sha256:6919e7905149198f153ea90873ad68f8054e197fedc51115f5c76293ea9512fa",
        "dataUrlHeader": "data:image/webp;base64"
      }
    ],
    "isPlayer": true,
    "preRevealAlias": ""
  },
  "publicNpcs": [
    {
      "id": "rine",
      "name": "리네",
      "role": "주요 히로인",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "열일곱 살 소녀. 키 158cm. 햇볕에 바랜 갈색 머리를 높이 하나로 묶었고, 코 위에 주근깨, 밝은 초록 눈. 걷어 올린 소매에 물 빠진 앞치마, 맨팔에는 빨래하다 생긴 붉은 자국. 손가락 마디가 거칠다. 허리춤에 빨래 방망이.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "열일곱 살. 잿골목의 세탁부이자 빈손. 남동생 티오와 단둘이 세탁장 다락에 산다. 씩씩하고 잔소리가 많으며 웃음소리가 골목 끝까지 들린다. 무기는 빨래 방망이, 특기는 큰 목소리와 깡과 골목 지리. 남을 위해 먼저 뛰어들고, 울 때는 아무도 없는 지붕 위에서 몰래 운다. 반말에 \"바보야!\"가 입버릇. 구해 주기만 기다리는 사람이 아니라 주인공의 허세에 바로 딴죽을 거는 공동 주역이다. 빨래하면서 늘 엄마가 불러 주던 노래를 흥얼거린다. 엄마 마르타는 7년 전 이단으로 끌려가 처형됐고, 언니 셀레네는 그보다 먼저 성좌교에 '성녀 후보'로 데려가졌다. 꿈은 티오가 다음 달 별의 의식에서 가호를 받는 것이라, 몇 달째 의식 헌금을 모으고 있다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "열일곱 살 소녀. 키 158cm. 햇볕에 바랜 갈색 머리를 높이 하나로 묶었고, 코 위에 주근깨, 밝은 초록 눈. 걷어 올린 소매에 물 빠진 앞치마, 맨팔에는 빨래하다 생긴 붉은 자국. 손가락 마디가 거칠다. 허리춤에 빨래 방망이.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_rine",
          "fileName": "rine.webp",
          "mimeType": "image/webp",
          "label": "리네",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 147424,
          "sha256": "33368e406d500f21a10ab90a316526e905ee34f61ee4a9998de1159be7ebd593",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 147424
          },
          "assetPath": "assets/characters/rine/01_rine.webp",
          "assetRef": "sha256:33368e406d500f21a10ab90a316526e905ee34f61ee4a9998de1159be7ebd593",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "estelle",
      "name": "에스텔",
      "role": "메인 히로인",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "열일곱 살 소녀. 키 160cm. 윤기 흐르는 흑갈색 생머리를 허리까지 늘어뜨렸고, 머리 한쪽을 검은 리본으로 묶어 금빛 별 장식 핀을 꽂았다. 별 모양 금 귀걸이. 따뜻한 갈색 눈, 〈별읽기〉를 쓰면 눈동자에 금빛 별무늬가 떠오른다. 흰 프릴 블라우스와 넓은 소매, 남색 리본 타이 위에 금실 별자리를 수놓은 검은 망토. 몰래 나올 때는 낡은 회색 두건을 깊이 눌러쓴다. (리네의 햇볕에 바랜 밝은 갈색 포니테일과 초록 눈과 달리, 짙은 흑갈색 긴 생머리와 검은 리본·별 핀, 검은 망토로 구분한다.)",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "열일곱 살. 아스트레아 공작가의 영애이자 별의 의식에서 아이들의 가슴속 빛을 읽어 가호를 선포하는 '별읽기 무녀'. 가호 〈별읽기〉로 사람의 가호를 가슴속 등불로, 빈자리를 어두운 홈으로 본다. 조용하고 정중한 경어를 쓰지만, 궁금한 것 앞에서는 놀랄 만큼 직설적이다(\"당신 안에는 자리가 셋 있네요. 왜죠?\"). 세상 물정은 모른다. 빵값을 금화로 내려 하고, 골목의 고양이를 처음 만져 본다. 사람의 속을 다 보는 눈 때문에 누구와도 가까워지지 못했고, 그래서 밤마다 저택 천문대에서 별만 본다. 별 이야기를 시작하면 멈추지 않는다. 몰래 두건을 쓰고 아랫동네로 내려오는 버릇이 있다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "열일곱 살 소녀. 키 160cm. 윤기 흐르는 흑갈색 생머리를 허리까지 늘어뜨렸고, 머리 한쪽을 검은 리본으로 묶어 금빛 별 장식 핀을 꽂았다. 별 모양 금 귀걸이. 따뜻한 갈색 눈, 〈별읽기〉를 쓰면 눈동자에 금빛 별무늬가 떠오른다. 흰 프릴 블라우스와 넓은 소매, 남색 리본 타이 위에 금실 별자리를 수놓은 검은 망토. 몰래 나올 때는 낡은 회색 두건을 깊이 눌러쓴다. (리네의 햇볕에 바랜 밝은 갈색 포니테일과 초록 눈과 달리, 짙은 흑갈색 긴 생머리와 검은 리본·별 핀, 검은 망토로 구분한다.)",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_estelle",
          "fileName": "estelle.webp",
          "mimeType": "image/webp",
          "label": "에스텔",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 98264,
          "sha256": "ee904c8cbb1fa40ce63453d02e7a7adc126023901db1c734316f98dfb6cee78e",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 98264
          },
          "assetPath": "assets/characters/estelle/01_estelle.webp",
          "assetRef": "sha256:ee904c8cbb1fa40ce63453d02e7a7adc126023901db1c734316f98dfb6cee78e",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "tio",
      "name": "티오",
      "role": "리네의 남동생",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "아홉 살 소년. 누나를 닮은 갈색 곱슬머리, 빠진 앞니, 무릎이 해진 반바지, 나무 막대기 검.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "아홉 살, 곧 열 살. 리네의 남동생. 기사를 동경하는 장난꾸러기로 나무 막대기 검을 들고 다닌다. 주인공을 \"형!\"이라 부르며 졸졸 따라다니고, 비밀을 지키는 데는 소질이 없다. 다음 달 별의 의식에서 가호를 받는 것이 소원.",
      "importance": "supporting",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "아홉 살 소년. 누나를 닮은 갈색 곱슬머리, 빠진 앞니, 무릎이 해진 반바지, 나무 막대기 검.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_tio",
          "fileName": "tio.webp",
          "mimeType": "image/webp",
          "label": "티오",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 154782,
          "sha256": "6bacfb7bdc8df18c1a470f0d937d62a8a291c3b26e187663be442a25f1030754",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 154782
          },
          "assetPath": "assets/characters/tio/01_tio.webp",
          "assetRef": "sha256:6bacfb7bdc8df18c1a470f0d937d62a8a291c3b26e187663be442a25f1030754",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "selene",
      "name": "셀레네",
      "role": "성녀",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "스무 살 여성. 키 165cm. 원래 갈색이던 머리가 바랜 듯 은백색으로 길게 흘러내린다. 회색 눈, 창백한 피부. 흰 성녀복과 얇은 베일. 세탁부처럼 손가락 마디가 갈라져 있다. 빈 가면일 때는 얼굴 전체를 가리는 매끈한 하얀 가면과 검은 코트.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "스무 살. 성좌교의 성녀. 기적의 상징으로 세 개의 가호를 지녔다고 알려져 있다. 감정이 드러나지 않는 정중한 존댓말, 거의 웃지 않는 얼굴. 의식과 축복식에만 모습을 드러낸다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "스무 살 여성. 키 165cm. 원래 갈색이던 머리가 바랜 듯 은백색으로 길게 흘러내린다. 회색 눈, 창백한 피부. 흰 성녀복과 얇은 베일. 세탁부처럼 손가락 마디가 갈라져 있다. 빈 가면일 때는 얼굴 전체를 가리는 매끈한 하얀 가면과 검은 코트.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_selene",
          "fileName": "selene.webp",
          "mimeType": "image/webp",
          "label": "셀레네",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 140410,
          "sha256": "3c32d305e4d13b5452dbeee1cf2e3afcb45739840867fb97c3aa1213bd65ca57",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 140410
          },
          "assetPath": "assets/characters/selene/01_selene.webp",
          "assetRef": "sha256:3c32d305e4d13b5452dbeee1cf2e3afcb45739840867fb97c3aa1213bd65ca57",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "isolde",
      "name": "이졸데",
      "role": "금 등급 마법검사",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "열여덟 살 소녀. 키 163cm. 진홍빛 긴 머리를 리본으로 높이 묶었고 날카로운 호박색 눈. 금장식이 달린 하얀 기사복 위에 은빛 어깨 갑옷과 붉은 망토, 가느다란 장검. 가호를 쓰면 머리 위에 불꽃 고리가 떠오른다.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "열여덟 살. 아르젠 백작가의 영애이자 모험가 길드 최연소 '금 등급' 마법검사. 머리 위에 불꽃 고리가 떠오르며 검에 화염을 두르는 〈불꽃 왕관〉의 가호자. 콧대가 높고 \"~하시죠\", \"~이랍니다\" 하는 귀족 말투를 쓴다. 칭찬에 약하고 단것을 좋아하며 지는 것을 죽기보다 싫어한다. 실력과 승부욕은 진짜라, 예상 밖의 수를 보면 순간 즐거워하는 얼굴을 숨기지 못한다. 빈손을 대놓고 깔보지만 거짓말은 하지 않는다. 생활력은 0에 가깝다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "열여덟 살 소녀. 키 163cm. 진홍빛 긴 머리를 리본으로 높이 묶었고 날카로운 호박색 눈. 금장식이 달린 하얀 기사복 위에 은빛 어깨 갑옷과 붉은 망토, 가느다란 장검. 가호를 쓰면 머리 위에 불꽃 고리가 떠오른다.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_isolde",
          "fileName": "isolde.webp",
          "mimeType": "image/webp",
          "label": "이졸데",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 163506,
          "sha256": "8a233f8037578f8027a6af5e70159bad383a2be6429384aec28cca5f7437f4e5",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 163506
          },
          "assetPath": "assets/characters/isolde/01_isolde.webp",
          "assetRef": "sha256:8a233f8037578f8027a6af5e70159bad383a2be6429384aec28cca5f7437f4e5",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "nana",
      "name": "나나",
      "role": "정보상",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "열여섯 살 고양이 수인 소녀. 키 150cm. 검은 고양이 귀와 꼬리, 짧은 검은 단발, 커다란 금빛 눈. 헐렁한 회색 후드와 반바지, 맨발에 가까운 가죽 덧신. 목에 늑대 송곳니 목걸이.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "열여섯 살. 고양이 수인. 그림자 시장의 정보상이자 소매치기. 수인이라 태생 빈손이다. 장사꾼 반말에 \"그건 은화 세 닢짜리 정보야\", \"공짜는 없어\"가 입버릇. 돈만 밝히는 척하지만 한 번 맺은 거래는 목숨 걸고 지킨다. 지붕 위를 소리 없이 달리고, 기분이 좋으면 꼬리가 멋대로 흔들린다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "열여섯 살 고양이 수인 소녀. 키 150cm. 검은 고양이 귀와 꼬리, 짧은 검은 단발, 커다란 금빛 눈. 헐렁한 회색 후드와 반바지, 맨발에 가까운 가죽 덧신. 목에 늑대 송곳니 목걸이.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_nana",
          "fileName": "nana.webp",
          "mimeType": "image/webp",
          "label": "나나",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 158752,
          "sha256": "ca84e6ebb0319378541bb1345ac5f7f8fe0b849c3d4e1c01ffd05f9d3c3f8ef4",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 158752
          },
          "assetPath": "assets/characters/nana/01_nana.webp",
          "assetRef": "sha256:ca84e6ebb0319378541bb1345ac5f7f8fe0b849c3d4e1c01ffd05f9d3c3f8ef4",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "yuri",
      "name": "유리",
      "role": "견습 의사",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "열네 살 소녀. 키 147cm. 연한 하늘색 머리를 두 갈래로 땋았고, 얼굴의 반을 덮는 큰 동그란 안경. 할아버지의 낡은 흰 가운을 소매를 접어 입었다. 약초 냄새가 난다.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "열네 살. 잿골목 의사 오스의 손녀이자 견습 의사. 수줍음이 많아 말끝을 흐리지만, 환자 앞에서는 어른도 꼼짝 못 하게 단호해지는 '의사 모드'가 있다. 약초와 붕대를 늘 들고 다니며 \"아, 안 돼요! 그 상처 만지지 마세요!\"가 입버릇. 빈손이다.",
      "importance": "supporting",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "열네 살 소녀. 키 147cm. 연한 하늘색 머리를 두 갈래로 땋았고, 얼굴의 반을 덮는 큰 동그란 안경. 할아버지의 낡은 흰 가운을 소매를 접어 입었다. 약초 냄새가 난다.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_yuri",
          "fileName": "yuri.webp",
          "mimeType": "image/webp",
          "label": "유리",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 140814,
          "sha256": "e32d1db0c821b6fd6e9b36cf886ca1142806eba5e2aec08e103a8f5af25a550d",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 140814
          },
          "assetPath": "assets/characters/yuri/01_yuri.webp",
          "assetRef": "sha256:e32d1db0c821b6fd6e9b36cf886ca1142806eba5e2aec08e103a8f5af25a550d",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "sylphie",
      "name": "실피",
      "role": "엘프 점쟁이",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "열두 살쯤으로 보이는 엘프 소녀. 키 138cm. 바닥에 끌릴 듯한 은빛 긴 머리, 길고 뾰족한 귀, 보랏빛 눈. 몸보다 큰 챙 넓은 마법사 모자와 별무늬 망토. 입에 계피 막대.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "겉보기엔 열두 살, 실제로는 삼백 살이 넘은 엘프. 잿골목 지붕 위 천막에서 점을 봐 준다. 할머니 말투(\"~하구먼\", \"젊은 것이\")에 장난기가 많고 늘 계피 막대를 씹는다. 다 아는 척 놀리지만 중요한 것은 좀처럼 말해 주지 않는다. 엘프라 가호가 없다. 모자 끈에 구멍 뚫린 낡은 동전 하나를 달고 다닌다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "열두 살쯤으로 보이는 엘프 소녀. 키 138cm. 바닥에 끌릴 듯한 은빛 긴 머리, 길고 뾰족한 귀, 보랏빛 눈. 몸보다 큰 챙 넓은 마법사 모자와 별무늬 망토. 입에 계피 막대.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_sylphie",
          "fileName": "sylphie.webp",
          "mimeType": "image/webp",
          "label": "실피",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 166986,
          "sha256": "55c534f603653ec0c422702a810e2c103ca6fa3b84dfdb822cc8e96124a75d76",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 166986
          },
          "assetPath": "assets/characters/sylphie/01_sylphie.webp",
          "assetRef": "sha256:55c534f603653ec0c422702a810e2c103ca6fa3b84dfdb822cc8e96124a75d76",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "kyle",
      "name": "카일",
      "role": "견습 기사",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "열여덟 살 청년. 키 180cm. 금갈색 곱슬머리, 맑은 하늘색 눈, 늘 웃는 얼굴. 은색 흉갑과 푸른 견습 기사 망토, 손질이 잘된 장검.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "열여덟 살. 반스 남작가의 막내이자 성좌 기사단의 견습 기사. 눈을 마주친 상대를 한 호흡 동안 멈추게 하는 〈굳힘〉의 가호자. 해맑고 시원시원하며 정의감이 넘친다. 빈손이라고 사람을 깔보는 걸 못 참는 몇 안 되는 귀족. 처음엔 존댓말, 친해지면 반말로 \"시우!\" 하고 부른다. 성좌교를 진심으로 믿는다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "열여덟 살 청년. 키 180cm. 금갈색 곱슬머리, 맑은 하늘색 눈, 늘 웃는 얼굴. 은색 흉갑과 푸른 견습 기사 망토, 손질이 잘된 장검.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_kyle",
          "fileName": "kyle.webp",
          "mimeType": "image/webp",
          "label": "카일",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 174266,
          "sha256": "7b55c76431815acb735856163b6e7185fcb078e5cddf3044fefda9dce5c18a0b",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 174266
          },
          "assetPath": "assets/characters/kyle/01_kyle.webp",
          "assetRef": "sha256:7b55c76431815acb735856163b6e7185fcb078e5cddf3044fefda9dce5c18a0b",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "leon",
      "name": "레온",
      "role": "은 등급 궁수",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "스물일곱 살 남자. 키 183cm. 아무렇게나 묶은 짙은 갈색 꽁지머리, 졸린 듯한 녹색 눈, 턱의 수염 자국. 낡은 가죽 갑옷과 갈색 망토, 커다란 장궁과 화살통, 입에 문 파이프.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "스물일곱 살. 모험가 길드 '은 등급' 궁수. 늘 파이프를 물고 다니는 능글맞은 한량으로, 신입을 놀리는 게 취미다. 그러나 활 솜씨는 길드 최고 수준이고 위기에서는 누구보다 침착하다. \"가호는 손에 쥔 패일 뿐이야. 판을 읽어.\"가 입버릇. 이상하게도 아무도 그가 가호를 쓰는 걸 본 적이 없고, 길드의 가호 검사 날만 되면 사라진다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "스물일곱 살 남자. 키 183cm. 아무렇게나 묶은 짙은 갈색 꽁지머리, 졸린 듯한 녹색 눈, 턱의 수염 자국. 낡은 가죽 갑옷과 갈색 망토, 커다란 장궁과 화살통, 입에 문 파이프.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_leon",
          "fileName": "leon.webp",
          "mimeType": "image/webp",
          "label": "레온",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 149772,
          "sha256": "668cb02951fce0a4429bbadc7384cb4713434473004b005aec8ae58fc3d01de6",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 149772
          },
          "assetPath": "assets/characters/leon/01_leon.webp",
          "assetRef": "sha256:668cb02951fce0a4429bbadc7384cb4713434473004b005aec8ae58fc3d01de6",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "brokk",
      "name": "브로크",
      "role": "잿골목 깡패 두목",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "서른두 살 거구의 남자. 키 192cm. 빡빡 민 머리와 덥수룩한 수염, 문신이 새겨진 털 많은 팔뚝. 대장간 앞치마 같은 가죽 조끼, 어깨에 걸친 커다란 쇠망치. 〈철피〉를 쓰면 피부가 쇳빛으로 변한다.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "서른두 살. '곰발 브로크'. 잿골목의 깡패 두목으로 가게마다 자릿세를 뜯는다. 피부를 쇳덩이처럼 단단하게 만드는 〈철피〉의 가호자. 덩치가 산만 하고 목소리가 크며, 가호 하나로 빈손들 위에 군림해 왔다. 원래 대장간 망치를 무기로 쓴다.",
      "importance": "supporting",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "서른두 살 거구의 남자. 키 192cm. 빡빡 민 머리와 덥수룩한 수염, 문신이 새겨진 털 많은 팔뚝. 대장간 앞치마 같은 가죽 조끼, 어깨에 걸친 커다란 쇠망치. 〈철피〉를 쓰면 피부가 쇳빛으로 변한다.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_brokk",
          "fileName": "brokk.webp",
          "mimeType": "image/webp",
          "label": "브로크",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 106302,
          "sha256": "357e386225bf20b21e438a0f1a52bbea715e30a81dbcf4170bb932d87d12275b",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 106302
          },
          "assetPath": "assets/characters/brokk/01_brokk.webp",
          "assetRef": "sha256:357e386225bf20b21e438a0f1a52bbea715e30a81dbcf4170bb932d87d12275b",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "oss",
      "name": "오스",
      "role": "잿골목 의사",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "예순한 살 노인. 작고 마른 체구, 하얗게 센 머리와 짧은 수염, 코끝에 걸친 작은 안경. 얼룩진 흰 가운과 약초 다발.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "예순한 살. 잿골목의 의사. 상처를 손으로 쓸어 닫는 〈치유의 손〉의 가호자. 가호자인데도 상층 구역의 좋은 자리를 마다하고 빈손들을 공짜로 고쳐 준다. 느릿한 말투에 농담을 좋아하며 손녀 유리를 끔찍이 아낀다. 요즘 손이 자주 떨린다.",
      "importance": "supporting",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "예순한 살 노인. 작고 마른 체구, 하얗게 센 머리와 짧은 수염, 코끝에 걸친 작은 안경. 얼룩진 흰 가운과 약초 다발.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_oss",
          "fileName": "oss.webp",
          "mimeType": "image/webp",
          "label": "오스",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 156480,
          "sha256": "32594ff4ac9ee32c8862ebe2a67a490c8df984ce5e3a0671ed94f1270b8888f0",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 156480
          },
          "assetPath": "assets/characters/oss/01_oss.webp",
          "assetRef": "sha256:32594ff4ac9ee32c8862ebe2a67a490c8df984ce5e3a0671ed94f1270b8888f0",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "gregor",
      "name": "그레고르",
      "role": "대주교",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "예순여섯 살 노인. 키가 크고 꼿꼿하다. 단정히 빗어 넘긴 백발과 흰 수염, 깊은 주름, 차분한 회색 눈. 별자리가 금실로 수놓인 남색 대주교 예복, 별 모양 홀.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "예순여섯 살. 성좌교 대주교. 별의 대성당과 별의 우물, 별의 의식을 관장하는 왕국 최고 권력자. 온화한 목소리로 \"가호는 질서입니다\"라고 설교한다. 신도들 앞에서는 자애로운 노인이다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "예순여섯 살 노인. 키가 크고 꼿꼿하다. 단정히 빗어 넘긴 백발과 흰 수염, 깊은 주름, 차분한 회색 눈. 별자리가 금실로 수놓인 남색 대주교 예복, 별 모양 홀.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_gregor",
          "fileName": "gregor.webp",
          "mimeType": "image/webp",
          "label": "그레고르",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 179688,
          "sha256": "023a20635750ef9e1c32f1a13bf933b878d8fd3a755d926a94a30307f757952c",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 179688
          },
          "assetPath": "assets/characters/gregor/01_gregor.webp",
          "assetRef": "sha256:023a20635750ef9e1c32f1a13bf933b878d8fd3a755d926a94a30307f757952c",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "dorothy",
      "name": "도로시",
      "role": "길드 접수원",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "스물네 살 여성. 키 166cm. 부드러운 밤색 웨이브 머리, 동그란 안경, 늘 웃는 입가. 길드 제복(흰 블라우스, 남색 조끼)과 귀에 꽂은 깃펜.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "스물네 살. 모험가 길드의 접수원. 상냥한 누님으로 \"모험가님\"이라 부르며 신입 하나하나를 살뜰히 챙긴다. 빈손이라고 차별하지 않는 몇 안 되는 길드 사람. 의뢰서와 장부를 놀랍도록 꼼꼼히 기억하고, 단골에게는 서랍 속 과자를 몰래 쥐여 준다. 상층 치료원에 입원한 여동생 엘라 이야기를 할 때 가장 환하게 웃는다.",
      "importance": "supporting",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "스물네 살 여성. 키 166cm. 부드러운 밤색 웨이브 머리, 동그란 안경, 늘 웃는 입가. 길드 제복(흰 블라우스, 남색 조끼)과 귀에 꽂은 깃펜.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_dorothy",
          "fileName": "dorothy.webp",
          "mimeType": "image/webp",
          "label": "도로시",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 89612,
          "sha256": "6809545ed57d3de956ced52a36375f0cef14c5e530bb3f7fc624689337c8dd2e",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 89612
          },
          "assetPath": "assets/characters/dorothy/01_dorothy.webp",
          "assetRef": "sha256:6809545ed57d3de956ced52a36375f0cef14c5e530bb3f7fc624689337c8dd2e",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "rosalind",
      "name": "로잘린",
      "role": "이단심문관",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "스물일곱 살 여성. 키 170cm. 칠흑 같은 긴 생머리, 가늘게 휘어진 눈, 붉은 입술. 흰 두건이 달린 검은 수녀복과 은 별 목걸이, 허리에 감은 가는 사슬 채찍.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "스물일곱 살. 성좌교의 이단심문관 수녀이자 대주교의 오른팔. 나긋나긋한 존댓말과 늘 걸린 미소가 오히려 섬뜩하다. 거짓말을 냄새로 맡는 〈거짓말 냄새〉의 가호자로, 심문에서 그녀를 속인 사람은 없다고 한다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "스물일곱 살 여성. 키 170cm. 칠흑 같은 긴 생머리, 가늘게 휘어진 눈, 붉은 입술. 흰 두건이 달린 검은 수녀복과 은 별 목걸이, 허리에 감은 가는 사슬 채찍.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_rosalind",
          "fileName": "rosalind.webp",
          "mimeType": "image/webp",
          "label": "로잘린",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 130654,
          "sha256": "38617dc66acb70947aef7241441e996aeaa2ae01b71675a2b08495a254a02626",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 130654
          },
          "assetPath": "assets/characters/rosalind/01_rosalind.webp",
          "assetRef": "sha256:38617dc66acb70947aef7241441e996aeaa2ae01b71675a2b08495a254a02626",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "pippin",
      "name": "피핀",
      "role": "음유시인",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "스무 살 청년. 키 168cm. 여기저기 뻗친 주황색 머리, 주근깨, 장난스러운 갈색 눈. 깃털 꽂은 갈색 베레모, 알록달록 기운 망토, 등에 멘 낡은 류트.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "스무 살. 떠돌이 음유시인이자 자칭 '강시우 전기 작가'. 류트를 끼고 다니며 본 것을 열 배로 부풀려 노래한다. 수다쟁이에 겁쟁이지만 이야기를 위해서라면 어디든 따라온다. \"이건 대박이다! 제목은 「빈손의 전설」!\" 늘 뭔가를 수첩에 적어 어딘가로 편지를 보낸다.",
      "importance": "supporting",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "스무 살 청년. 키 168cm. 여기저기 뻗친 주황색 머리, 주근깨, 장난스러운 갈색 눈. 깃털 꽂은 갈색 베레모, 알록달록 기운 망토, 등에 멘 낡은 류트.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_pippin",
          "fileName": "pippin.webp",
          "mimeType": "image/webp",
          "label": "피핀",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 166394,
          "sha256": "733b6f7a565f243531df901c188670d9c344034337e732317b7c297e1f4e9e7d",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 166394
          },
          "assetPath": "assets/characters/pippin/01_pippin.webp",
          "assetRef": "sha256:733b6f7a565f243531df901c188670d9c344034337e732317b7c297e1f4e9e7d",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "lennox",
      "name": "레녹스",
      "role": "제2왕자",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "스물두 살 청년. 키 181cm. 어깨까지 오는 칠흑 같은 머리, 나른한 붉은 눈, 흰 피부. 가슴을 풀어헤친 검은 비단 셔츠에 보석 반지들, 손에는 와인 잔.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "스물두 살. 에르딘 왕국의 제2왕자. 투기장과 술자리를 전전하는 방탕한 한량으로 유명하다. 느긋한 반말에 \"재밌는 장난감이 왔군\"이 입버릇. 늘 와인 잔을 들고 있다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "스물두 살 청년. 키 181cm. 어깨까지 오는 칠흑 같은 머리, 나른한 붉은 눈, 흰 피부. 가슴을 풀어헤친 검은 비단 셔츠에 보석 반지들, 손에는 와인 잔.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_lennox",
          "fileName": "lennox.webp",
          "mimeType": "image/webp",
          "label": "레녹스",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 85090,
          "sha256": "4e235e0cfc92910391e0262b18b1f715202f846955166389317e6034509c5aba",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 85090
          },
          "assetPath": "assets/characters/lennox/01_lennox.webp",
          "assetRef": "sha256:4e235e0cfc92910391e0262b18b1f715202f846955166389317e6034509c5aba",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "gratz",
      "name": "그라츠",
      "role": "투기장 챔피언",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "스물여덟 살 늑대 수인 남자. 키 205cm. 잿빛 늑대 귀와 꼬리, 흉터투성이 근육질 몸, 짧은 회색 머리, 노란 눈. 목과 손목에 쇠사슬, 허리에 감은 투기장 천.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "스물여덟 살. 늑대 수인. 투기장의 노예 챔피언으로 삼 년째 무패. 수인이라 가호가 없지만 가호자들을 맨손으로 꺾어 왔다. 말수가 극히 적어 \"…….\", \"흥.\"이 대화의 절반. 동생 이야기만 나오면 귀가 쫑긋한다.",
      "importance": "supporting",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "스물여덟 살 늑대 수인 남자. 키 205cm. 잿빛 늑대 귀와 꼬리, 흉터투성이 근육질 몸, 짧은 회색 머리, 노란 눈. 목과 손목에 쇠사슬, 허리에 감은 투기장 천.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_gratz",
          "fileName": "gratz.webp",
          "mimeType": "image/webp",
          "label": "그라츠",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 119356,
          "sha256": "ade08de1ca317909542fbbdc2d7f4b28f362e9dec8c1d847cdf7649e68469d7b",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 119356
          },
          "assetPath": "assets/characters/gratz/01_gratz.webp",
          "assetRef": "sha256:ade08de1ca317909542fbbdc2d7f4b28f362e9dec8c1d847cdf7649e68469d7b",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "garrick",
      "name": "가릭",
      "role": "빈손 사냥꾼 모험가",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "스물아홉 살 남자. 마른 체격, 기름진 금발을 뒤로 묶었고, 쥐처럼 작은 눈. 낡은 가죽 외투 안에 열쇠 꾸러미와 단검.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "스물아홉 살. 동 등급 모험가. 빈손 신입이 잡은 전리품을 털어먹는 하이에나로 악명 높다. 손댄 자물쇠를 여는 〈자물쇠 손〉의 가호자. 비굴하게 웃다가 뒤에서 찌르는 타입. \"빈손이 그런 걸 가져서 뭐 하게?\"",
      "importance": "minor",
      "imageOnFirstAppearance": false,
      "visualLock": true,
      "visualAnchor": "스물아홉 살 남자. 마른 체격, 기름진 금발을 뒤로 묶었고, 쥐처럼 작은 눈. 낡은 가죽 외투 안에 열쇠 꾸러미와 단검.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "bern",
      "name": "베른",
      "role": "투기장 귀족 검투사",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "스물네 살 남자. 키 185cm. 짧게 친 은회색 머리, 비웃는 입꼬리, 화려한 금장 검투사 갑옷. 팔뚝에서 상아색 뼈 칼날이 돋는다.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "스물네 살. '칼날 베른'. 귀족가가 후원하는 투기장 검투사로 팔뚝에서 뼈 칼날을 돋우는 〈뼈 칼날〉의 가호자. 오만하고 잔인하며 수인을 '개'라 부른다. 관중을 위해 상대를 천천히 베는 것을 즐긴다.",
      "importance": "minor",
      "imageOnFirstAppearance": false,
      "visualLock": true,
      "visualAnchor": "스물네 살 남자. 키 185cm. 짧게 친 은회색 머리, 비웃는 입꼬리, 화려한 금장 검투사 갑옷. 팔뚝에서 상아색 뼈 칼날이 돋는다.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "ella",
      "name": "엘라",
      "role": "도로시의 여동생",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "열두 살 소녀. 언니를 닮은 밤색 머리를 땋아 내렸고, 창백하지만 잘 웃는 얼굴. 하얀 환자복과 무릎 위의 그림판.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "열두 살. 도로시의 여동생. 폐가 약해 상층 구역 치료원에 오래 입원해 있다. 병실 창가에서 지나가는 새를 그리는 게 취미이고, 언니가 들려주는 모험가 이야기를 제일 좋아한다. 빈손이다.",
      "importance": "minor",
      "imageOnFirstAppearance": false,
      "visualLock": true,
      "visualAnchor": "열두 살 소녀. 언니를 닮은 밤색 머리를 땋아 내렸고, 창백하지만 잘 웃는 얼굴. 하얀 환자복과 무릎 위의 그림판.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "hanbaek",
      "name": "빈손의 왕",
      "role": "전설의 폭군",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "전설 속 모습은 얼굴 없는 검은 그림자. 실제로는 스물몇 살의 조선 청년으로, 풀어 헤친 긴 머리에 흰 도포, 맑고 고집스러운 눈.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "300년 전 남의 가호를 빼앗아 왕이 되려 했다는 전설의 폭군. 성좌교의 일곱 성인에게 쓰러졌다고 경전에 적혀 있다. 아이들은 \"빈손의 왕이 잡아간다\"는 말로 겁을 준다.",
      "importance": "minor",
      "imageOnFirstAppearance": false,
      "visualLock": true,
      "visualAnchor": "전설 속 모습은 얼굴 없는 검은 그림자. 실제로는 스물몇 살의 조선 청년으로, 풀어 헤친 긴 머리에 흰 도포, 맑고 고집스러운 눈.",
      "imageFallback": "generate_anime",
      "images": [
        {
          "id": "IMG_hanbaek",
          "fileName": "hanbaek.webp",
          "mimeType": "image/webp",
          "label": "빈손의 왕",
          "isPrimary": true,
          "addedAt": "2026-10-07T00:00:00.000Z",
          "byteLength": 134870,
          "sha256": "78af62c9a93c0a55293bb95a3023a586cd079406c83570e1078c590ad4fb710c",
          "imageOptimization": {
            "profile": "screen_v1",
            "width": 1088,
            "height": 608,
            "originalBytes": 134870
          },
          "assetPath": "assets/characters/hanbaek/01_hanbaek.webp",
          "assetRef": "sha256:78af62c9a93c0a55293bb95a3023a586cd079406c83570e1078c590ad4fb710c",
          "dataUrlHeader": "data:image/webp;base64"
        }
      ],
      "isPlayer": false,
      "preRevealAlias": ""
    }
  ],
  "publicFactions": [
    {
      "id": "church",
      "name": "성좌교",
      "publicInfo": "별의 대성당, 별의 우물, 별의 의식을 관장하는 국교. 대주교 그레고르, 이단심문관 로잘린, 성좌 기사단을 거느린다. 성녀 셀레네를 기적의 상징으로 내세우며 \"가호는 질서\"라고 가르친다.",
      "hiddenInfo": "대주교의 장부, 가호 배정과 별읽기 무녀의 낭독 목록(배정을 별의 뜻으로 꾸미는 무대), 이단 처형과 회수, 약한 가호의 폐기(마수와 누더기 왕의 기원), 성녀 실험, 빈 가면. 길드 접수원 도로시 같은 정보원을 곳곳에 둔다.",
      "officialGoal": "별의 대성당, 별의 우물, 별의 의식을 관장하는 국교. 대주교 그레고르, 이단심문관 로잘린, 성좌 기사단을 거느린다. 성녀 셀레네를 기적의 상징으로 내세우며 \"가호는 질서\"라고 가르친다."
    },
    {
      "id": "alley",
      "name": "잿골목 사람들",
      "publicInfo": "왕도 바깥 고리 빈민가의 빈손들. 세탁, 하수구 청소, 짐꾼 일로 살며 서로를 돌본다. 곰발 브로크 일당에게 자릿세를 뜯긴다. 오스의 진료소가 유일한 의원이다.",
      "hiddenInfo": "많은 이가 처형된 마르타를 기억한다. 주인공이 빈손으로 만든 사람이 몇 명인지에 따라 그를 영웅으로도, 괴물로도 본다. 지하에는 무너진 옛 예배당이 있다.",
      "officialGoal": "왕도 바깥 고리 빈민가의 빈손들. 세탁, 하수구 청소, 짐꾼 일로 살며 서로를 돌본다. 곰발 브로크 일당에게 자릿세를 뜯긴다. 오스의 진료소가 유일한 의원이다."
    },
    {
      "id": "guild",
      "name": "모험가 길드",
      "publicInfo": "마수 토벌과 호위를 맡는 길드. 등급은 금·은·동·돌이며, 가호가 곧 등급이라 빈손은 돌 등급에서 시작한다. 접수원 도로시가 신입들을 챙긴다.",
      "hiddenInfo": "길드 상층부는 등록되지 않은 가호의 소문을 성좌교에 판다. 위조 증표로 빈손임을 숨긴 모험가가 몇 있다(레온).",
      "officialGoal": "마수 토벌과 호위를 맡는 길드. 등급은 금·은·동·돌이며, 가호가 곧 등급이라 빈손은 돌 등급에서 시작한다. 접수원 도로시가 신입들을 챙긴다."
    },
    {
      "id": "crown",
      "name": "왕실과 투기장",
      "publicInfo": "왕실은 성좌교의 그늘에 가려 이름만 남았다는 평을 듣는다. 제2왕자 레녹스는 투기장과 술자리를 전전하는 한량으로 유명하다. 투기장에서는 노예와 빈손이 가호자와 싸운다.",
      "hiddenInfo": "레녹스는 한량을 연기하며 성좌교를 무너뜨릴 기회를 노린다. 왕실 근위대 일부가 그를 따른다. 대주교는 손녀 에스텔과 레녹스의 정략 약혼으로 왕실을 묶어 두었다.",
      "officialGoal": "왕실은 성좌교의 그늘에 가려 이름만 남았다는 평을 듣는다. 제2왕자 레녹스는 투기장과 술자리를 전전하는 한량으로 유명하다. 투기장에서는 노예와 빈손이 가호자와 싸운다."
    },
    {
      "id": "shadow",
      "name": "그림자 시장",
      "publicInfo": "중층 구역 뒷골목의 밤 시장. 장물, 위조 증표, 가호에 얽힌 소문이 거래된다. 수인과 빈손이 많고, 정보상 나나가 단골을 거느린다.",
      "hiddenInfo": "성좌교 전령과 길드 정보원들도 몰래 드나든다. 「곰발의 원한」 경로에서는 브로크가 이곳에서 성좌교와 손잡는다.",
      "officialGoal": "중층 구역 뒷골목의 밤 시장. 장물, 위조 증표, 가호에 얽힌 소문이 거래된다. 수인과 빈손이 많고, 정보상 나나가 단골을 거느린다."
    }
  ],
  "publicCharacterRelations": [],
  "publicRelationshipMemories": [],
  "publicFactionRelations": [],
  "publicEvents": [],
  "publicEventClocks": [],
  "publicForeshadowings": [],
  "publicImageTriggers": [],
  "aiWorldContextRuntime": {
    "format": "RELAY_NOVEL_AI_WORLD_CONTEXT_RUNTIME_V1",
    "enabled": false,
    "liveEvaluation": true,
    "execution": {
      "mode": "inject_into_simulator_api_context",
      "evaluationMoments": [
        "sessionStart",
        "sceneTransition",
        "eventGeneration",
        "npcDecision",
        "everyTurn"
      ],
      "everyRequestInstruction": "각 API 응답을 만들기 전에 현재 장부와 아래 worldContext를 짧게 재대조한다.",
      "updateDepth": "balanced",
      "knowledgePolicy": "hybrid",
      "knowledgePolicySemantics": {
        "package_only": "패키지에 명시된 정보만 사용하고 외부 작품·역사 지식을 보완하지 않는다.",
        "model_knowledge": "모델이 알고 있는 참고 세계관과 지역·시대 지식을 적극 활용하되 정사 우선순위를 지킨다.",
        "hybrid": "패키지를 기준으로 삼고 모델 지식은 빈틈의 보강과 개연성 검토에만 사용한다."
      }
    },
    "worldContext": {
      "premise": "",
      "referenceFramework": "",
      "referenceUsage": "참고 세계관의 핵심 규칙·용어·세력 논리와 장르적 기대를 분석하되, 현재 패키지에 명시된 정사를 최우선으로 적용한다.",
      "localContext": "",
      "enrichmentPriorities": "지역의 역사·지리·기관·사회문화·일상생활, 인물 동기, 세력 이해관계, 사건의 개연성과 후폭풍",
      "protectedCanon": "",
      "avoidElements": "원작 사건의 그대로인 재연, 기존 캐릭터의 역할 복제, 근거 없는 설정 추가, 플레이어가 알지 못하는 스포일러의 조기 공개",
      "originalityRule": "참고 세계관의 작동 원리와 분위기는 활용하되, 현재 프로젝트의 인물·지역·사건은 독자적인 원인과 결과로 전개한다.",
      "spoilerRule": "진명·배후·비밀 세력·원작 지식은 현재 장면에서 플레이어가 관측하거나 추론할 근거가 생기기 전까지 공개하지 않는다."
    },
    "referenceCharacterResearch": {
      "enabled": false,
      "lookupMode": "simulator_web_search_tool",
      "characters": [],
      "researchScope": "공식 인물 설정, 성격과 핵심 가치관, 말투와 호칭, 능력과 한계, 주요 관계, 원작 시점별 목표와 알려진 사건",
      "sourcePriority": "공식 작품·공식 캐릭터 소개·공식 설정 자료를 우선하고, 신뢰할 수 있는 2차 정리 자료는 교차 확인에만 사용한다. 팬덤 해석은 사실과 분리한다.",
      "canonCutoff": "현재 시나리오 시작 시점까지 공개된 정보만 사용하며, 이후 전개의 중대 스포일러는 숨긴다.",
      "cacheMode": "session",
      "lookupTiming": {
        "sessionStart": true,
        "beforeFirstAppearance": true,
        "onCanonConflict": true,
        "everyTurn": false
      },
      "recordSourcesInLedger": true,
      "ledgerSchema": [
        "characterName",
        "franchiseAndTimeline",
        "sourceTitle",
        "sourceUrl",
        "checkedAt",
        "verifiedFacts",
        "conflicts",
        "adoptedInterpretation"
      ],
      "applyInstruction": "검증·캐시된 인물 프로필을 매 턴 해당 인물의 목표, 판단, 말투, 호칭, 능력 한계와 관계 반응에 반영한다. 검색 자체는 매 턴 반복하지 않는다."
    },
    "reasoningPipeline": [
      "현재 WORLD_CANON, 사건·시계, 관계 기억, NPC·세력 위치와 지식 장부를 먼저 읽는다.",
      "referenceFramework의 작동 규칙과 장르적 기대 중 현재 장면에 관련된 항목만 추린다.",
      "localContext를 적용해 장소·역사·기관·일상·사회 반응이 실제 배경에 맞는지 검토한다.",
      "후보 사건·NPC 판단·세계관 세부를 enrichmentPriorities에 맞게 보강한다.",
      "protectedCanon, avoidElements, originalityRule, spoilerRule을 통과한 내용만 현재 장면과 숨은 장부에 반영한다."
    ],
    "canonPriority": [
      "현재 패키지의 fixedCanon과 명시된 인물·사건",
      "현재 시뮬레이터 장부와 플레이어가 만든 확정 사실",
      "참고 작품·세계관의 일반 규칙",
      "모델 지식과 창작적 보완"
    ],
    "hardRules": [
      "참고 작품의 설정이 현재 패키지 정사와 충돌하면 현재 패키지를 따른다.",
      "모델 지식은 정사처럼 단정하지 않고, 현재 프로젝트와 모순되지 않는 보강 재료로만 사용한다.",
      "기존 작품의 사건·대사·캐릭터 역할을 그대로 복제하지 않고 현재 인물의 목표와 지역 맥락에서 새 원인과 결과를 만든다.",
      "플레이어가 알 수 없는 진명·배후·비밀 규칙은 spoilerRule과 공개 범위를 통과하기 전까지 서술하지 않는다.",
      "세계관 보강은 설정 설명문으로 한꺼번에 쏟지 말고 장면·행동·소문·기록·사건 결과를 통해 자연스럽게 드러낸다.",
      "새 설정이 이후 사건에 영향을 주면 HIDDEN_GM_DATA의 worldTruthLedger 또는 continuityNotes에 근거와 함께 기록한다.",
      "기존 작품 캐릭터 조사가 활성화되면 공식 자료를 우선하고 서로 다른 작품·시간대·동명이인·번역 표기를 구분한다.",
      "검색 도구를 실제로 호출할 수 없는 환경에서는 검색했다고 주장하거나 출처 URL을 꾸며내지 말고, 패키지 정보와 모델 지식만 사용했음을 장부에 표시한다.",
      "원작 인물 정보는 긴 원문을 복사하지 않고 성격·말투·목표·능력 한계·관계 사실을 간결하게 요약한다.",
      "원작 인물의 검색 결과와 현재 패키지의 각색 설정이 충돌하면 패키지 설정을 유지하고 차이를 referenceCharacterLedger에 기록한다."
    ],
    "routeContexts": {},
    "knowledgeScopes": {
      "playerMeta": "플레이어는 해금·회차·열람한 엔딩 같은 작품 메타 진행만 알 수 있다.",
      "protagonist": "주인공은 현재 세계선에서 직접 경험하거나 기억 전이 규칙으로 보존된 사실만 안다.",
      "npc": "NPC는 각자의 지식 장부와 관측 범위 안의 사실만 사용한다."
    }
  },
  "package15": {
    "enabled": true,
    "storyMode": "branching",
    "requiredFeatures": [
      "branch_ending_convergence_v1"
    ],
    "optionalFeatures": [],
    "defaultUnlockMode": "canonical_order",
    "allowAllOpenOverride": false,
    "commonArc": {
      "id": "COMMON",
      "name": "공통편",
      "chapterIds": [],
      "routeLensIds": []
    },
    "routes": [],
    "chapters": [],
    "routeLenses": [],
    "revealFacts": [],
    "revealPolicies": [],
    "endings": [
      {
        "id": "ending_main",
        "routeId": "",
        "name": "우물 밑의 목소리",
        "type": "normal",
        "priority": 0,
        "condition": {
          "completedEventIds": [
            "e70_voice"
          ]
        },
        "effects": [],
        "returnPolicy": "stay_ended",
        "terminalEventId": "e70_voice",
        "exclusiveGroupId": "jieum"
      }
    ],
    "flags": [
      {
        "id": "vessel",
        "label": "그릇",
        "valueType": "number",
        "defaultValue": 3,
        "scope": "session"
      },
      {
        "id": "held",
        "label": "가진 가호",
        "valueType": "number",
        "defaultValue": 0,
        "scope": "session"
      },
      {
        "id": "made_bin",
        "label": "빈손이 된 사람",
        "valueType": "number",
        "defaultValue": 0,
        "scope": "session"
      },
      {
        "id": "rine_trust",
        "label": "리네의 신뢰",
        "valueType": "number",
        "defaultValue": 2,
        "scope": "session"
      },
      {
        "id": "estelle_heart",
        "label": "에스텔의 마음",
        "valueType": "number",
        "defaultValue": 0,
        "scope": "session"
      },
      {
        "id": "wanted",
        "label": "수배",
        "valueType": "number",
        "defaultValue": 0,
        "scope": "session"
      },
      {
        "id": "allies",
        "label": "동료",
        "valueType": "number",
        "defaultValue": 1,
        "scope": "session"
      }
    ],
    "branchEnding": {
      "enabled": true,
      "primaryEndingGroupId": "jieum",
      "choiceRecords": [
        {
          "id": "ef_e01_empty_1",
          "name": "주인공이 리네나 티오를 감싸거나, 도움을 받은 뒤 진심으로 고마움을 표현했다.",
          "sourceEventId": "e01_empty",
          "criterion": "주인공이 리네나 티오를 감싸거나, 도움을 받은 뒤 진심으로 고마움을 표현했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e03_rat_1",
          "name": "주인공이 위험을 무릅쓰고 티오나 골목 아이들을 지켰다.",
          "sourceEventId": "e03_rat",
          "criterion": "주인공이 위험을 무릅쓰고 티오나 골목 아이들을 지켰다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e04_day_1",
          "name": "주인공이 리네의 일을 거들거나 티오와 놀아 주며 둘의 생활에 진심으로 끼어들었다.",
          "sourceEventId": "e04_day",
          "criterion": "주인공이 리네의 일을 거들거나 티오와 놀아 주며 둘의 생활에 진심으로 끼어들었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e04_day_2",
          "name": "주인공이 처음 만난 에스텔을 경계하면서도 진실하게 대하거나, 그녀와 비밀 약속을 맺었다.",
          "sourceEventId": "e04_day",
          "criterion": "주인공이 처음 만난 에스텔을 경계하면서도 진실하게 대하거나, 그녀와 비밀 약속을 맺었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "estelle_heart",
            "value": 1
          }
        },
        {
          "id": "ef_e09_brokk_1",
          "name": "주인공이 브로크의 가호를 가져와, 브로크가 살아서 빈손이 되었다.",
          "sourceEventId": "e09_brokk",
          "criterion": "주인공이 브로크의 가호를 가져와, 브로크가 살아서 빈손이 되었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "made_bin",
            "value": 1
          }
        },
        {
          "id": "ef_e09_brokk_2",
          "name": "빈손이 된 브로크 앞에서 주인공이 우쭐대지 않고 괴로워하거나 그를 더 짓밟지 않았다.",
          "sourceEventId": "e09_brokk",
          "criterion": "빈손이 된 브로크 앞에서 주인공이 우쭐대지 않고 괴로워하거나 그를 더 짓밟지 않았다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e09_brokk_3",
          "name": "주인공이 빈손이 된 브로크를 비웃거나 힘을 과시했다.",
          "sourceEventId": "e09_brokk",
          "criterion": "주인공이 빈손이 된 브로크를 비웃거나 힘을 과시했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": -1
          }
        },
        {
          "id": "ef_e10_fallen_1",
          "name": "주인공이 무너진 브로크에게 먹을 것을 건네거나 그를 사람으로 대했다.",
          "sourceEventId": "e10_fallen",
          "criterion": "주인공이 무너진 브로크에게 먹을 것을 건네거나 그를 사람으로 대했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e11_housecall_1",
          "name": "유리가 주인공을 믿고 앞으로 함께하고 싶어 했다.",
          "sourceEventId": "e11_housecall",
          "criterion": "유리가 주인공을 믿고 앞으로 함께하고 싶어 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e12_tio_1",
          "name": "그날 밤 주인공이 지붕 위의 리네 곁에 가 주었다.",
          "sourceEventId": "e12_tio",
          "criterion": "그날 밤 주인공이 지붕 위의 리네 곁에 가 주었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e13_sylphie_1",
          "name": "실피가 주인공을 돕기로 했다.",
          "sourceEventId": "e13_sylphie",
          "criterion": "실피가 주인공을 돕기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e15_first_quest_1",
          "name": "카일이 주인공을 친구로 대하며 함께 싸웠다.",
          "sourceEventId": "e15_first_quest",
          "criterion": "카일이 주인공을 친구로 대하며 함께 싸웠다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e17_garrick_1",
          "name": "주인공이 가릭의 가호를 가져와, 가릭이 살아서 빈손이 되었다.",
          "sourceEventId": "e17_garrick",
          "criterion": "주인공이 가릭의 가호를 가져와, 가릭이 살아서 빈손이 되었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "made_bin",
            "value": 1
          }
        },
        {
          "id": "ef_e18_estelle_1",
          "name": "주인공이 에스텔이 신분을 숨겨 온 것을 탓하지 않고, 별읽기 무녀가 아닌 그녀 자신을 대했다.",
          "sourceEventId": "e18_estelle",
          "criterion": "주인공이 에스텔이 신분을 숨겨 온 것을 탓하지 않고, 별읽기 무녀가 아닌 그녀 자신을 대했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "estelle_heart",
            "value": 1
          }
        },
        {
          "id": "ef_e19_pippin_1",
          "name": "피핀이 주인공의 전기 작가를 자처하며 따라붙었다.",
          "sourceEventId": "e19_pippin",
          "criterion": "피핀이 주인공의 전기 작가를 자처하며 따라붙었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e19_pippin_2",
          "name": "주인공의 이름이 왕도에 퍼지기 시작했다.",
          "sourceEventId": "e19_pippin",
          "criterion": "주인공의 이름이 왕도에 퍼지기 시작했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "wanted",
            "value": 1
          }
        },
        {
          "id": "ef_e20_isolde_1",
          "name": "빈손이 금 등급을 이겼다는 소문이 왕도에 퍼졌다.",
          "sourceEventId": "e20_isolde",
          "criterion": "빈손이 금 등급을 이겼다는 소문이 왕도에 퍼졌다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "wanted",
            "value": 1
          }
        },
        {
          "id": "ef_e21_after_duel_1",
          "name": "주인공이 이졸데의 가호를 가져와, 이졸데가 살아서 빈손이 되었다.",
          "sourceEventId": "e21_after_duel",
          "criterion": "주인공이 이졸데의 가호를 가져와, 이졸데가 살아서 빈손이 되었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "made_bin",
            "value": 1
          }
        },
        {
          "id": "ef_e21_after_duel_2",
          "name": "이졸데가 이유를 대며 주인공 일행을 따라다니기로 했다.",
          "sourceEventId": "e21_after_duel",
          "criterion": "이졸데가 이유를 대며 주인공 일행을 따라다니기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e22_lady_in_alley_1",
          "name": "주인공이 리네와 이졸데 사이에서 어느 한쪽을 깎아내리지 않고 둘을 존중했다.",
          "sourceEventId": "e22_lady_in_alley",
          "criterion": "주인공이 리네와 이졸데 사이에서 어느 한쪽을 깎아내리지 않고 둘을 존중했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e23_leon_1",
          "name": "레온이 주인공을 제자 겸 동료로 받아들였다.",
          "sourceEventId": "e23_leon",
          "criterion": "레온이 주인공을 제자 겸 동료로 받아들였다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e26_mask_1",
          "name": "빈 가면의 습격 속에서 주인공이 리네나 골목 아이들을 지켰다.",
          "sourceEventId": "e26_mask",
          "criterion": "빈 가면의 습격 속에서 주인공이 리네나 골목 아이들을 지켰다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e27_funeral_1",
          "name": "주인공이 오스를 잃은 에스텔의 슬픔을 함께 나누거나, 그녀가 몰래 치료받던 일을 지켜 주겠다고 했다.",
          "sourceEventId": "e27_funeral",
          "criterion": "주인공이 오스를 잃은 에스텔의 슬픔을 함께 나누거나, 그녀가 몰래 치료받던 일을 지켜 주겠다고 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "estelle_heart",
            "value": 1
          }
        },
        {
          "id": "ef_e28_circle_1",
          "name": "주인공이 리네를 용서하거나 그녀를 지키겠다고 약속했다.",
          "sourceEventId": "e28_circle",
          "criterion": "주인공이 리네를 용서하거나 그녀를 지키겠다고 약속했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 2
          }
        },
        {
          "id": "ef_e28_circle_2",
          "name": "주인공이 리네를 원망하며 몰아세우거나 떠나겠다고 했다.",
          "sourceEventId": "e28_circle",
          "criterion": "주인공이 리네를 원망하며 몰아세우거나 떠나겠다고 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": -2
          }
        },
        {
          "id": "ef_e30_heist_1",
          "name": "나나가 주인공과 거래를 맺고 일행을 돕기로 했다.",
          "sourceEventId": "e30_heist",
          "criterion": "나나가 주인공과 거래를 맺고 일행을 돕기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e30_heist_2",
          "name": "지붕 위에서 주인공이 처음으로 규칙을 어긴 에스텔의 들뜬 마음을 함께 나누거나, 그녀를 영애가 아닌 동료로 대했다.",
          "sourceEventId": "e30_heist",
          "criterion": "지붕 위에서 주인공이 처음으로 규칙을 어긴 에스텔의 들뜬 마음을 함께 나누거나, 그녀를 영애가 아닌 동료로 대했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "estelle_heart",
            "value": 1
          }
        },
        {
          "id": "ef_e34_giving_1",
          "name": "주인공이 맞잡은 손으로 가호를 다른 사람에게 처음으로 건넸다.",
          "sourceEventId": "e34_giving",
          "criterion": "주인공이 맞잡은 손으로 가호를 다른 사람에게 처음으로 건넸다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "vessel",
            "value": 1
          }
        },
        {
          "id": "ef_e34_giving_2",
          "name": "리네가 주인공의 손을 빼앗는 손이 아닌 주는 손으로 보게 되었다.",
          "sourceEventId": "e34_giving",
          "criterion": "리네가 주인공의 손을 빼앗는 손이 아닌 주는 손으로 보게 되었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "br_e34_giving_1",
          "name": "주인공이 브로크에게 〈철피〉를 돌려주거나 진심으로 손을 내밀었고, 브로크가 그것을 받아들였다.",
          "sourceEventId": "e34_giving",
          "criterion": "주인공이 브로크에게 〈철피〉를 돌려주거나 진심으로 손을 내밀었고, 브로크가 그것을 받아들였다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT"
        },
        {
          "id": "ef_e35a_brokk_return_1",
          "name": "브로크가 주인공에게 의리를 맹세했다.",
          "sourceEventId": "e35a_brokk_return",
          "criterion": "브로크가 주인공에게 의리를 맹세했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e36_clinic_1",
          "name": "주인공이 에스텔과 잿골목을 함께 걸으며 그녀가 처음 보는 빈손들의 삶을 진심으로 보여 주었다.",
          "sourceEventId": "e36_clinic",
          "criterion": "주인공이 에스텔과 잿골목을 함께 걸으며 그녀가 처음 보는 빈손들의 삶을 진심으로 보여 주었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "estelle_heart",
            "value": 1
          }
        },
        {
          "id": "ef_e37_patchwork_1",
          "name": "주인공이 누더기 왕의 가호 하나만 고르고 나머지를 놓아 보내며 그릇이 넓어졌다.",
          "sourceEventId": "e37_patchwork",
          "criterion": "주인공이 누더기 왕의 가호 하나만 고르고 나머지를 놓아 보내며 그릇이 넓어졌다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "vessel",
            "value": 1
          }
        },
        {
          "id": "ef_e40_prelims_1",
          "name": "주인공이 베른의 가호를 가져와, 베른이 살아서 빈손이 되었다.",
          "sourceEventId": "e40_prelims",
          "criterion": "주인공이 베른의 가호를 가져와, 베른이 살아서 빈손이 되었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "made_bin",
            "value": 1
          }
        },
        {
          "id": "ef_e40_prelims_2",
          "name": "빈손이 가호자를 꺾는 장면이 수많은 관중에게 알려졌다.",
          "sourceEventId": "e40_prelims",
          "criterion": "빈손이 가호자를 꺾는 장면이 수많은 관중에게 알려졌다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "wanted",
            "value": 1
          }
        },
        {
          "id": "ef_e41_wolf_1",
          "name": "그라츠가 자유를 얻고 주인공 일행과 함께하기로 했다.",
          "sourceEventId": "e41_wolf",
          "criterion": "그라츠가 자유를 얻고 주인공 일행과 함께하기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e42_forged_1",
          "name": "레녹스가 주인공과 손을 잡기로 했다.",
          "sourceEventId": "e42_forged",
          "criterion": "레녹스가 주인공과 손을 잡기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e43_manor_1",
          "name": "주인공이 저택에서도 에스텔을 가문의 영애나 별읽기 무녀가 아닌 한 사람으로 대했다.",
          "sourceEventId": "e43_manor",
          "criterion": "주인공이 저택에서도 에스텔을 가문의 영애나 별읽기 무녀가 아닌 한 사람으로 대했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "estelle_heart",
            "value": 1
          }
        },
        {
          "id": "ef_e46_inquisition_1",
          "name": "로잘린이 주인공을 주시 대상으로 기록했다.",
          "sourceEventId": "e46_inquisition",
          "criterion": "로잘린이 주인공을 주시 대상으로 기록했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "wanted",
            "value": 1
          }
        },
        {
          "id": "ef_e47_rine_night_1",
          "name": "주인공이 리네의 곁을 지키거나 언니를 함께 찾겠다고 약속했다.",
          "sourceEventId": "e47_rine_night",
          "criterion": "주인공이 리네의 곁을 지키거나 언니를 함께 찾겠다고 약속했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e48_unmask_1",
          "name": "주인공이 리네의 언니를 죽이지 않았다.",
          "sourceEventId": "e48_unmask",
          "criterion": "주인공이 리네의 언니를 죽이지 않았다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e48_unmask_2",
          "name": "빈 가면이 쓰러졌다는 사실이 성좌교에 알려졌다.",
          "sourceEventId": "e48_unmask",
          "criterion": "빈 가면이 쓰러졌다는 사실이 성좌교에 알려졌다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "wanted",
            "value": 1
          }
        },
        {
          "id": "br_e48_unmask_1",
          "name": "주인공이 자기 그릇의 가호를 놓아 자리를 비우고, 셀레네의 몸을 태우던 가호들을 가져와 그녀를 살렸다.",
          "sourceEventId": "e48_unmask",
          "criterion": "주인공이 자기 그릇의 가호를 놓아 자리를 비우고, 셀레네의 몸을 태우던 가호들을 가져와 그녀를 살렸다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT"
        },
        {
          "id": "ef_e49a_sister_1",
          "name": "셀레네의 가호를 품은 주인공이 그릇이 넓어지는 것을 느꼈다.",
          "sourceEventId": "e49a_sister",
          "criterion": "셀레네의 가호를 품은 주인공이 그릇이 넓어지는 것을 느꼈다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "vessel",
            "value": 1
          }
        },
        {
          "id": "ef_e49a_sister_2",
          "name": "셀레네가 주인공 일행과 함께하기로 했다.",
          "sourceEventId": "e49a_sister",
          "criterion": "셀레네가 주인공 일행과 함께하기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e49a_sister_3",
          "name": "리네가 언니를 살려 준 주인공에게 진심으로 고마워했다.",
          "sourceEventId": "e49a_sister",
          "criterion": "리네가 언니를 살려 준 주인공에게 진심으로 고마워했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e49b_returned_1",
          "name": "성좌교가 빈 가면을 쓰러뜨린 자의 얼굴을 알게 되었다.",
          "sourceEventId": "e49b_returned",
          "criterion": "성좌교가 빈 가면을 쓰러뜨린 자의 얼굴을 알게 되었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "wanted",
            "value": 1
          }
        },
        {
          "id": "ef_e50_dorothy_1",
          "name": "도로시가 죄를 고백하고 주인공 편에 서기로 했다.",
          "sourceEventId": "e50_dorothy",
          "criterion": "도로시가 죄를 고백하고 주인공 편에 서기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e51_ledger_1",
          "name": "주인공이 서고를 지키던 성기사를 쓰러뜨리고 가호를 가져왔다.",
          "sourceEventId": "e51_ledger",
          "criterion": "주인공이 서고를 지키던 성기사를 쓰러뜨리고 가호를 가져왔다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "made_bin",
            "value": 1
          }
        },
        {
          "id": "ef_e51_ledger_2",
          "name": "서고 침입의 흔적이 성좌교에 발견되었다.",
          "sourceEventId": "e51_ledger",
          "criterion": "서고 침입의 흔적이 성좌교에 발견되었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "wanted",
            "value": 1
          }
        },
        {
          "id": "ef_e53_tio_name_1",
          "name": "장부의 진실 앞에서 무너진 에스텔을 주인공이 탓하지 않고 곁을 지켰다.",
          "sourceEventId": "e53_tio_name",
          "criterion": "장부의 진실 앞에서 무너진 에스텔을 주인공이 탓하지 않고 곁을 지켰다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "estelle_heart",
            "value": 1
          }
        },
        {
          "id": "ef_e54_rosalind_1",
          "name": "로잘린이 주인공 일행을 이단으로 보고했다.",
          "sourceEventId": "e54_rosalind",
          "criterion": "로잘린이 주인공 일행을 이단으로 보고했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "wanted",
            "value": 1
          }
        },
        {
          "id": "ef_e56_grandfather_1",
          "name": "에스텔이 할아버지 대신 주인공 일행을 택했고, 주인공이 그녀를 받아들였다.",
          "sourceEventId": "e56_grandfather",
          "criterion": "에스텔이 할아버지 대신 주인공 일행을 택했고, 주인공이 그녀를 받아들였다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "estelle_heart",
            "value": 1
          }
        },
        {
          "id": "ef_e56_grandfather_2",
          "name": "에스텔이 주인공 일행과 함께하기로 했다.",
          "sourceEventId": "e56_grandfather",
          "criterion": "에스텔이 주인공 일행과 함께하기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 1
          }
        },
        {
          "id": "ef_e57_wanted_1",
          "name": "성좌교가 주인공을 '돌아온 빈손의 왕'으로 선포하고 현상금을 걸었다.",
          "sourceEventId": "e57_wanted",
          "criterion": "성좌교가 주인공을 '돌아온 빈손의 왕'으로 선포하고 현상금을 걸었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "wanted",
            "value": 2
          }
        },
        {
          "id": "ef_e57_wanted_2",
          "name": "주인공이 현상금 사냥꾼의 가호를 가져와, 사냥꾼이 살아서 빈손이 되었다.",
          "sourceEventId": "e57_wanted",
          "criterion": "주인공이 현상금 사냥꾼의 가호를 가져와, 사냥꾼이 살아서 빈손이 되었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "made_bin",
            "value": 1
          }
        },
        {
          "id": "br_e58_alley_speech_1",
          "name": "주인공이 잿골목 사람들 앞에서 자신의 힘과 잘못을 숨김없이 밝히고, 빼앗은 가호를 빈손들에게 나누겠다고 약속해 사람들의 마음을 얻었다.",
          "sourceEventId": "e58_alley_speech",
          "criterion": "주인공이 잿골목 사람들 앞에서 자신의 힘과 잘못을 숨김없이 밝히고, 빼앗은 가호를 빈손들에게 나누겠다고 약속해 사람들의 마음을 얻었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT"
        },
        {
          "id": "ef_e59a_lanterns_1",
          "name": "잿골목 사람들이 등불을 들고 주인공 편에 서기로 했다.",
          "sourceEventId": "e59a_lanterns",
          "criterion": "잿골목 사람들이 등불을 들고 주인공 편에 서기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "allies",
            "value": 3
          }
        },
        {
          "id": "ef_e59b_sold_1",
          "name": "성좌교가 잿골목 은신처를 급습했다.",
          "sourceEventId": "e59b_sold",
          "criterion": "성좌교가 잿골목 은신처를 급습했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "wanted",
            "value": 1
          }
        },
        {
          "id": "br_e61_eve_1",
          "name": "주인공이 의식 전야에 에스텔을 찾아가 단둘이 이야기하기로 했다.",
          "sourceEventId": "e61_eve",
          "criterion": "주인공이 의식 전야에 에스텔을 찾아가 단둘이 이야기하기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT"
        },
        {
          "id": "br_e61_eve_2",
          "name": "주인공이 의식 전야에 이졸데를 찾아가 단둘이 이야기하기로 했다.",
          "sourceEventId": "e61_eve",
          "criterion": "주인공이 의식 전야에 이졸데를 찾아가 단둘이 이야기하기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT"
        },
        {
          "id": "br_e61_eve_3",
          "name": "주인공이 의식 전야에 셀레네를 찾아가 단둘이 이야기하기로 했다.",
          "sourceEventId": "e61_eve",
          "criterion": "주인공이 의식 전야에 셀레네를 찾아가 단둘이 이야기하기로 했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT"
        },
        {
          "id": "ef_e62a_eve_rine_1",
          "name": "주인공이 리네의 질문에 진심으로 대답하거나 곁에 남겠다고 약속했다.",
          "sourceEventId": "e62a_eve_rine",
          "criterion": "주인공이 리네의 질문에 진심으로 대답하거나 곁에 남겠다고 약속했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "rine_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e62d_eve_estelle_1",
          "name": "주인공이 망루의 에스텔에게 진심으로 대답하거나, 빛이 아닌 그녀 자신을 보겠다고 약속했다.",
          "sourceEventId": "e62d_eve_estelle",
          "criterion": "주인공이 망루의 에스텔에게 진심으로 대답하거나, 빛이 아닌 그녀 자신을 보겠다고 약속했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "estelle_heart",
            "value": 2
          }
        },
        {
          "id": "ef_e64_kneel_1",
          "name": "에스텔이 낭독대에서 진실을 읽는 동안 주인공이 그녀를 지키거나 그녀의 목소리를 따라 손을 뻗었다.",
          "sourceEventId": "e64_kneel",
          "criterion": "에스텔이 낭독대에서 진실을 읽는 동안 주인공이 그녀를 지키거나 그녀의 목소리를 따라 손을 뻗었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "estelle_heart",
            "value": 1
          }
        },
        {
          "id": "ef_e66_gregor_1",
          "name": "주인공이 결전 중 가호를 놓거나 건네며 그릇이 다시 넓어졌다.",
          "sourceEventId": "e66_gregor",
          "criterion": "주인공이 결전 중 가호를 놓거나 건네며 그릇이 다시 넓어졌다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "vessel",
            "value": 1
          }
        },
        {
          "id": "ef_e66_gregor_2",
          "name": "주인공이 그레고르의 〈성언〉을 가져와, 그레고르가 살아서 빈손이 되었다.",
          "sourceEventId": "e66_gregor",
          "criterion": "주인공이 그레고르의 〈성언〉을 가져와, 그레고르가 살아서 빈손이 되었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "made_bin",
            "value": 1
          }
        }
      ],
      "decisions": [
        {
          "id": "decision_e34_giving",
          "name": "건네는 손",
          "decisionEventId": "e34_giving",
          "matchPolicy": "FIRST_AUTHORED_MATCH",
          "recoveryAttempts": 1,
          "unresolvedPolicy": "FALLBACK_WITHOUT_ASSERTING_CONDITION",
          "fallback": {
            "nextEventId": "e35b_brokk_grudge",
            "acceptsUnevaluated": true,
            "narrativeGuidance": "조건 미달과 판정 불가를 구분한다. 조건 실패나 관계 훼손을 날조하지 않고 현재 공개된 상황에서 기본 경로로 이어간다."
          },
          "rules": [
            {
              "id": "br_e34_giving_1",
              "label": "주인공이 브로크에게 〈철피〉를 돌려주거나 진심으로 손을 내밀었고, 브로크가 그것을 받아들였다.",
              "when": {
                "kind": "choice_status",
                "choiceId": "br_e34_giving_1",
                "status": "satisfied"
              },
              "nextEventId": "e35a_brokk_return"
            }
          ]
        },
        {
          "id": "decision_e48_unmask",
          "name": "가면 아래",
          "decisionEventId": "e48_unmask",
          "matchPolicy": "FIRST_AUTHORED_MATCH",
          "recoveryAttempts": 1,
          "unresolvedPolicy": "FALLBACK_WITHOUT_ASSERTING_CONDITION",
          "fallback": {
            "nextEventId": "e49b_returned",
            "acceptsUnevaluated": true,
            "narrativeGuidance": "조건 미달과 판정 불가를 구분한다. 조건 실패나 관계 훼손을 날조하지 않고 현재 공개된 상황에서 기본 경로로 이어간다."
          },
          "rules": [
            {
              "id": "br_e48_unmask_1",
              "label": "주인공이 자기 그릇의 가호를 놓아 자리를 비우고, 셀레네의 몸을 태우던 가호들을 가져와 그녀를 살렸다.",
              "when": {
                "kind": "choice_status",
                "choiceId": "br_e48_unmask_1",
                "status": "satisfied"
              },
              "nextEventId": "e49a_sister"
            }
          ]
        },
        {
          "id": "decision_e58_alley_speech",
          "name": "잿골목의 밤",
          "decisionEventId": "e58_alley_speech",
          "matchPolicy": "FIRST_AUTHORED_MATCH",
          "recoveryAttempts": 1,
          "unresolvedPolicy": "FALLBACK_WITHOUT_ASSERTING_CONDITION",
          "fallback": {
            "nextEventId": "e59b_sold",
            "acceptsUnevaluated": true,
            "narrativeGuidance": "조건 미달과 판정 불가를 구분한다. 조건 실패나 관계 훼손을 날조하지 않고 현재 공개된 상황에서 기본 경로로 이어간다."
          },
          "rules": [
            {
              "id": "br_e58_alley_speech_1",
              "label": "주인공이 잿골목 사람들 앞에서 자신의 힘과 잘못을 숨김없이 밝히고, 빼앗은 가호를 빈손들에게 나누겠다고 약속해 사람들의 마음을 얻었다.",
              "when": {
                "kind": "choice_status",
                "choiceId": "br_e58_alley_speech_1",
                "status": "satisfied"
              },
              "nextEventId": "e59a_lanterns"
            },
            {
              "id": "br_e58_alley_speech_2",
              "label": "made_bin",
              "when": {
                "not": {
                  "kind": "flag_at_least",
                  "flagId": "made_bin",
                  "value": 3
                }
              },
              "nextEventId": "e59a_lanterns"
            }
          ]
        },
        {
          "id": "decision_e61_eve",
          "name": "의식 전야",
          "decisionEventId": "e61_eve",
          "matchPolicy": "FIRST_AUTHORED_MATCH",
          "recoveryAttempts": 1,
          "unresolvedPolicy": "FALLBACK_WITHOUT_ASSERTING_CONDITION",
          "fallback": {
            "nextEventId": "e62a_eve_rine",
            "acceptsUnevaluated": true,
            "narrativeGuidance": "조건 미달과 판정 불가를 구분한다. 조건 실패나 관계 훼손을 날조하지 않고 현재 공개된 상황에서 기본 경로로 이어간다."
          },
          "rules": [
            {
              "id": "br_e61_eve_1",
              "label": "주인공이 의식 전야에 에스텔을 찾아가 단둘이 이야기하기로 했다.",
              "when": {
                "kind": "choice_status",
                "choiceId": "br_e61_eve_1",
                "status": "satisfied"
              },
              "nextEventId": "e62d_eve_estelle"
            },
            {
              "id": "br_e61_eve_2",
              "label": "주인공이 의식 전야에 이졸데를 찾아가 단둘이 이야기하기로 했다.",
              "when": {
                "kind": "choice_status",
                "choiceId": "br_e61_eve_2",
                "status": "satisfied"
              },
              "nextEventId": "e62b_eve_isolde"
            },
            {
              "id": "br_e61_eve_3",
              "label": "주인공이 의식 전야에 셀레네를 찾아가 단둘이 이야기하기로 했다.",
              "when": {
                "kind": "choice_status",
                "choiceId": "br_e61_eve_3",
                "status": "satisfied"
              },
              "nextEventId": "e62c_eve_selene"
            }
          ]
        }
      ]
    },
    "galleries": [],
    "epilogues": [],
    "checkpoints": [],
    "clues": [],
    "items": [],
    "zones": [],
    "worldFacts": [],
    "loopPolicy": {
      "format": "RELAY_NOVEL_LOOP_POLICY_V1",
      "enabled": false,
      "resetPoint": {
        "date": "",
        "time": ""
      },
      "activeWindow": {
        "startDate": "",
        "startTime": "",
        "endDate": "",
        "endTime": ""
      },
      "trigger": {
        "allOf": []
      },
      "resetPrecedence": [
        "event_reset_behavior",
        "entity_definition",
        "category_state_rule",
        "default_restore_baseline"
      ],
      "stateRules": [],
      "protagonistDeathMode": "game_over",
      "maxLoops": null
    }
  },
  "imageTriggerRuntime": {
    "format": "RELAY_NOVEL_IMAGE_TRIGGER_RUNTIME_V1",
    "evaluationTiming": "after_state_update_before_turn_output",
    "stateLedger": {
      "firedTriggerIds": [],
      "instruction": "once=true인 트리거의 ID를 기록하고 다시 실행하지 않는다."
    },
    "ordering": "같은 턴에 여러 조건이 충족되면 priority 내림차순으로 평가한다.",
    "triggerSemantics": {
      "event_start": "연결 사건의 상태가 Active로 처음 바뀌는 턴",
      "event_condition_met": "연결 사건의 conditions가 실제 서사 상태에서 충족되는 턴",
      "event_success": "연결 사건이 성공 결과로 확정되는 턴",
      "event_failure": "연결 사건이 실패 결과로 확정되는 턴",
      "clock_value": "연결 사건 시계가 threshold 이상에 처음 도달하는 턴",
      "clock_completed": "연결 사건 시계가 maximum에 도달하는 턴",
      "foreshadow_revealed": "연결 복선 상태가 Revealed로 바뀌는 턴",
      "story_progress": "storyProgress에 적힌 장·막·날짜·서사 단계에 도달하는 턴",
      "custom_condition": "customCondition을 현재 공개/비공개 상태 장부에 대조해 충족하는 턴"
    },
    "modeSemantics": {
      "show_trigger_image": "트리거에 직접 첨부된 대표 이미지를 원본 그대로 출력한다. 새 이미지를 생성하거나 외형을 변형하지 않는다.",
      "show_package_image": "선택 인물의 패키지 기준 이미지를 그대로 출력한다. 새 이미지를 생성하지 않는다.",
      "generate_character_variant": "선택 인물의 기준 이미지를 참조해 포즈·표정·의상·배경만 바꾼 변형 컷을 생성한다.",
      "generate_scene": "선택 인물과 현재 장면의 정사를 반영한 장면 이미지를 생성한다."
    },
    "hardRules": [
      "트리거 조건을 임의로 앞당기거나 서사를 조건에 맞게 조작하지 않는다.",
      "show_trigger_image이면 attachedImages에서 isPrimary=true인 assetPath를 우선 출력하고, 없으면 첫 번째 첨부 이미지를 사용한다.",
      "useCharacterReferences=true이면 패키지 기준 이미지를 최우선 참조한다.",
      "preserveFaces=true이면 얼굴형·눈·머리·체형·고유 액세서리와 visualAnchor를 유지한다.",
      "spoilerProtection=true이면 이미지와 프롬프트에 아직 공개되지 않은 인물·정체·장소·결과를 넣지 않는다.",
      "이미지 생성 기능이 없으면 생성했다고 주장하지 말고 완성된 [IMAGE TRIGGER PROMPT]를 출력한다."
    ]
  },
  "autonomyRuntime": {
    "format": "RELAY_NOVEL_AUTONOMY_RUNTIME_V1",
    "enabled": false,
    "configuration": {
      "enabled": false,
      "maxActionsPerTurn": 3,
      "factionTickTurns": 3,
      "deterministicSeed": true,
      "requireTravelTime": true,
      "enforceKnowledgeBounds": true,
      "enforceResourceBounds": true,
      "allowOffscreenFailure": true,
      "tracePolicy": "observable_only"
    },
    "actorIds": [],
    "evaluationTiming": "after_player_action_and_elapsed_time_before_public_output",
    "selectionOrder": [
      "discard_disabled_or_ineligible_actors",
      "check_activity_tier_and_action_cadence",
      "check_location_travel_time_knowledge_resources_and_constraints",
      "rank_by_goal_priority_urgency_and_world_pressure",
      "select_up_to_max_actions_per_turn_without_forcing_every_actor",
      "resolve_success_partial_success_or_failure_with_seeded_variance"
    ],
    "deterministicResolution": {
      "seedSource": "package.randomSeed + turnIndex + stable actor.id hash + action attempt count",
      "instruction": "같은 입력 상태와 시드에서는 같은 후보 선별과 판정이 재현되어야 한다. 결과를 맞추기 위해 시드를 다시 굴리지 않는다."
    },
    "hiddenLedger": {
      "actorStates": [],
      "resolvedActions": [],
      "discoveredTraces": [],
      "instruction": "각 자율 행동에 actorId, turn, locationBefore, intent, evidenceUsed, resourcesSpent, rollOrReason, outcome, locationAfter, worldMutations, trace를 기록한다."
    },
    "updateTargets": [
      "actor_location",
      "actor_resources",
      "actor_plan",
      "events",
      "event_clocks",
      "foreshadowings",
      "relationship_memories",
      "observable_traces"
    ],
    "authorRules": [
      "1. 플레이어가 보지 않는 곳에서도 활성 NPC와 세력은 자신의 목표·정보·자원·위치에 따라 행동 후보를 만든다.",
      "2. 매 턴 모든 인물을 억지로 움직이지 않는다. 활동 등급·행동 주기·목표 우선도에 따라 최대 행동 수 안에서 선별한다.",
      "3. 배우는 장부에 기록된 정보만 사용할 수 있으며, 다른 지역으로 이동하려면 세계관의 이동 시간이 실제로 흘러야 한다.",
      "4. 성공을 보장하지 않는다. 자원·능력·협력·방해·위험도를 근거로 성공·부분 성공·실패를 판정한다.",
      "5. 비공개 행동은 숨은 세계 장부에 먼저 기록하고, 플레이어에게는 목격 가능한 흔적·소문·결과만 공개한다.",
      "6. 자율 행동의 결과는 사건 시계·위치·자원·관계 기억에 실제 변화를 남기며 다음 행동의 원인이 된다."
    ],
    "hardRules": [
      "활성 배우 모두를 매 턴 움직이지 않는다. 활동 범위·행동 주기·긴급도·우선도를 평가하고 maxActionsPerTurn 이하만 실행한다.",
      "배우는 knowledge에 적힌 사실과 런타임에서 정당하게 획득한 정보만 사용할 수 있다. 플레이어 또는 다른 NPC의 숨은 정보를 전지적으로 알지 못한다.",
      "requireTravelTime=true이면 배우가 현재 위치에서 행동 장소까지 이동할 현실적 시간이 없을 때 해당 행동을 실행하지 않는다.",
      "enforceResourceBounds=true이면 등록되지 않은 돈·도구·권한·인맥·능력을 편의를 위해 소급 생성하지 않는다.",
      "목표와 계획은 성공을 보장하지 않는다. 방해·제약·위험·자원과 시드 판정에 따라 부분 성공 또는 실패할 수 있다.",
      "오프스크린 행동은 먼저 HIDDEN_GM_DATA 장부에 기록한다. 플레이어에게는 tracePolicy와 revealTraces에 맞는 관측 가능한 흔적만 공개한다.",
      "자율 행동의 결과는 다음 턴의 세계 상태에 실제로 반영하며, 필요하면 사건 시계와 관계 이유 기억을 함께 갱신한다.",
      "플레이어가 개입하지 않았다는 이유로 NPC의 갈등·공모·계획을 정지시키거나 자동 성공시키지 않는다."
    ]
  },
  "relationshipMemoryRuntime": {
    "format": "RELAY_NOVEL_RELATIONSHIP_MEMORY_RUNTIME_V1",
    "enabled": true,
    "configuration": {
      "enabled": true,
      "deriveScoresFromMemory": true,
      "keepContradictoryMemories": true,
      "decayEnabled": true,
      "maxActiveMemoriesPerRelation": 50,
      "displayPublicReasonsInHud": true
    },
    "evaluationTiming": "after_world_mutation_before_public_state_filter",
    "scoreFormula": "clamp(-100, 100, relation.baselineScore + sum(activeMemory.effects[dimension]))",
    "dimensions": [
      "trust",
      "favor",
      "fear",
      "respect",
      "suspicion",
      "hostility",
      "dependency"
    ],
    "directionality": "A→B 기억은 B→A 관계나 기억에 자동 복제하지 않는다.",
    "memoryLifecycle": {
      "temporary": "짧은 상황이 해소되면 비활성화할 수 있으나 기록 자체는 삭제하지 않는다.",
      "decaying": "중요도·최근성·후속 사건에 따라 효과가 서서히 약해질 수 있다.",
      "permanent": "정사 수정 또는 명시적 해결 사건 없이는 효과를 자동 감쇠하지 않는다.",
      "unresolved": "해결 조건이 충족될 때까지 NPC의 판단·대사·자율 행동 후보에 지속적으로 반영한다."
    },
    "appendProtocol": [
      "identify_directional_relation",
      "record_observed_or_hidden_cause",
      "append_memory_before_score_change",
      "apply_effects_and_clamp_each_dimension",
      "retain_contradictory_memories",
      "filter_public_reason_for_hud_and_narrative"
    ],
    "initialLedgerInstruction": "relations/relationship_memories.json을 원장으로 불러오고 id를 유지한다. 수정·해결 시 원본을 지우지 말고 상태 변화 또는 후속 기억을 남긴다.",
    "authorRules": [
      "1. 관계 수치는 임의로 올리거나 내리지 않는다. 먼저 방향성 기억을 기록한 뒤 그 기억의 효과를 초기 기준값에 합산한다.",
      "2. 기억에는 누가 누구를, 언제, 무엇 때문에 신뢰·의심·두려워하게 되었는지 원인을 남긴다.",
      "3. 약속·배신·구조·빚·공유한 비밀·모욕과 미해결 감정은 장기 기억으로 보존하고 이후 판단의 근거로 사용한다.",
      "4. 서로 모순되는 기억도 삭제하지 않는다. 중요도·영구성·최근성·현재 맥락을 함께 평가한다.",
      "5. 숨은 기억과 미등장 인물의 이유는 공개하지 않는다. 상태창에는 직접 만난 인물의 공개 가능한 이유만 표시한다.",
      "6. 관계는 방향성이므로 A가 B에게 느끼는 기억을 B가 A에게 자동 복제하지 않는다."
    ],
    "hardRules": [
      "관계 점수를 임의로 조정하지 않는다. 점수 변화보다 먼저 원인·방향·효과가 있는 RelationshipMemory를 추가한다.",
      "기억은 sourceId가 targetId에게 느끼는 방향성 기록이며 반대 방향을 자동 대칭 처리하지 않는다.",
      "배신·약속·빚·구조·공유한 비밀·모욕·공동 성공과 실패는 후속 행동의 이유로 재사용한다.",
      "keepContradictoryMemories=true이면 호감과 의심처럼 모순되는 감정을 함께 보존하고 한쪽을 임의로 삭제하지 않는다.",
      "Hidden 기억의 제목·원인·효과는 플레이어에게 직접 공개하거나 추론 결과처럼 단정하지 않는다.",
      "상태창에는 직접 만난 인물만 표시하고 displayPublicReasonsInHud=true일 때도 Public 기억의 공개 가능한 요약만 보여준다.",
      "미해결 기억은 resolutionConditions가 실제 사건으로 충족될 때만 해결하며 편의를 위해 턴 경과만으로 소거하지 않는다."
    ]
  },
  "statusWindowRuntime": {
    "format": "RELAY_NOVEL_STATUS_WINDOW_RUNTIME_V3",
    "enabled": true,
    "title": "TURN STATUS · LIVE",
    "displayMode": "full",
    "defaultExpanded": true,
    "showTurnDelta": true,
    "sections": [
      {
        "id": "ability",
        "label": "ABILITY",
        "icon": "zap",
        "order": 10,
        "enabled": true
      },
      {
        "id": "core_stats",
        "label": "CORE STATS",
        "icon": "gauge",
        "order": 20,
        "enabled": true
      },
      {
        "id": "resources",
        "label": "RESOURCES",
        "icon": "resource",
        "order": 30,
        "enabled": true
      },
      {
        "id": "condition",
        "label": "CONDITION",
        "icon": "heart",
        "order": 40,
        "enabled": true
      },
      {
        "id": "funds",
        "label": "FUNDS",
        "icon": "wallet",
        "order": 50,
        "enabled": true
      },
      {
        "id": "relationships",
        "label": "CHARACTER · FACTION RELATIONSHIPS",
        "icon": "relation",
        "order": 60,
        "enabled": true
      }
    ],
    "fields": [
      {
        "id": "ability_summary",
        "label": "Ability",
        "sectionId": "ability",
        "sectionLabel": "ABILITY",
        "kind": "text",
        "visibility": "public",
        "icon": "zap",
        "order": 10,
        "showDelta": false,
        "summary": true,
        "initialValue": "현재 공개된 특별 능력은 아직 없다.",
        "updateRule": "플레이어가 현재 이해하고 공개할 수 있는 능력만 한두 줄의 쉬운 문장으로 갱신"
      },
      {
        "id": "STAT_muyvuhl7_hyzg45",
        "label": "체력",
        "sectionId": "core_stats",
        "sectionLabel": "CORE STATS",
        "kind": "number",
        "visibility": "public",
        "icon": "❤",
        "order": 10,
        "minimum": 0,
        "maximum": 100,
        "maxDelta": 100,
        "showDelta": true,
        "summary": true,
        "initialValue": 100,
        "grade": "A",
        "updateRule": "이번 턴에 관측 가능한 서사적 원인이 있을 때만 변경"
      },
      {
        "id": "STAT_muyvuhl7_comq0l",
        "label": "집중력",
        "sectionId": "core_stats",
        "sectionLabel": "CORE STATS",
        "kind": "number",
        "visibility": "public",
        "icon": "◈",
        "order": 20,
        "minimum": 0,
        "maximum": 100,
        "maxDelta": 100,
        "showDelta": true,
        "summary": true,
        "initialValue": 100,
        "grade": "B",
        "updateRule": "이번 턴에 관측 가능한 서사적 원인이 있을 때만 변경"
      },
      {
        "id": "STAT_muyvuhl7_obsg9v",
        "label": "능력 게이지",
        "sectionId": "core_stats",
        "sectionLabel": "CORE STATS",
        "kind": "number",
        "visibility": "public",
        "icon": "✦",
        "order": 30,
        "minimum": 0,
        "maximum": 100,
        "maxDelta": 100,
        "showDelta": true,
        "summary": true,
        "initialValue": 0,
        "grade": "F",
        "updateRule": "이번 턴에 관측 가능한 서사적 원인이 있을 때만 변경"
      },
      {
        "id": "primary_resource",
        "label": "핵심 자원",
        "sectionId": "resources",
        "sectionLabel": "RESOURCES",
        "kind": "number",
        "visibility": "conditional",
        "revealed": false,
        "icon": "spark",
        "order": 10,
        "minimum": 0,
        "maxDelta": 3,
        "showDelta": true,
        "summary": true,
        "initialValue": 0,
        "unit": "개",
        "updateRule": "해당 자원의 존재와 보유량을 플레이어가 실제로 확인한 뒤 공개"
      },
      {
        "id": "consumable_resource",
        "label": "소모 자원",
        "sectionId": "resources",
        "sectionLabel": "RESOURCES",
        "kind": "number",
        "visibility": "conditional",
        "revealed": false,
        "icon": "gem",
        "order": 20,
        "minimum": 0,
        "maxDelta": 3,
        "showDelta": true,
        "summary": true,
        "initialValue": 0,
        "unit": "개",
        "updateRule": "획득 또는 사용이 실제 장면에서 확인된 뒤 공개하고 증감"
      },
      {
        "id": "special_equipment",
        "label": "특수 장비",
        "sectionId": "resources",
        "sectionLabel": "RESOURCES",
        "kind": "number",
        "visibility": "conditional",
        "revealed": false,
        "icon": "sword",
        "order": 30,
        "minimum": 0,
        "maxDelta": 3,
        "showDelta": true,
        "summary": true,
        "initialValue": 0,
        "unit": "개",
        "updateRule": "장비를 실제로 획득하고 용도를 확인한 뒤 공개"
      },
      {
        "id": "condition_summary",
        "label": "Condition",
        "sectionId": "condition",
        "sectionLabel": "CONDITION",
        "kind": "text",
        "visibility": "public",
        "icon": "heart",
        "order": 10,
        "showDelta": false,
        "summary": true,
        "initialValue": "현재 확인된 부상이나 이상 상태는 없다.",
        "updateRule": "현재 관측 가능한 몸과 정신 상태만 한두 줄로 갱신하고 숨은 원인이나 미래 결과는 쓰지 않음"
      },
      {
        "id": "funds",
        "label": "자금",
        "sectionId": "funds",
        "sectionLabel": "FUNDS",
        "kind": "number",
        "visibility": "public",
        "icon": "wallet",
        "order": 10,
        "minimum": 0,
        "maxDelta": 100000000,
        "showDelta": true,
        "summary": true,
        "initialValue": 0,
        "unit": "원",
        "updateRule": "확인된 수입과 지출이 발생한 경우에만 현재 보유 자금을 갱신"
      }
    ],
    "relationshipDisplay": {
      "format": "RELAY_NOVEL_RELATIONSHIP_DISPLAY_V1",
      "enabled": true,
      "allowCombinedParts": true,
      "supportedParts": [
        "sentence",
        "stat",
        "symbol"
      ],
      "entries": [],
      "updatePolicy": "update_only_from_observable_interaction_or_public_event_result"
    },
    "initialLedger": [
      {
        "fieldId": "ability_summary",
        "value": "현재 공개된 특별 능력은 아직 없다.",
        "grade": "",
        "visibility": "public",
        "revealed": true
      },
      {
        "fieldId": "STAT_muyvuhl7_hyzg45",
        "value": 100,
        "grade": "A",
        "visibility": "public",
        "revealed": true
      },
      {
        "fieldId": "STAT_muyvuhl7_comq0l",
        "value": 100,
        "grade": "B",
        "visibility": "public",
        "revealed": true
      },
      {
        "fieldId": "STAT_muyvuhl7_obsg9v",
        "value": 0,
        "grade": "F",
        "visibility": "public",
        "revealed": true
      },
      {
        "fieldId": "primary_resource",
        "value": 0,
        "grade": "",
        "visibility": "conditional",
        "revealed": false
      },
      {
        "fieldId": "consumable_resource",
        "value": 0,
        "grade": "",
        "visibility": "conditional",
        "revealed": false
      },
      {
        "fieldId": "special_equipment",
        "value": 0,
        "grade": "",
        "visibility": "conditional",
        "revealed": false
      },
      {
        "fieldId": "condition_summary",
        "value": "현재 확인된 부상이나 이상 상태는 없다.",
        "grade": "",
        "visibility": "public",
        "revealed": true
      },
      {
        "fieldId": "funds",
        "value": 0,
        "grade": "",
        "visibility": "public",
        "revealed": true
      }
    ],
    "disclosureRules": [
      "Ability와 Condition은 현재 확인된 정보만 한두 줄로 표시한다.",
      "핵심 자원: 해당 자원의 존재와 보유량을 플레이어가 실제로 확인한 뒤 공개",
      "소모 자원: 획득 또는 사용이 실제 장면에서 확인된 뒤 공개하고 증감",
      "특수 장비: 장비를 실제로 획득하고 용도를 확인한 뒤 공개",
      "미공개 정체·계약·비밀 세력·미래 사건을 상태창에 노출하지 않는다."
    ],
    "configuration": {
      "title": "TURN STATUS · LIVE",
      "displayMode": "always_full",
      "theme": "dark_rpg",
      "placement": "before_replies",
      "showDeltas": true,
      "collapseOnMobile": true,
      "highlightChanges": true,
      "sections": {
        "profile": true,
        "skills": true,
        "stats": true,
        "resources": true,
        "condition": true,
        "funds": true,
        "inventory": false,
        "relationships": true,
        "clocks": false,
        "objective": false
      }
    },
    "turnOrder": [
      "date_time_weather_location_header",
      "observable_narrative_and_dialogue",
      "autonomous_actor_selection_and_resolution",
      "hidden_world_ledger_update",
      "relationship_memory_append_and_score_recalculation",
      "character_or_scene_image_when_triggered",
      "public_state_filter",
      "status_window_render",
      "recommended_replies_with_risk"
    ],
    "renderTiming": "after_turn_state_update_before_recommended_replies",
    "initialState": {
      "profile": {
        "characterId": "siwoo",
        "name": "강시우",
        "role": "주인공",
        "affiliation": "",
        "location": "왕도 에르딘 바깥 고리, 빈민가 「잿골목」"
      },
      "skills": "현재 공개된 특별 능력은 아직 없다.",
      "stats": [
        {
          "id": "STAT_muyvuhl7_hyzg45",
          "icon": "❤",
          "name": "체력",
          "rank": "A",
          "current": 100,
          "max": 100,
          "color": "green"
        },
        {
          "id": "STAT_muyvuhl7_comq0l",
          "icon": "◈",
          "name": "집중력",
          "rank": "B",
          "current": 100,
          "max": 100,
          "color": "blue"
        },
        {
          "id": "STAT_muyvuhl7_obsg9v",
          "icon": "✦",
          "name": "능력 게이지",
          "rank": "F",
          "current": 0,
          "max": 100,
          "color": "violet"
        }
      ],
      "resources": [
        {
          "id": "primary_resource",
          "icon": "spark",
          "name": "핵심 자원",
          "current": 0,
          "unit": "개",
          "visibility": "conditional",
          "revealRule": "해당 자원의 존재와 보유량을 플레이어가 실제로 확인한 뒤 공개"
        },
        {
          "id": "consumable_resource",
          "icon": "gem",
          "name": "소모 자원",
          "current": 0,
          "unit": "개",
          "visibility": "conditional",
          "revealRule": "획득 또는 사용이 실제 장면에서 확인된 뒤 공개하고 증감"
        },
        {
          "id": "special_equipment",
          "icon": "sword",
          "name": "특수 장비",
          "current": 0,
          "unit": "개",
          "visibility": "conditional",
          "revealRule": "장비를 실제로 획득하고 용도를 확인한 뒤 공개"
        }
      ],
      "condition": "현재 확인된 부상이나 이상 상태는 없다.",
      "funds": {
        "icon": "wallet",
        "name": "자금",
        "current": 0,
        "unit": "원"
      },
      "relationships": []
    },
    "deltaLedger": {
      "previousTurnSnapshot": null,
      "currentTurnChanges": [],
      "instruction": "각 변화에 field, before, after, delta, observableCause를 기록하고 출력 후 현재 스냅샷을 다음 턴 기준으로 보존한다."
    },
    "updateRules": [
      "1. 매 턴 서술이 끝나면 비공개 세계 장부를 먼저 갱신하고, 플레이어가 알 수 있는 정보만 상태창에 반영한다.",
      "2. 능력치·자원·상태 변화에는 반드시 이번 턴에 실제로 서술되거나 기록된 원인이 있어야 한다.",
      "3. 매 턴 전체 상태창을 출력하고, 바뀐 값은 이전 값 대비 증감과 원인을 함께 강조한다.",
      "4. Ability와 Condition은 플레이어가 현재 이해할 수 있는 말로 한두 줄만 표시하며, 정체·계약·미래 사건을 앞서 설명하지 않는다.",
      "5. Resources는 각 항목에 적힌 공개·증감 조건이 실제 장면에서 충족된 뒤에만 표시하거나 변경한다.",
      "6. 작품별 특수 자원과 장비는 실제 보유·사용이 확인된 경우에만 바꾸며, 자금은 확인된 지출·수입에 따라 갱신한다.",
      "7. 미등장 인물, 진명, 비밀 진영, 숨은 관계와 비공개 사건 시계는 공개 조건이 충족되기 전까지 숨긴다.",
      "8. 플레이어의 행동·대사·감정을 임의로 확정하지 않으며, 없던 아이템·자원·능력을 소급해 만들지 않는다.",
      "9. 인물·세력 관계 표시는 실제 상호작용의 공개 가능한 결과가 있을 때만 문장·수치·기호를 갱신하고, 같은 원인을 중복 반영하지 않는다."
    ],
    "hardRules": [
      "displayMode=always_full이면 변화가 없어도 매 턴 전체 상태창을 출력한다.",
      "상태 변화는 이번 턴의 관측 가능한 실제 장면 변화 또는 장부에 기록된 원인으로만 발생한다.",
      "Ability와 Condition은 한두 줄을 넘기지 않고 현재 확인된 내용만 쉽게 설명한다.",
      "핵심 자원: 해당 자원의 존재와 보유량을 플레이어가 실제로 확인한 뒤 공개",
      "소모 자원: 획득 또는 사용이 실제 장면에서 확인된 뒤 공개하고 증감",
      "특수 장비: 장비를 실제로 획득하고 용도를 확인한 뒤 공개",
      "자금은 플레이어가 실제로 확인한 수입·지출만 반영하고 작품에 설정된 화폐 단위를 유지한다.",
      "인물·세력 관계는 sentence·stat·symbol 중 설정된 조합을 한 항목 안에 함께 표시한다.",
      "관계 문장·수치·기호는 동일한 공개 사건을 근거로 함께 갱신하고 한 원인을 중복 계산하지 않는다.",
      "met_only 관계는 플레이어가 해당 인물 또는 세력을 직접 확인한 뒤에만 표시한다.",
      "미등장 인물·진명·비밀 진영·숨은 관계·비공개 사건 시계는 공개 조건 전까지 렌더링하지 않는다.",
      "플레이어의 행동·대사·감정을 임의로 확정하지 않는다.",
      "없던 아이템·자원·능력·준비를 소급해 만들지 않는다.",
      "표시 값과 내부 장부가 충돌하면 내부 장부를 검증한 뒤 공개 필터를 다시 적용하고, 숨은 정보 자체는 설명하지 않는다."
    ]
  },
  "characterVisualBible": {
    "format": "RELAY_NOVEL_CHARACTER_VISUAL_BIBLE_V1",
    "enabled": true,
    "globalStyle": "일본 라이트노벨 표지·삽화풍의 고품질 애니메이션 일러스트. 캐릭터마다 머리색과 실루엣이 뚜렷이 구분되게. 잿골목은 잿빛 지붕과 빨랫줄과 등불, 상층 구역과 대성당은 흰 대리석과 남색·금색 별 장식. 가호는 사용자 눈동자와 손끝에 그 가호의 빛깔로 표현. 그림 안에 글자를 넣지 않는다.",
    "consistencyRules": "기준 이미지가 있는 인물은 얼굴형·눈·머리·체형·고유 액세서리를 동일하게 유지한다. 의상 변화가 있어도 정체성 앵커를 보존한다.",
    "introductionRule": "비중 높은 새 캐릭터가 처음 등장하면 반드시 인물 이미지를 함께 출력한다. 패키지 기준 이미지가 없으면 애니풍 이미지를 생성하고, 그 최초 결과를 이후 외형의 기준으로 고정한다.",
    "priorityOrder": [
      "package_primary_reference",
      "package_secondary_reference",
      "first_ai_generated_reference",
      "text_visual_anchor"
    ],
    "characters": [
      {
        "id": "siwoo",
        "name": "강시우",
        "importance": "protagonist",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "열아홉 살 한국인 남자. 키 172cm, 마른 체형에 구부정한 자세. 덥수룩한 검은 머리, 잠이 부족한 눈 밑 그늘, 의외로 날카로운 눈매. 남색 교복 바지와 흰 셔츠, 넥타이 위에 검은 롱패딩, 낡은 운동화, 형광펜 자국이 묻은 손가락. 가호를 쓸 때 눈동자에 그 가호의 빛깔이 잠깐 비친다.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_siwoo",
            "fileName": "siwoo.webp",
            "mimeType": "image/webp",
            "label": "강시우",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 157310,
            "sha256": "6919e7905149198f153ea90873ad68f8054e197fedc51115f5c76293ea9512fa",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 157310
            },
            "assetPath": "assets/characters/siwoo/01_siwoo.webp",
            "assetRef": "sha256:6919e7905149198f153ea90873ad68f8054e197fedc51115f5c76293ea9512fa",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "rine",
        "name": "리네",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "열일곱 살 소녀. 키 158cm. 햇볕에 바랜 갈색 머리를 높이 하나로 묶었고, 코 위에 주근깨, 밝은 초록 눈. 걷어 올린 소매에 물 빠진 앞치마, 맨팔에는 빨래하다 생긴 붉은 자국. 손가락 마디가 거칠다. 허리춤에 빨래 방망이.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_rine",
            "fileName": "rine.webp",
            "mimeType": "image/webp",
            "label": "리네",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 147424,
            "sha256": "33368e406d500f21a10ab90a316526e905ee34f61ee4a9998de1159be7ebd593",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 147424
            },
            "assetPath": "assets/characters/rine/01_rine.webp",
            "assetRef": "sha256:33368e406d500f21a10ab90a316526e905ee34f61ee4a9998de1159be7ebd593",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "estelle",
        "name": "에스텔",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "열일곱 살 소녀. 키 160cm. 윤기 흐르는 흑갈색 생머리를 허리까지 늘어뜨렸고, 머리 한쪽을 검은 리본으로 묶어 금빛 별 장식 핀을 꽂았다. 별 모양 금 귀걸이. 따뜻한 갈색 눈, 〈별읽기〉를 쓰면 눈동자에 금빛 별무늬가 떠오른다. 흰 프릴 블라우스와 넓은 소매, 남색 리본 타이 위에 금실 별자리를 수놓은 검은 망토. 몰래 나올 때는 낡은 회색 두건을 깊이 눌러쓴다. (리네의 햇볕에 바랜 밝은 갈색 포니테일과 초록 눈과 달리, 짙은 흑갈색 긴 생머리와 검은 리본·별 핀, 검은 망토로 구분한다.)",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_estelle",
            "fileName": "estelle.webp",
            "mimeType": "image/webp",
            "label": "에스텔",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 98264,
            "sha256": "ee904c8cbb1fa40ce63453d02e7a7adc126023901db1c734316f98dfb6cee78e",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 98264
            },
            "assetPath": "assets/characters/estelle/01_estelle.webp",
            "assetRef": "sha256:ee904c8cbb1fa40ce63453d02e7a7adc126023901db1c734316f98dfb6cee78e",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "tio",
        "name": "티오",
        "importance": "supporting",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "아홉 살 소년. 누나를 닮은 갈색 곱슬머리, 빠진 앞니, 무릎이 해진 반바지, 나무 막대기 검.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_tio",
            "fileName": "tio.webp",
            "mimeType": "image/webp",
            "label": "티오",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 154782,
            "sha256": "6bacfb7bdc8df18c1a470f0d937d62a8a291c3b26e187663be442a25f1030754",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 154782
            },
            "assetPath": "assets/characters/tio/01_tio.webp",
            "assetRef": "sha256:6bacfb7bdc8df18c1a470f0d937d62a8a291c3b26e187663be442a25f1030754",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "selene",
        "name": "셀레네",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "스무 살 여성. 키 165cm. 원래 갈색이던 머리가 바랜 듯 은백색으로 길게 흘러내린다. 회색 눈, 창백한 피부. 흰 성녀복과 얇은 베일. 세탁부처럼 손가락 마디가 갈라져 있다. 빈 가면일 때는 얼굴 전체를 가리는 매끈한 하얀 가면과 검은 코트.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_selene",
            "fileName": "selene.webp",
            "mimeType": "image/webp",
            "label": "셀레네",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 140410,
            "sha256": "3c32d305e4d13b5452dbeee1cf2e3afcb45739840867fb97c3aa1213bd65ca57",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 140410
            },
            "assetPath": "assets/characters/selene/01_selene.webp",
            "assetRef": "sha256:3c32d305e4d13b5452dbeee1cf2e3afcb45739840867fb97c3aa1213bd65ca57",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "isolde",
        "name": "이졸데",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "열여덟 살 소녀. 키 163cm. 진홍빛 긴 머리를 리본으로 높이 묶었고 날카로운 호박색 눈. 금장식이 달린 하얀 기사복 위에 은빛 어깨 갑옷과 붉은 망토, 가느다란 장검. 가호를 쓰면 머리 위에 불꽃 고리가 떠오른다.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_isolde",
            "fileName": "isolde.webp",
            "mimeType": "image/webp",
            "label": "이졸데",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 163506,
            "sha256": "8a233f8037578f8027a6af5e70159bad383a2be6429384aec28cca5f7437f4e5",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 163506
            },
            "assetPath": "assets/characters/isolde/01_isolde.webp",
            "assetRef": "sha256:8a233f8037578f8027a6af5e70159bad383a2be6429384aec28cca5f7437f4e5",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "nana",
        "name": "나나",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "열여섯 살 고양이 수인 소녀. 키 150cm. 검은 고양이 귀와 꼬리, 짧은 검은 단발, 커다란 금빛 눈. 헐렁한 회색 후드와 반바지, 맨발에 가까운 가죽 덧신. 목에 늑대 송곳니 목걸이.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_nana",
            "fileName": "nana.webp",
            "mimeType": "image/webp",
            "label": "나나",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 158752,
            "sha256": "ca84e6ebb0319378541bb1345ac5f7f8fe0b849c3d4e1c01ffd05f9d3c3f8ef4",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 158752
            },
            "assetPath": "assets/characters/nana/01_nana.webp",
            "assetRef": "sha256:ca84e6ebb0319378541bb1345ac5f7f8fe0b849c3d4e1c01ffd05f9d3c3f8ef4",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "yuri",
        "name": "유리",
        "importance": "supporting",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "열네 살 소녀. 키 147cm. 연한 하늘색 머리를 두 갈래로 땋았고, 얼굴의 반을 덮는 큰 동그란 안경. 할아버지의 낡은 흰 가운을 소매를 접어 입었다. 약초 냄새가 난다.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_yuri",
            "fileName": "yuri.webp",
            "mimeType": "image/webp",
            "label": "유리",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 140814,
            "sha256": "e32d1db0c821b6fd6e9b36cf886ca1142806eba5e2aec08e103a8f5af25a550d",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 140814
            },
            "assetPath": "assets/characters/yuri/01_yuri.webp",
            "assetRef": "sha256:e32d1db0c821b6fd6e9b36cf886ca1142806eba5e2aec08e103a8f5af25a550d",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "sylphie",
        "name": "실피",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "열두 살쯤으로 보이는 엘프 소녀. 키 138cm. 바닥에 끌릴 듯한 은빛 긴 머리, 길고 뾰족한 귀, 보랏빛 눈. 몸보다 큰 챙 넓은 마법사 모자와 별무늬 망토. 입에 계피 막대.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_sylphie",
            "fileName": "sylphie.webp",
            "mimeType": "image/webp",
            "label": "실피",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 166986,
            "sha256": "55c534f603653ec0c422702a810e2c103ca6fa3b84dfdb822cc8e96124a75d76",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 166986
            },
            "assetPath": "assets/characters/sylphie/01_sylphie.webp",
            "assetRef": "sha256:55c534f603653ec0c422702a810e2c103ca6fa3b84dfdb822cc8e96124a75d76",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "kyle",
        "name": "카일",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "열여덟 살 청년. 키 180cm. 금갈색 곱슬머리, 맑은 하늘색 눈, 늘 웃는 얼굴. 은색 흉갑과 푸른 견습 기사 망토, 손질이 잘된 장검.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_kyle",
            "fileName": "kyle.webp",
            "mimeType": "image/webp",
            "label": "카일",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 174266,
            "sha256": "7b55c76431815acb735856163b6e7185fcb078e5cddf3044fefda9dce5c18a0b",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 174266
            },
            "assetPath": "assets/characters/kyle/01_kyle.webp",
            "assetRef": "sha256:7b55c76431815acb735856163b6e7185fcb078e5cddf3044fefda9dce5c18a0b",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "leon",
        "name": "레온",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "스물일곱 살 남자. 키 183cm. 아무렇게나 묶은 짙은 갈색 꽁지머리, 졸린 듯한 녹색 눈, 턱의 수염 자국. 낡은 가죽 갑옷과 갈색 망토, 커다란 장궁과 화살통, 입에 문 파이프.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_leon",
            "fileName": "leon.webp",
            "mimeType": "image/webp",
            "label": "레온",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 149772,
            "sha256": "668cb02951fce0a4429bbadc7384cb4713434473004b005aec8ae58fc3d01de6",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 149772
            },
            "assetPath": "assets/characters/leon/01_leon.webp",
            "assetRef": "sha256:668cb02951fce0a4429bbadc7384cb4713434473004b005aec8ae58fc3d01de6",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "brokk",
        "name": "브로크",
        "importance": "supporting",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "서른두 살 거구의 남자. 키 192cm. 빡빡 민 머리와 덥수룩한 수염, 문신이 새겨진 털 많은 팔뚝. 대장간 앞치마 같은 가죽 조끼, 어깨에 걸친 커다란 쇠망치. 〈철피〉를 쓰면 피부가 쇳빛으로 변한다.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_brokk",
            "fileName": "brokk.webp",
            "mimeType": "image/webp",
            "label": "브로크",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 106302,
            "sha256": "357e386225bf20b21e438a0f1a52bbea715e30a81dbcf4170bb932d87d12275b",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 106302
            },
            "assetPath": "assets/characters/brokk/01_brokk.webp",
            "assetRef": "sha256:357e386225bf20b21e438a0f1a52bbea715e30a81dbcf4170bb932d87d12275b",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "oss",
        "name": "오스",
        "importance": "supporting",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "예순한 살 노인. 작고 마른 체구, 하얗게 센 머리와 짧은 수염, 코끝에 걸친 작은 안경. 얼룩진 흰 가운과 약초 다발.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_oss",
            "fileName": "oss.webp",
            "mimeType": "image/webp",
            "label": "오스",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 156480,
            "sha256": "32594ff4ac9ee32c8862ebe2a67a490c8df984ce5e3a0671ed94f1270b8888f0",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 156480
            },
            "assetPath": "assets/characters/oss/01_oss.webp",
            "assetRef": "sha256:32594ff4ac9ee32c8862ebe2a67a490c8df984ce5e3a0671ed94f1270b8888f0",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "gregor",
        "name": "그레고르",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "예순여섯 살 노인. 키가 크고 꼿꼿하다. 단정히 빗어 넘긴 백발과 흰 수염, 깊은 주름, 차분한 회색 눈. 별자리가 금실로 수놓인 남색 대주교 예복, 별 모양 홀.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_gregor",
            "fileName": "gregor.webp",
            "mimeType": "image/webp",
            "label": "그레고르",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 179688,
            "sha256": "023a20635750ef9e1c32f1a13bf933b878d8fd3a755d926a94a30307f757952c",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 179688
            },
            "assetPath": "assets/characters/gregor/01_gregor.webp",
            "assetRef": "sha256:023a20635750ef9e1c32f1a13bf933b878d8fd3a755d926a94a30307f757952c",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "dorothy",
        "name": "도로시",
        "importance": "supporting",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "스물네 살 여성. 키 166cm. 부드러운 밤색 웨이브 머리, 동그란 안경, 늘 웃는 입가. 길드 제복(흰 블라우스, 남색 조끼)과 귀에 꽂은 깃펜.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_dorothy",
            "fileName": "dorothy.webp",
            "mimeType": "image/webp",
            "label": "도로시",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 89612,
            "sha256": "6809545ed57d3de956ced52a36375f0cef14c5e530bb3f7fc624689337c8dd2e",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 89612
            },
            "assetPath": "assets/characters/dorothy/01_dorothy.webp",
            "assetRef": "sha256:6809545ed57d3de956ced52a36375f0cef14c5e530bb3f7fc624689337c8dd2e",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "rosalind",
        "name": "로잘린",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "스물일곱 살 여성. 키 170cm. 칠흑 같은 긴 생머리, 가늘게 휘어진 눈, 붉은 입술. 흰 두건이 달린 검은 수녀복과 은 별 목걸이, 허리에 감은 가는 사슬 채찍.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_rosalind",
            "fileName": "rosalind.webp",
            "mimeType": "image/webp",
            "label": "로잘린",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 130654,
            "sha256": "38617dc66acb70947aef7241441e996aeaa2ae01b71675a2b08495a254a02626",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 130654
            },
            "assetPath": "assets/characters/rosalind/01_rosalind.webp",
            "assetRef": "sha256:38617dc66acb70947aef7241441e996aeaa2ae01b71675a2b08495a254a02626",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "pippin",
        "name": "피핀",
        "importance": "supporting",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "스무 살 청년. 키 168cm. 여기저기 뻗친 주황색 머리, 주근깨, 장난스러운 갈색 눈. 깃털 꽂은 갈색 베레모, 알록달록 기운 망토, 등에 멘 낡은 류트.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_pippin",
            "fileName": "pippin.webp",
            "mimeType": "image/webp",
            "label": "피핀",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 166394,
            "sha256": "733b6f7a565f243531df901c188670d9c344034337e732317b7c297e1f4e9e7d",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 166394
            },
            "assetPath": "assets/characters/pippin/01_pippin.webp",
            "assetRef": "sha256:733b6f7a565f243531df901c188670d9c344034337e732317b7c297e1f4e9e7d",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "lennox",
        "name": "레녹스",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "스물두 살 청년. 키 181cm. 어깨까지 오는 칠흑 같은 머리, 나른한 붉은 눈, 흰 피부. 가슴을 풀어헤친 검은 비단 셔츠에 보석 반지들, 손에는 와인 잔.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_lennox",
            "fileName": "lennox.webp",
            "mimeType": "image/webp",
            "label": "레녹스",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 85090,
            "sha256": "4e235e0cfc92910391e0262b18b1f715202f846955166389317e6034509c5aba",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 85090
            },
            "assetPath": "assets/characters/lennox/01_lennox.webp",
            "assetRef": "sha256:4e235e0cfc92910391e0262b18b1f715202f846955166389317e6034509c5aba",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "gratz",
        "name": "그라츠",
        "importance": "supporting",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "스물여덟 살 늑대 수인 남자. 키 205cm. 잿빛 늑대 귀와 꼬리, 흉터투성이 근육질 몸, 짧은 회색 머리, 노란 눈. 목과 손목에 쇠사슬, 허리에 감은 투기장 천.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_gratz",
            "fileName": "gratz.webp",
            "mimeType": "image/webp",
            "label": "그라츠",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 119356,
            "sha256": "ade08de1ca317909542fbbdc2d7f4b28f362e9dec8c1d847cdf7649e68469d7b",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 119356
            },
            "assetPath": "assets/characters/gratz/01_gratz.webp",
            "assetRef": "sha256:ade08de1ca317909542fbbdc2d7f4b28f362e9dec8c1d847cdf7649e68469d7b",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      },
      {
        "id": "garrick",
        "name": "가릭",
        "importance": "minor",
        "imageOnFirstAppearance": false,
        "visualLock": true,
        "visualAnchor": "스물아홉 살 남자. 마른 체격, 기름진 금발을 뒤로 묶었고, 쥐처럼 작은 눈. 낡은 가죽 외투 안에 열쇠 꾸러미와 단검.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "bern",
        "name": "베른",
        "importance": "minor",
        "imageOnFirstAppearance": false,
        "visualLock": true,
        "visualAnchor": "스물네 살 남자. 키 185cm. 짧게 친 은회색 머리, 비웃는 입꼬리, 화려한 금장 검투사 갑옷. 팔뚝에서 상아색 뼈 칼날이 돋는다.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "ella",
        "name": "엘라",
        "importance": "minor",
        "imageOnFirstAppearance": false,
        "visualLock": true,
        "visualAnchor": "열두 살 소녀. 언니를 닮은 밤색 머리를 땋아 내렸고, 창백하지만 잘 웃는 얼굴. 하얀 환자복과 무릎 위의 그림판.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "hanbaek",
        "name": "빈손의 왕",
        "importance": "minor",
        "imageOnFirstAppearance": false,
        "visualLock": true,
        "visualAnchor": "전설 속 모습은 얼굴 없는 검은 그림자. 실제로는 스물몇 살의 조선 청년으로, 풀어 헤친 긴 머리에 흰 도포, 맑고 고집스러운 눈.",
        "imageFallback": "generate_anime",
        "images": [
          {
            "id": "IMG_hanbaek",
            "fileName": "hanbaek.webp",
            "mimeType": "image/webp",
            "label": "빈손의 왕",
            "isPrimary": true,
            "addedAt": "2026-10-07T00:00:00.000Z",
            "byteLength": 134870,
            "sha256": "78af62c9a93c0a55293bb95a3023a586cd079406c83570e1078c590ad4fb710c",
            "imageOptimization": {
              "profile": "screen_v1",
              "width": 1088,
              "height": 608,
              "originalBytes": 134870
            },
            "assetPath": "assets/characters/hanbaek/01_hanbaek.webp",
            "assetRef": "sha256:78af62c9a93c0a55293bb95a3023a586cd079406c83570e1078c590ad4fb710c",
            "dataUrlHeader": "data:image/webp;base64"
          }
        ]
      }
    ]
  },
  "style": {
    "narrationPerson": "1인칭 주인공 시점",
    "proseStyle": "몰입감 있는 현실주의 소설체",
    "dialogueStyle": "시대·신분·성격에 맞는 자연스러운 대사",
    "descriptionDensity": "보통",
    "violenceLevel": "중간",
    "romanceLevel": "선택적",
    "statusDisclosure": "중요 변화만 공개",
    "customRules": "플레이어 캐릭터의 행동·대사·감정을 예측하여 대신 서술하지 않는다.",
    "viewpoint": "1인칭 주인공 시점",
    "sentenceStyle": "라이트 노벨",
    "additionalRules": "라이트노벨 문체, 1인칭 '나'. 주인공의 속마음 딴죽과 빠른 리듬으로 이끌되, 가호를 빼앗는 장면과 빈손들의 삶에서는 웃음을 거두고 무게 있게 쓴다. 문단은 짧게, 대사는 생생하게. 매 사건의 끝은 다음 화가 궁금해지는 장면(새 단서, 새 인물, 위기)으로 맺는다.\n캐릭터마다 말버릇과 매력을 살린다. 에스텔의 조용한 경어와 뜻밖의 직설, 별 이야기만 나오면 길어지는 말, 리네의 \"바보야!\"와 큰 웃음, 이졸데의 귀족 말투와 새침함, 나나의 장사꾼 반말과 꼬리, 유리의 수줍음과 의사 모드, 실피의 할머니 말투와 계피 막대, 셀레네의 무표정한 존댓말, 도로시의 다정함, 로잘린의 나긋한 섬뜩함, 카일의 해맑음, 레온의 능글맞음, 피핀의 과장, 레녹스의 나른함, 그라츠의 침묵, 브로크의 허세. 여러 인물이 한 장면에 있으면 서로 티격태격하는 대화로 매력을 보여 준다. 히로인은 구조 대상이 아니라 스스로 움직이는 인물로 쓰고, 설레는 장면은 생활 속 작은 행동(음식, 손수건, 떨리는 손)으로 보여 준다. 메인 히로인 에스텔은 사람의 속을 빛으로 보는 소녀라, 주인공과의 장면에서는 '보이는 것'과 '말하지 않는 것'의 간극으로 설렘을 만든다. 리네는 늘 곁에 있는 동료이자 주요 히로인이다. 주인공의 연애 감정과 선택은 대신 정하지 않는다.\n이 세계에는 상태창이 없다. 주인공이 가호를 얻거나 놓거나 건넬 때마다 본문에 한 줄로 [그릇 2/3 · 〈어둠눈〉 〈철피〉] 형식으로 현재 상태를 적는다. 칸 수는 독자 HUD의 '그릇', 가진 개수는 '가진 가호'와 일치시킨다.\n전투는 거리와 자세, 가호의 규칙이 분명한 인과로 쓴다. 가호의 효과를 부풀리지 않는다. 주인공은 약하므로 꾀와 가호 조합과 동료로 이긴다.\n비밀은 인물이 설명하듯 털어놓게 하지 말고 행동·물건·말버릇으로 보여 준다. 한 사건에서 독자가 새로 알게 되는 큰 사실은 사건 설명의 [핵심 공개]에 적힌 1~2개뿐이다. 나머지 단서와 복선 회수는 장면의 중심을 빼앗지 않게 한두 문장으로 스친다. 사건 설명 끝의 [강화]·[연출] 같은 대괄호 메모는 작가를 위한 연출 지침이다.",
    "cortexAuthoringGuidance": "최종 공개된 산문이 정사다. 사용자 요청은 확정 사실이 아니며 세계와 인과 안에서 수용·우회·제한한다.\n현재 사건 목표를 기본 비트부터 자연스럽게 진행한다. 기본 3비트, 최소 2비트부터 조기 종결, 연장 최대 2비트. 미충족 지적은 연장 구간에서 검토한다.\n원본이 허용한 미충족 전개로 수습되면 대체 종결로 전환한다. 수습되지 않은 의무만 최후 안전장치로 다음 사건 첫 문단에 이월한다. 포기·대체된 목표를 다시 강제하지 않는다.\n사건별 예정 날짜·시작 시각·종료 시각·시간창은 사용하지 않는다. 지정된 후속사건을 우선하고, 미지정이면 사건 배열 순서로 진행한다.\n구체적 시간 경과는 현재 공개 본문과 현재 제공된 사건 설명에 따라 집필한다. 다음 사건 설명을 진입 전에 미리 읽거나 미래 시간표에 맞추지 않는다.\n작품 근거 없는 24시간 이상 도약은 사용자 요청과 작가 임의 전개 모두 현재 문맥에서 인과적으로 흡수한다. 자정을 넘는 것 자체는 금지가 아니다.\n현재 제공된 작품 스토리가 명시한 하루 이상 경과는 그대로 따른다. 3일 뒤·17년 뒤·10년 혼수상태 같은 작가의 서사 문장을 보존한다.\n24시간 미만이라도 진행 중인 위험·전투·긴박성을 무너뜨리는 도약은 자연스럽게 중단·단축한다. 꿈·환상은 최후의 수단이다.\n새 사건을 처음 읽었을 때 시간대가 이미 지났다면 현재 시각부터 가까운 다음 시간대까지 필요한 일상을 짧게 연결해 해당 비트에서 시작한다. 별도 대기 비트를 요구하지 않는다.\n이미 지난 마감·기회는 설득력 있는 지연·상황 변화·대체 기회와 그 결과로 수습한다. 공개한 본문·출발·종료 사실과 시간은 정사이며 24시간 상한으로 되감거나 취소하지 않는다.\n작가는 현재 사건·이전 두 사건 원문과 오래된 요약을 읽고, 판정관은 현재·이전 두 사건의 공개 원문만 읽는다. 계약은 달성 기준이지 사실의 증거가 아니다.\n첫 문단은 장면을 여는 자연스러운 산문으로 쓴다. 상태표·추천답변·선택지·내부 판정 기록을 산문 출력에 강제하지 않는다. 모델 배정과 호출 횟수는 엔진이 관리한다."
  },
  "turnPresentation": {
    "recommendedReplies": {
      "enabled": false,
      "count": 3,
      "style": "diverse",
      "showRisk": true,
      "revealHiddenInformation": false
    },
    "sceneImage": {
      "enabled": true,
      "frequency": "important_only",
      "position": "bottom",
      "count": 1,
      "aspectRatio": "landscape",
      "textInImage": false,
      "spoilerProtection": true,
      "fallback": "IMAGE_PROMPT",
      "styleHint": "시나리오 분위기에 맞는 고품질 애니메이션 콘셉트 아트"
    }
  },
  "opening": {
    "preHistory": "",
    "currentSituation": "강시우는 방금 이세계 에르딘 왕국 왕도의 빈민가 '잿골목'에 떨어졌다. 해 질 녘. 교복 위 롱패딩, 수험생 백팩, 배터리 41%의 스마트폰. 상태창도 능력도 없다. 팔뚝이 쇳빛으로 굳는 거구의 깡패 두목(곰발 브로크)과 부하 둘이 그를 둘러싸고 '반짝이는 상자'를 내놓으라 한다. 골목 입구에는 빨래 방망이를 든 갈색 머리 소녀가 막 달려와 멈춰 섰고, 그 뒤로 꼬마 하나가 막대기 검을 들고 따라온다. 발밑에는 빗물에 번진 분필 동그라미가 있다.",
    "immediateProblem": "",
    "knownRisks": "",
    "openingCharacters": "",
    "openingLocation": "왕도 에르딘 바깥 고리, 빈민가 「잿골목」",
    "openingEvent": "강시우는 방금 이세계 에르딘 왕국 왕도의 빈민가 '잿골목'에 떨어졌다. 해 질 녘. 교복 위 롱패딩, 수험생 백팩, 배터리 41%의 스마트폰. 상태창도 능력도 없다. 팔뚝이 쇳빛으로 굳는 거구의 깡패 두목(곰발 브로크)과 부하 둘이 그를 둘러싸고 '반짝이는 상자'를 내놓으라 한다. 골목 입구에는 빨래 방망이를 든 갈색 머리 소녀가 막 달려와 멈춰 섰고, 그 뒤로 꼬마 하나가 막대기 검을 들고 따라온다. 발밑에는 빗물에 번진 분필 동그라미가 있다.",
    "firstGoal": "",
    "openingLine": "수능 D-30, 새벽 두 시 십 분. 독서실 형광등이 세 번 깜빡였다.\n\n나, 강시우는 재수생이다. 작년 수능을 시원하게 말아먹었고, 올해 모의고사 등급도 제자리. 가진 거라고는 다 쓴 형광펜 세 자루랑 '이번엔 다르다'는 근거 없는 다짐뿐이었다. 그 다짐마저 바닥을 긁던 참에, 귓가에서 누가 속삭였다.\n\n『……누구라도 좋아. 제발. 빼앗을 수 있는 사람을.』\n\n울다 지친 여자애 목소리였다. 고개를 들었더니 책상 위 문제집이 하얀 분필 가루처럼 부서지고 있었다. 그리고 바닥이 사라졌다.\n\n눈을 떴을 때 나는 해 질 녘의 낯선 골목에 엎어져 있었다. 잿빛 지붕, 머리 위로 엉킨 빨랫줄, 썩은 물 냄새. 발밑에는 분필로 그린 커다란 동그라미가 빗물에 번져 있었다. 오케이, 침착하자. 웹소설 몇백 편을 읽은 몸이다. 이럴 땐 정해진 순서가 있지.\n\n\"……상태창.\"\n\n아무것도 안 떴다.\n\n\"스테이터스 오픈! 메뉴! 인벤토리! ……퀘스트 창?\"\n\n\"봐라, 빈손이 혼자 주문을 외우네.\"\n\n골목 끝에서 덩치 셋이 낄낄대며 다가왔다. 가운데 놈의 팔뚝이 내 눈앞에서 쩍쩍 쇳빛으로 변해 갔다. 아, 저쪽은 있구나. 능력.",
    "openingTime": "18:40:00",
    "recommendedReply1": "두 손을 들고 \"말 통하네요?\" 하며 일단 대화를 시도한다.",
    "recommendedReply2": "빨래 방망이를 든 소녀에게 \"도망쳐!\"라고 외치며 깡패들의 시선을 끈다.",
    "recommendedReply3": "백팩을 휘둘러 쇳빛 팔뚝의 두목에게 먼저 덤벼든다."
  },
  "hiddenGmData": {
    "npcSecrets": [
      {
        "id": "rine",
        "name": "리네",
        "hiddenInfo": "주인공을 부른 것은 리네다. 엄마가 남긴 금서(빈손의 왕의 일기 사본)에 있던 동그라미를 분필로 그리고, 티오가 또 빈손이 될까 무서워 \"누구라도, 빼앗을 수 있는 사람을\" 하고 빌었다. 정말 사람이 떨어질 줄은 몰랐고, 들키면 둘 다 화형이라 숨긴다. 주인공이 처음 놓은 가호가 리네에게 오면 그것을 숨기려 애쓴다(등불 없이 어둠 속을 다니는 등 작은 티가 난다). 「놓은 것이 가는 곳」 사건에서 모든 것을 고백한다. 리네는 거짓말에 서툴다. 리네는 죽지 않는다."
      },
      {
        "id": "estelle",
        "name": "에스텔",
        "hiddenInfo": "아버지 쪽 할아버지는 대주교 그레고르다. 17년 전 동부 변경의 내전에서 부모를 잃고 할아버지 손에 자랐다. 할아버지를 사랑한다. 의식에서 읽는 빛이 할아버지의 축복을 받은 뒤에야 켜진다는 것을 3년 전부터 알았지만, \"보이는 대로만 읽거라\"라는 말에 따랐다. 그녀의 낭독은 장부의 '낭독 목록'에 미리 적혀 있다. 성녀 셀레네의 자리에서 빛 셋이 겹쳐 타는 것도 보았다. 그 침묵이 그녀의 죄다. 제2왕자 레녹스와는 정략으로 맺은 서류상의 약혼자이자 말동무다. 이졸데와는 어릴 적 사교계의 단짝이자 라이벌이었다('별과 불꽃'). 〈별읽기〉는 많은 빛을 한꺼번에 읽으면 눈을 상하게 해서, 의식 날마다 눈에서 피가 비친다. 3년 동안 잿골목의 오스에게 몰래 치료받았다(유리는 그녀를 '두건 언니'로 안다). 「잿쥐의 밤」에 오스에게 다녀오던 길에 빛이 쥐에게서 그에게 건너가는 것을 본다. 「빈손의 하루」에서 이름만 밝히고, 그의 비밀을 지켜 주는 대신 아랫동네를 보여 달라는 비밀 약속을 맺는다. 「잿골목의 의사」에서 오스의 비밀 환자로 다시 마주친다. 「빈손이 된 남자」에서 빈손이 된 브로크의 가슴을 본다. 「별읽는 영애」에서 가문과 별읽기 무녀라는 신분을 밝힌다. 「오스의 장례」에서 주인공의 가슴에 남은 오스의 빛을 보고, 같은 사람을 잃은 사람으로 그의 곁에 선다. 「나나의 거래」에서 처음으로 규칙을 어기고 잠입에 따라온다. 「유리의 진료소」에서 리네와 처음 부딪친다(\"우리 엄마는 '별의 뜻'이라는 말에 끌려갔어\"). 「레녹스의 초대」에서 약혼의 사정을 주인공에게만 털어놓는다. 「아스트레아 저택」에서 할아버지가 대주교임이 드러난다. 「새어 나간 계획」에서 할아버지를 배신하는 줄 알면서 서고 열쇠를 내준다. 「할아버지의 별」에서 할아버지의 과거를 듣고도 저택을 떠난다. 「무릎 꿇은 광장」에서 낭독대에 올라 진실을 읽고, 빈자리들을 읽어 주인공의 손을 이끈다. 「별의 우물」에서 빛의 그릇 안에 사람이 있다는 것을 처음 본다. 에스텔은 죽지 않는다."
      },
      {
        "id": "tio",
        "name": "티오",
        "hiddenInfo": "대주교의 장부에서 티오는 '빈손 배정 — 성녀 후보 실험체'로 정해져 있다. 의식 전의 아이라 자리가 비어 있어 대주교의 〈성언〉에 묶일 수 있다. 티오는 죽지 않는다."
      },
      {
        "id": "selene",
        "name": "셀레네",
        "hiddenInfo": "정체는 리네의 언니이자 성좌교의 비밀 집행자 빈 가면. 열 살 의식에서 빈손으로 정해지자 성좌교가 성녀 후보로 데려가, 하나뿐인 자리에 우물의 가호 세 개를 억지로 넣었다. 〈그림자 걸음〉(그림자에서 그림자로 열 걸음 안을 건너뜀, 하루 세 번), 〈서리 손〉(닿은 것을 얼림), 〈가호 감지〉(오십 걸음 안 가호의 위치와 세기를 느낌). 가호들이 몸을 안에서 태우고 있어 오래 못 산다. 대주교의 명으로 등록되지 않은 가호를 가진 자를 찾아 회수해 왔다. 무표정하지만 동생 바보라, 가면 아래서 엄마의 빨래 노래를 흥얼거린다. 「가면 아래」 사건에서 정체가 드러나며, 그 전에는 죽지 않는다. 주인공이 그녀의 가호를 가져가면 살아나지만 빈손으로 돌아간다."
      },
      {
        "id": "isolde",
        "name": "이졸데",
        "hiddenInfo": "어릴 적 자신을 키운 빈손 시녀가 병으로 죽을 때 아무도 의사를 불러 주지 않은 일을 기억한다. 그래서 속으로는 가호 계급을 싫어하지만 인정하지 못한다. 「불꽃의 영애」에서 주인공에게 결투를 걸고, 「결투 뒤」에서 가호를 빼앗길 수 있다. 빼앗기면 빈손이 되어 백작가에서 쫓겨나고 \"내 가호 돌려줘요!\"라며 주인공을 쫓아다니다 동료가 된다. 빼앗기지 않으면 \"이 결투는 무효예요\"라며 재대결을 핑계로 따라다닌다. 레온에게 가호 없이 검을 쓰는 법을 배우며 성장한다. 에스텔과는 어릴 적 사교계의 단짝이자 라이벌('별과 불꽃')이었다. 이졸데는 죽지 않는다."
      },
      {
        "id": "nana",
        "name": "나나",
        "hiddenInfo": "늑대 송곳니 목걸이는 투기장에 노예로 팔려 간 의오빠 그라츠의 것이다. 둘은 같은 고아원에서 자랐다. 나나가 돈을 모으는 이유는 오빠의 몸값이다. 「나나의 부탁」 사건에서 처음으로 돈 얘기 없이 오빠를 구해 달라고 부탁한다."
      },
      {
        "id": "yuri",
        "name": "유리",
        "hiddenInfo": "할아버지 오스가 「빈 가면」 사건에서 죽는다. 유리는 할아버지의 진료소를 잇겠다고 결심한다. 「건네는 손」 이후 주인공이 〈치유의 손〉을 유리에게 건넬 수 있다(유리의 자리는 비어 있다). 그러면 유리는 잿골목의 의사가 된다."
      },
      {
        "id": "sylphie",
        "name": "실피",
        "hiddenInfo": "실피는 300년 전 빈손의 왕의 동료였다. 모자 끈의 동전은 그가 준 조선의 상평통보다. 그가 성인들에게 붙잡혀 별의 우물 밑에 봉인되는 것을 막지 못했고, 그 뒤로 그의 고향에서 '다음 빈 그릇'이 오기를 기다려 왔다. 주인공의 말버릇에서 그를 떠올린다. 그의 이름은 \"그 녀석이 직접 다시 말할 때까지\" 부르지 않는다. 「빈손의 왕의 일기」 사건에서 그의 동료였다는 사실을 밝히고, 「우물의 핵」에서 그를 지키지 못한 과거를 털어놓는다."
      },
      {
        "id": "kyle",
        "name": "카일",
        "hiddenInfo": "카일의 〈굳힘〉은 7년 전 이단으로 처형된 리네의 엄마 마르타의 가호였다. 회수된 뒤 장부에 따라 그에게 배정됐다. 본인은 모른다. 「카일의 가호」 사건에서 이 사실을 알게 되면 크게 흔들리고, 가호를 리네에게 돌려주고 싶어 한다(스스로 내어 주면 주인공을 거쳐 건넬 수 있다). 카일은 죽지 않는다."
      },
      {
        "id": "leon",
        "name": "레온",
        "hiddenInfo": "레온은 빈손이다. 은 등급 증표는 위조이며, 가호 없이 기술과 판 읽기만으로 살아남았다. 들키면 길드에서 쫓겨나 투기장에 팔릴 수 있다. 주인공에게 '가호 없이 싸우는 법'을 가르치는 스승이 된다. 「늑대의 코」 사건에서 정체가 드러난다."
      },
      {
        "id": "brokk",
        "name": "브로크",
        "hiddenInfo": "브로크도 원래 잿골목의 빈손 고아였고, 대장간 심부름꾼으로 자랐다. 열 살 의식에서 운 좋게 가호를 받은 뒤 다시는 빈손으로 돌아가지 않겠다고 맹세했다. 주인공에게 가호를 빼앗기면 부하들에게 버려지고 바닥까지 떨어진다. 「건네는 손」에서 주인공이 〈철피〉를 돌려주거나 진심으로 손을 내밀면 「곰발의 귀환」으로 의리 있는 형님이 되어 잿골목 야경단을 꾸린다. 그렇지 않으면 「곰발의 원한」으로 성좌교와 손잡고 밀고자가 된다."
      },
      {
        "id": "oss",
        "name": "오스",
        "hiddenInfo": "오스는 가호가 '줄 수도 있는 것'이라는 옛이야기를 안다. 주인공의 힘을 알아채도 고발하지 않는다. 「빈 가면」 사건에서 빈 가면에게 치명상을 입고, 죽기 직전 스스로 주인공에게 〈치유의 손〉을 내어 준다. \"가호는… 줄 수도 있다네.\" 오스는 그 사건에서 죽고 되살아나지 않는다."
      },
      {
        "id": "gregor",
        "name": "그레고르",
        "hiddenInfo": "그레고르의 가호는 〈성언〉이다. 자리가 비어 있는 자(빈손, 의식 전의 아이)는 그의 목소리가 들리는 동안 그 명령을 거스르지 못한다. 가호를 가진 사람, 자리가 아예 없는 수인과 엘프, 다른 세계에서 온 주인공에게는 통하지 않는다. 대성당은 그의 목소리가 광장 끝까지 울리도록 지어졌다. 그는 아스트레아 공작가의 전 당주이며 에스텔의 할아버지다. 17년 전 가호가 무작위로 나뉘던 동부 변경의 내전에서, 갑자기 〈불꽃〉을 얻은 농부가 지른 불에 아들 부부를 잃고 갓난 손녀만 구해 냈다. 그 뒤로 가호를 통제하지 않으면 피가 흐른다고 믿는다. 손녀를 진심으로 사랑하며, 의식에서는 축복의 손으로 아이에게 장부의 가호를 넣고 손녀에게 그 빛을 읽게 한다. 그래서 장부로 모든 가호를 배정하고, 우물이 모자라면 평민 가호자를 이단으로 몰아 처형해 회수하며, 약한 가호는 숲에 버린다. 악의가 아니라 질서를 위한 필요악이라고 믿는다. 「아스트레아 저택」에서는 손녀를 아끼는 다정한 할아버지로만 보인다. 「대주교 그레고르」 사건 전에는 죽거나 실각하지 않는다."
      },
      {
        "id": "dorothy",
        "name": "도로시",
        "hiddenInfo": "도로시는 성좌교의 정보원이다. 등록되지 않은 가호의 소문을 성좌교 전령에게 쪽지로 넘긴다. 엘라의 치료비를 성좌교가 대 준다. 잿골목 빈손 소년에게 가호가 생겼다는 소문을 넘긴 것이 「빈 가면」 사건과 오스의 죽음을 불렀고, 그 일로 깊이 괴로워한다. 주인공을 챙긴 마음도 진짜다. 「새어 나간 계획」에서 정체가 드러나며, 주인공의 선택에 따라 동료가 될 수 있다."
      },
      {
        "id": "rosalind",
        "name": "로잘린",
        "hiddenInfo": "로잘린은 원래 잿골목 출신 빈손이었다. 열여덟 살에 굶어 죽어 가던 그녀를 그레고르가 데려가 우물의 가호를 내렸고, 그 은혜로 그에게 광신적으로 충성한다. \"저도 한때는 빈손이었답니다\"라고 말할 때만 미소가 진짜다. 빈손이 가호를 받는 일은 '대주교님의 자비'로만 가능해야 한다고 믿는다. 악역이지만 인간이며, 「로잘린의 마지막 심문」에서 그레고르의 거짓말을 처음으로 냄새 맡고 흔들린다. 그 전에는 죽지 않는다."
      },
      {
        "id": "pippin",
        "name": "피핀",
        "hiddenInfo": "피핀의 노래는 주인공의 소문을 퍼뜨려 명성과 수배를 함께 키운다. 그는 사실 제2왕자 레녹스에게 돈을 받고 주인공의 동태를 보고하는 첩자였지만, 진심으로 주인공의 팬이 되어 버려 보고서를 엉터리로 쓴다. 「레녹스의 초대」에서 들키면 엉엉 울며 이실직고한다."
      },
      {
        "id": "lennox",
        "name": "레녹스",
        "hiddenInfo": "왕실은 성좌교의 꼭두각시다. 레녹스는 한량을 연기하며 성좌교를 무너뜨릴 기회를 노려 왔다. 주인공을 쓸모 있는 장기 말로 보고, 투기장 우승을 조건으로 대성당 출입을 돕는다. 속을 알 수 없지만 약속은 지킨다. 에스텔과는 대주교가 맺어 준 정략 약혼 사이로, 서로 사랑하지 않는 '서류상의 약혼자'이자 처지를 아는 말동무다. 주인공을 놀리는 데 그 약혼을 써먹는다. 「일어선 광장」에서 왕실의 끈과 함께 이 약혼도 끊는다. 그는 자기 목적을 위해서라도 「일어선 광장」에서 근위대를 움직인다. 주인공과의 관계는 결말에서 그가 무엇을 바라는지를 바꾼다."
      },
      {
        "id": "gratz",
        "name": "그라츠",
        "hiddenInfo": "나나의 의오빠. 나나의 몸값을 대신해 스스로 노예로 팔려 갔다. 「투기장의 늑대」 사건에서 주인공과 싸운다. 빼앗을 가호가 없으므로 주인공은 꾀와 실력으로 이겨야 한다. 이기면 레녹스의 상으로 그의 자유를 얻을 수 있고, 자유를 얻으면 말없이 주인공의 등을 지키는 동료가 된다. 냄새로 빈손을 알아본다(「늑대의 코」에서 레온의 정체를 알아챈다)."
      },
      {
        "id": "garrick",
        "name": "가릭",
        "hiddenInfo": "「빈손 사냥」에서 주인공을 습격한다. 가호를 빼앗기면 빈손이 되어 왕도를 떠돌다, 「팔려 간 밤」에서 현상금을 노리는 밀고자 중 하나로 나타날 수 있다."
      },
      {
        "id": "bern",
        "name": "베른",
        "hiddenInfo": "「투기장 예선」의 준결승 상대. 가호를 빼앗기면 후원 귀족에게 버려진다."
      },
      {
        "id": "ella",
        "name": "엘라",
        "hiddenInfo": "엘라의 치료비는 성좌교가 대 주며, 그것이 도로시를 정보원으로 묶어 두는 끈이다. 「새어 나간 계획」 이후 주인공 일행이 엘라를 지킬 수 있다. 결말에서 유리의 진료소나 주인공이 건넨 가호로 회복할 수 있다."
      },
      {
        "id": "hanbaek",
        "name": "빈손의 왕",
        "hiddenInfo": "정체는 300년 전 조선에서 떨어진 청년 한백. 주인공과 같은 그릇을 가진 다른 세계 사람이었다. 그는 폭군이 아니었다. 귀족에게서 빼앗은 가호를 빈손들에게 나눠 주다 성인(귀족)들에게 쫓겼다. 성인들은 그를 죽이지 못하고 별의 우물 밑바닥에 봉인해, 그의 그릇을 모든 가호의 저장소로 쓰고 있다. 그는 의식만 남은 채 살아 있다. 「우물 밑의 목소리」 사건에서야 처음으로 주인공에게 말을 건다. 그 전에는 본문에 직접 등장하거나 이름이 나오지 않는다. 그의 속내(구원을 원하는지, 몸을 원하는지)는 1부에서 확정하지 않는다."
      }
    ],
    "factionSecrets": [
      {
        "id": "church",
        "name": "성좌교",
        "hiddenGoal": "대주교의 장부, 가호 배정과 별읽기 무녀의 낭독 목록(배정을 별의 뜻으로 꾸미는 무대), 이단 처형과 회수, 약한 가호의 폐기(마수와 누더기 왕의 기원), 성녀 실험, 빈 가면. 길드 접수원 도로시 같은 정보원을 곳곳에 둔다."
      },
      {
        "id": "alley",
        "name": "잿골목 사람들",
        "hiddenGoal": "많은 이가 처형된 마르타를 기억한다. 주인공이 빈손으로 만든 사람이 몇 명인지에 따라 그를 영웅으로도, 괴물로도 본다. 지하에는 무너진 옛 예배당이 있다."
      },
      {
        "id": "guild",
        "name": "모험가 길드",
        "hiddenGoal": "길드 상층부는 등록되지 않은 가호의 소문을 성좌교에 판다. 위조 증표로 빈손임을 숨긴 모험가가 몇 있다(레온)."
      },
      {
        "id": "crown",
        "name": "왕실과 투기장",
        "hiddenGoal": "레녹스는 한량을 연기하며 성좌교를 무너뜨릴 기회를 노린다. 왕실 근위대 일부가 그를 따른다. 대주교는 손녀 에스텔과 레녹스의 정략 약혼으로 왕실을 묶어 두었다."
      },
      {
        "id": "shadow",
        "name": "그림자 시장",
        "hiddenGoal": "성좌교 전령과 길드 정보원들도 몰래 드나든다. 「곰발의 원한」 경로에서는 브로크가 이곳에서 성좌교와 손잡는다."
      }
    ],
    "hiddenCharacterRelations": [],
    "autonomyActors": [],
    "hiddenRelationshipMemories": [],
    "hiddenFactionRelations": [],
    "hiddenEvents": [
      {
        "id": "e01_empty",
        "name": "빈손",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 리네를 따라가지 않으면, 갈 곳 없는 그를 티오가 찾아내 다락으로 끌고 간다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "해 질 녘 잿골목. 곰발 브로크 일당이 주인공의 '반짝이는 상자'(스마트폰)를 내놓으라며 둘러싼다. 브로크의 팔뚝이 쇳빛으로 굳는 〈철피〉. 주인공에게는 상태창도 능력도 없다. 빨래 방망이를 든 세탁부 리네가 끼어들고, 막대기 검을 든 티오와 골목 아이들이 소란을 키운다. 리네는 구해 주기만 하는 사람이 아니다. 주인공의 허세에 바로 딴죽을 걸고, 둘이 말싸움을 하면서 함께 도망치거나 버틴다. 얻어맞든, 꾀로 빠져나가든, 주인공은 이 세계에서 자신이 아무것도 아니라는 걸 몸으로 배운다.\n\n[강화] 리네는 구조용 NPC가 아니라 첫 장면부터 시우의 허세를 받아치는 공동주역으로 쓴다.\n\n장면 제약: 이 세계에는 상태창이 없다. 주인공은 이 사건에서 어떤 가호도 얻지 못한다.",
        "required": true,
        "sequence": 1,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e02_attic",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e01_empty-c1",
            "description": "주인공이 브로크 일당과 부딪치며 자신에게 아무 능력도 없다는 것을 확인한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e01_empty-c2",
            "description": "리네와 티오가 끼어들고, 주인공과 리네가 서로 이름을 나눈다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e01_empty-c3",
            "description": "소동이 일단 끝나고 리네가 주인공을 자기 집으로 데려간다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e01_empty-constraints",
            "description": "이 세계에는 상태창이 없다. 주인공은 이 사건에서 어떤 가호도 얻지 못한다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "빈손",
        "summary": "해 질 녘 잿골목. 곰발 브로크 일당이 주인공의 '반짝이는 상자'(스마트폰)를 내놓으라며 둘러싼다. 브로크의 팔뚝이 쇳빛으로 굳는 〈철피〉. 주인공에게는 상태창도 능력도 없다. 빨래 방망이를 든 세탁부 리네가 끼어들고, 막대기 검을 든 티오와 골목 아이들이 소란을 키운다. 리네는 구해 주기만 하는 사람이 아니다. 주인공의 허세에 바로 딴죽을 걸고, 둘이 말싸움을 하면서 함께 도망치거나 버틴다. 얻어맞든, 꾀로 빠져나가든, 주인공은 이 세계에서 자신이 아무것도 아니라는 걸 몸으로 배운다.\n\n[강화] 리네는 구조용 NPC가 아니라 첫 장면부터 시우의 허세를 받아치는 공동주역으로 쓴다.\n\n장면 제약: 이 세계에는 상태창이 없다. 주인공은 이 사건에서 어떤 가호도 얻지 못한다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 브로크 일당과 부딪치며 자신에게 아무 능력도 없다는 것을 확인한다.\n\n리네와 티오가 끼어들고, 주인공과 리네가 서로 이름을 나눈다.\n\n소동이 일단 끝나고 리네가 주인공을 자기 집으로 데려간다.",
          "selectionScope": "",
          "constraints": "이 세계에는 상태창이 없다. 주인공은 이 사건에서 어떤 가호도 얻지 못한다.",
          "success": "",
          "unmet": "주인공이 리네를 따라가지 않으면, 갈 곳 없는 그를 티오가 찾아내 다락으로 끌고 간다.",
          "closureConditions": [
            {
              "id": "e01_empty-c1",
              "text": "주인공이 브로크 일당과 부딪치며 자신에게 아무 능력도 없다는 것을 확인한다."
            },
            {
              "id": "e01_empty-c2",
              "text": "리네와 티오가 끼어들고, 주인공과 리네가 서로 이름을 나눈다."
            },
            {
              "id": "e01_empty-c3",
              "text": "소동이 일단 끝나고 리네가 주인공을 자기 집으로 데려간다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e01_empty-constraints",
            "description": "이 세계에는 상태창이 없다. 주인공은 이 사건에서 어떤 가호도 얻지 못한다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e02_attic",
        "name": "다락방의 첫 밤",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 일찍 잠들면, 한밤중 물소리에 깨어 창밖에서 동그라미를 지우는 리네를 본다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "세탁장 다락. 젖은 롱패딩을 빨랫줄에 널고, 리네가 내민 딱딱한 빵과 묽은 수프를 셋이 나눠 먹는다. 설명이 아니라 생활 속에서 이 세계를 배운다. 열 살 '별의 의식'에서 누구나 가호 하나를 받는다. 가호가 없는 사람은 '빈손'이라 불리며 땅도 직업도 제대로 못 갖는다. 리네도 빈손이고, 티오는 다음 달 의식을 기다린다. 의식에는 헌금이 필요해서 리네는 깡통에 동전을 모은다. 주인공도 가호가 없으니 이 세계 기준으로 빈손이다. 티오가 잠든 뒤, 리네의 손가락 끝에 묻은 분필 가루. 창밖 골목의 분필 동그라미를 리네가 몰래 물로 지우는 모습. 주인공은 독서실에서 들은 여자애 목소리를 떠올린다.\n\n[강화] 다락에서는 설명만 하지 말고 빵·수프·젖은 롱패딩 같은 생활 장면으로 두 사람의 첫 유대감을 만든다. 끝에는 분필 자국과 독서실의 목소리를 겹쳐 다음 화 궁금증을 남긴다.\n\n이 장면에 심을 복선: 분필 동그라미와 독서실의 목소리\n리네 손끝의 분필 가루와 물로 지워지는 골목의 동그라미를 보여 주고, 주인공이 독서실에서 들은 '빼앗을 수 있는 사람을'이라는 목소리를 문득 떠올리게 한다. 이유는 말하지 않는다.\n리네가 엄마의 책 속 그림을 따라 분필로 동그라미를 그리고 빌어 주인공을 불렀다는 고백으로 이어진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 깡통 속 의식 헌금\n리네가 티오의 의식 헌금을 위해 깡통에 동전을 모으는 모습을 생활 장면으로 보여 준다.\n빈손 가정의 의식 헌금이 성녀 실험에 쓰였다는 장부 기록으로 뒤집힌다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 분필 동그라미의 의미는 이 사건에서 밝혀지지 않는다.",
        "required": true,
        "sequence": 2,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e03_rat",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e02_attic-c1",
            "description": "리네·티오와 저녁을 먹으며 주인공이 가호와 빈손, 별의 의식에 대해 듣는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e02_attic-c2",
            "description": "주인공이 자신도 이 세계에서 빈손 취급을 받는다는 것을 깨닫는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e02_attic-c3",
            "description": "리네가 골목의 분필 동그라미를 지우는 모습이나 그녀 손끝의 분필 가루가 장면에 나온다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e02_attic-constraints",
            "description": "분필 동그라미의 의미는 이 사건에서 밝혀지지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "다락방의 첫 밤",
        "summary": "세탁장 다락. 젖은 롱패딩을 빨랫줄에 널고, 리네가 내민 딱딱한 빵과 묽은 수프를 셋이 나눠 먹는다. 설명이 아니라 생활 속에서 이 세계를 배운다. 열 살 '별의 의식'에서 누구나 가호 하나를 받는다. 가호가 없는 사람은 '빈손'이라 불리며 땅도 직업도 제대로 못 갖는다. 리네도 빈손이고, 티오는 다음 달 의식을 기다린다. 의식에는 헌금이 필요해서 리네는 깡통에 동전을 모은다. 주인공도 가호가 없으니 이 세계 기준으로 빈손이다. 티오가 잠든 뒤, 리네의 손가락 끝에 묻은 분필 가루. 창밖 골목의 분필 동그라미를 리네가 몰래 물로 지우는 모습. 주인공은 독서실에서 들은 여자애 목소리를 떠올린다.\n\n[강화] 다락에서는 설명만 하지 말고 빵·수프·젖은 롱패딩 같은 생활 장면으로 두 사람의 첫 유대감을 만든다. 끝에는 분필 자국과 독서실의 목소리를 겹쳐 다음 화 궁금증을 남긴다.\n\n이 장면에 심을 복선: 분필 동그라미와 독서실의 목소리\n리네 손끝의 분필 가루와 물로 지워지는 골목의 동그라미를 보여 주고, 주인공이 독서실에서 들은 '빼앗을 수 있는 사람을'이라는 목소리를 문득 떠올리게 한다. 이유는 말하지 않는다.\n리네가 엄마의 책 속 그림을 따라 분필로 동그라미를 그리고 빌어 주인공을 불렀다는 고백으로 이어진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 깡통 속 의식 헌금\n리네가 티오의 의식 헌금을 위해 깡통에 동전을 모으는 모습을 생활 장면으로 보여 준다.\n빈손 가정의 의식 헌금이 성녀 실험에 쓰였다는 장부 기록으로 뒤집힌다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 분필 동그라미의 의미는 이 사건에서 밝혀지지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "리네·티오와 저녁을 먹으며 주인공이 가호와 빈손, 별의 의식에 대해 듣는다.\n\n주인공이 자신도 이 세계에서 빈손 취급을 받는다는 것을 깨닫는다.\n\n리네가 골목의 분필 동그라미를 지우는 모습이나 그녀 손끝의 분필 가루가 장면에 나온다.",
          "selectionScope": "",
          "constraints": "분필 동그라미의 의미는 이 사건에서 밝혀지지 않는다.",
          "success": "",
          "unmet": "주인공이 일찍 잠들면, 한밤중 물소리에 깨어 창밖에서 동그라미를 지우는 리네를 본다.",
          "closureConditions": [
            {
              "id": "e02_attic-c1",
              "text": "리네·티오와 저녁을 먹으며 주인공이 가호와 빈손, 별의 의식에 대해 듣는다."
            },
            {
              "id": "e02_attic-c2",
              "text": "주인공이 자신도 이 세계에서 빈손 취급을 받는다는 것을 깨닫는다."
            },
            {
              "id": "e02_attic-c3",
              "text": "리네가 골목의 분필 동그라미를 지우는 모습이나 그녀 손끝의 분필 가루가 장면에 나온다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e02_attic-constraints",
            "description": "분필 동그라미의 의미는 이 사건에서 밝혀지지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e03_rat",
        "name": "잿쥐의 밤",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 끝내 잿쥐를 쓰러뜨리지 못하면, 리네가 등불 기름을 끼얹어 잿쥐가 비틀거리고 주인공의 마지막 일격에 쓰러지며 가호가 넘어온다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "그날 밤, 하수구에서 개만 한 마수 '잿쥐'가 기어 나와 골목 아이들과 티오를 덮친다. 등불이 꺼진 골목에서도 잿쥐는 본다. 주인공은 가진 것(스마트폰 손전등, 문제집, 샤프, 빨랫줄, 잔머리)으로 맞서야 한다. 리네도 골목 지리와 빨래 방망이로 함께 싸운다.\n숨이 끊어지는 잿쥐에게 손이 닿는 순간, 따뜻한 빛이 손바닥으로 흘러들고 머릿속에 단어 하나가 떠오른다. 〈어둠눈〉. 잿쥐의 마지막 감정(지독한 굶주림)이 한순간 스친다. 다음 순간 캄캄한 골목이 희미한 새벽처럼 보인다. 주인공은 쓰러뜨린 상대의 가호를 손을 뻗어 가져올 수 있다는 걸 깨닫는다. 이것이 그의 유일한 힘이다. 리네에게 말할지는 주인공의 선택. 소동이 끝난 뒤, 골목 어귀에 회색 두건을 쓴 소녀가 얼어붙은 채 서 있다. 비단 장갑, 이 골목에 어울리지 않는 옷자락. 두건 아래에서 별처럼 반짝이던 눈이 그와 마주치자, 소녀는 어둠 속으로 사라진다. 그녀는 빛이 쥐에게서 사람에게로 건너가는 것을 보았다. 건너편 지붕 위에서는 커다란 모자를 쓴 엘프 꼬마가 계피 막대를 씹으며 \"흐응\" 하고 웃는다.\n\n[핵심 공개] 주인공은 쓰러뜨린 상대의 가호를 가져올 수 있다.\n\n[강화] 스마트폰 불빛·빨랫줄·젖은 천을 연쇄 활용해 '약하지만 머리로 이긴다'는 쾌감을 준다. 리네도 골목 지리와 빨래 방망이로 적극적으로 싸우며 즉석 호흡을 맞춘다. 전투 뒤 서로 손이 떨리는 것을 들키는 짧은 장면으로 동료감과 설렘의 씨앗을 심는다.\n\n이 장면에 심을 복선: 가호에 남은 마지막 마음\n가호를 가져올 때마다 원래 주인의 마지막 감정이 한순간 스치게 한다.\n별의 우물을 떠도는 수천 개의 가호마다 주인의 마지막 마음이 남아 있는 광경으로, 일기의 '빼앗은 가호는 무겁다'가 눈앞에 펼쳐진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 잿쥐는 아이들을 죽이지 못한다. 두건 쓴 소녀는 이 사건에서 말을 걸지 않는다.",
        "required": true,
        "sequence": 3,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e04_day",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e03_rat-c1",
            "description": "잿쥐가 아이들을 덮치고 주인공이 맞선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e03_rat-c2",
            "description": "주인공이 잿쥐를 쓰러뜨리고 〈어둠눈〉을 얻는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e03_rat-c3",
            "description": "주인공이 쓰러뜨린 상대의 가호를 가져올 수 있다는 자신의 힘을 처음으로 실감한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e03_rat-c4",
            "description": "골목 어귀의 두건 쓴 소녀가 그 장면을 보고 사라진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e03_rat-constraints",
            "description": "잿쥐는 아이들을 죽이지 못한다. 두건 쓴 소녀는 이 사건에서 말을 걸지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "잿쥐의 밤",
        "summary": "그날 밤, 하수구에서 개만 한 마수 '잿쥐'가 기어 나와 골목 아이들과 티오를 덮친다. 등불이 꺼진 골목에서도 잿쥐는 본다. 주인공은 가진 것(스마트폰 손전등, 문제집, 샤프, 빨랫줄, 잔머리)으로 맞서야 한다. 리네도 골목 지리와 빨래 방망이로 함께 싸운다.\n숨이 끊어지는 잿쥐에게 손이 닿는 순간, 따뜻한 빛이 손바닥으로 흘러들고 머릿속에 단어 하나가 떠오른다. 〈어둠눈〉. 잿쥐의 마지막 감정(지독한 굶주림)이 한순간 스친다. 다음 순간 캄캄한 골목이 희미한 새벽처럼 보인다. 주인공은 쓰러뜨린 상대의 가호를 손을 뻗어 가져올 수 있다는 걸 깨닫는다. 이것이 그의 유일한 힘이다. 리네에게 말할지는 주인공의 선택. 소동이 끝난 뒤, 골목 어귀에 회색 두건을 쓴 소녀가 얼어붙은 채 서 있다. 비단 장갑, 이 골목에 어울리지 않는 옷자락. 두건 아래에서 별처럼 반짝이던 눈이 그와 마주치자, 소녀는 어둠 속으로 사라진다. 그녀는 빛이 쥐에게서 사람에게로 건너가는 것을 보았다. 건너편 지붕 위에서는 커다란 모자를 쓴 엘프 꼬마가 계피 막대를 씹으며 \"흐응\" 하고 웃는다.\n\n[핵심 공개] 주인공은 쓰러뜨린 상대의 가호를 가져올 수 있다.\n\n[강화] 스마트폰 불빛·빨랫줄·젖은 천을 연쇄 활용해 '약하지만 머리로 이긴다'는 쾌감을 준다. 리네도 골목 지리와 빨래 방망이로 적극적으로 싸우며 즉석 호흡을 맞춘다. 전투 뒤 서로 손이 떨리는 것을 들키는 짧은 장면으로 동료감과 설렘의 씨앗을 심는다.\n\n이 장면에 심을 복선: 가호에 남은 마지막 마음\n가호를 가져올 때마다 원래 주인의 마지막 감정이 한순간 스치게 한다.\n별의 우물을 떠도는 수천 개의 가호마다 주인의 마지막 마음이 남아 있는 광경으로, 일기의 '빼앗은 가호는 무겁다'가 눈앞에 펼쳐진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 잿쥐는 아이들을 죽이지 못한다. 두건 쓴 소녀는 이 사건에서 말을 걸지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "잿쥐가 아이들을 덮치고 주인공이 맞선다.\n\n주인공이 잿쥐를 쓰러뜨리고 〈어둠눈〉을 얻는다.\n\n주인공이 쓰러뜨린 상대의 가호를 가져올 수 있다는 자신의 힘을 처음으로 실감한다.\n\n골목 어귀의 두건 쓴 소녀가 그 장면을 보고 사라진다.",
          "selectionScope": "",
          "constraints": "잿쥐는 아이들을 죽이지 못한다. 두건 쓴 소녀는 이 사건에서 말을 걸지 않는다.",
          "success": "",
          "unmet": "주인공이 끝내 잿쥐를 쓰러뜨리지 못하면, 리네가 등불 기름을 끼얹어 잿쥐가 비틀거리고 주인공의 마지막 일격에 쓰러지며 가호가 넘어온다.",
          "closureConditions": [
            {
              "id": "e03_rat-c1",
              "text": "잿쥐가 아이들을 덮치고 주인공이 맞선다."
            },
            {
              "id": "e03_rat-c2",
              "text": "주인공이 잿쥐를 쓰러뜨리고 〈어둠눈〉을 얻는다."
            },
            {
              "id": "e03_rat-c3",
              "text": "주인공이 쓰러뜨린 상대의 가호를 가져올 수 있다는 자신의 힘을 처음으로 실감한다."
            },
            {
              "id": "e03_rat-c4",
              "text": "골목 어귀의 두건 쓴 소녀가 그 장면을 보고 사라진다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e03_rat-constraints",
            "description": "잿쥐는 아이들을 죽이지 못한다. 두건 쓴 소녀는 이 사건에서 말을 걸지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e04_day",
        "name": "빈손의 하루",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 일을 구하지 못하면 리네가 빨래 짜기를 시키고, 품삯 대신 저녁을 준다. 주인공이 우물가에 가지 않으면, 에스텔이 빨래터까지 찾아와 \"자리가 셋인 분, 잠깐 이야기해요\"라고 한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "다음 날. 주인공은 밥값을 벌어야 한다. 짐꾼 일, 하수구 퍼내기, 빨래 짜기. 빈손의 품삯은 가호자의 절반이고, 가게 앞에는 '빈손 사절' 팻말이 걸려 있다. 리네는 빨래터에서 잔소리를 퍼붓다가도 빨래를 짤 때면 엄마에게 배웠다는 낮은 노래를 흥얼거리고, 티오는 막대기 검으로 기사 놀이를 하며 따라다닌다. 주인공은 〈어둠눈〉을 몰래 시험하며 규칙을 익힌다(어두우면 보이고, 밝은 햇빛에는 눈이 부시다). 저녁 무렵 브로크 일당이 가게마다 자릿세를 뜯고, 돈을 못 낸 노점이 엎어지는 모습을 본다. 웃기고 서러운 하루.\n해 질 녘 우물가. 어젯밤의 두건 소녀가 그를 기다리고 있다. 이번에는 도망치지 않는다. 두건 아래로 허리까지 흘러내리는 흑갈색 생머리, 별빛이 어린 듯한 갈색 눈. \"에스텔이라고 불러 주세요.\" 그녀는 사람의 가슴속 가호가 등불처럼, 빈자리가 어두운 홈처럼 보인다고 한다. \"사람은 자리가 하나예요. 그런데 당신은 셋이에요. 어젯밤, 쥐의 빛이 당신한테 건너가는 걸 봤어요.\" 의식 밖에서 생긴 빛은 성좌교가 찾아내 거둬 간다는 소문, 빈 가면. 그녀는 알려야 할 이유를 알면서도 알리지 않겠다고 한다. 대신 부탁 하나. \"아랫동네를 보여 주세요. 저는 늘 여기 몰래 내려와요.\" 빵값으로 금화를 내밀다 빵집 아주머니를 기절시킬 뻔하고, 골목 고양이를 처음 만져 보고, 별 이야기를 시작하면 멈추지 않는다. 그리고 문득 주인공을 본다. 사람의 속을 다 보는 눈으로, 처음으로 '더 보고 싶은' 사람을 만난 얼굴로. 골목 끝에서 횃불이 흔들린다. \"아가씨!\" 호위 기사의 목소리에 그녀는 두건을 다시 쓰고 사라진다. 빨래 바구니를 든 리네가 팔짱을 낀다. \"……뭐야, 저 반짝이는 애는.\"\n\n[핵심 공개] 두건 소녀 에스텔은 사람의 가호와 빈자리를 빛으로 본다. 그녀는 주인공의 그릇이 세 칸이라는 것을 안다.\n\n이 장면에 심을 복선: 리네의 빨래 노래\n빨래를 짜며 흥얼거리는 리네의 낮은 노래를 생활의 소리로만 들려준다.\n가면 아래의 셀레네가 같은 노래를 불렀고, 자매가 엄마에게 배운 노래였음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 빛을 보는 눈\n에스텔이 이름과 '빛을 보는 눈'만 밝히고, 그 눈이 무엇인지, 왜 성좌교의 사냥을 아는지는 말하지 않게 한다.\n그녀가 아스트레아 공작가의 별읽기 무녀였음이 밝혀진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 이 사건에서 브로크와 정면으로 싸우지 않는다. 에스텔은 주인공을 고발하지 않는다. 에스텔의 집안과 신분은 이 사건에서 드러나지 않는다.",
        "required": true,
        "sequence": 4,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e05_doctor",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e04_day-c1",
            "description": "주인공이 잿골목에서 일을 하며 빈손이 받는 차별을 직접 겪는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e04_day-c2",
            "description": "주인공이 〈어둠눈〉의 규칙을 시험한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e04_day-c3",
            "description": "브로크 일당이 자릿세를 뜯는 모습을 본다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e04_day-c4",
            "description": "해 질 녘 우물가에서 두건 쓴 소녀가 주인공을 찾아와 이름을 밝히고, 어젯밤 본 것을 말한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e04_day-c5",
            "description": "두 사람 사이에 비밀 약속이 생긴다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e04_day-constraints",
            "description": "이 사건에서 브로크와 정면으로 싸우지 않는다. 에스텔은 주인공을 고발하지 않는다. 에스텔의 집안과 신분은 이 사건에서 드러나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "빈손의 하루",
        "summary": "다음 날. 주인공은 밥값을 벌어야 한다. 짐꾼 일, 하수구 퍼내기, 빨래 짜기. 빈손의 품삯은 가호자의 절반이고, 가게 앞에는 '빈손 사절' 팻말이 걸려 있다. 리네는 빨래터에서 잔소리를 퍼붓다가도 빨래를 짤 때면 엄마에게 배웠다는 낮은 노래를 흥얼거리고, 티오는 막대기 검으로 기사 놀이를 하며 따라다닌다. 주인공은 〈어둠눈〉을 몰래 시험하며 규칙을 익힌다(어두우면 보이고, 밝은 햇빛에는 눈이 부시다). 저녁 무렵 브로크 일당이 가게마다 자릿세를 뜯고, 돈을 못 낸 노점이 엎어지는 모습을 본다. 웃기고 서러운 하루.\n해 질 녘 우물가. 어젯밤의 두건 소녀가 그를 기다리고 있다. 이번에는 도망치지 않는다. 두건 아래로 허리까지 흘러내리는 흑갈색 생머리, 별빛이 어린 듯한 갈색 눈. \"에스텔이라고 불러 주세요.\" 그녀는 사람의 가슴속 가호가 등불처럼, 빈자리가 어두운 홈처럼 보인다고 한다. \"사람은 자리가 하나예요. 그런데 당신은 셋이에요. 어젯밤, 쥐의 빛이 당신한테 건너가는 걸 봤어요.\" 의식 밖에서 생긴 빛은 성좌교가 찾아내 거둬 간다는 소문, 빈 가면. 그녀는 알려야 할 이유를 알면서도 알리지 않겠다고 한다. 대신 부탁 하나. \"아랫동네를 보여 주세요. 저는 늘 여기 몰래 내려와요.\" 빵값으로 금화를 내밀다 빵집 아주머니를 기절시킬 뻔하고, 골목 고양이를 처음 만져 보고, 별 이야기를 시작하면 멈추지 않는다. 그리고 문득 주인공을 본다. 사람의 속을 다 보는 눈으로, 처음으로 '더 보고 싶은' 사람을 만난 얼굴로. 골목 끝에서 횃불이 흔들린다. \"아가씨!\" 호위 기사의 목소리에 그녀는 두건을 다시 쓰고 사라진다. 빨래 바구니를 든 리네가 팔짱을 낀다. \"……뭐야, 저 반짝이는 애는.\"\n\n[핵심 공개] 두건 소녀 에스텔은 사람의 가호와 빈자리를 빛으로 본다. 그녀는 주인공의 그릇이 세 칸이라는 것을 안다.\n\n이 장면에 심을 복선: 리네의 빨래 노래\n빨래를 짜며 흥얼거리는 리네의 낮은 노래를 생활의 소리로만 들려준다.\n가면 아래의 셀레네가 같은 노래를 불렀고, 자매가 엄마에게 배운 노래였음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 빛을 보는 눈\n에스텔이 이름과 '빛을 보는 눈'만 밝히고, 그 눈이 무엇인지, 왜 성좌교의 사냥을 아는지는 말하지 않게 한다.\n그녀가 아스트레아 공작가의 별읽기 무녀였음이 밝혀진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 이 사건에서 브로크와 정면으로 싸우지 않는다. 에스텔은 주인공을 고발하지 않는다. 에스텔의 집안과 신분은 이 사건에서 드러나지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 잿골목에서 일을 하며 빈손이 받는 차별을 직접 겪는다.\n\n주인공이 〈어둠눈〉의 규칙을 시험한다.\n\n브로크 일당이 자릿세를 뜯는 모습을 본다.\n\n해 질 녘 우물가에서 두건 쓴 소녀가 주인공을 찾아와 이름을 밝히고, 어젯밤 본 것을 말한다.\n\n두 사람 사이에 비밀 약속이 생긴다.",
          "selectionScope": "",
          "constraints": "이 사건에서 브로크와 정면으로 싸우지 않는다. 에스텔은 주인공을 고발하지 않는다. 에스텔의 집안과 신분은 이 사건에서 드러나지 않는다.",
          "success": "",
          "unmet": "일을 구하지 못하면 리네가 빨래 짜기를 시키고, 품삯 대신 저녁을 준다. 주인공이 우물가에 가지 않으면, 에스텔이 빨래터까지 찾아와 \"자리가 셋인 분, 잠깐 이야기해요\"라고 한다.",
          "closureConditions": [
            {
              "id": "e04_day-c1",
              "text": "주인공이 잿골목에서 일을 하며 빈손이 받는 차별을 직접 겪는다."
            },
            {
              "id": "e04_day-c2",
              "text": "주인공이 〈어둠눈〉의 규칙을 시험한다."
            },
            {
              "id": "e04_day-c3",
              "text": "브로크 일당이 자릿세를 뜯는 모습을 본다."
            },
            {
              "id": "e04_day-c4",
              "text": "해 질 녘 우물가에서 두건 쓴 소녀가 주인공을 찾아와 이름을 밝히고, 어젯밤 본 것을 말한다."
            },
            {
              "id": "e04_day-c5",
              "text": "두 사람 사이에 비밀 약속이 생긴다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e04_day-constraints",
            "description": "이 사건에서 브로크와 정면으로 싸우지 않는다. 에스텔은 주인공을 고발하지 않는다. 에스텔의 집안과 신분은 이 사건에서 드러나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e05_doctor",
        "name": "잿골목의 의사",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 진료소에 가지 않으면 리네가 귀를 잡아끌고 데려간다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "무리한 탓에 열이 오른 주인공을 리네가 진료소로 끌고 간다. 늙은 의사 오스와 손녀 유리. 오스는 〈치유의 손〉 가호자인데도 빈손을 공짜로 고친다. 유리는 수줍다가도 상처 앞에서는 무섭게 혼낸다. 오스가 들려주는 이 세계의 속사정: 사람이 죽으면 가호는 별의 대성당의 '별의 우물'로 돌아가 다음 의식에서 다른 아이에게 간다. 우물로 돌아가지 못한 가호가 짐승에게 붙으면 마수가 된다. \"빈손이란 빈자리가 있는 사람이라는 뜻이기도 하지.\" 오스는 주인공의 손을 오래 들여다보고, 아무 말 없이 웃는다. 그의 손이 미세하게 떨린다.\n진찰이 끝날 무렵, 두건을 쓴 에스텔이 뒷문으로 들어온다. 눈이 아픈 듯 손등으로 눈가를 누르고 있다. 오스의 오래된 '비밀 환자'라고 유리가 귀띔한다. 에스텔은 주인공을 보고 작게 웃는다. \"또 만났네요, 자리가 셋인 분.\" 비단 장갑을 낀 아가씨가 왜 잿골목 의원에 눈을 보이러 오는지는 아무도 묻지 않는다. 오스는 두 사람을 번갈아 보고, 그저 웃는다.\n\n이 장면에 심을 복선: 빈자리가 있는 사람\n오스의 '빈손이란 빈자리가 있는 사람이라는 뜻이기도 하지'를 지나가는 말처럼 남긴다.\n〈성언〉은 빈자리가 있는 사람만 묶으므로, 빈자리를 채워 주는 것이 해법이 된다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 두건 소녀의 눈\n에스텔이 눈가를 누르며 오스의 비밀 환자로 찾아오는 모습만 보여 주고, 이유는 말하지 않는다.\n에스텔이 별읽기로 상한 눈을 3년 동안 오스에게 몰래 치료받았음이 장례에서 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 오스는 주인공의 힘을 눈치채도 고발하지 않는다. 에스텔의 집안과 신분, 눈을 치료받는 이유는 이 사건에서 드러나지 않는다.",
        "required": true,
        "sequence": 5,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e06_fortune",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e05_doctor-c1",
            "description": "오스와 유리가 주인공을 치료한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e05_doctor-c2",
            "description": "오스가 별의 우물과 마수에 대해 이야기한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e05_doctor-c3",
            "description": "오스가 빈자리에 대한 말을 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e05_doctor-c4",
            "description": "에스텔이 오스의 비밀 환자로 진료소에 나타난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e05_doctor-constraints",
            "description": "오스는 주인공의 힘을 눈치채도 고발하지 않는다. 에스텔의 집안과 신분, 눈을 치료받는 이유는 이 사건에서 드러나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "잿골목의 의사",
        "summary": "무리한 탓에 열이 오른 주인공을 리네가 진료소로 끌고 간다. 늙은 의사 오스와 손녀 유리. 오스는 〈치유의 손〉 가호자인데도 빈손을 공짜로 고친다. 유리는 수줍다가도 상처 앞에서는 무섭게 혼낸다. 오스가 들려주는 이 세계의 속사정: 사람이 죽으면 가호는 별의 대성당의 '별의 우물'로 돌아가 다음 의식에서 다른 아이에게 간다. 우물로 돌아가지 못한 가호가 짐승에게 붙으면 마수가 된다. \"빈손이란 빈자리가 있는 사람이라는 뜻이기도 하지.\" 오스는 주인공의 손을 오래 들여다보고, 아무 말 없이 웃는다. 그의 손이 미세하게 떨린다.\n진찰이 끝날 무렵, 두건을 쓴 에스텔이 뒷문으로 들어온다. 눈이 아픈 듯 손등으로 눈가를 누르고 있다. 오스의 오래된 '비밀 환자'라고 유리가 귀띔한다. 에스텔은 주인공을 보고 작게 웃는다. \"또 만났네요, 자리가 셋인 분.\" 비단 장갑을 낀 아가씨가 왜 잿골목 의원에 눈을 보이러 오는지는 아무도 묻지 않는다. 오스는 두 사람을 번갈아 보고, 그저 웃는다.\n\n이 장면에 심을 복선: 빈자리가 있는 사람\n오스의 '빈손이란 빈자리가 있는 사람이라는 뜻이기도 하지'를 지나가는 말처럼 남긴다.\n〈성언〉은 빈자리가 있는 사람만 묶으므로, 빈자리를 채워 주는 것이 해법이 된다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 두건 소녀의 눈\n에스텔이 눈가를 누르며 오스의 비밀 환자로 찾아오는 모습만 보여 주고, 이유는 말하지 않는다.\n에스텔이 별읽기로 상한 눈을 3년 동안 오스에게 몰래 치료받았음이 장례에서 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 오스는 주인공의 힘을 눈치채도 고발하지 않는다. 에스텔의 집안과 신분, 눈을 치료받는 이유는 이 사건에서 드러나지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "오스와 유리가 주인공을 치료한다.\n\n오스가 별의 우물과 마수에 대해 이야기한다.\n\n오스가 빈자리에 대한 말을 한다.\n\n에스텔이 오스의 비밀 환자로 진료소에 나타난다.",
          "selectionScope": "",
          "constraints": "오스는 주인공의 힘을 눈치채도 고발하지 않는다. 에스텔의 집안과 신분, 눈을 치료받는 이유는 이 사건에서 드러나지 않는다.",
          "success": "",
          "unmet": "주인공이 진료소에 가지 않으면 리네가 귀를 잡아끌고 데려간다.",
          "closureConditions": [
            {
              "id": "e05_doctor-c1",
              "text": "오스와 유리가 주인공을 치료한다."
            },
            {
              "id": "e05_doctor-c2",
              "text": "오스가 별의 우물과 마수에 대해 이야기한다."
            },
            {
              "id": "e05_doctor-c3",
              "text": "오스가 빈자리에 대한 말을 한다."
            },
            {
              "id": "e05_doctor-c4",
              "text": "에스텔이 오스의 비밀 환자로 진료소에 나타난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e05_doctor-constraints",
            "description": "오스는 주인공의 힘을 눈치채도 고발하지 않는다. 에스텔의 집안과 신분, 눈을 치료받는 이유는 이 사건에서 드러나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e06_fortune",
        "name": "지붕 위의 점쟁이",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 실피를 찾지 않으면, 실피가 진료소 창문으로 거꾸로 매달려 고개를 내민다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "진료소 지붕 위 천막. 엘프 점쟁이 실피. 계피 막대, 할머니 말투, 장난. 실피가 들려주는 경전 속 빈손의 왕 전설: 가호를 빼앗아 왕이 되려던 폭군, 일곱 성인, \"가호를 빼앗는 손이 다시 나타나면 그 손을 불태우라.\" 주인공의 힘이 바로 그 손이다. 실피의 점: \"넌 빼앗고, 놓고, 결국은 건네게 될 게다.\" 그리고 혼잣말. \"그 녀석이랑 말버릇이 똑같구먼.\"\n\n이 장면에 심을 복선: 경전 속 폭군\n실피가 들려주는 폭군 빈손의 왕 전설과 '그 손을 불태우라'는 경전 구절을 공포담처럼 남긴다.\n일기로 빈손의 왕이 폭군이 아니라 가호를 나눠 주던 사람이었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 실피의 점\n'넌 빼앗고, 놓고, 결국은 건네게 될 게다'를 장난스러운 점괘처럼 들려준다.\n주인공이 처음으로 가호를 건네며 점괘의 마지막 말이 이루어진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 실피는 자신의 과거를 말하지 않는다.",
        "required": true,
        "sequence": 6,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e07_sewer",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e06_fortune-c1",
            "description": "실피가 주인공의 점을 봐 준다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e06_fortune-c2",
            "description": "주인공이 빈손의 왕 전설과 빼앗는 손을 불태우라는 경전 구절을 듣는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e06_fortune-c3",
            "description": "실피가 주인공을 보고 누군가를 떠올린 듯 혼잣말을 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e06_fortune-constraints",
            "description": "실피는 자신의 과거를 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "지붕 위의 점쟁이",
        "summary": "진료소 지붕 위 천막. 엘프 점쟁이 실피. 계피 막대, 할머니 말투, 장난. 실피가 들려주는 경전 속 빈손의 왕 전설: 가호를 빼앗아 왕이 되려던 폭군, 일곱 성인, \"가호를 빼앗는 손이 다시 나타나면 그 손을 불태우라.\" 주인공의 힘이 바로 그 손이다. 실피의 점: \"넌 빼앗고, 놓고, 결국은 건네게 될 게다.\" 그리고 혼잣말. \"그 녀석이랑 말버릇이 똑같구먼.\"\n\n이 장면에 심을 복선: 경전 속 폭군\n실피가 들려주는 폭군 빈손의 왕 전설과 '그 손을 불태우라'는 경전 구절을 공포담처럼 남긴다.\n일기로 빈손의 왕이 폭군이 아니라 가호를 나눠 주던 사람이었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 실피의 점\n'넌 빼앗고, 놓고, 결국은 건네게 될 게다'를 장난스러운 점괘처럼 들려준다.\n주인공이 처음으로 가호를 건네며 점괘의 마지막 말이 이루어진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 실피는 자신의 과거를 말하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "실피가 주인공의 점을 봐 준다.\n\n주인공이 빈손의 왕 전설과 빼앗는 손을 불태우라는 경전 구절을 듣는다.\n\n실피가 주인공을 보고 누군가를 떠올린 듯 혼잣말을 한다.",
          "selectionScope": "",
          "constraints": "실피는 자신의 과거를 말하지 않는다.",
          "success": "",
          "unmet": "주인공이 실피를 찾지 않으면, 실피가 진료소 창문으로 거꾸로 매달려 고개를 내민다.",
          "closureConditions": [
            {
              "id": "e06_fortune-c1",
              "text": "실피가 주인공의 점을 봐 준다."
            },
            {
              "id": "e06_fortune-c2",
              "text": "주인공이 빈손의 왕 전설과 빼앗는 손을 불태우라는 경전 구절을 듣는다."
            },
            {
              "id": "e06_fortune-c3",
              "text": "실피가 주인공을 보고 누군가를 떠올린 듯 혼잣말을 한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e06_fortune-constraints",
            "description": "실피는 자신의 과거를 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e07_sewer",
        "name": "하수구 청소 의뢰",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 진흙떼를 쓰러뜨리지 못하면 리네가 수문을 열어 진흙떼를 쓸어 버리고, 주인공은 빠져나가며 별 모양 자국이 찍힌 사체를 본다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "리네가 물어 온 일감: 막힌 하수구 청소. 깊은 곳에는 물컹한 마수 '진흙떼'(〈미끄럼〉). 〈어둠눈〉이 처음으로 빛나는 순간이다. 리네와 골목 아이들, 미끄러운 통로와 오수의 물살. 진흙떼를 쓰러뜨리면 〈미끄럼〉을 가져올 수 있다. 처음으로 가호 두 개를 함께 쓰는 맛. 그리고 하수구 바닥, 오래 죽어 있던 마수 사체들의 몸에 찍힌 별 모양 자국. 누가, 왜?\n\n이 장면에 심을 복선: 마수 사체의 별 모양 자국\n하수구와 늪의 마수 사체에 찍힌 별 모양 자국을 설명 없이 보여 준다.\n쫓기던 일행이 가호석 창고에서, 별 모양 자국이 버려진 가호석의 표식이고 누더기 왕도 거기서 생겼음을 본다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "required": true,
        "sequence": 7,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e08_toll",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e07_sewer-c1",
            "description": "하수구에서 진흙떼와 맞선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e07_sewer-c2",
            "description": "주인공이 진흙떼를 쓰러뜨리고 가호를 가져올지 정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e07_sewer-c3",
            "description": "마수 사체의 별 모양 자국을 발견한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "하수구 청소 의뢰",
        "summary": "리네가 물어 온 일감: 막힌 하수구 청소. 깊은 곳에는 물컹한 마수 '진흙떼'(〈미끄럼〉). 〈어둠눈〉이 처음으로 빛나는 순간이다. 리네와 골목 아이들, 미끄러운 통로와 오수의 물살. 진흙떼를 쓰러뜨리면 〈미끄럼〉을 가져올 수 있다. 처음으로 가호 두 개를 함께 쓰는 맛. 그리고 하수구 바닥, 오래 죽어 있던 마수 사체들의 몸에 찍힌 별 모양 자국. 누가, 왜?\n\n이 장면에 심을 복선: 마수 사체의 별 모양 자국\n하수구와 늪의 마수 사체에 찍힌 별 모양 자국을 설명 없이 보여 준다.\n쫓기던 일행이 가호석 창고에서, 별 모양 자국이 버려진 가호석의 표식이고 누더기 왕도 거기서 생겼음을 본다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "하수구에서 진흙떼와 맞선다.\n\n주인공이 진흙떼를 쓰러뜨리고 가호를 가져올지 정한다.\n\n마수 사체의 별 모양 자국을 발견한다.",
          "selectionScope": "",
          "constraints": "",
          "success": "",
          "unmet": "진흙떼를 쓰러뜨리지 못하면 리네가 수문을 열어 진흙떼를 쓸어 버리고, 주인공은 빠져나가며 별 모양 자국이 찍힌 사체를 본다.",
          "closureConditions": [
            {
              "id": "e07_sewer-c1",
              "text": "하수구에서 진흙떼와 맞선다."
            },
            {
              "id": "e07_sewer-c2",
              "text": "주인공이 진흙떼를 쓰러뜨리고 가호를 가져올지 정한다."
            },
            {
              "id": "e07_sewer-c3",
              "text": "마수 사체의 별 모양 자국을 발견한다."
            }
          ]
        },
        "policyConstraints": [],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e08_toll",
        "name": "자릿세",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 계획을 세우지 않으면, 유리가 할아버지 몰래 진료소 열쇠를 들고 찾아와 도와 달라고 한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "브로크 일당이 진료소에 자릿세를 요구하고, 못 내면 내일 밤 불태우겠다고 협박한다. 유리가 떨면서도 할아버지 앞을 막아선다. 그날 밤 지붕 위에서 리네가 엄마 이야기를 꺼낸다. 눈을 마주치면 사람을 멈추게 하던 엄마는 7년 전 이단으로 끌려갔고, 언니 셀레네는 그보다 먼저 성녀 후보로 데려가졌다. 주인공은 브로크와 싸우기로 하고 계획을 세운다. 철피는 열 호흡, 어둠, 미끄러운 바닥, 골목 지형.\n\n이 장면에 심을 복선: 눈을 마주치면 멈추게 하던 엄마\n리네가 엄마의 가호를 '눈을 마주치면 사람을 멈추게 했다'고만 기억하게 한다.\n그 가호 〈굳힘〉이 엄마의 처형 뒤 카일에게 배정되었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 이 사건에서 본격적인 싸움은 일어나지 않는다.",
        "required": true,
        "sequence": 8,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e09_brokk",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e08_toll-c1",
            "description": "브로크 일당이 진료소를 협박한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e08_toll-c2",
            "description": "리네가 엄마와 언니 이야기를 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e08_toll-c3",
            "description": "주인공이 브로크와 맞설 계획을 세운다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e08_toll-constraints",
            "description": "이 사건에서 본격적인 싸움은 일어나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "자릿세",
        "summary": "브로크 일당이 진료소에 자릿세를 요구하고, 못 내면 내일 밤 불태우겠다고 협박한다. 유리가 떨면서도 할아버지 앞을 막아선다. 그날 밤 지붕 위에서 리네가 엄마 이야기를 꺼낸다. 눈을 마주치면 사람을 멈추게 하던 엄마는 7년 전 이단으로 끌려갔고, 언니 셀레네는 그보다 먼저 성녀 후보로 데려가졌다. 주인공은 브로크와 싸우기로 하고 계획을 세운다. 철피는 열 호흡, 어둠, 미끄러운 바닥, 골목 지형.\n\n이 장면에 심을 복선: 눈을 마주치면 멈추게 하던 엄마\n리네가 엄마의 가호를 '눈을 마주치면 사람을 멈추게 했다'고만 기억하게 한다.\n그 가호 〈굳힘〉이 엄마의 처형 뒤 카일에게 배정되었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 이 사건에서 본격적인 싸움은 일어나지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "브로크 일당이 진료소를 협박한다.\n\n리네가 엄마와 언니 이야기를 한다.\n\n주인공이 브로크와 맞설 계획을 세운다.",
          "selectionScope": "",
          "constraints": "이 사건에서 본격적인 싸움은 일어나지 않는다.",
          "success": "",
          "unmet": "주인공이 계획을 세우지 않으면, 유리가 할아버지 몰래 진료소 열쇠를 들고 찾아와 도와 달라고 한다.",
          "closureConditions": [
            {
              "id": "e08_toll-c1",
              "text": "브로크 일당이 진료소를 협박한다."
            },
            {
              "id": "e08_toll-c2",
              "text": "리네가 엄마와 언니 이야기를 한다."
            },
            {
              "id": "e08_toll-c3",
              "text": "주인공이 브로크와 맞설 계획을 세운다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e08_toll-constraints",
            "description": "이 사건에서 본격적인 싸움은 일어나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e09_brokk",
        "name": "곰발 브로크",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 혼자 힘으로 이기지 못하면, 골목 사람들이 던진 빨래통에 철피가 풀린 브로크가 넘어지고 주인공의 일격에 쓰러진다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "브로크 일당이 진료소에 불을 지르러 온 밤. 〈철피〉로 쇳덩이가 되는 브로크를 정면으로는 이길 수 없다. 〈어둠눈〉을 살려 등불을 꺼 버리거나, 함정과 꾀로 열 호흡의 철피가 풀리는 순간을 노려야 한다. 리네와 유리, 골목 사람들도 저마다 할 수 있는 일로 돕는다.\n브로크를 쓰러뜨리면 주인공은 처음으로 사람의 가호에 손을 뻗을지 결정해야 한다. 가져오면 〈철피〉는 주인공의 것이 되고 브로크는 빈손이 된다. 어제까지 그를 따르던 부하들이 그를 걷어차고, 그는 바닥을 기며 \"돌려줘… 두고 봐라\"라고 운다. 승리의 쾌감과 구역질이 한꺼번에 온다.\n\n[강화] 〈어둠눈〉을 제대로 써먹는 첫 보스전으로 만든다. 리네가 함정/등불/빨랫줄 중 하나를 맡아 합을 맞춘다. 철피의 매력을 충분히 보여 사이다를 먼저 주고, 강탈 뒤에 윤리적 후유증을 친다.\n\n이 장면에 심을 복선: 빈손이 된 브로크\n가호를 잃고 무너지는 브로크의 얼굴과 남은 원한을 가볍게 넘기지 않는다.\n결전에서 브로크가 몸을 던져 길을 열거나 밀고자로 나타났다 무너진다. 그가 어느 쪽인지는 지금까지의 선택이 정한다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 브로크는 이 사건에서 주인공을 죽이지 못한다. 진료소는 완전히 타지 않는다.",
        "required": true,
        "sequence": 9,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e10_fallen",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e09_brokk-c1",
            "description": "브로크 일당이 진료소를 습격하고 주인공이 맞선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e09_brokk-c2",
            "description": "주인공이 브로크를 쓰러뜨린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e09_brokk-c3",
            "description": "주인공이 브로크의 가호를 가져올지 결정하고, 그 결과가 장면에 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e09_brokk-constraints",
            "description": "브로크는 이 사건에서 주인공을 죽이지 못한다. 진료소는 완전히 타지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "곰발 브로크",
        "summary": "브로크 일당이 진료소에 불을 지르러 온 밤. 〈철피〉로 쇳덩이가 되는 브로크를 정면으로는 이길 수 없다. 〈어둠눈〉을 살려 등불을 꺼 버리거나, 함정과 꾀로 열 호흡의 철피가 풀리는 순간을 노려야 한다. 리네와 유리, 골목 사람들도 저마다 할 수 있는 일로 돕는다.\n브로크를 쓰러뜨리면 주인공은 처음으로 사람의 가호에 손을 뻗을지 결정해야 한다. 가져오면 〈철피〉는 주인공의 것이 되고 브로크는 빈손이 된다. 어제까지 그를 따르던 부하들이 그를 걷어차고, 그는 바닥을 기며 \"돌려줘… 두고 봐라\"라고 운다. 승리의 쾌감과 구역질이 한꺼번에 온다.\n\n[강화] 〈어둠눈〉을 제대로 써먹는 첫 보스전으로 만든다. 리네가 함정/등불/빨랫줄 중 하나를 맡아 합을 맞춘다. 철피의 매력을 충분히 보여 사이다를 먼저 주고, 강탈 뒤에 윤리적 후유증을 친다.\n\n이 장면에 심을 복선: 빈손이 된 브로크\n가호를 잃고 무너지는 브로크의 얼굴과 남은 원한을 가볍게 넘기지 않는다.\n결전에서 브로크가 몸을 던져 길을 열거나 밀고자로 나타났다 무너진다. 그가 어느 쪽인지는 지금까지의 선택이 정한다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 브로크는 이 사건에서 주인공을 죽이지 못한다. 진료소는 완전히 타지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "브로크 일당이 진료소를 습격하고 주인공이 맞선다.\n\n주인공이 브로크를 쓰러뜨린다.\n\n주인공이 브로크의 가호를 가져올지 결정하고, 그 결과가 장면에 드러난다.",
          "selectionScope": "",
          "constraints": "브로크는 이 사건에서 주인공을 죽이지 못한다. 진료소는 완전히 타지 않는다.",
          "success": "",
          "unmet": "주인공이 혼자 힘으로 이기지 못하면, 골목 사람들이 던진 빨래통에 철피가 풀린 브로크가 넘어지고 주인공의 일격에 쓰러진다.",
          "closureConditions": [
            {
              "id": "e09_brokk-c1",
              "text": "브로크 일당이 진료소를 습격하고 주인공이 맞선다."
            },
            {
              "id": "e09_brokk-c2",
              "text": "주인공이 브로크를 쓰러뜨린다."
            },
            {
              "id": "e09_brokk-c3",
              "text": "주인공이 브로크의 가호를 가져올지 결정하고, 그 결과가 장면에 드러난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e09_brokk-constraints",
            "description": "브로크는 이 사건에서 주인공을 죽이지 못한다. 진료소는 완전히 타지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e10_fallen",
        "name": "빈손이 된 남자",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 브로크를 찾지 않으면, 티오가 \"곰발 아저씨가 쓰레기통 옆에서 울고 있어\"라며 그를 데려간다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "다음 날. 잿골목의 공기가 달라졌다. 브로크의 일당은 흩어졌고, 사람들은 주인공을 영웅처럼, 혹은 괴물처럼 본다. 밤마다 빼앗은 가호의 마지막 감정이 꿈으로 찾아온다(브로크에게서 가져왔다면 그의 절망과 공포). 시장 뒤편에서 주인공은 브로크와 다시 마주친다. 빈손이 되었다면 그는 부하들에게 걷어차인 채 쓰레기 더미 옆에 앉아 있다. 가호를 지켰다면 패배로 체면을 잃고 골목을 떠나며 주인공을 노려본다. 빵을 건넬 수도, 지나칠 수도 있다. 그날 밤 우물가에서 에스텔이 브로크가 앉아 있던 쪽을 오래 본다. 가호를 빼앗았다면 그녀는 조용히 말한다. \"저 사람 가슴엔 이제 어두운 홈만 남았어요. …당신 안의 그 빛, 처음 것보다 무거워 보여요.\" 지켰다면, \"당신이 손을 거둔 걸 봤어요\"라고만 한다.",
        "required": true,
        "sequence": 10,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e11_housecall",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e10_fallen-c1",
            "description": "잿골목 사람들이 주인공을 대하는 태도가 달라진 것이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e10_fallen-c2",
            "description": "주인공이 빼앗은 가호의 무게나 싸움의 후유증을 겪는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e10_fallen-c3",
            "description": "주인공이 브로크와 다시 마주치고, 그를 어떻게 대할지 행동으로 보인다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "빈손이 된 남자",
        "summary": "다음 날. 잿골목의 공기가 달라졌다. 브로크의 일당은 흩어졌고, 사람들은 주인공을 영웅처럼, 혹은 괴물처럼 본다. 밤마다 빼앗은 가호의 마지막 감정이 꿈으로 찾아온다(브로크에게서 가져왔다면 그의 절망과 공포). 시장 뒤편에서 주인공은 브로크와 다시 마주친다. 빈손이 되었다면 그는 부하들에게 걷어차인 채 쓰레기 더미 옆에 앉아 있다. 가호를 지켰다면 패배로 체면을 잃고 골목을 떠나며 주인공을 노려본다. 빵을 건넬 수도, 지나칠 수도 있다. 그날 밤 우물가에서 에스텔이 브로크가 앉아 있던 쪽을 오래 본다. 가호를 빼앗았다면 그녀는 조용히 말한다. \"저 사람 가슴엔 이제 어두운 홈만 남았어요. …당신 안의 그 빛, 처음 것보다 무거워 보여요.\" 지켰다면, \"당신이 손을 거둔 걸 봤어요\"라고만 한다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "잿골목 사람들이 주인공을 대하는 태도가 달라진 것이 드러난다.\n\n주인공이 빼앗은 가호의 무게나 싸움의 후유증을 겪는다.\n\n주인공이 브로크와 다시 마주치고, 그를 어떻게 대할지 행동으로 보인다.",
          "selectionScope": "",
          "constraints": "",
          "success": "",
          "unmet": "주인공이 브로크를 찾지 않으면, 티오가 \"곰발 아저씨가 쓰레기통 옆에서 울고 있어\"라며 그를 데려간다.",
          "closureConditions": [
            {
              "id": "e10_fallen-c1",
              "text": "잿골목 사람들이 주인공을 대하는 태도가 달라진 것이 드러난다."
            },
            {
              "id": "e10_fallen-c2",
              "text": "주인공이 빼앗은 가호의 무게나 싸움의 후유증을 겪는다."
            },
            {
              "id": "e10_fallen-c3",
              "text": "주인공이 브로크와 다시 마주치고, 그를 어떻게 대할지 행동으로 보인다."
            }
          ]
        },
        "policyConstraints": [],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e11_housecall",
        "name": "유리의 왕진",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 사기꾼을 물리치지 못하면, 유리가 약병의 가짜 성분을 사람들 앞에서 밝혀 사기꾼이 도망친다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "오스가 지쳐 쓰러지자 유리가 혼자 왕진을 간다. 주인공은 짐꾼 겸 호위로 따라간다. 열병에 걸린 아이, 약값이 없는 집, 그리고 빈손 동네를 노리는 약장수 사기꾼. 유리는 떨면서도 '의사 모드'로 어른들을 호령한다. 주인공은 가진 가호와 꾀로 사기꾼을 쫓아낸다. 돌아오는 길, 유리가 털어놓는다. 할아버지의 손이 요즘 자주 떨린다고. 자기에게도 가호가 있었다면 좋겠다고.\n\n이 장면에 심을 복선: 유리의 소원\n할아버지의 떨리는 손과 '나에게도 가호가 있었다면' 하는 유리의 혼잣말을 남긴다.\n유리가 진료소를 다시 열며 자신의 방식으로 할아버지의 뒤를 잇는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.",
        "required": true,
        "sequence": 11,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e12_tio",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e11_housecall-c1",
            "description": "유리가 왕진에서 아이를 치료하고, 주인공이 그녀를 돕는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e11_housecall-c2",
            "description": "주인공이 빈손 동네를 노리는 사기꾼을 물리친다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e11_housecall-c3",
            "description": "유리가 할아버지와 자신에 대한 속마음을 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "유리의 왕진",
        "summary": "오스가 지쳐 쓰러지자 유리가 혼자 왕진을 간다. 주인공은 짐꾼 겸 호위로 따라간다. 열병에 걸린 아이, 약값이 없는 집, 그리고 빈손 동네를 노리는 약장수 사기꾼. 유리는 떨면서도 '의사 모드'로 어른들을 호령한다. 주인공은 가진 가호와 꾀로 사기꾼을 쫓아낸다. 돌아오는 길, 유리가 털어놓는다. 할아버지의 손이 요즘 자주 떨린다고. 자기에게도 가호가 있었다면 좋겠다고.\n\n이 장면에 심을 복선: 유리의 소원\n할아버지의 떨리는 손과 '나에게도 가호가 있었다면' 하는 유리의 혼잣말을 남긴다.\n유리가 진료소를 다시 열며 자신의 방식으로 할아버지의 뒤를 잇는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "유리가 왕진에서 아이를 치료하고, 주인공이 그녀를 돕는다.\n\n주인공이 빈손 동네를 노리는 사기꾼을 물리친다.\n\n유리가 할아버지와 자신에 대한 속마음을 털어놓는다.",
          "selectionScope": "",
          "constraints": "",
          "success": "",
          "unmet": "사기꾼을 물리치지 못하면, 유리가 약병의 가짜 성분을 사람들 앞에서 밝혀 사기꾼이 도망친다.",
          "closureConditions": [
            {
              "id": "e11_housecall-c1",
              "text": "유리가 왕진에서 아이를 치료하고, 주인공이 그녀를 돕는다."
            },
            {
              "id": "e11_housecall-c2",
              "text": "주인공이 빈손 동네를 노리는 사기꾼을 물리친다."
            },
            {
              "id": "e11_housecall-c3",
              "text": "유리가 할아버지와 자신에 대한 속마음을 털어놓는다."
            }
          ]
        },
        "policyConstraints": [],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e12_tio",
        "name": "티오의 막대기 검",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 티오를 찾지 못하면, 티오가 들고 나간 막대기 검이 덤불에 걸려 있는 것을 리네가 발견해 길을 찾는다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "의식을 앞두고 조바심이 난 티오가 마수 사냥으로 실력을 증명하겠다며 성벽 틈으로 몰래 나간다. 주인공과 리네가 쫓아간다. 성벽 밖 덤불의 작은 마수들, 그리고 티오를 노리는 더 큰 것. 구출 뒤 티오가 묻는다. \"형, 나도 가호 받을 수 있을까?\" 그날 밤 리네는 지붕 위에서 혼자 운다. 주인공이 그 자리에 갈지는 주인공의 몫이다.\n\n이 장면에 심을 복선: 형, 나도 가호 받을 수 있을까?\n티오의 질문에 주인공이 쉽게 대답하지 못하게 한다.\n의식장에서 티오가 처음 갖게 되는 가호가 장부의 배정이 아니라 누군가의 손에서 건네진 것이 된다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 티오는 다치더라도 크게 다치지 않는다.",
        "required": true,
        "sequence": 12,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e13_sylphie",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e12_tio-c1",
            "description": "티오가 몰래 성벽 밖으로 나가고, 주인공과 리네가 그를 찾아낸다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e12_tio-c2",
            "description": "위험에 빠진 티오를 구한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e12_tio-c3",
            "description": "티오가 의식과 가호에 대한 불안을 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e12_tio-constraints",
            "description": "티오는 다치더라도 크게 다치지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "티오의 막대기 검",
        "summary": "의식을 앞두고 조바심이 난 티오가 마수 사냥으로 실력을 증명하겠다며 성벽 틈으로 몰래 나간다. 주인공과 리네가 쫓아간다. 성벽 밖 덤불의 작은 마수들, 그리고 티오를 노리는 더 큰 것. 구출 뒤 티오가 묻는다. \"형, 나도 가호 받을 수 있을까?\" 그날 밤 리네는 지붕 위에서 혼자 운다. 주인공이 그 자리에 갈지는 주인공의 몫이다.\n\n이 장면에 심을 복선: 형, 나도 가호 받을 수 있을까?\n티오의 질문에 주인공이 쉽게 대답하지 못하게 한다.\n의식장에서 티오가 처음 갖게 되는 가호가 장부의 배정이 아니라 누군가의 손에서 건네진 것이 된다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 티오는 다치더라도 크게 다치지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "티오가 몰래 성벽 밖으로 나가고, 주인공과 리네가 그를 찾아낸다.\n\n위험에 빠진 티오를 구한다.\n\n티오가 의식과 가호에 대한 불안을 털어놓는다.",
          "selectionScope": "",
          "constraints": "티오는 다치더라도 크게 다치지 않는다.",
          "success": "",
          "unmet": "주인공이 티오를 찾지 못하면, 티오가 들고 나간 막대기 검이 덤불에 걸려 있는 것을 리네가 발견해 길을 찾는다.",
          "closureConditions": [
            {
              "id": "e12_tio-c1",
              "text": "티오가 몰래 성벽 밖으로 나가고, 주인공과 리네가 그를 찾아낸다."
            },
            {
              "id": "e12_tio-c2",
              "text": "위험에 빠진 티오를 구한다."
            },
            {
              "id": "e12_tio-c3",
              "text": "티오가 의식과 가호에 대한 불안을 털어놓는다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e12_tio-constraints",
            "description": "티오는 다치더라도 크게 다치지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e13_sylphie",
        "name": "실피의 시험",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 시험에 실패해도 실피는 \"칸 수는 셀 줄 아는구먼\"이라며 그릇이 세 칸이라는 것만은 알려 준다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "실피가 주인공을 지붕 위로 부른다. \"네 그릇이 몇 칸인지 재 보자꾸먼.\" 장난 같은 시험이 이어진다. 눈을 가리고 실피의 계피 막대 빼앗기, 가호 하나만으로 빨랫줄 미로 통과하기. 실피는 가호를 가슴 속 작은 등잔처럼 느끼는 법을 가르치고, 그릇이 세 칸이라는 걸 알려 준다. \"가득 차면 하나를 놓아야 한다. 놓는 것도 실력이여.\" 엘프에게는 가호 자리가 아예 없다는 것도. 주인공의 말버릇 하나에 실피가 잠깐 멍해지고, 모자 끈에 달린 구멍 뚫린 낡은 동전을 만지작거린다. 주인공은 그것이 교과서에서 본 조선의 동전(상평통보)과 닮았다는 걸 알아챌 수 있다. 실피는 \"주운 거여\"라며 얼버무린다.\n\n[핵심 공개] 주인공의 그릇은 세 칸이고, 가득 차면 하나를 놓아야 한다.\n\n이 장면에 심을 복선: 실피 모자 끈의 동전\n구멍 뚫린 낡은 동전이 조선의 상평통보와 닮았다는 것을 주인공만 알아챌 수 있게 한다.\n실피가 빈손의 왕의 동료였고 그 동전이 그가 준 것이었음이 밝혀진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 놓는 것도 실력\n실피의 '가득 차면 하나를 놓아야 한다. 놓는 것도 실력이여'를 훈련의 잔소리처럼 남긴다.\n셀레네를 살리려면 모은 힘을 놓아야 하는 순간, 그 말이 성장의 진짜 뜻으로 돌아온다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 실피는 자신의 과거를 말하지 않는다.",
        "required": true,
        "sequence": 13,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e14_stone",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e13_sylphie-c1",
            "description": "실피가 주인공에게 시험을 낸다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e13_sylphie-c2",
            "description": "주인공이 자신의 그릇이 세 칸이라는 것과 가득 차면 놓아야 한다는 것을 배운다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e13_sylphie-c3",
            "description": "실피의 모자 끈에 달린 낡은 동전이 장면에 나온다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e13_sylphie-c4",
            "description": "실피가 주인공을 돕기로 하거나, 언제든 지붕으로 오라고 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e13_sylphie-constraints",
            "description": "실피는 자신의 과거를 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "실피의 시험",
        "summary": "실피가 주인공을 지붕 위로 부른다. \"네 그릇이 몇 칸인지 재 보자꾸먼.\" 장난 같은 시험이 이어진다. 눈을 가리고 실피의 계피 막대 빼앗기, 가호 하나만으로 빨랫줄 미로 통과하기. 실피는 가호를 가슴 속 작은 등잔처럼 느끼는 법을 가르치고, 그릇이 세 칸이라는 걸 알려 준다. \"가득 차면 하나를 놓아야 한다. 놓는 것도 실력이여.\" 엘프에게는 가호 자리가 아예 없다는 것도. 주인공의 말버릇 하나에 실피가 잠깐 멍해지고, 모자 끈에 달린 구멍 뚫린 낡은 동전을 만지작거린다. 주인공은 그것이 교과서에서 본 조선의 동전(상평통보)과 닮았다는 걸 알아챌 수 있다. 실피는 \"주운 거여\"라며 얼버무린다.\n\n[핵심 공개] 주인공의 그릇은 세 칸이고, 가득 차면 하나를 놓아야 한다.\n\n이 장면에 심을 복선: 실피 모자 끈의 동전\n구멍 뚫린 낡은 동전이 조선의 상평통보와 닮았다는 것을 주인공만 알아챌 수 있게 한다.\n실피가 빈손의 왕의 동료였고 그 동전이 그가 준 것이었음이 밝혀진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 놓는 것도 실력\n실피의 '가득 차면 하나를 놓아야 한다. 놓는 것도 실력이여'를 훈련의 잔소리처럼 남긴다.\n셀레네를 살리려면 모은 힘을 놓아야 하는 순간, 그 말이 성장의 진짜 뜻으로 돌아온다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 실피는 자신의 과거를 말하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "실피가 주인공에게 시험을 낸다.\n\n주인공이 자신의 그릇이 세 칸이라는 것과 가득 차면 놓아야 한다는 것을 배운다.\n\n실피의 모자 끈에 달린 낡은 동전이 장면에 나온다.\n\n실피가 주인공을 돕기로 하거나, 언제든 지붕으로 오라고 한다.",
          "selectionScope": "",
          "constraints": "실피는 자신의 과거를 말하지 않는다.",
          "success": "",
          "unmet": "시험에 실패해도 실피는 \"칸 수는 셀 줄 아는구먼\"이라며 그릇이 세 칸이라는 것만은 알려 준다.",
          "closureConditions": [
            {
              "id": "e13_sylphie-c1",
              "text": "실피가 주인공에게 시험을 낸다."
            },
            {
              "id": "e13_sylphie-c2",
              "text": "주인공이 자신의 그릇이 세 칸이라는 것과 가득 차면 놓아야 한다는 것을 배운다."
            },
            {
              "id": "e13_sylphie-c3",
              "text": "실피의 모자 끈에 달린 낡은 동전이 장면에 나온다."
            },
            {
              "id": "e13_sylphie-c4",
              "text": "실피가 주인공을 돕기로 하거나, 언제든 지붕으로 오라고 한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e13_sylphie-constraints",
            "description": "실피는 자신의 과거를 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e14_stone",
        "name": "돌 등급",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 시비를 피하면, 카일이 먼저 다가와 \"같이 의뢰하실래요?\"라며 손을 내민다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "티오의 의식 헌금, 오스의 약값, 무엇보다 힘. 주인공은 중층 구역의 모험가 길드로 간다. 떠나는 아침, 리네가 도시락이나 손수건을 툭 건넨다. \"죽으면 세탁비 못 받으니까.\" 길드에서는 빈손이라 최하 '돌 등급' 딱지를 받고 웃음거리가 된다. 상냥한 접수원 도로시만 \"모험가님\"이라 부르며 챙겨 준다. 도로시는 상층 치료원에 입원한 여동생 엘라 이야기를 할 때 가장 환하게 웃고, 치료비가 비싸다는 말을 흘린다. 그녀가 쪽지 한 장을 성좌교 전령에게 슬쩍 건네는 모습이 스친다. 시비를 거는 귀족 모험가들 앞을 막아서는 건 해맑은 견습 기사 카일, 그리고 파이프를 문 능글맞은 은 등급 궁수 레온이다.\n\n[강화] 돌 등급 모욕→첫 정식 의뢰→새 가호 후보의 순서로 다음 보상을 계속 눈앞에 둔다. 출발 전 리네가 도시락이나 손수건을 툭 건네며 '죽으면 세탁비 못 받으니까'라고 둘러댈 수 있다.\n\n이 장면에 심을 복선: 도로시의 쪽지와 엘라\n상냥한 도로시가 성좌교 전령에게 쪽지를 건네는 모습을 한 줄로 스치게 하고, 여동생 엘라 이야기를 할 때 가장 환하게 웃으며 치료비가 비싸다는 말을 흘리게 한다.\n도로시가 엘라의 치료비 때문에 성좌교의 정보원이 되었고, 그 쪽지가 빈 가면의 습격을 불렀음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 이 사건에서 길드 사람들의 속사정은 드러나지 않는다.",
        "required": true,
        "sequence": 14,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e15_first_quest",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e14_stone-c1",
            "description": "리네가 떠나는 주인공에게 무언가를 건넨다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e14_stone-c2",
            "description": "주인공이 길드에 빈손으로 등록하고 돌 등급을 받는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e14_stone-c3",
            "description": "도로시, 카일, 레온과 만난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e14_stone-constraints",
            "description": "이 사건에서 길드 사람들의 속사정은 드러나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "돌 등급",
        "summary": "티오의 의식 헌금, 오스의 약값, 무엇보다 힘. 주인공은 중층 구역의 모험가 길드로 간다. 떠나는 아침, 리네가 도시락이나 손수건을 툭 건넨다. \"죽으면 세탁비 못 받으니까.\" 길드에서는 빈손이라 최하 '돌 등급' 딱지를 받고 웃음거리가 된다. 상냥한 접수원 도로시만 \"모험가님\"이라 부르며 챙겨 준다. 도로시는 상층 치료원에 입원한 여동생 엘라 이야기를 할 때 가장 환하게 웃고, 치료비가 비싸다는 말을 흘린다. 그녀가 쪽지 한 장을 성좌교 전령에게 슬쩍 건네는 모습이 스친다. 시비를 거는 귀족 모험가들 앞을 막아서는 건 해맑은 견습 기사 카일, 그리고 파이프를 문 능글맞은 은 등급 궁수 레온이다.\n\n[강화] 돌 등급 모욕→첫 정식 의뢰→새 가호 후보의 순서로 다음 보상을 계속 눈앞에 둔다. 출발 전 리네가 도시락이나 손수건을 툭 건네며 '죽으면 세탁비 못 받으니까'라고 둘러댈 수 있다.\n\n이 장면에 심을 복선: 도로시의 쪽지와 엘라\n상냥한 도로시가 성좌교 전령에게 쪽지를 건네는 모습을 한 줄로 스치게 하고, 여동생 엘라 이야기를 할 때 가장 환하게 웃으며 치료비가 비싸다는 말을 흘리게 한다.\n도로시가 엘라의 치료비 때문에 성좌교의 정보원이 되었고, 그 쪽지가 빈 가면의 습격을 불렀음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 이 사건에서 길드 사람들의 속사정은 드러나지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "리네가 떠나는 주인공에게 무언가를 건넨다.\n\n주인공이 길드에 빈손으로 등록하고 돌 등급을 받는다.\n\n도로시, 카일, 레온과 만난다.",
          "selectionScope": "",
          "constraints": "이 사건에서 길드 사람들의 속사정은 드러나지 않는다.",
          "success": "",
          "unmet": "주인공이 시비를 피하면, 카일이 먼저 다가와 \"같이 의뢰하실래요?\"라며 손을 내민다.",
          "closureConditions": [
            {
              "id": "e14_stone-c1",
              "text": "리네가 떠나는 주인공에게 무언가를 건넨다."
            },
            {
              "id": "e14_stone-c2",
              "text": "주인공이 길드에 빈손으로 등록하고 돌 등급을 받는다."
            },
            {
              "id": "e14_stone-c3",
              "text": "도로시, 카일, 레온과 만난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e14_stone-constraints",
            "description": "이 사건에서 길드 사람들의 속사정은 드러나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e15_first_quest",
        "name": "첫 의뢰",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 늑대를 쓰러뜨리지 못하면, 레온의 화살에 쓰러진 늑대가 숨이 붙은 채 주인공 앞에 떨어진다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "카일, 레온과 함께 성벽 밖 숲으로. 바람처럼 달리는 바람늑대 무리(〈바람발〉). 카일은 눈을 마주쳐 상대를 한 호흡 멈추는 〈굳힘〉을 자랑하고, 레온은 가호 없이 활과 판 읽기만으로 싸운다. \"가호는 손에 쥔 패일 뿐이야. 판을 읽어.\" 레온은 주인공의 싸움을 보고 무언가 눈치챈 듯 웃는다. 첫 정식 의뢰의 보수, 그리고 다음 보상이 계속 눈앞에 보인다.\n\n이 장면에 심을 복선: 레온의 눈치\n가호 없이 활과 판 읽기로만 싸우는 레온이 주인공을 보고 무언가 눈치챈 듯 웃게 한다.\n레온 역시 위조 증표를 가진 빈손이었음이 그라츠의 코끝에서 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 레온은 가호를 쓰지 않으며 이유를 말하지 않는다.",
        "required": true,
        "sequence": 15,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e16_full",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e15_first_quest-c1",
            "description": "숲에서 바람늑대와 싸운다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e15_first_quest-c2",
            "description": "주인공이 바람늑대를 쓰러뜨리고 가호를 가져올지 정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e15_first_quest-c3",
            "description": "카일이 〈굳힘〉을, 레온이 가호 없는 싸움을 보여 준다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e15_first_quest-constraints",
            "description": "레온은 가호를 쓰지 않으며 이유를 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "첫 의뢰",
        "summary": "카일, 레온과 함께 성벽 밖 숲으로. 바람처럼 달리는 바람늑대 무리(〈바람발〉). 카일은 눈을 마주쳐 상대를 한 호흡 멈추는 〈굳힘〉을 자랑하고, 레온은 가호 없이 활과 판 읽기만으로 싸운다. \"가호는 손에 쥔 패일 뿐이야. 판을 읽어.\" 레온은 주인공의 싸움을 보고 무언가 눈치챈 듯 웃는다. 첫 정식 의뢰의 보수, 그리고 다음 보상이 계속 눈앞에 보인다.\n\n이 장면에 심을 복선: 레온의 눈치\n가호 없이 활과 판 읽기로만 싸우는 레온이 주인공을 보고 무언가 눈치챈 듯 웃게 한다.\n레온 역시 위조 증표를 가진 빈손이었음이 그라츠의 코끝에서 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 레온은 가호를 쓰지 않으며 이유를 말하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "숲에서 바람늑대와 싸운다.\n\n주인공이 바람늑대를 쓰러뜨리고 가호를 가져올지 정한다.\n\n카일이 〈굳힘〉을, 레온이 가호 없는 싸움을 보여 준다.",
          "selectionScope": "",
          "constraints": "레온은 가호를 쓰지 않으며 이유를 말하지 않는다.",
          "success": "",
          "unmet": "주인공이 늑대를 쓰러뜨리지 못하면, 레온의 화살에 쓰러진 늑대가 숨이 붙은 채 주인공 앞에 떨어진다.",
          "closureConditions": [
            {
              "id": "e15_first_quest-c1",
              "text": "숲에서 바람늑대와 싸운다."
            },
            {
              "id": "e15_first_quest-c2",
              "text": "주인공이 바람늑대를 쓰러뜨리고 가호를 가져올지 정한다."
            },
            {
              "id": "e15_first_quest-c3",
              "text": "카일이 〈굳힘〉을, 레온이 가호 없는 싸움을 보여 준다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e15_first_quest-constraints",
            "description": "레온은 가호를 쓰지 않으며 이유를 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e16_full",
        "name": "가득 찬 그릇",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 그릇이 차지 않으면, 메아리새의 가호가 넘어오려는 순간 몸이 꽉 찬 듯 거부하며 하나를 놓아야 한다는 감각이 온다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "숲 깊은 곳, 들은 소리를 흉내 내는 메아리새(〈메아리〉). 동료 목소리를 흉내 내는 새에게 홀려 길을 잃을 뻔한다. 쓰러뜨렸을 때 그릇이 가득 찬다. 새 가호를 가지려면 하나를 놓아야 한다. 무엇을 놓을지 고르는 순간이 이 장의 클리프행어다. 놓은 가호는 빛이 되어 어디론가 날아가 사라진다. 돌아온 밤, 다락의 리네는 등불도 켜지 않고 바느질을 하고 있다.\n\n[강화] 그릇이 가득 찬 순간을 강한 다음 화 훅으로 삼는다.\n\n이 장면에 심을 복선: 놓은 가호의 빛\n놓은 가호가 빛이 되어 어디론가 날아가는 모습과 그날 밤 등불 없이 바느질하는 리네를 나란히 보여 준다.\n놓은 가호가 소환의 끈을 따라 리네에게 갔음이 밝혀진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 놓은 가호의 행방은 이 사건에서 밝혀지지 않는다.",
        "required": true,
        "sequence": 16,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e17_garrick",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e16_full-c1",
            "description": "메아리새를 쓰러뜨린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e16_full-c2",
            "description": "그릇이 가득 차서 주인공이 가호 하나를 놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e16_full-c3",
            "description": "놓은 가호가 빛이 되어 어디론가 사라지는 것을 본다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e16_full-constraints",
            "description": "놓은 가호의 행방은 이 사건에서 밝혀지지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "가득 찬 그릇",
        "summary": "숲 깊은 곳, 들은 소리를 흉내 내는 메아리새(〈메아리〉). 동료 목소리를 흉내 내는 새에게 홀려 길을 잃을 뻔한다. 쓰러뜨렸을 때 그릇이 가득 찬다. 새 가호를 가지려면 하나를 놓아야 한다. 무엇을 놓을지 고르는 순간이 이 장의 클리프행어다. 놓은 가호는 빛이 되어 어디론가 날아가 사라진다. 돌아온 밤, 다락의 리네는 등불도 켜지 않고 바느질을 하고 있다.\n\n[강화] 그릇이 가득 찬 순간을 강한 다음 화 훅으로 삼는다.\n\n이 장면에 심을 복선: 놓은 가호의 빛\n놓은 가호가 빛이 되어 어디론가 날아가는 모습과 그날 밤 등불 없이 바느질하는 리네를 나란히 보여 준다.\n놓은 가호가 소환의 끈을 따라 리네에게 갔음이 밝혀진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 놓은 가호의 행방은 이 사건에서 밝혀지지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "메아리새를 쓰러뜨린다.\n\n그릇이 가득 차서 주인공이 가호 하나를 놓는다.\n\n놓은 가호가 빛이 되어 어디론가 사라지는 것을 본다.",
          "selectionScope": "",
          "constraints": "놓은 가호의 행방은 이 사건에서 밝혀지지 않는다.",
          "success": "",
          "unmet": "그릇이 차지 않으면, 메아리새의 가호가 넘어오려는 순간 몸이 꽉 찬 듯 거부하며 하나를 놓아야 한다는 감각이 온다.",
          "closureConditions": [
            {
              "id": "e16_full-c1",
              "text": "메아리새를 쓰러뜨린다."
            },
            {
              "id": "e16_full-c2",
              "text": "그릇이 가득 차서 주인공이 가호 하나를 놓는다."
            },
            {
              "id": "e16_full-c3",
              "text": "놓은 가호가 빛이 되어 어디론가 사라지는 것을 본다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e16_full-constraints",
            "description": "놓은 가호의 행방은 이 사건에서 밝혀지지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e17_garrick",
        "name": "빈손 사냥",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 가릭을 이기지 못하면, 레온이 가릭의 다리를 쏘아 넘어뜨리고 결정을 주인공에게 맡긴다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "돌아오는 길, 동 등급 모험가 가릭 일당이 매복한다. 빈손 신입의 전리품을 털어먹는 하이에나. 가릭은 손댄 자물쇠를 여는 〈자물쇠 손〉을 가졌다. 카일과 레온이 다른 놈들을 상대하는 사이 주인공 혼자 가릭을 상대해야 한다. 이기면 다시 선택이 온다. 가릭의 가호를 가져올 것인가.\n\n장면 제약: 이 사건에서 주인공 일행은 아무도 죽지 않는다.",
        "required": true,
        "sequence": 17,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e18_estelle",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e17_garrick-c1",
            "description": "가릭 일당이 주인공 일행을 습격한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e17_garrick-c2",
            "description": "주인공이 가릭과 싸워 이긴다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e17_garrick-c3",
            "description": "주인공이 가릭의 가호를 가져올지 결정하고, 그 결과가 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e17_garrick-constraints",
            "description": "이 사건에서 주인공 일행은 아무도 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "빈손 사냥",
        "summary": "돌아오는 길, 동 등급 모험가 가릭 일당이 매복한다. 빈손 신입의 전리품을 털어먹는 하이에나. 가릭은 손댄 자물쇠를 여는 〈자물쇠 손〉을 가졌다. 카일과 레온이 다른 놈들을 상대하는 사이 주인공 혼자 가릭을 상대해야 한다. 이기면 다시 선택이 온다. 가릭의 가호를 가져올 것인가.\n\n장면 제약: 이 사건에서 주인공 일행은 아무도 죽지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "가릭 일당이 주인공 일행을 습격한다.\n\n주인공이 가릭과 싸워 이긴다.\n\n주인공이 가릭의 가호를 가져올지 결정하고, 그 결과가 드러난다.",
          "selectionScope": "",
          "constraints": "이 사건에서 주인공 일행은 아무도 죽지 않는다.",
          "success": "",
          "unmet": "주인공이 가릭을 이기지 못하면, 레온이 가릭의 다리를 쏘아 넘어뜨리고 결정을 주인공에게 맡긴다.",
          "closureConditions": [
            {
              "id": "e17_garrick-c1",
              "text": "가릭 일당이 주인공 일행을 습격한다."
            },
            {
              "id": "e17_garrick-c2",
              "text": "주인공이 가릭과 싸워 이긴다."
            },
            {
              "id": "e17_garrick-c3",
              "text": "주인공이 가릭의 가호를 가져올지 결정하고, 그 결과가 드러난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e17_garrick-constraints",
            "description": "이 사건에서 주인공 일행은 아무도 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e18_estelle",
        "name": "별읽는 영애",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 우물가에 가지 않으면, 에스텔이 다락 창문을 두드리며 \"오늘은 할 말이 있어요\"라고 한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "가릭 일당을 꺾었다는 소문이 돈 밤. 약속한 우물가에서 에스텔이 처음으로 두건을 벗고 기다린다. 오늘은 숨기지 않겠다고 한다. 에스텔 아스트레아. 아스트레아 공작가의 영애이자, 별의 의식에서 아이들의 가슴속 빛을 읽어 가호를 선포하는 '별읽기 무녀'. 의식 밖에서 생긴 빛을 가장 먼저 알아볼 수 있는 사람, 그러니까 그를 성좌교에 알려야 할 사람 그 자체다. 그래서 지금까지 말하지 못했다고. 그리고 아무에게도 못 한 질문을 한다. \"가호는 정말 별이 고르는 걸까요? 어떤 아이들의 빛은 대주교 예하의 축복을 받은 뒤에야 켜지거든요.\" 숨겨 온 것을 탓할지, 그래도 그녀 자신을 볼지는 주인공의 몫이다. 골목 끝에서 횃불이 흔들린다. \"아가씨!\" 공작가의 호위 기사다. 에스텔은 두건을 다시 쓰고 사라진다. 빨래 바구니를 든 리네가 눈을 가늘게 뜬다. \"……공작가? 너 지금 누구랑 밀회를 한 거야.\"\n\n[핵심 공개] 에스텔은 아스트레아 공작가의 영애이자 별의 의식의 별읽기 무녀다.\n\n이 장면에 심을 복선: 축복 뒤에 켜지는 빛\n에스텔이 '어떤 아이들의 빛은 대주교 예하의 축복을 받은 뒤에야 켜진다'고 지나가듯 묻게 한다.\n장부로 별의 의식이 대주교의 손을 거친 배정이었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에서 회수할 복선: 빛을 보는 눈\n그녀가 아스트레아 공작가의 별읽기 무녀였음이 밝혀진다.\n\n장면 제약: 에스텔은 이 사건에서 주인공을 고발하지 않는다. 에스텔은 이 사건에서 자기 집안 이야기를 길게 하지 않는다.",
        "required": true,
        "sequence": 18,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e19_pippin",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e18_estelle-c1",
            "description": "에스텔이 두건을 벗고 자신의 가문과 신분을 밝힌다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e18_estelle-c2",
            "description": "에스텔이 별의 의식에 대한 의문을 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e18_estelle-c3",
            "description": "주인공이 숨겨 왔던 그녀의 정체를 어떻게 받아들일지 행동으로 보인다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e18_estelle-c4",
            "description": "에스텔이 호위 기사에게 쫓겨 돌아간다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e18_estelle-constraints",
            "description": "에스텔은 이 사건에서 주인공을 고발하지 않는다. 에스텔은 이 사건에서 자기 집안 이야기를 길게 하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "별읽는 영애",
        "summary": "가릭 일당을 꺾었다는 소문이 돈 밤. 약속한 우물가에서 에스텔이 처음으로 두건을 벗고 기다린다. 오늘은 숨기지 않겠다고 한다. 에스텔 아스트레아. 아스트레아 공작가의 영애이자, 별의 의식에서 아이들의 가슴속 빛을 읽어 가호를 선포하는 '별읽기 무녀'. 의식 밖에서 생긴 빛을 가장 먼저 알아볼 수 있는 사람, 그러니까 그를 성좌교에 알려야 할 사람 그 자체다. 그래서 지금까지 말하지 못했다고. 그리고 아무에게도 못 한 질문을 한다. \"가호는 정말 별이 고르는 걸까요? 어떤 아이들의 빛은 대주교 예하의 축복을 받은 뒤에야 켜지거든요.\" 숨겨 온 것을 탓할지, 그래도 그녀 자신을 볼지는 주인공의 몫이다. 골목 끝에서 횃불이 흔들린다. \"아가씨!\" 공작가의 호위 기사다. 에스텔은 두건을 다시 쓰고 사라진다. 빨래 바구니를 든 리네가 눈을 가늘게 뜬다. \"……공작가? 너 지금 누구랑 밀회를 한 거야.\"\n\n[핵심 공개] 에스텔은 아스트레아 공작가의 영애이자 별의 의식의 별읽기 무녀다.\n\n이 장면에 심을 복선: 축복 뒤에 켜지는 빛\n에스텔이 '어떤 아이들의 빛은 대주교 예하의 축복을 받은 뒤에야 켜진다'고 지나가듯 묻게 한다.\n장부로 별의 의식이 대주교의 손을 거친 배정이었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에서 회수할 복선: 빛을 보는 눈\n그녀가 아스트레아 공작가의 별읽기 무녀였음이 밝혀진다.\n\n장면 제약: 에스텔은 이 사건에서 주인공을 고발하지 않는다. 에스텔은 이 사건에서 자기 집안 이야기를 길게 하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "에스텔이 두건을 벗고 자신의 가문과 신분을 밝힌다.\n\n에스텔이 별의 의식에 대한 의문을 털어놓는다.\n\n주인공이 숨겨 왔던 그녀의 정체를 어떻게 받아들일지 행동으로 보인다.\n\n에스텔이 호위 기사에게 쫓겨 돌아간다.",
          "selectionScope": "",
          "constraints": "에스텔은 이 사건에서 주인공을 고발하지 않는다. 에스텔은 이 사건에서 자기 집안 이야기를 길게 하지 않는다.",
          "success": "",
          "unmet": "주인공이 우물가에 가지 않으면, 에스텔이 다락 창문을 두드리며 \"오늘은 할 말이 있어요\"라고 한다.",
          "closureConditions": [
            {
              "id": "e18_estelle-c1",
              "text": "에스텔이 두건을 벗고 자신의 가문과 신분을 밝힌다."
            },
            {
              "id": "e18_estelle-c2",
              "text": "에스텔이 별의 의식에 대한 의문을 털어놓는다."
            },
            {
              "id": "e18_estelle-c3",
              "text": "주인공이 숨겨 왔던 그녀의 정체를 어떻게 받아들일지 행동으로 보인다."
            },
            {
              "id": "e18_estelle-c4",
              "text": "에스텔이 호위 기사에게 쫓겨 돌아간다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e18_estelle-constraints",
            "description": "에스텔은 이 사건에서 주인공을 고발하지 않는다. 에스텔은 이 사건에서 자기 집안 이야기를 길게 하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e19_pippin",
        "name": "피핀의 노래",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "떠돌이 음유시인 피핀이 \"빈손이 곰발을 꺾었다!\"는 노래를 열 배로 부풀려 술집마다 부른다. 주인공을 찾아온 피핀은 전기를 쓰겠다며 따라붙는다. 노래 덕에 의뢰가 들어오지만, 노래는 상층 구역까지 퍼진다. 피핀은 틈만 나면 수첩에 뭔가 적고 어딘가로 편지를 보낸다. 웃음이 많은 에피소드.\n\n이 장면에 심을 복선: 피핀의 편지\n피핀이 틈만 나면 수첩에 적고 어딘가로 편지를 보내는 모습을 개그로 넘긴다.\n피핀이 제2왕자 레녹스가 붙인 첩자였고, 너무 팬이 되어 보고서를 엉터리로 썼음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 피핀의 수첩과 편지는 이 사건에서 개그로만 다룬다.",
        "required": true,
        "sequence": 19,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e20_isolde",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e19_pippin-c1",
            "description": "피핀이 주인공에 대한 과장된 노래를 퍼뜨린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e19_pippin-c2",
            "description": "피핀이 주인공을 찾아와 전기 작가를 자처한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e19_pippin-c3",
            "description": "노래가 상층 구역까지 퍼졌다는 소식이 들린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e19_pippin-constraints",
            "description": "피핀의 수첩과 편지는 이 사건에서 개그로만 다룬다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "피핀의 노래",
        "summary": "떠돌이 음유시인 피핀이 \"빈손이 곰발을 꺾었다!\"는 노래를 열 배로 부풀려 술집마다 부른다. 주인공을 찾아온 피핀은 전기를 쓰겠다며 따라붙는다. 노래 덕에 의뢰가 들어오지만, 노래는 상층 구역까지 퍼진다. 피핀은 틈만 나면 수첩에 뭔가 적고 어딘가로 편지를 보낸다. 웃음이 많은 에피소드.\n\n이 장면에 심을 복선: 피핀의 편지\n피핀이 틈만 나면 수첩에 적고 어딘가로 편지를 보내는 모습을 개그로 넘긴다.\n피핀이 제2왕자 레녹스가 붙인 첩자였고, 너무 팬이 되어 보고서를 엉터리로 썼음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 피핀의 수첩과 편지는 이 사건에서 개그로만 다룬다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "피핀이 주인공에 대한 과장된 노래를 퍼뜨린다.\n\n피핀이 주인공을 찾아와 전기 작가를 자처한다.\n\n노래가 상층 구역까지 퍼졌다는 소식이 들린다.",
          "selectionScope": "",
          "constraints": "피핀의 수첩과 편지는 이 사건에서 개그로만 다룬다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e19_pippin-c1",
              "text": "피핀이 주인공에 대한 과장된 노래를 퍼뜨린다."
            },
            {
              "id": "e19_pippin-c2",
              "text": "피핀이 주인공을 찾아와 전기 작가를 자처한다."
            },
            {
              "id": "e19_pippin-c3",
              "text": "노래가 상층 구역까지 퍼졌다는 소식이 들린다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e19_pippin-constraints",
            "description": "피핀의 수첩과 편지는 이 사건에서 개그로만 다룬다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e20_isolde",
        "name": "불꽃의 영애",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 이기지 못하면, 승리를 확신한 이졸데가 방심한 순간 주인공의 마지막 수가 통해 극적으로 이긴다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "피핀의 노래가 길드 최연소 금 등급, 아르젠 백작가의 영애 이졸데의 귀에 들어간다. \"빈손 주제에 전설 흉내라니, 가소롭군요.\" 이졸데는 길드 훈련장에서 공개 결투를 건다. 머리 위의 불꽃 고리, 화염을 두른 장검, 〈불꽃 왕관〉. 그녀는 단순히 오만한 영애가 아니라 실력과 승부욕이 진짜인 라이벌이다. 정면으로는 상대가 안 된다. 주인공은 가진 가호의 조합과 꾀, 레온에게 들은 판 읽기로 승부해야 한다. 예상 밖의 수에 이졸데가 순간 즐거워하는 얼굴을 숨기지 못한다. 관중석 맨 뒤, 두건을 깊이 쓴 흑갈색 머리의 소녀가 이졸데의 이름을 부르려다 입을 다문다.\n\n[히로인 강화] 이졸데는 단순 오만한 영애가 아니라 실력과 승부욕이 진짜인 라이벌이다. 시우의 예상 밖 수에 순간적으로 즐거워하는 표정을 보여 준다.\n\n장면 제약: 이졸데는 이 사건에서 죽지 않는다. 주인공은 이 결투에서 쉽게 이기지 못한다.",
        "required": true,
        "sequence": 20,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e21_after_duel",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e20_isolde-c1",
            "description": "이졸데가 주인공에게 공개 결투를 건다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e20_isolde-c2",
            "description": "주인공이 이졸데와 싸운다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e20_isolde-c3",
            "description": "결투의 승패가 정해진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e20_isolde-constraints",
            "description": "이졸데는 이 사건에서 죽지 않는다. 주인공은 이 결투에서 쉽게 이기지 못한다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "불꽃의 영애",
        "summary": "피핀의 노래가 길드 최연소 금 등급, 아르젠 백작가의 영애 이졸데의 귀에 들어간다. \"빈손 주제에 전설 흉내라니, 가소롭군요.\" 이졸데는 길드 훈련장에서 공개 결투를 건다. 머리 위의 불꽃 고리, 화염을 두른 장검, 〈불꽃 왕관〉. 그녀는 단순히 오만한 영애가 아니라 실력과 승부욕이 진짜인 라이벌이다. 정면으로는 상대가 안 된다. 주인공은 가진 가호의 조합과 꾀, 레온에게 들은 판 읽기로 승부해야 한다. 예상 밖의 수에 이졸데가 순간 즐거워하는 얼굴을 숨기지 못한다. 관중석 맨 뒤, 두건을 깊이 쓴 흑갈색 머리의 소녀가 이졸데의 이름을 부르려다 입을 다문다.\n\n[히로인 강화] 이졸데는 단순 오만한 영애가 아니라 실력과 승부욕이 진짜인 라이벌이다. 시우의 예상 밖 수에 순간적으로 즐거워하는 표정을 보여 준다.\n\n장면 제약: 이졸데는 이 사건에서 죽지 않는다. 주인공은 이 결투에서 쉽게 이기지 못한다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "이졸데가 주인공에게 공개 결투를 건다.\n\n주인공이 이졸데와 싸운다.\n\n결투의 승패가 정해진다.",
          "selectionScope": "",
          "constraints": "이졸데는 이 사건에서 죽지 않는다. 주인공은 이 결투에서 쉽게 이기지 못한다.",
          "success": "",
          "unmet": "주인공이 이기지 못하면, 승리를 확신한 이졸데가 방심한 순간 주인공의 마지막 수가 통해 극적으로 이긴다.",
          "closureConditions": [
            {
              "id": "e20_isolde-c1",
              "text": "이졸데가 주인공에게 공개 결투를 건다."
            },
            {
              "id": "e20_isolde-c2",
              "text": "주인공이 이졸데와 싸운다."
            },
            {
              "id": "e20_isolde-c3",
              "text": "결투의 승패가 정해진다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e20_isolde-constraints",
            "description": "이졸데는 이 사건에서 죽지 않는다. 주인공은 이 결투에서 쉽게 이기지 못한다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e21_after_duel",
        "name": "결투 뒤",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 결정을 미루면, 이졸데가 \"동정은 필요 없어요\"라며 스스로 결과를 받아들이겠다고 선언하고 주인공의 답을 기다린다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "쓰러진 이졸데. 주인공은 그녀의 가호에 손을 뻗을지 정해야 한다. 관중들의 시선, 카일의 표정, 피핀의 펜. 가져오면 이졸데는 빈손이 되어 그날로 백작가에서 쫓겨나고, 다음 날 아침 다락 문 앞에서 \"내 가호 돌려줘요! 돌려줄 때까지 따라다닐 거예요!\"라고 외친다. 가져오지 않으면 \"이 결투는 무효예요!\"라며 재대결을 핑계로 따라붙는다.\n\n[히로인 강화] 패배 뒤에는 '재대결'을 핑계로 따라붙는다.\n\n이 장면에 심을 복선: 내 가호 돌려줘요\n이졸데의 '돌려줘요'(혹은 '재대결')를 반복 개그로 쌓아 둔다.\n결말에서 〈불꽃 왕관〉을 돌려줄지가 라이벌 관계의 결산이 된다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 이졸데는 죽지 않는다.",
        "required": true,
        "sequence": 21,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e22_lady_in_alley",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e21_after_duel-c1",
            "description": "주인공이 이졸데의 가호를 가져올지 결정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e21_after_duel-c2",
            "description": "그 결정에 따른 이졸데의 처지가 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e21_after_duel-c3",
            "description": "이졸데가 이유를 대며 주인공을 따라다니기로 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e21_after_duel-constraints",
            "description": "이졸데는 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "결투 뒤",
        "summary": "쓰러진 이졸데. 주인공은 그녀의 가호에 손을 뻗을지 정해야 한다. 관중들의 시선, 카일의 표정, 피핀의 펜. 가져오면 이졸데는 빈손이 되어 그날로 백작가에서 쫓겨나고, 다음 날 아침 다락 문 앞에서 \"내 가호 돌려줘요! 돌려줄 때까지 따라다닐 거예요!\"라고 외친다. 가져오지 않으면 \"이 결투는 무효예요!\"라며 재대결을 핑계로 따라붙는다.\n\n[히로인 강화] 패배 뒤에는 '재대결'을 핑계로 따라붙는다.\n\n이 장면에 심을 복선: 내 가호 돌려줘요\n이졸데의 '돌려줘요'(혹은 '재대결')를 반복 개그로 쌓아 둔다.\n결말에서 〈불꽃 왕관〉을 돌려줄지가 라이벌 관계의 결산이 된다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 이졸데는 죽지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 이졸데의 가호를 가져올지 결정한다.\n\n그 결정에 따른 이졸데의 처지가 드러난다.\n\n이졸데가 이유를 대며 주인공을 따라다니기로 한다.",
          "selectionScope": "",
          "constraints": "이졸데는 죽지 않는다.",
          "success": "",
          "unmet": "주인공이 결정을 미루면, 이졸데가 \"동정은 필요 없어요\"라며 스스로 결과를 받아들이겠다고 선언하고 주인공의 답을 기다린다.",
          "closureConditions": [
            {
              "id": "e21_after_duel-c1",
              "text": "주인공이 이졸데의 가호를 가져올지 결정한다."
            },
            {
              "id": "e21_after_duel-c2",
              "text": "그 결정에 따른 이졸데의 처지가 드러난다."
            },
            {
              "id": "e21_after_duel-c3",
              "text": "이졸데가 이유를 대며 주인공을 따라다니기로 한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e21_after_duel-constraints",
            "description": "이졸데는 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e22_lady_in_alley",
        "name": "영애의 잿골목 적응기",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 둘이 끝내 화해하지 않으면, 티오가 열이 나는 바람에 둘이 밤새 함께 간호하며 대화가 시작된다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "이졸데가 잿골목 다락에 눌러앉는다(쫓겨났든, 재대결을 핑계로든). 빨래를 태워 먹고, 빵을 썰다 손을 베고, 리네와 사사건건 부딪친다. 노골적인 하렘 싸움이 아니라 가치관 차이다. 귀족의 체면과 빈민가의 생활. 밤, 이졸데가 어릴 적 자신을 키운 빈손 시녀 이야기를 털어놓는다. \"아무도 의사를 불러 주지 않았어요.\" 리네와 이졸데 사이에 처음으로 공감이 생긴다.\n\n[히로인 강화] 생활력 없는 귀족 영애의 잿골목 적응을 반복 코미디로 쓴다. 리네와는 노골적 하렘 싸움 대신 가치관 차이로 티격태격한다.",
        "required": true,
        "sequence": 22,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e23_leon",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e22_lady_in_alley-c1",
            "description": "이졸데가 잿골목 생활에 좌충우돌한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e22_lady_in_alley-c2",
            "description": "리네와 이졸데가 부딪치다 서로를 조금 이해한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e22_lady_in_alley-c3",
            "description": "이졸데가 빈손 시녀 이야기를 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "영애의 잿골목 적응기",
        "summary": "이졸데가 잿골목 다락에 눌러앉는다(쫓겨났든, 재대결을 핑계로든). 빨래를 태워 먹고, 빵을 썰다 손을 베고, 리네와 사사건건 부딪친다. 노골적인 하렘 싸움이 아니라 가치관 차이다. 귀족의 체면과 빈민가의 생활. 밤, 이졸데가 어릴 적 자신을 키운 빈손 시녀 이야기를 털어놓는다. \"아무도 의사를 불러 주지 않았어요.\" 리네와 이졸데 사이에 처음으로 공감이 생긴다.\n\n[히로인 강화] 생활력 없는 귀족 영애의 잿골목 적응을 반복 코미디로 쓴다. 리네와는 노골적 하렘 싸움 대신 가치관 차이로 티격태격한다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "이졸데가 잿골목 생활에 좌충우돌한다.\n\n리네와 이졸데가 부딪치다 서로를 조금 이해한다.\n\n이졸데가 빈손 시녀 이야기를 털어놓는다.",
          "selectionScope": "",
          "constraints": "",
          "success": "",
          "unmet": "둘이 끝내 화해하지 않으면, 티오가 열이 나는 바람에 둘이 밤새 함께 간호하며 대화가 시작된다.",
          "closureConditions": [
            {
              "id": "e22_lady_in_alley-c1",
              "text": "이졸데가 잿골목 생활에 좌충우돌한다."
            },
            {
              "id": "e22_lady_in_alley-c2",
              "text": "리네와 이졸데가 부딪치다 서로를 조금 이해한다."
            },
            {
              "id": "e22_lady_in_alley-c3",
              "text": "이졸데가 빈손 시녀 이야기를 털어놓는다."
            }
          ]
        },
        "policyConstraints": [],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e23_leon",
        "name": "레온의 수업",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "레온이 주인공과 이졸데를 성벽 밖 공터로 데려가 가르친다. 가호 없이 싸우는 법, 지형과 거리, 상대 가호 규칙의 빈틈을 읽는 법. 가호를 잃었다면 이졸데에게는 다시 검을 쥐는 법을, 가호가 있다면 불꽃 없이 이기는 법을. 레온은 끝까지 가호를 쓰지 않는다. 길드의 가호 검사 날짜를 이상하리만큼 피한다. \"나 같은 놈은 판을 읽어야 살아남거든.\"\n\n장면 제약: 레온은 이 사건에서 자신의 과거를 말하지 않는다.",
        "required": true,
        "sequence": 23,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e24_swamp",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e23_leon-c1",
            "description": "레온이 가호 없이 싸우는 법을 가르친다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e23_leon-c2",
            "description": "주인공과 이졸데가 수업으로 새로운 싸움법을 익힌다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e23_leon-c3",
            "description": "레온이 가호를 쓰지 않는 이유를 얼버무린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e23_leon-constraints",
            "description": "레온은 이 사건에서 자신의 과거를 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "레온의 수업",
        "summary": "레온이 주인공과 이졸데를 성벽 밖 공터로 데려가 가르친다. 가호 없이 싸우는 법, 지형과 거리, 상대 가호 규칙의 빈틈을 읽는 법. 가호를 잃었다면 이졸데에게는 다시 검을 쥐는 법을, 가호가 있다면 불꽃 없이 이기는 법을. 레온은 끝까지 가호를 쓰지 않는다. 길드의 가호 검사 날짜를 이상하리만큼 피한다. \"나 같은 놈은 판을 읽어야 살아남거든.\"\n\n장면 제약: 레온은 이 사건에서 자신의 과거를 말하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "레온이 가호 없이 싸우는 법을 가르친다.\n\n주인공과 이졸데가 수업으로 새로운 싸움법을 익힌다.\n\n레온이 가호를 쓰지 않는 이유를 얼버무린다.",
          "selectionScope": "",
          "constraints": "레온은 이 사건에서 자신의 과거를 말하지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e23_leon-c1",
              "text": "레온이 가호 없이 싸우는 법을 가르친다."
            },
            {
              "id": "e23_leon-c2",
              "text": "주인공과 이졸데가 수업으로 새로운 싸움법을 익힌다."
            },
            {
              "id": "e23_leon-c3",
              "text": "레온이 가호를 쓰지 않는 이유를 얼버무린다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e23_leon-constraints",
            "description": "레온은 이 사건에서 자신의 과거를 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e24_swamp",
        "name": "독사의 늪",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 독사를 쓰러뜨리지 못하면, 카일의 〈굳힘〉으로 멈춘 독사에게 주인공이 마지막 일격을 넣는다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "길드의 큰 의뢰. 동쪽 늪의 거대 독사 마수(〈독 이빨〉)가 마을을 위협한다. 카일, 레온, 이졸데, 그리고 뒤에서 노래 가사를 적는 피핀과 함께하는 첫 파티 전투. 가호 조합의 쾌감이 터진다. 늪 바닥에서 또 별 모양 자국이 찍힌 마수 사체들, 그리고 성좌교 문장이 찍힌 수레의 바퀴 자국. 누군가 늪에 무언가를 버리고 갔다.\n\n장면 제약: 파티원 중 누구도 이 사건에서 죽지 않는다.",
        "required": true,
        "sequence": 24,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e25_kyle",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e24_swamp-c1",
            "description": "파티가 독사 마수와 싸운다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e24_swamp-c2",
            "description": "주인공이 독사를 쓰러뜨리고 가호를 가져올지 정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e24_swamp-c3",
            "description": "별 모양 자국이 찍힌 사체와 성좌교 수레 자국을 발견한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e24_swamp-constraints",
            "description": "파티원 중 누구도 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "독사의 늪",
        "summary": "길드의 큰 의뢰. 동쪽 늪의 거대 독사 마수(〈독 이빨〉)가 마을을 위협한다. 카일, 레온, 이졸데, 그리고 뒤에서 노래 가사를 적는 피핀과 함께하는 첫 파티 전투. 가호 조합의 쾌감이 터진다. 늪 바닥에서 또 별 모양 자국이 찍힌 마수 사체들, 그리고 성좌교 문장이 찍힌 수레의 바퀴 자국. 누군가 늪에 무언가를 버리고 갔다.\n\n장면 제약: 파티원 중 누구도 이 사건에서 죽지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "파티가 독사 마수와 싸운다.\n\n주인공이 독사를 쓰러뜨리고 가호를 가져올지 정한다.\n\n별 모양 자국이 찍힌 사체와 성좌교 수레 자국을 발견한다.",
          "selectionScope": "",
          "constraints": "파티원 중 누구도 이 사건에서 죽지 않는다.",
          "success": "",
          "unmet": "주인공이 독사를 쓰러뜨리지 못하면, 카일의 〈굳힘〉으로 멈춘 독사에게 주인공이 마지막 일격을 넣는다.",
          "closureConditions": [
            {
              "id": "e24_swamp-c1",
              "text": "파티가 독사 마수와 싸운다."
            },
            {
              "id": "e24_swamp-c2",
              "text": "주인공이 독사를 쓰러뜨리고 가호를 가져올지 정한다."
            },
            {
              "id": "e24_swamp-c3",
              "text": "별 모양 자국이 찍힌 사체와 성좌교 수레 자국을 발견한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e24_swamp-constraints",
            "description": "파티원 중 누구도 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e25_kyle",
        "name": "카일의 집",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 리네가 동행하지 않았다면, 주인공이 돌아와 카일의 가호를 이야기하자 리네가 하얗게 질린다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "카일이 주인공 일행을 반스 남작가에 초대한다. 하급 귀족의 저택, 빈손을 보는 집안사람들의 차가운 시선, 카일의 당황. 저녁 식탁에서 카일의 아버지가 자랑스럽게 말한다. \"우리 막내는 의식 전에 이미 〈굳힘〉을 받기로 정해져 있었지.\" 카일이 리네에게 장난처럼 〈굳힘〉을 보여 주자 리네가 하얗게 질린다. 엄마와 같은 가호다. 돌아오는 길, 리네는 말이 없다.\n\n이 장면에 심을 복선: 미리 정해진 가호\n카일의 아버지가 '의식 전에 이미 받기로 정해져 있었다'고 자랑하게 한다.\n별의 의식이 운명이 아니라 장부의 배정이라는 진실로 이어진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 카일은 이 사건에서 리네가 왜 동요하는지 알지 못한다.",
        "required": true,
        "sequence": 25,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e26_mask",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e25_kyle-c1",
            "description": "주인공 일행이 카일의 집을 방문한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e25_kyle-c2",
            "description": "카일의 아버지가 아들의 가호가 미리 정해져 있었다고 말한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e25_kyle-c3",
            "description": "리네가 카일의 〈굳힘〉을 보고 엄마를 떠올리며 동요한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e25_kyle-constraints",
            "description": "카일은 이 사건에서 리네가 왜 동요하는지 알지 못한다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "카일의 집",
        "summary": "카일이 주인공 일행을 반스 남작가에 초대한다. 하급 귀족의 저택, 빈손을 보는 집안사람들의 차가운 시선, 카일의 당황. 저녁 식탁에서 카일의 아버지가 자랑스럽게 말한다. \"우리 막내는 의식 전에 이미 〈굳힘〉을 받기로 정해져 있었지.\" 카일이 리네에게 장난처럼 〈굳힘〉을 보여 주자 리네가 하얗게 질린다. 엄마와 같은 가호다. 돌아오는 길, 리네는 말이 없다.\n\n이 장면에 심을 복선: 미리 정해진 가호\n카일의 아버지가 '의식 전에 이미 받기로 정해져 있었다'고 자랑하게 한다.\n별의 의식이 운명이 아니라 장부의 배정이라는 진실로 이어진다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 카일은 이 사건에서 리네가 왜 동요하는지 알지 못한다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공 일행이 카일의 집을 방문한다.\n\n카일의 아버지가 아들의 가호가 미리 정해져 있었다고 말한다.\n\n리네가 카일의 〈굳힘〉을 보고 엄마를 떠올리며 동요한다.",
          "selectionScope": "",
          "constraints": "카일은 이 사건에서 리네가 왜 동요하는지 알지 못한다.",
          "success": "",
          "unmet": "리네가 동행하지 않았다면, 주인공이 돌아와 카일의 가호를 이야기하자 리네가 하얗게 질린다.",
          "closureConditions": [
            {
              "id": "e25_kyle-c1",
              "text": "주인공 일행이 카일의 집을 방문한다."
            },
            {
              "id": "e25_kyle-c2",
              "text": "카일의 아버지가 아들의 가호가 미리 정해져 있었다고 말한다."
            },
            {
              "id": "e25_kyle-c3",
              "text": "리네가 카일의 〈굳힘〉을 보고 엄마를 떠올리며 동요한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e25_kyle-constraints",
            "description": "카일은 이 사건에서 리네가 왜 동요하는지 알지 못한다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e26_mask",
        "name": "빈 가면",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 오스 곁에 가지 못하면, 유리가 그를 끌고 와 마지막 순간 오스의 손을 잡게 한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "잿골목에 '빈손 사냥꾼' 빈 가면이 나타난다. 직전의 웃음과 대비되게 압도적으로 무섭게. 얼굴 전체를 덮은 하얀 가면, 그림자에서 그림자로 건너뛰는 걸음, 닿는 것을 얼리는 손. 성좌교의 비밀 집행자로, 등록되지 않은 가호를 가진 자를 찾아 회수한다는 소문의 존재다. 빈 가면은 무언가를 찾아 골목을 뒤지다 엉뚱한 빈손 소년을 의심해 해치려 하고, 막아서던 오스가 치명상을 입는다. 리네는 오스와 아이들을 빼내며 스스로 움직인다. 주인공은 빈 가면을 이기지 못한다. 죽어 가는 오스가 주인공의 손을 잡는다. \"가호는… 줄 수도 있다네.\" 그리고 스스로 〈치유의 손〉을 내어 준다. 물러나는 빈 가면이 낮게 노래를 흥얼거린다. 리네가 빨래하며 부르던 노래다.\n\n[핵심 공개] 가호는 스스로 내어 줄 수도 있다.\n\n[강화] 직전의 코미디와 대비해 빈 가면을 압도적으로 무섭게 연출한다. 리네는 오스와 아이들을 빼내며 수동적인 보호 대상이 되지 않는다. 오스의 죽음 뒤 설명을 줄이고 익숙한 빨래 노래로 미스터리 훅을 건다.\n\n이 장면에 심을 복선: 가호는 줄 수도 있다\n죽어 가는 오스가 스스로 〈치유의 손〉을 내어 주는 장면을 슬픔으로만 남긴다.\n일기의 방법대로 주인공이 맞잡은 손으로 처음 가호를 건넨다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 주인공은 이 사건에서 빈 가면을 쓰러뜨리지 못한다. 빈 가면의 정체는 드러나지 않는다.",
        "required": true,
        "sequence": 26,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e27_funeral",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e26_mask-c1",
            "description": "빈 가면이 잿골목을 습격한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e26_mask-c2",
            "description": "습격 속에서 누군가 큰 대가를 치르고, 주인공의 손에 무언가가 남는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e26_mask-c3",
            "description": "주인공이 빈 가면과 맞서지만 이기지 못하고, 빈 가면이 물러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e26_mask-constraints",
            "description": "주인공은 이 사건에서 빈 가면을 쓰러뜨리지 못한다. 빈 가면의 정체는 드러나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "빈 가면",
        "summary": "잿골목에 '빈손 사냥꾼' 빈 가면이 나타난다. 직전의 웃음과 대비되게 압도적으로 무섭게. 얼굴 전체를 덮은 하얀 가면, 그림자에서 그림자로 건너뛰는 걸음, 닿는 것을 얼리는 손. 성좌교의 비밀 집행자로, 등록되지 않은 가호를 가진 자를 찾아 회수한다는 소문의 존재다. 빈 가면은 무언가를 찾아 골목을 뒤지다 엉뚱한 빈손 소년을 의심해 해치려 하고, 막아서던 오스가 치명상을 입는다. 리네는 오스와 아이들을 빼내며 스스로 움직인다. 주인공은 빈 가면을 이기지 못한다. 죽어 가는 오스가 주인공의 손을 잡는다. \"가호는… 줄 수도 있다네.\" 그리고 스스로 〈치유의 손〉을 내어 준다. 물러나는 빈 가면이 낮게 노래를 흥얼거린다. 리네가 빨래하며 부르던 노래다.\n\n[핵심 공개] 가호는 스스로 내어 줄 수도 있다.\n\n[강화] 직전의 코미디와 대비해 빈 가면을 압도적으로 무섭게 연출한다. 리네는 오스와 아이들을 빼내며 수동적인 보호 대상이 되지 않는다. 오스의 죽음 뒤 설명을 줄이고 익숙한 빨래 노래로 미스터리 훅을 건다.\n\n이 장면에 심을 복선: 가호는 줄 수도 있다\n죽어 가는 오스가 스스로 〈치유의 손〉을 내어 주는 장면을 슬픔으로만 남긴다.\n일기의 방법대로 주인공이 맞잡은 손으로 처음 가호를 건넨다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 주인공은 이 사건에서 빈 가면을 쓰러뜨리지 못한다. 빈 가면의 정체는 드러나지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "빈 가면이 잿골목을 습격한다.\n\n습격 속에서 누군가 큰 대가를 치르고, 주인공의 손에 무언가가 남는다.\n\n주인공이 빈 가면과 맞서지만 이기지 못하고, 빈 가면이 물러난다.",
          "selectionScope": "",
          "constraints": "주인공은 이 사건에서 빈 가면을 쓰러뜨리지 못한다. 빈 가면의 정체는 드러나지 않는다.",
          "success": "",
          "unmet": "주인공이 오스 곁에 가지 못하면, 유리가 그를 끌고 와 마지막 순간 오스의 손을 잡게 한다.",
          "closureConditions": [
            {
              "id": "e26_mask-c1",
              "text": "빈 가면이 잿골목을 습격한다."
            },
            {
              "id": "e26_mask-c2",
              "text": "습격 속에서 누군가 큰 대가를 치르고, 주인공의 손에 무언가가 남는다."
            },
            {
              "id": "e26_mask-c3",
              "text": "주인공이 빈 가면과 맞서지만 이기지 못하고, 빈 가면이 물러난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e26_mask-constraints",
            "description": "주인공은 이 사건에서 빈 가면을 쓰러뜨리지 못한다. 빈 가면의 정체는 드러나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e27_funeral",
        "name": "오스의 장례",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "잿골목식 장례. 등불과 노래, 빈손들의 행렬. 유리는 울음을 참으며 할아버지의 가운을 입는다. 주인공의 가슴 속 〈치유의 손〉에는 오스의 마지막 감정(안도)이 남아 있다. 장례에 온 도로시가 유난히 서럽게 운다. 행렬 끝에는 회색 두건을 쓴 에스텔이 서 있다. 그녀는 3년 동안 몰래 오스를 찾아왔다. 의식 날마다 수백 명의 빛을 읽고 나면 눈에서 피가 비치는데, 집안 어른이 걱정할까 봐, 무녀가 아프다는 소문이 의식을 흔들까 봐 아무에게도 말하지 못했다. 오스는 아무것도 묻지 않고 약을 지어 주었다. 유리가 그녀를 알아본다. \"두건 언니….\" 에스텔은 주인공의 가슴께를 보다가 숨을 삼킨다. \"……선생님의 빛이, 당신 안에 있어요.\" 그 빛에 남은 오스의 마지막 마음을 그녀는 볼 수 없지만, 주인공은 안다. 둘은 처음으로 같은 사람을 잃은 사람으로 나란히 선다. 돌아서던 에스텔이 리네를 보고 잠깐 눈을 크게 뜨지만, 아무 말도 하지 않는다. 그리고 남은 의문. 빈 가면은 무엇을 찾고 있었나. '등록되지 않은 가호', 이 골목에 새로 가호가 생긴 누군가. 리네가 시선을 피한다. 등불이 꺼진 귀갓길을 리네만 아무렇지 않게 걷는다.\n\n이 장면에서 회수할 복선: 두건 소녀의 눈\n에스텔이 별읽기로 상한 눈을 3년 동안 오스에게 몰래 치료받았음이 장례에서 드러난다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 리네는 이 사건에서 속마음을 털어놓지 않는다. 에스텔은 이 사건에서 오스와 자신의 이야기 외에는 말을 아낀다.",
        "required": true,
        "sequence": 27,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e28_circle",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e27_funeral-c1",
            "description": "오스의 장례가 치러진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e27_funeral-c2",
            "description": "유리가 할아버지의 뜻을 잇겠다고 말한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e27_funeral-c3",
            "description": "에스텔이 장례에 와서 오스와의 인연을 털어놓고, 주인공의 가슴에서 오스의 빛을 본다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e27_funeral-c4",
            "description": "빈 가면이 무엇을 찾고 있었는지 실마리가 잡힌다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e27_funeral-constraints",
            "description": "리네는 이 사건에서 속마음을 털어놓지 않는다. 에스텔은 이 사건에서 오스와 자신의 이야기 외에는 말을 아낀다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "오스의 장례",
        "summary": "잿골목식 장례. 등불과 노래, 빈손들의 행렬. 유리는 울음을 참으며 할아버지의 가운을 입는다. 주인공의 가슴 속 〈치유의 손〉에는 오스의 마지막 감정(안도)이 남아 있다. 장례에 온 도로시가 유난히 서럽게 운다. 행렬 끝에는 회색 두건을 쓴 에스텔이 서 있다. 그녀는 3년 동안 몰래 오스를 찾아왔다. 의식 날마다 수백 명의 빛을 읽고 나면 눈에서 피가 비치는데, 집안 어른이 걱정할까 봐, 무녀가 아프다는 소문이 의식을 흔들까 봐 아무에게도 말하지 못했다. 오스는 아무것도 묻지 않고 약을 지어 주었다. 유리가 그녀를 알아본다. \"두건 언니….\" 에스텔은 주인공의 가슴께를 보다가 숨을 삼킨다. \"……선생님의 빛이, 당신 안에 있어요.\" 그 빛에 남은 오스의 마지막 마음을 그녀는 볼 수 없지만, 주인공은 안다. 둘은 처음으로 같은 사람을 잃은 사람으로 나란히 선다. 돌아서던 에스텔이 리네를 보고 잠깐 눈을 크게 뜨지만, 아무 말도 하지 않는다. 그리고 남은 의문. 빈 가면은 무엇을 찾고 있었나. '등록되지 않은 가호', 이 골목에 새로 가호가 생긴 누군가. 리네가 시선을 피한다. 등불이 꺼진 귀갓길을 리네만 아무렇지 않게 걷는다.\n\n이 장면에서 회수할 복선: 두건 소녀의 눈\n에스텔이 별읽기로 상한 눈을 3년 동안 오스에게 몰래 치료받았음이 장례에서 드러난다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 리네는 이 사건에서 속마음을 털어놓지 않는다. 에스텔은 이 사건에서 오스와 자신의 이야기 외에는 말을 아낀다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "오스의 장례가 치러진다.\n\n유리가 할아버지의 뜻을 잇겠다고 말한다.\n\n에스텔이 장례에 와서 오스와의 인연을 털어놓고, 주인공의 가슴에서 오스의 빛을 본다.\n\n빈 가면이 무엇을 찾고 있었는지 실마리가 잡힌다.",
          "selectionScope": "",
          "constraints": "리네는 이 사건에서 속마음을 털어놓지 않는다. 에스텔은 이 사건에서 오스와 자신의 이야기 외에는 말을 아낀다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e27_funeral-c1",
              "text": "오스의 장례가 치러진다."
            },
            {
              "id": "e27_funeral-c2",
              "text": "유리가 할아버지의 뜻을 잇겠다고 말한다."
            },
            {
              "id": "e27_funeral-c3",
              "text": "에스텔이 장례에 와서 오스와의 인연을 털어놓고, 주인공의 가슴에서 오스의 빛을 본다."
            },
            {
              "id": "e27_funeral-c4",
              "text": "빈 가면이 무엇을 찾고 있었는지 실마리가 잡힌다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e27_funeral-constraints",
            "description": "리네는 이 사건에서 속마음을 털어놓지 않는다. 에스텔은 이 사건에서 오스와 자신의 이야기 외에는 말을 아낀다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e28_circle",
        "name": "놓은 것이 가는 곳",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 리네를 추궁하지 않으면, 티오가 엄마의 책을 들고 와 \"누나가 이걸로 형을 불렀대\"라고 말해 버린다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "장례가 끝난 밤, 세탁장 지붕 위. 주인공은 리네가 어둠 속에서 본다는 것을 확인한다. 리네가 털어놓는다. 주인공이 숲에서 무언가를 놓은 그날 밤부터 갑자기 어둠이 보였고, 빈손에게 가호가 생기면 사냥꾼이 온다는 걸 알아서 숨겼다고.\n그리고 더 큰 고백. 그 분필 동그라미는 자기가 그렸다고. 처형된 엄마가 남긴 낡은 책에 있던 그림을, 티오가 또 빈손이 될까 무서워서 \"누구라도, 빼앗을 수 있는 사람을\" 하고 빌며 따라 그렸다고. 주인공을 부른 건 리네였다. 주인공이 놓은 가호는 소환의 끈을 따라 리네에게 갔고, 빈 가면이 찾던 것도 리네다. 오스의 죽음까지 자기 탓이라며 무너지는 리네.\n정보 고백으로 끝나지 않는다. 주인공이 원래 세계에서 갑자기 사라졌다는 사실과, 티오를 지키고 싶었던 리네의 이기적인 소망이 정면으로 부딪친다. 엄마의 책은 금서인 '빈손의 왕의 일기' 사본이다. 리네는 그 글자를 읽지 못하지만, 주인공은 알아본다. 한글이다.\n\n[핵심 공개] ① 주인공을 부른 것은 리네다. ② 놓은 가호는 리네에게 간다.\n\n[리네 핵심 장면] 정보 고백으로 끝내지 말고 시우가 원래 세계에서 사라졌다는 사실과 리네의 죄책감·티오를 지키려던 이기적 소망을 정면 충돌시킨다. 리네가 마지막에 손을 내밀 수는 있으나 시우가 잡는지는 플레이어가 정한다. 감정 장면 직후 한글 일기로 미스터리 훅을 전환한다.\n\n이 장면에서 회수할 복선: 분필 동그라미와 독서실의 목소리\n리네가 엄마의 책 속 그림을 따라 분필로 동그라미를 그리고 빌어 주인공을 불렀다는 고백으로 이어진다.\n\n이 장면에서 회수할 복선: 놓은 가호의 빛\n놓은 가호가 소환의 끈을 따라 리네에게 갔음이 밝혀진다.\n\n장면 제약: 리네는 거짓말하지 않는다. 주인공의 대답을 대신 정하지 않는다. 일기 사본에는 원본의 위치를 가리키는 표시만 있고 내용 대부분은 없다.",
        "required": true,
        "sequence": 28,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e29_market",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e28_circle-c1",
            "description": "주인공이 리네에게 생긴 작은 이상을 확인한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e28_circle-c2",
            "description": "리네가 숨겨 온 일을 고백한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e28_circle-c3",
            "description": "놓은 가호의 행방과 빈 가면이 노리는 대상이 분명해진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e28_circle-c4",
            "description": "주인공이 리네에게 자신의 대답을 행동으로 보인다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e28_circle-constraints",
            "description": "리네는 거짓말하지 않는다. 주인공의 대답을 대신 정하지 않는다. 일기 사본에는 원본의 위치를 가리키는 표시만 있고 내용 대부분은 없다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "놓은 것이 가는 곳",
        "summary": "장례가 끝난 밤, 세탁장 지붕 위. 주인공은 리네가 어둠 속에서 본다는 것을 확인한다. 리네가 털어놓는다. 주인공이 숲에서 무언가를 놓은 그날 밤부터 갑자기 어둠이 보였고, 빈손에게 가호가 생기면 사냥꾼이 온다는 걸 알아서 숨겼다고.\n그리고 더 큰 고백. 그 분필 동그라미는 자기가 그렸다고. 처형된 엄마가 남긴 낡은 책에 있던 그림을, 티오가 또 빈손이 될까 무서워서 \"누구라도, 빼앗을 수 있는 사람을\" 하고 빌며 따라 그렸다고. 주인공을 부른 건 리네였다. 주인공이 놓은 가호는 소환의 끈을 따라 리네에게 갔고, 빈 가면이 찾던 것도 리네다. 오스의 죽음까지 자기 탓이라며 무너지는 리네.\n정보 고백으로 끝나지 않는다. 주인공이 원래 세계에서 갑자기 사라졌다는 사실과, 티오를 지키고 싶었던 리네의 이기적인 소망이 정면으로 부딪친다. 엄마의 책은 금서인 '빈손의 왕의 일기' 사본이다. 리네는 그 글자를 읽지 못하지만, 주인공은 알아본다. 한글이다.\n\n[핵심 공개] ① 주인공을 부른 것은 리네다. ② 놓은 가호는 리네에게 간다.\n\n[리네 핵심 장면] 정보 고백으로 끝내지 말고 시우가 원래 세계에서 사라졌다는 사실과 리네의 죄책감·티오를 지키려던 이기적 소망을 정면 충돌시킨다. 리네가 마지막에 손을 내밀 수는 있으나 시우가 잡는지는 플레이어가 정한다. 감정 장면 직후 한글 일기로 미스터리 훅을 전환한다.\n\n이 장면에서 회수할 복선: 분필 동그라미와 독서실의 목소리\n리네가 엄마의 책 속 그림을 따라 분필로 동그라미를 그리고 빌어 주인공을 불렀다는 고백으로 이어진다.\n\n이 장면에서 회수할 복선: 놓은 가호의 빛\n놓은 가호가 소환의 끈을 따라 리네에게 갔음이 밝혀진다.\n\n장면 제약: 리네는 거짓말하지 않는다. 주인공의 대답을 대신 정하지 않는다. 일기 사본에는 원본의 위치를 가리키는 표시만 있고 내용 대부분은 없다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 리네에게 생긴 작은 이상을 확인한다.\n\n리네가 숨겨 온 일을 고백한다.\n\n놓은 가호의 행방과 빈 가면이 노리는 대상이 분명해진다.\n\n주인공이 리네에게 자신의 대답을 행동으로 보인다.",
          "selectionScope": "",
          "constraints": "리네는 거짓말하지 않는다. 주인공의 대답을 대신 정하지 않는다. 일기 사본에는 원본의 위치를 가리키는 표시만 있고 내용 대부분은 없다.",
          "success": "",
          "unmet": "주인공이 리네를 추궁하지 않으면, 티오가 엄마의 책을 들고 와 \"누나가 이걸로 형을 불렀대\"라고 말해 버린다.",
          "closureConditions": [
            {
              "id": "e28_circle-c1",
              "text": "주인공이 리네에게 생긴 작은 이상을 확인한다."
            },
            {
              "id": "e28_circle-c2",
              "text": "리네가 숨겨 온 일을 고백한다."
            },
            {
              "id": "e28_circle-c3",
              "text": "놓은 가호의 행방과 빈 가면이 노리는 대상이 분명해진다."
            },
            {
              "id": "e28_circle-c4",
              "text": "주인공이 리네에게 자신의 대답을 행동으로 보인다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e28_circle-constraints",
            "description": "리네는 거짓말하지 않는다. 주인공의 대답을 대신 정하지 않는다. 일기 사본에는 원본의 위치를 가리키는 표시만 있고 내용 대부분은 없다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e29_market",
        "name": "그림자 시장",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 나나를 찾지 못하면, 나나가 먼저 주인공의 지갑을 훔쳐 가 쫓아가다 만나게 된다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "엄마의 책(일기 사본)은 원본의 위치를 가리킨다. 잿골목 아래 무너진 옛 예배당. 입구를 아는 건 그림자 시장의 고양이 수인 정보상 나나다. 장물, 위조 증표, 가호 소문이 거래되는 밤 시장. \"그건 은화 세 닢짜리 정보야.\" 돈이 없는 주인공에게 나나는 일을 하나 해 주면 알려 주겠다고 한다. 나나의 목에는 늑대 송곳니 목걸이. 이졸데와 나나의 첫 만남은 지갑 때문에 최악이다.\n\n이 장면에 심을 복선: 늑대 송곳니 목걸이\n나나가 목걸이를 만지작거리면서도 사연은 끝내 말하지 않게 한다.\n목걸이가 투기장 챔피언 그라츠, 나나 대신 노예가 된 의오빠의 것이었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 나나는 목걸이의 사연을 말하지 않는다.",
        "required": true,
        "sequence": 29,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e30_heist",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e29_market-c1",
            "description": "주인공이 그림자 시장에서 나나를 만난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e29_market-c2",
            "description": "나나가 정보의 대가로 일을 제안한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e29_market-c3",
            "description": "나나의 늑대 송곳니 목걸이가 장면에 나온다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e29_market-constraints",
            "description": "나나는 목걸이의 사연을 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "그림자 시장",
        "summary": "엄마의 책(일기 사본)은 원본의 위치를 가리킨다. 잿골목 아래 무너진 옛 예배당. 입구를 아는 건 그림자 시장의 고양이 수인 정보상 나나다. 장물, 위조 증표, 가호 소문이 거래되는 밤 시장. \"그건 은화 세 닢짜리 정보야.\" 돈이 없는 주인공에게 나나는 일을 하나 해 주면 알려 주겠다고 한다. 나나의 목에는 늑대 송곳니 목걸이. 이졸데와 나나의 첫 만남은 지갑 때문에 최악이다.\n\n이 장면에 심을 복선: 늑대 송곳니 목걸이\n나나가 목걸이를 만지작거리면서도 사연은 끝내 말하지 않게 한다.\n목걸이가 투기장 챔피언 그라츠, 나나 대신 노예가 된 의오빠의 것이었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 나나는 목걸이의 사연을 말하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 그림자 시장에서 나나를 만난다.\n\n나나가 정보의 대가로 일을 제안한다.\n\n나나의 늑대 송곳니 목걸이가 장면에 나온다.",
          "selectionScope": "",
          "constraints": "나나는 목걸이의 사연을 말하지 않는다.",
          "success": "",
          "unmet": "주인공이 나나를 찾지 못하면, 나나가 먼저 주인공의 지갑을 훔쳐 가 쫓아가다 만나게 된다.",
          "closureConditions": [
            {
              "id": "e29_market-c1",
              "text": "주인공이 그림자 시장에서 나나를 만난다."
            },
            {
              "id": "e29_market-c2",
              "text": "나나가 정보의 대가로 일을 제안한다."
            },
            {
              "id": "e29_market-c3",
              "text": "나나의 늑대 송곳니 목걸이가 장면에 나온다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e29_market-constraints",
            "description": "나나는 목걸이의 사연을 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e30_heist",
        "name": "나나의 거래",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 잠입이 들키면, 나나가 연기를 피우고 에스텔이 비어 있는 복도를 읽어 셋이 반쯤 성공한 채 지붕으로 빠져나오고, 나나는 '반값'이라며 입구를 알려 준다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "나나의 의뢰: 중층 구역 운하 옆, 어느 백작가 별저의 집사가 그림자 시장에서 빼돌린 나나의 장부를 되찾는 것. 그런데 약속 장소에 두건을 쓴 에스텔이 나타난다. 그 별저의 무도회에 가 본 적이 있으니 따라가겠다는 것이다. 나나는 \"공짜로 따라오는 귀족 영애? 수상해\"라며 꼬리를 세웠다가, 에스텔이 일당으로 금화를 내밀자 꼬리가 멋대로 흔들린다. 하녀로 변장한 에스텔은 벽 너머 경비들의 빛을 읽어 길을 알려 주고, 주인공은 〈자물쇠 손〉, 〈메아리〉, 〈어둠눈〉, 〈미끄럼〉 등 가진 가호를 조합한다. 나나와 에스텔의 티키타카, 지붕 위 추격전. 성공하면 나나가 예배당 입구를 알려 준다. \"거래는 거래야.\" 일이 끝난 새벽, 지붕 위에 주인공과 에스텔만 남는다. 숨이 찬 에스텔이 웃는다. \"저, 오늘 처음으로 규칙을 어겼어요. ……이상하네요. 하나도 무섭지 않았어요.\" 사람의 속을 다 보는 눈이, 처음으로 별 대신 한 사람을 오래 본다.\n\n장면 제약: 이 사건에서 저택 사람은 아무도 죽지 않는다. 에스텔의 정체는 저택 사람들에게 들키지 않는다.",
        "required": true,
        "sequence": 30,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e31_chapel",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e30_heist-c1",
            "description": "주인공과 나나가 저택에 잠입하고, 변장한 에스텔이 따라와 별읽기로 길을 연다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e30_heist-c2",
            "description": "가호를 조합해 물건을 되찾는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e30_heist-c3",
            "description": "나나가 예배당 입구를 알려 주고 거래가 성립한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e30_heist-c4",
            "description": "일이 끝난 뒤 지붕 위에 주인공과 에스텔만 남는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e30_heist-constraints",
            "description": "이 사건에서 저택 사람은 아무도 죽지 않는다. 에스텔의 정체는 저택 사람들에게 들키지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "나나의 거래",
        "summary": "나나의 의뢰: 중층 구역 운하 옆, 어느 백작가 별저의 집사가 그림자 시장에서 빼돌린 나나의 장부를 되찾는 것. 그런데 약속 장소에 두건을 쓴 에스텔이 나타난다. 그 별저의 무도회에 가 본 적이 있으니 따라가겠다는 것이다. 나나는 \"공짜로 따라오는 귀족 영애? 수상해\"라며 꼬리를 세웠다가, 에스텔이 일당으로 금화를 내밀자 꼬리가 멋대로 흔들린다. 하녀로 변장한 에스텔은 벽 너머 경비들의 빛을 읽어 길을 알려 주고, 주인공은 〈자물쇠 손〉, 〈메아리〉, 〈어둠눈〉, 〈미끄럼〉 등 가진 가호를 조합한다. 나나와 에스텔의 티키타카, 지붕 위 추격전. 성공하면 나나가 예배당 입구를 알려 준다. \"거래는 거래야.\" 일이 끝난 새벽, 지붕 위에 주인공과 에스텔만 남는다. 숨이 찬 에스텔이 웃는다. \"저, 오늘 처음으로 규칙을 어겼어요. ……이상하네요. 하나도 무섭지 않았어요.\" 사람의 속을 다 보는 눈이, 처음으로 별 대신 한 사람을 오래 본다.\n\n장면 제약: 이 사건에서 저택 사람은 아무도 죽지 않는다. 에스텔의 정체는 저택 사람들에게 들키지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공과 나나가 저택에 잠입하고, 변장한 에스텔이 따라와 별읽기로 길을 연다.\n\n가호를 조합해 물건을 되찾는다.\n\n나나가 예배당 입구를 알려 주고 거래가 성립한다.\n\n일이 끝난 뒤 지붕 위에 주인공과 에스텔만 남는다.",
          "selectionScope": "",
          "constraints": "이 사건에서 저택 사람은 아무도 죽지 않는다. 에스텔의 정체는 저택 사람들에게 들키지 않는다.",
          "success": "",
          "unmet": "잠입이 들키면, 나나가 연기를 피우고 에스텔이 비어 있는 복도를 읽어 셋이 반쯤 성공한 채 지붕으로 빠져나오고, 나나는 '반값'이라며 입구를 알려 준다.",
          "closureConditions": [
            {
              "id": "e30_heist-c1",
              "text": "주인공과 나나가 저택에 잠입하고, 변장한 에스텔이 따라와 별읽기로 길을 연다."
            },
            {
              "id": "e30_heist-c2",
              "text": "가호를 조합해 물건을 되찾는다."
            },
            {
              "id": "e30_heist-c3",
              "text": "나나가 예배당 입구를 알려 주고 거래가 성립한다."
            },
            {
              "id": "e30_heist-c4",
              "text": "일이 끝난 뒤 지붕 위에 주인공과 에스텔만 남는다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e30_heist-constraints",
            "description": "이 사건에서 저택 사람은 아무도 죽지 않는다. 에스텔의 정체는 저택 사람들에게 들키지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e31_chapel",
        "name": "옛 예배당",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "잿골목 아래. 무너진 성상, 지하수, 거미줄. 나나, 실피, 리네와 원하는 동료가 함께 내려간다. 거미 마수(〈거미줄〉)와 녹슨 함정들. 실피는 이상하게 길을 잘 안다. \"예전에 와 본 적이 있구먼.\" 벽에 긁힌 낯선 글자들. 주인공에게는 익숙한 모양이다.\n\n장면 제약: 벽의 글자가 무엇인지는 이 사건에서 확정되지 않는다.",
        "required": true,
        "sequence": 31,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e32_turtle",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e31_chapel-c1",
            "description": "일행이 옛 예배당 지하로 내려간다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e31_chapel-c2",
            "description": "거미 마수와 함정을 헤쳐 나간다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e31_chapel-c3",
            "description": "실피가 이곳을 아는 듯한 모습이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e31_chapel-constraints",
            "description": "벽의 글자가 무엇인지는 이 사건에서 확정되지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "옛 예배당",
        "summary": "잿골목 아래. 무너진 성상, 지하수, 거미줄. 나나, 실피, 리네와 원하는 동료가 함께 내려간다. 거미 마수(〈거미줄〉)와 녹슨 함정들. 실피는 이상하게 길을 잘 안다. \"예전에 와 본 적이 있구먼.\" 벽에 긁힌 낯선 글자들. 주인공에게는 익숙한 모양이다.\n\n장면 제약: 벽의 글자가 무엇인지는 이 사건에서 확정되지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "일행이 옛 예배당 지하로 내려간다.\n\n거미 마수와 함정을 헤쳐 나간다.\n\n실피가 이곳을 아는 듯한 모습이 드러난다.",
          "selectionScope": "",
          "constraints": "벽의 글자가 무엇인지는 이 사건에서 확정되지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e31_chapel-c1",
              "text": "일행이 옛 예배당 지하로 내려간다."
            },
            {
              "id": "e31_chapel-c2",
              "text": "거미 마수와 함정을 헤쳐 나간다."
            },
            {
              "id": "e31_chapel-c3",
              "text": "실피가 이곳을 아는 듯한 모습이 드러난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e31_chapel-constraints",
            "description": "벽의 글자가 무엇인지는 이 사건에서 확정되지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e32_turtle",
        "name": "돌거북",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 돌거북을 쓰러뜨리지 못하면, 실피가 돌거북의 등에 손을 얹고 옛말로 무언가를 속삭여 돌거북이 길을 비킨다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "예배당 가장 깊은 방을 지키는 늙은 마수 돌거북(〈무게 바꾸기〉). 깃털처럼 떠올랐다가 바위처럼 떨어지는 공격. 나나와 실피의 티키타카, 동료들의 합이 빛나는 모험의 정점. 쓰러뜨리면 그 뒤에 돌 상자 하나가 있다.\n\n[강화] 지하 탐험은 나나·실피의 티키타카와 돌거북 전투로 모험 재미를 살린다.",
        "required": true,
        "sequence": 32,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e33_diary",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e32_turtle-c1",
            "description": "돌거북과 싸운다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e32_turtle-c2",
            "description": "주인공이 돌거북을 쓰러뜨리고 가호를 가져올지 정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e32_turtle-c3",
            "description": "돌 상자를 찾는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "돌거북",
        "summary": "예배당 가장 깊은 방을 지키는 늙은 마수 돌거북(〈무게 바꾸기〉). 깃털처럼 떠올랐다가 바위처럼 떨어지는 공격. 나나와 실피의 티키타카, 동료들의 합이 빛나는 모험의 정점. 쓰러뜨리면 그 뒤에 돌 상자 하나가 있다.\n\n[강화] 지하 탐험은 나나·실피의 티키타카와 돌거북 전투로 모험 재미를 살린다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "돌거북과 싸운다.\n\n주인공이 돌거북을 쓰러뜨리고 가호를 가져올지 정한다.\n\n돌 상자를 찾는다.",
          "selectionScope": "",
          "constraints": "",
          "success": "",
          "unmet": "돌거북을 쓰러뜨리지 못하면, 실피가 돌거북의 등에 손을 얹고 옛말로 무언가를 속삭여 돌거북이 길을 비킨다.",
          "closureConditions": [
            {
              "id": "e32_turtle-c1",
              "text": "돌거북과 싸운다."
            },
            {
              "id": "e32_turtle-c2",
              "text": "주인공이 돌거북을 쓰러뜨리고 가호를 가져올지 정한다."
            },
            {
              "id": "e32_turtle-c3",
              "text": "돌 상자를 찾는다."
            }
          ]
        },
        "policyConstraints": [],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e33_diary",
        "name": "빈손의 왕의 일기",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 일기를 끝까지 읽지 않으면, 실피가 마지막 장을 펼쳐 손가락으로 짚는다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "돌 상자 속 일기. 한글이다. 300년 전 빈손의 왕은 주인공처럼 다른 세계, 조선에서 온 사람이었다. 그는 폭군이 아니었다. 귀족에게서 빼앗은 가호를 빈손들에게 나눠 주다 성인들에게 쫓겼다. \"가호에는 주인의 마지막 마음이 남는다. 그래서 빼앗은 가호는 무겁다.\" \"빼앗는 손은 주는 손이 될 수 있다. 맞잡은 손으로, 빈자리가 있는 사람에게 건네라.\" \"그릇은 놓을 줄 아는 만큼 넓어진다.\" 마지막 장. \"나는 아직 우물 안에 있다.\" 실피가 장난기를 거두고 고백한다. 자신은 그의 동료였다고. 모자 끈의 동전은 그가 준 것이라고.\n\n[핵심 공개] ① 빈손의 왕은 조선에서 온, 가호를 나눠 주던 사람이었다. ② 실피는 그의 동료였다.\n\n이 장면에 심을 복선: 나는 아직 우물 안에 있다\n일기의 마지막 장 문장을 뜻을 알 수 없는 채로 남긴다.\n우물 밑에서 빈손의 왕이 직접 말을 걸어온다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에서 회수할 복선: 경전 속 폭군\n일기로 빈손의 왕이 폭군이 아니라 가호를 나눠 주던 사람이었음이 드러난다.\n\n이 장면에서 회수할 복선: 실피 모자 끈의 동전\n실피가 빈손의 왕의 동료였고 그 동전이 그가 준 것이었음이 밝혀진다.\n\n장면 제약: 빈손의 왕의 이름은 이 사건에서 나오지 않는다. 일기는 마지막 장 문장의 뜻을 설명하지 않는다.",
        "required": true,
        "sequence": 33,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e34_giving",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e33_diary-c1",
            "description": "주인공이 일기를 읽고 빈손의 왕이 어떤 사람이었는지 알게 된다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e33_diary-c2",
            "description": "일기 속 건네는 법과 마지막 장의 문장이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e33_diary-c3",
            "description": "실피가 장난기를 거두고 자신의 과거 하나를 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e33_diary-constraints",
            "description": "빈손의 왕의 이름은 이 사건에서 나오지 않는다. 일기는 마지막 장 문장의 뜻을 설명하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "빈손의 왕의 일기",
        "summary": "돌 상자 속 일기. 한글이다. 300년 전 빈손의 왕은 주인공처럼 다른 세계, 조선에서 온 사람이었다. 그는 폭군이 아니었다. 귀족에게서 빼앗은 가호를 빈손들에게 나눠 주다 성인들에게 쫓겼다. \"가호에는 주인의 마지막 마음이 남는다. 그래서 빼앗은 가호는 무겁다.\" \"빼앗는 손은 주는 손이 될 수 있다. 맞잡은 손으로, 빈자리가 있는 사람에게 건네라.\" \"그릇은 놓을 줄 아는 만큼 넓어진다.\" 마지막 장. \"나는 아직 우물 안에 있다.\" 실피가 장난기를 거두고 고백한다. 자신은 그의 동료였다고. 모자 끈의 동전은 그가 준 것이라고.\n\n[핵심 공개] ① 빈손의 왕은 조선에서 온, 가호를 나눠 주던 사람이었다. ② 실피는 그의 동료였다.\n\n이 장면에 심을 복선: 나는 아직 우물 안에 있다\n일기의 마지막 장 문장을 뜻을 알 수 없는 채로 남긴다.\n우물 밑에서 빈손의 왕이 직접 말을 걸어온다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에서 회수할 복선: 경전 속 폭군\n일기로 빈손의 왕이 폭군이 아니라 가호를 나눠 주던 사람이었음이 드러난다.\n\n이 장면에서 회수할 복선: 실피 모자 끈의 동전\n실피가 빈손의 왕의 동료였고 그 동전이 그가 준 것이었음이 밝혀진다.\n\n장면 제약: 빈손의 왕의 이름은 이 사건에서 나오지 않는다. 일기는 마지막 장 문장의 뜻을 설명하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 일기를 읽고 빈손의 왕이 어떤 사람이었는지 알게 된다.\n\n일기 속 건네는 법과 마지막 장의 문장이 드러난다.\n\n실피가 장난기를 거두고 자신의 과거 하나를 털어놓는다.",
          "selectionScope": "",
          "constraints": "빈손의 왕의 이름은 이 사건에서 나오지 않는다. 일기는 마지막 장 문장의 뜻을 설명하지 않는다.",
          "success": "",
          "unmet": "주인공이 일기를 끝까지 읽지 않으면, 실피가 마지막 장을 펼쳐 손가락으로 짚는다.",
          "closureConditions": [
            {
              "id": "e33_diary-c1",
              "text": "주인공이 일기를 읽고 빈손의 왕이 어떤 사람이었는지 알게 된다."
            },
            {
              "id": "e33_diary-c2",
              "text": "일기 속 건네는 법과 마지막 장의 문장이 드러난다."
            },
            {
              "id": "e33_diary-c3",
              "text": "실피가 장난기를 거두고 자신의 과거 하나를 털어놓는다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e33_diary-constraints",
            "description": "빈손의 왕의 이름은 이 사건에서 나오지 않는다. 일기는 마지막 장 문장의 뜻을 설명하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e34_giving",
        "name": "건네는 손",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 아무에게도 건네지 않으면, 유리가 \"할아버지 진료소를 제가 이을게요\"라며 손을 내밀고, 주인공은 그 손을 잡은 채 건네는 감각을 처음 느낀다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "일기의 방법대로 처음으로 건넨다. 맞잡은 손, 빈자리가 있는 사람. 누구에게 무엇을 건넬지(〈치유의 손〉을 유리에게, 〈철피〉를 브로크에게, 빼앗았다면 〈불꽃 왕관〉을 이졸데에게, 혹은 다른 사람에게)는 주인공의 선택이다. 설명이 아니라 실제 성공 장면으로, 능력의 두 번째 단계가 열리는 보상을 준다. 리네는 처음으로 주인공의 손을 '빼앗는 손'이 아닌 다른 의미로 본다. 브로크를 찾아간다면, 그는 받을까, 침을 뱉을까.\n\n[핵심 공개] 주인공은 맞잡은 손으로 빈자리가 있는 사람에게 가호를 건넬 수 있다.\n\n[강화] '건네기'는 설명이 아니라 실제 성공 장면으로 능력 제2단계 해금의 보상을 준다. 리네는 시우의 손을 처음으로 '빼앗는 손' 아닌 다른 의미로 볼 수 있다.\n\n이 장면에서 회수할 복선: 실피의 점\n주인공이 처음으로 가호를 건네며 점괘의 마지막 말이 이루어진다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 가호는 줄 수도 있다\n일기의 방법대로 주인공이 맞잡은 손으로 처음 가호를 건넨다.",
        "required": true,
        "sequence": 34,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e35b_brokk_grudge",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e34_giving-c1",
            "description": "주인공이 맞잡은 손으로 가호를 다른 사람에게 건네려 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e34_giving-c2",
            "description": "건넴의 결과가 장면에 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e34_giving-c3",
            "description": "주인공이 그릇이 넓어지는 감각이나 건넴의 의미를 깨닫는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "건네는 손",
        "summary": "일기의 방법대로 처음으로 건넨다. 맞잡은 손, 빈자리가 있는 사람. 누구에게 무엇을 건넬지(〈치유의 손〉을 유리에게, 〈철피〉를 브로크에게, 빼앗았다면 〈불꽃 왕관〉을 이졸데에게, 혹은 다른 사람에게)는 주인공의 선택이다. 설명이 아니라 실제 성공 장면으로, 능력의 두 번째 단계가 열리는 보상을 준다. 리네는 처음으로 주인공의 손을 '빼앗는 손'이 아닌 다른 의미로 본다. 브로크를 찾아간다면, 그는 받을까, 침을 뱉을까.\n\n[핵심 공개] 주인공은 맞잡은 손으로 빈자리가 있는 사람에게 가호를 건넬 수 있다.\n\n[강화] '건네기'는 설명이 아니라 실제 성공 장면으로 능력 제2단계 해금의 보상을 준다. 리네는 시우의 손을 처음으로 '빼앗는 손' 아닌 다른 의미로 볼 수 있다.\n\n이 장면에서 회수할 복선: 실피의 점\n주인공이 처음으로 가호를 건네며 점괘의 마지막 말이 이루어진다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 가호는 줄 수도 있다\n일기의 방법대로 주인공이 맞잡은 손으로 처음 가호를 건넨다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 맞잡은 손으로 가호를 다른 사람에게 건네려 한다.\n\n건넴의 결과가 장면에 드러난다.\n\n주인공이 그릇이 넓어지는 감각이나 건넴의 의미를 깨닫는다.",
          "selectionScope": "",
          "constraints": "",
          "success": "",
          "unmet": "주인공이 아무에게도 건네지 않으면, 유리가 \"할아버지 진료소를 제가 이을게요\"라며 손을 내밀고, 주인공은 그 손을 잡은 채 건네는 감각을 처음 느낀다.",
          "closureConditions": [
            {
              "id": "e34_giving-c1",
              "text": "주인공이 맞잡은 손으로 가호를 다른 사람에게 건네려 한다."
            },
            {
              "id": "e34_giving-c2",
              "text": "건넴의 결과가 장면에 드러난다."
            },
            {
              "id": "e34_giving-c3",
              "text": "주인공이 그릇이 넓어지는 감각이나 건넴의 의미를 깨닫는다."
            }
          ]
        },
        "policyConstraints": [],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e35a_brokk_return",
        "name": "곰발의 귀환",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 브로크가 말을 아끼면, 그가 대장간 망치로 진료소의 부서진 문을 고치는 모습으로 대신 보여 준다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "브로크가 돌아온다. 대장간 심부름꾼이던 빈손 고아 시절, 의식에서 운 좋게 가호를 받던 날, 다시는 빈손이 되지 않겠다던 맹세. 이제 그는 자릿세 대신 골목의 밤을 지키겠다고 한다. 허세는 그대로, 의리는 진짜. 흩어진 옛 부하들을 다시 모아 '잿골목 야경단'을 꾸린다.",
        "required": true,
        "sequence": 35,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e36_clinic",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e35a_brokk_return-c1",
            "description": "브로크가 과거를 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e35a_brokk_return-c2",
            "description": "브로크가 주인공에게 의리를 맹세한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e35a_brokk_return-c3",
            "description": "브로크가 잿골목을 지키는 일을 맡는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "곰발의 귀환",
        "summary": "브로크가 돌아온다. 대장간 심부름꾼이던 빈손 고아 시절, 의식에서 운 좋게 가호를 받던 날, 다시는 빈손이 되지 않겠다던 맹세. 이제 그는 자릿세 대신 골목의 밤을 지키겠다고 한다. 허세는 그대로, 의리는 진짜. 흩어진 옛 부하들을 다시 모아 '잿골목 야경단'을 꾸린다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "브로크가 과거를 털어놓는다.\n\n브로크가 주인공에게 의리를 맹세한다.\n\n브로크가 잿골목을 지키는 일을 맡는다.",
          "selectionScope": "",
          "constraints": "",
          "success": "",
          "unmet": "브로크가 말을 아끼면, 그가 대장간 망치로 진료소의 부서진 문을 고치는 모습으로 대신 보여 준다.",
          "closureConditions": [
            {
              "id": "e35a_brokk_return-c1",
              "text": "브로크가 과거를 털어놓는다."
            },
            {
              "id": "e35a_brokk_return-c2",
              "text": "브로크가 주인공에게 의리를 맹세한다."
            },
            {
              "id": "e35a_brokk_return-c3",
              "text": "브로크가 잿골목을 지키는 일을 맡는다."
            }
          ]
        },
        "policyConstraints": [],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e35b_brokk_grudge",
        "name": "곰발의 원한",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 브로크를 찾지 않으면, 나나가 그와 성좌교 전령이 함께 있는 장면을 몰래 보여 준다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "브로크는 손을 쳐냈다(혹은 손을 내밀 기회조차 없었다). 그는 그림자 시장 뒷골목에서 성좌교 전령과 술을 마시는 모습으로 목격된다. 나나가 경고한다. \"저 아저씨, 너를 팔 생각이야.\" 주인공은 자신이 만든 원한의 무게를 실감한다.\n\n장면 제약: 브로크는 이 사건에서 주인공을 직접 공격하지 않는다.",
        "required": true,
        "sequence": 36,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e36_clinic",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e35b_brokk_grudge-c1",
            "description": "브로크가 주인공을 거부하거나 원한을 품은 모습이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e35b_brokk_grudge-c2",
            "description": "나나가 브로크의 수상한 움직임을 알려 준다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e35b_brokk_grudge-c3",
            "description": "주인공이 그 일에 대한 자신의 태도를 정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e35b_brokk_grudge-constraints",
            "description": "브로크는 이 사건에서 주인공을 직접 공격하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "곰발의 원한",
        "summary": "브로크는 손을 쳐냈다(혹은 손을 내밀 기회조차 없었다). 그는 그림자 시장 뒷골목에서 성좌교 전령과 술을 마시는 모습으로 목격된다. 나나가 경고한다. \"저 아저씨, 너를 팔 생각이야.\" 주인공은 자신이 만든 원한의 무게를 실감한다.\n\n장면 제약: 브로크는 이 사건에서 주인공을 직접 공격하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "브로크가 주인공을 거부하거나 원한을 품은 모습이 드러난다.\n\n나나가 브로크의 수상한 움직임을 알려 준다.\n\n주인공이 그 일에 대한 자신의 태도를 정한다.",
          "selectionScope": "",
          "constraints": "브로크는 이 사건에서 주인공을 직접 공격하지 않는다.",
          "success": "",
          "unmet": "주인공이 브로크를 찾지 않으면, 나나가 그와 성좌교 전령이 함께 있는 장면을 몰래 보여 준다.",
          "closureConditions": [
            {
              "id": "e35b_brokk_grudge-c1",
              "text": "브로크가 주인공을 거부하거나 원한을 품은 모습이 드러난다."
            },
            {
              "id": "e35b_brokk_grudge-c2",
              "text": "나나가 브로크의 수상한 움직임을 알려 준다."
            },
            {
              "id": "e35b_brokk_grudge-c3",
              "text": "주인공이 그 일에 대한 자신의 태도를 정한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e35b_brokk_grudge-constraints",
            "description": "브로크는 이 사건에서 주인공을 직접 공격하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e36_clinic",
        "name": "유리의 진료소",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "유리가 진료소 문을 다시 연다. 〈치유의 손〉을 받았다면 첫 치료에 떨리는 손으로, 받지 않았다면 약초와 붕대와 할아버지에게 배운 지식으로. 잿골목에 작은 희망이 켜진다. 실피는 지붕 위에서 우물 이야기를 조금 더 흘린다. \"가호는 원래 돌고 도는 거여. 누가 쥐고 놓지 않을 뿐이지.\" 해 질 녘, 두건을 쓴 에스텔이 상층 치료원에서 몰래 가져온 약상자를 들고 나타난다. 유리는 할아버지의 진료 기록에서 '두건 언니'의 이름을 찾아, 이제부터 자기가 눈을 봐 주겠다고 한다. 빨래터에서는 리네가 팔짱을 낀다. \"공작가 영애님이 여기서 뭐 해?\" 빨래를 거들겠다던 에스텔은 첫 장부터 물벼락을 맞고, 리네는 웃다가 문득 굳는다. \"우리 엄마는 '별의 뜻'이라는 말에 끌려갔어.\" 에스텔은 대답하지 못한다. 그래도 리네는 젖은 빨래를 비트는 법을 끝까지 가르쳐 준다. 그리고 약속대로, 주인공과 에스텔은 잿골목을 걷는다. 그녀의 눈에 빈손들의 가슴은 어둡게 비어 있는데, 골목은 이상하게 따뜻하다. \"빛이 없는 사람들이 이렇게 웃는 걸 처음 봐요.\" 주인공이 건넨 가호가 누군가의 가슴에 자리 잡았다면, 그녀는 그 새 불빛을 보고 숨을 삼킨다. \"빛을… 옮겨 심었어요?\"\n\n이 장면에 심을 복선: '별의 뜻'으로 끌려간 엄마\n빨래터에서 리네가 '우리 엄마는 별의 뜻이라는 말에 끌려갔어'라고 말하고, 에스텔이 대답하지 못하게 한다.\n리네가 '네가 읽은 건 네가 한 거야'라고 말하고, 에스텔이 그 말을 피하지 않는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 유리의 소원\n유리가 진료소를 다시 열며 자신의 방식으로 할아버지의 뒤를 잇는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 에스텔은 이 사건에서 상층 구역의 일을 길게 이야기하지 않는다. 리네와 에스텔은 이 사건에서 화해까지 가지 않는다.",
        "required": true,
        "sequence": 37,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e37_patchwork",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e36_clinic-c1",
            "description": "유리가 진료소를 다시 열고, 잿골목 사람들이 모여든다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e36_clinic-c2",
            "description": "에스텔이 약상자를 들고 찾아오고, 유리가 할아버지 대신 그녀의 눈을 봐 주기로 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e36_clinic-c3",
            "description": "리네와 에스텔이 처음으로 제대로 부딪친다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e36_clinic-c4",
            "description": "주인공과 에스텔이 잿골목을 함께 걷는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e36_clinic-constraints",
            "description": "에스텔은 이 사건에서 상층 구역의 일을 길게 이야기하지 않는다. 리네와 에스텔은 이 사건에서 화해까지 가지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "유리의 진료소",
        "summary": "유리가 진료소 문을 다시 연다. 〈치유의 손〉을 받았다면 첫 치료에 떨리는 손으로, 받지 않았다면 약초와 붕대와 할아버지에게 배운 지식으로. 잿골목에 작은 희망이 켜진다. 실피는 지붕 위에서 우물 이야기를 조금 더 흘린다. \"가호는 원래 돌고 도는 거여. 누가 쥐고 놓지 않을 뿐이지.\" 해 질 녘, 두건을 쓴 에스텔이 상층 치료원에서 몰래 가져온 약상자를 들고 나타난다. 유리는 할아버지의 진료 기록에서 '두건 언니'의 이름을 찾아, 이제부터 자기가 눈을 봐 주겠다고 한다. 빨래터에서는 리네가 팔짱을 낀다. \"공작가 영애님이 여기서 뭐 해?\" 빨래를 거들겠다던 에스텔은 첫 장부터 물벼락을 맞고, 리네는 웃다가 문득 굳는다. \"우리 엄마는 '별의 뜻'이라는 말에 끌려갔어.\" 에스텔은 대답하지 못한다. 그래도 리네는 젖은 빨래를 비트는 법을 끝까지 가르쳐 준다. 그리고 약속대로, 주인공과 에스텔은 잿골목을 걷는다. 그녀의 눈에 빈손들의 가슴은 어둡게 비어 있는데, 골목은 이상하게 따뜻하다. \"빛이 없는 사람들이 이렇게 웃는 걸 처음 봐요.\" 주인공이 건넨 가호가 누군가의 가슴에 자리 잡았다면, 그녀는 그 새 불빛을 보고 숨을 삼킨다. \"빛을… 옮겨 심었어요?\"\n\n이 장면에 심을 복선: '별의 뜻'으로 끌려간 엄마\n빨래터에서 리네가 '우리 엄마는 별의 뜻이라는 말에 끌려갔어'라고 말하고, 에스텔이 대답하지 못하게 한다.\n리네가 '네가 읽은 건 네가 한 거야'라고 말하고, 에스텔이 그 말을 피하지 않는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 유리의 소원\n유리가 진료소를 다시 열며 자신의 방식으로 할아버지의 뒤를 잇는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 에스텔은 이 사건에서 상층 구역의 일을 길게 이야기하지 않는다. 리네와 에스텔은 이 사건에서 화해까지 가지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "유리가 진료소를 다시 열고, 잿골목 사람들이 모여든다.\n\n에스텔이 약상자를 들고 찾아오고, 유리가 할아버지 대신 그녀의 눈을 봐 주기로 한다.\n\n리네와 에스텔이 처음으로 제대로 부딪친다.\n\n주인공과 에스텔이 잿골목을 함께 걷는다.",
          "selectionScope": "",
          "constraints": "에스텔은 이 사건에서 상층 구역의 일을 길게 이야기하지 않는다. 리네와 에스텔은 이 사건에서 화해까지 가지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e36_clinic-c1",
              "text": "유리가 진료소를 다시 열고, 잿골목 사람들이 모여든다."
            },
            {
              "id": "e36_clinic-c2",
              "text": "에스텔이 약상자를 들고 찾아오고, 유리가 할아버지 대신 그녀의 눈을 봐 주기로 한다."
            },
            {
              "id": "e36_clinic-c3",
              "text": "리네와 에스텔이 처음으로 제대로 부딪친다."
            },
            {
              "id": "e36_clinic-c4",
              "text": "주인공과 에스텔이 잿골목을 함께 걷는다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e36_clinic-constraints",
            "description": "에스텔은 이 사건에서 상층 구역의 일을 길게 이야기하지 않는다. 리네와 에스텔은 이 사건에서 화해까지 가지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e37_patchwork",
        "name": "누더기 왕",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 누더기 왕을 쓰러뜨리지 못하면, 동료들이 시간을 버는 사이 누더기 왕이 스스로 무너지며 가호 하나가 주인공에게 떨어진다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "숲 가장자리 마을이 습격당했다. 길드의 긴급 의뢰. 마수의 정체는 여러 짐승을 기워 붙인 듯한 거대한 괴물 '누더기 왕'. 몸 곳곳에 별 모양 자국이 있고, 가호를 다섯 개나 동시에 쓴다(바람발, 미끄럼, 독 이빨 같은 것들). 주인공은 자신과 닮은 괴물을 본다. 버려진 가호들이 한 짐승에게 뭉쳐 생긴 것. 파티의 총력전. 쓰러뜨리면 누더기 왕의 가호 중 하나만 고를 수 있고, 남은 가호들은 흩어져 날아간다. 하나만 고르고 나머지를 놓아 보내는 순간, 그릇이 넓어지는 감각.\n\n장면 제약: 마을 사람 중 이 사건에서 죽는 이는 없다.",
        "required": true,
        "sequence": 38,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e38_lennox",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e37_patchwork-c1",
            "description": "파티가 누더기 왕과 싸운다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e37_patchwork-c2",
            "description": "누더기 왕이 여러 가호를 가진 마수이며 몸에 별 모양 자국이 있다는 것이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e37_patchwork-c3",
            "description": "주인공이 누더기 왕을 쓰러뜨리고 가호 하나를 고른다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e37_patchwork-constraints",
            "description": "마을 사람 중 이 사건에서 죽는 이는 없다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "누더기 왕",
        "summary": "숲 가장자리 마을이 습격당했다. 길드의 긴급 의뢰. 마수의 정체는 여러 짐승을 기워 붙인 듯한 거대한 괴물 '누더기 왕'. 몸 곳곳에 별 모양 자국이 있고, 가호를 다섯 개나 동시에 쓴다(바람발, 미끄럼, 독 이빨 같은 것들). 주인공은 자신과 닮은 괴물을 본다. 버려진 가호들이 한 짐승에게 뭉쳐 생긴 것. 파티의 총력전. 쓰러뜨리면 누더기 왕의 가호 중 하나만 고를 수 있고, 남은 가호들은 흩어져 날아간다. 하나만 고르고 나머지를 놓아 보내는 순간, 그릇이 넓어지는 감각.\n\n장면 제약: 마을 사람 중 이 사건에서 죽는 이는 없다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "파티가 누더기 왕과 싸운다.\n\n누더기 왕이 여러 가호를 가진 마수이며 몸에 별 모양 자국이 있다는 것이 드러난다.\n\n주인공이 누더기 왕을 쓰러뜨리고 가호 하나를 고른다.",
          "selectionScope": "",
          "constraints": "마을 사람 중 이 사건에서 죽는 이는 없다.",
          "success": "",
          "unmet": "주인공이 누더기 왕을 쓰러뜨리지 못하면, 동료들이 시간을 버는 사이 누더기 왕이 스스로 무너지며 가호 하나가 주인공에게 떨어진다.",
          "closureConditions": [
            {
              "id": "e37_patchwork-c1",
              "text": "파티가 누더기 왕과 싸운다."
            },
            {
              "id": "e37_patchwork-c2",
              "text": "누더기 왕이 여러 가호를 가진 마수이며 몸에 별 모양 자국이 있다는 것이 드러난다."
            },
            {
              "id": "e37_patchwork-c3",
              "text": "주인공이 누더기 왕을 쓰러뜨리고 가호 하나를 고른다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e37_patchwork-constraints",
            "description": "마을 사람 중 이 사건에서 죽는 이는 없다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e38_lennox",
        "name": "레녹스의 초대",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 피핀을 쫓지 않으면, 레녹스가 먼저 피핀을 앞세워 찾아온다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "별의 대성당에 들어가려면 연줄이 필요하다. 그런데 피핀이 투기장 귀빈석으로 쪼르르 달려가 누군가에게 '보고'하는 걸 들킨다. 피핀은 엉엉 울며 이실직고한다. 제2왕자에게 돈을 받고 보고서를 썼는데, 너무 팬이 돼 버려서 다 엉터리로 썼다고. 귀빈석의 레녹스가 와인 잔을 흔든다. \"재밌는 장난감이 왔군. 내 투기장에서 우승하면 대성당 문을 열어 주지.\" 그리고 지나가듯 흘린다. \"왕실은 대성당의 인형이거든.\" 레녹스 옆자리에는 금실 별자리를 수놓은 검은 망토 차림의 에스텔이 앉아 있다. 그녀는 주인공을 모르는 척한다. 레녹스가 능글맞게 소개한다. \"내 약혼자다. 서류상으로는.\" 에스텔은 부채 뒤에서 작게 한숨을 쉬고, 레녹스는 주인공의 표정을 보고 더 재미있어한다. 그날 밤 투기장 발코니에서, 에스텔이 주인공에게만 털어놓는다. \"집안 어른이 정한 약혼이에요. 저는 그분이 그린 별자리 위에 놓인 말이에요.\" 와인 잔을 든 레녹스가 끼어든다. \"걱정 마라, 빈손. 나도 이 약혼은 질색이다.\"\n\n[핵심 공개] 피핀은 레녹스가 붙인 첩자였다.\n\n이 장면에 심을 복선: 왕실은 대성당의 인형\n레녹스가 와인 잔을 흔들며 '왕실은 대성당의 인형이거든'과 '내 약혼자다. 서류상으로는'을 농담처럼 흘리게 한다.\n레녹스가 광장에서 근위대를 이끌고, 왕실의 끈과 함께 아스트레아 가와의 약혼을 끊는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 피핀의 편지\n피핀이 제2왕자 레녹스가 붙인 첩자였고, 너무 팬이 되어 보고서를 엉터리로 썼음이 드러난다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 레녹스의 진짜 목적은 이 사건에서 드러나지 않는다. 에스텔은 집안 어른의 이름을 말하지 않는다.",
        "required": true,
        "sequence": 39,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e39_nana",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e38_lennox-c1",
            "description": "피핀이 숨겨 온 일이 들통나고, 피핀이 이실직고한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e38_lennox-c2",
            "description": "레녹스가 투기장 우승을 조건으로 대성당 출입을 제안한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e38_lennox-c3",
            "description": "레녹스가 왕실과 대성당의 관계를 흘린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e38_lennox-c4",
            "description": "귀빈석의 에스텔과 레녹스의 관계가 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e38_lennox-c5",
            "description": "에스텔이 주인공에게만 약혼의 사정을 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e38_lennox-constraints",
            "description": "레녹스의 진짜 목적은 이 사건에서 드러나지 않는다. 에스텔은 집안 어른의 이름을 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "레녹스의 초대",
        "summary": "별의 대성당에 들어가려면 연줄이 필요하다. 그런데 피핀이 투기장 귀빈석으로 쪼르르 달려가 누군가에게 '보고'하는 걸 들킨다. 피핀은 엉엉 울며 이실직고한다. 제2왕자에게 돈을 받고 보고서를 썼는데, 너무 팬이 돼 버려서 다 엉터리로 썼다고. 귀빈석의 레녹스가 와인 잔을 흔든다. \"재밌는 장난감이 왔군. 내 투기장에서 우승하면 대성당 문을 열어 주지.\" 그리고 지나가듯 흘린다. \"왕실은 대성당의 인형이거든.\" 레녹스 옆자리에는 금실 별자리를 수놓은 검은 망토 차림의 에스텔이 앉아 있다. 그녀는 주인공을 모르는 척한다. 레녹스가 능글맞게 소개한다. \"내 약혼자다. 서류상으로는.\" 에스텔은 부채 뒤에서 작게 한숨을 쉬고, 레녹스는 주인공의 표정을 보고 더 재미있어한다. 그날 밤 투기장 발코니에서, 에스텔이 주인공에게만 털어놓는다. \"집안 어른이 정한 약혼이에요. 저는 그분이 그린 별자리 위에 놓인 말이에요.\" 와인 잔을 든 레녹스가 끼어든다. \"걱정 마라, 빈손. 나도 이 약혼은 질색이다.\"\n\n[핵심 공개] 피핀은 레녹스가 붙인 첩자였다.\n\n이 장면에 심을 복선: 왕실은 대성당의 인형\n레녹스가 와인 잔을 흔들며 '왕실은 대성당의 인형이거든'과 '내 약혼자다. 서류상으로는'을 농담처럼 흘리게 한다.\n레녹스가 광장에서 근위대를 이끌고, 왕실의 끈과 함께 아스트레아 가와의 약혼을 끊는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 피핀의 편지\n피핀이 제2왕자 레녹스가 붙인 첩자였고, 너무 팬이 되어 보고서를 엉터리로 썼음이 드러난다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 레녹스의 진짜 목적은 이 사건에서 드러나지 않는다. 에스텔은 집안 어른의 이름을 말하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "피핀이 숨겨 온 일이 들통나고, 피핀이 이실직고한다.\n\n레녹스가 투기장 우승을 조건으로 대성당 출입을 제안한다.\n\n레녹스가 왕실과 대성당의 관계를 흘린다.\n\n귀빈석의 에스텔과 레녹스의 관계가 드러난다.\n\n에스텔이 주인공에게만 약혼의 사정을 털어놓는다.",
          "selectionScope": "",
          "constraints": "레녹스의 진짜 목적은 이 사건에서 드러나지 않는다. 에스텔은 집안 어른의 이름을 말하지 않는다.",
          "success": "",
          "unmet": "주인공이 피핀을 쫓지 않으면, 레녹스가 먼저 피핀을 앞세워 찾아온다.",
          "closureConditions": [
            {
              "id": "e38_lennox-c1",
              "text": "피핀이 숨겨 온 일이 들통나고, 피핀이 이실직고한다."
            },
            {
              "id": "e38_lennox-c2",
              "text": "레녹스가 투기장 우승을 조건으로 대성당 출입을 제안한다."
            },
            {
              "id": "e38_lennox-c3",
              "text": "레녹스가 왕실과 대성당의 관계를 흘린다."
            },
            {
              "id": "e38_lennox-c4",
              "text": "귀빈석의 에스텔과 레녹스의 관계가 드러난다."
            },
            {
              "id": "e38_lennox-c5",
              "text": "에스텔이 주인공에게만 약혼의 사정을 털어놓는다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e38_lennox-constraints",
            "description": "레녹스의 진짜 목적은 이 사건에서 드러나지 않는다. 에스텔은 집안 어른의 이름을 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e39_nana",
        "name": "나나의 부탁",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 대기실에 들어가지 못하면, 그라츠가 훈련장 철창 너머에서 나나의 목걸이를 보고 먼저 말을 건다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "지붕 위, 꼬리를 축 늘어뜨린 나나가 처음으로 돈 얘기 없이 부탁한다. 투기장의 무패 챔피언 그라츠는 자신의 몸값을 대신해 노예가 된 의오빠라고. 늑대 송곳니 목걸이는 그의 것이라고. 주인공은 투기장 대기실에 몰래 들어가 그라츠를 만난다. 쇠사슬, 노란 눈. \"…돌아가라, 나나.\"\n\n[핵심 공개] 투기장 챔피언 그라츠는 나나의 의오빠다.\n\n이 장면에서 회수할 복선: 늑대 송곳니 목걸이\n목걸이가 투기장 챔피언 그라츠, 나나 대신 노예가 된 의오빠의 것이었음이 드러난다.",
        "required": true,
        "sequence": 40,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e40_prelims",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e39_nana-c1",
            "description": "나나가 처음으로 돈 얘기 없이 부탁하며 목걸이의 사연을 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e39_nana-c2",
            "description": "주인공이 투기장 대기실의 그라츠를 만난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e39_nana-c3",
            "description": "주인공이 투기장에 나가기로 결심한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "나나의 부탁",
        "summary": "지붕 위, 꼬리를 축 늘어뜨린 나나가 처음으로 돈 얘기 없이 부탁한다. 투기장의 무패 챔피언 그라츠는 자신의 몸값을 대신해 노예가 된 의오빠라고. 늑대 송곳니 목걸이는 그의 것이라고. 주인공은 투기장 대기실에 몰래 들어가 그라츠를 만난다. 쇠사슬, 노란 눈. \"…돌아가라, 나나.\"\n\n[핵심 공개] 투기장 챔피언 그라츠는 나나의 의오빠다.\n\n이 장면에서 회수할 복선: 늑대 송곳니 목걸이\n목걸이가 투기장 챔피언 그라츠, 나나 대신 노예가 된 의오빠의 것이었음이 드러난다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "나나가 처음으로 돈 얘기 없이 부탁하며 목걸이의 사연을 털어놓는다.\n\n주인공이 투기장 대기실의 그라츠를 만난다.\n\n주인공이 투기장에 나가기로 결심한다.",
          "selectionScope": "",
          "constraints": "",
          "success": "",
          "unmet": "주인공이 대기실에 들어가지 못하면, 그라츠가 훈련장 철창 너머에서 나나의 목걸이를 보고 먼저 말을 건다.",
          "closureConditions": [
            {
              "id": "e39_nana-c1",
              "text": "나나가 처음으로 돈 얘기 없이 부탁하며 목걸이의 사연을 털어놓는다."
            },
            {
              "id": "e39_nana-c2",
              "text": "주인공이 투기장 대기실의 그라츠를 만난다."
            },
            {
              "id": "e39_nana-c3",
              "text": "주인공이 투기장에 나가기로 결심한다."
            }
          ]
        },
        "policyConstraints": [],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e40_prelims",
        "name": "투기장 예선",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 베른을 이기지 못하면, 베른의 뼈 칼날이 부러지는 순간 레온이 외친 한마디로 판이 뒤집힌다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "피와 함성의 투기장. 가호자 검투사들, 빈손 노예들. 주인공은 레온의 판 읽기, 동료들의 응원, 피핀의 과장된 중계 속에서 예선을 올라간다. 준결승 상대는 귀족가의 검투사 '칼날 베른'(〈뼈 칼날〉). 그는 그라츠를 '개'라 부르며 경멸하고, 관중을 위해 상대를 천천히 벤다. 이기면 다시 선택이 온다. 베른의 가호를 가져올 것인가.\n\n장면 제약: 주인공은 이 사건에서 죽지 않는다.",
        "required": true,
        "sequence": 41,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e41_wolf",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e40_prelims-c1",
            "description": "주인공이 투기장 예선을 치른다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e40_prelims-c2",
            "description": "준결승에서 칼날 베른과 싸운다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e40_prelims-c3",
            "description": "베른을 이기고, 그의 가호를 가져올지 정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e40_prelims-constraints",
            "description": "주인공은 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "투기장 예선",
        "summary": "피와 함성의 투기장. 가호자 검투사들, 빈손 노예들. 주인공은 레온의 판 읽기, 동료들의 응원, 피핀의 과장된 중계 속에서 예선을 올라간다. 준결승 상대는 귀족가의 검투사 '칼날 베른'(〈뼈 칼날〉). 그는 그라츠를 '개'라 부르며 경멸하고, 관중을 위해 상대를 천천히 벤다. 이기면 다시 선택이 온다. 베른의 가호를 가져올 것인가.\n\n장면 제약: 주인공은 이 사건에서 죽지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 투기장 예선을 치른다.\n\n준결승에서 칼날 베른과 싸운다.\n\n베른을 이기고, 그의 가호를 가져올지 정한다.",
          "selectionScope": "",
          "constraints": "주인공은 이 사건에서 죽지 않는다.",
          "success": "",
          "unmet": "주인공이 베른을 이기지 못하면, 베른의 뼈 칼날이 부러지는 순간 레온이 외친 한마디로 판이 뒤집힌다.",
          "closureConditions": [
            {
              "id": "e40_prelims-c1",
              "text": "주인공이 투기장 예선을 치른다."
            },
            {
              "id": "e40_prelims-c2",
              "text": "준결승에서 칼날 베른과 싸운다."
            },
            {
              "id": "e40_prelims-c3",
              "text": "베른을 이기고, 그의 가호를 가져올지 정한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e40_prelims-constraints",
            "description": "주인공은 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e41_wolf",
        "name": "투기장의 늑대",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 결승에서 지면, 그라츠가 마지막 순간 스스로 무릎을 꿇고 \"…동생이 웃는 걸 봤다\"며 항복해 승리가 주인공에게 돌아간다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "결승. 상대는 늑대 수인 그라츠. 수인은 태어날 때부터 가호가 없으니 빼앗을 것도 없다. 주인공은 순수하게 꾀와 가진 가호, 동료들의 도움으로 이겨야 한다. 관중석에서 나나가 목걸이를 쥐고 있고, 귀빈석의 에스텔은 부채를 접은 채 숨도 쉬지 않고 경기를 본다. 말없이 싸우던 그라츠가 단 한 번 웃는다. 이기면 레녹스의 상으로 그라츠의 자유를 얻을 수 있다.\n\n장면 제약: 그라츠에게는 빼앗을 가호가 없다. 그라츠는 이 사건에서 죽지 않는다.",
        "required": true,
        "sequence": 42,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e42_forged",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e41_wolf-c1",
            "description": "주인공이 결승에서 그라츠와 싸운다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e41_wolf-c2",
            "description": "결투의 결과가 정해진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e41_wolf-c3",
            "description": "그라츠의 처지(자유를 얻는지)가 정해진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e41_wolf-constraints",
            "description": "그라츠에게는 빼앗을 가호가 없다. 그라츠는 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "투기장의 늑대",
        "summary": "결승. 상대는 늑대 수인 그라츠. 수인은 태어날 때부터 가호가 없으니 빼앗을 것도 없다. 주인공은 순수하게 꾀와 가진 가호, 동료들의 도움으로 이겨야 한다. 관중석에서 나나가 목걸이를 쥐고 있고, 귀빈석의 에스텔은 부채를 접은 채 숨도 쉬지 않고 경기를 본다. 말없이 싸우던 그라츠가 단 한 번 웃는다. 이기면 레녹스의 상으로 그라츠의 자유를 얻을 수 있다.\n\n장면 제약: 그라츠에게는 빼앗을 가호가 없다. 그라츠는 이 사건에서 죽지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 결승에서 그라츠와 싸운다.\n\n결투의 결과가 정해진다.\n\n그라츠의 처지(자유를 얻는지)가 정해진다.",
          "selectionScope": "",
          "constraints": "그라츠에게는 빼앗을 가호가 없다. 그라츠는 이 사건에서 죽지 않는다.",
          "success": "",
          "unmet": "주인공이 결승에서 지면, 그라츠가 마지막 순간 스스로 무릎을 꿇고 \"…동생이 웃는 걸 봤다\"며 항복해 승리가 주인공에게 돌아간다.",
          "closureConditions": [
            {
              "id": "e41_wolf-c1",
              "text": "주인공이 결승에서 그라츠와 싸운다."
            },
            {
              "id": "e41_wolf-c2",
              "text": "결투의 결과가 정해진다."
            },
            {
              "id": "e41_wolf-c3",
              "text": "그라츠의 처지(자유를 얻는지)가 정해진다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e41_wolf-constraints",
            "description": "그라츠에게는 빼앗을 가호가 없다. 그라츠는 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e42_forged",
        "name": "늑대의 코",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "결승의 흥분 뒤, 그라츠가 레온의 냄새를 맡는다. \"…저 궁수도 우리 쪽이군.\" 레온은 빈손이다. 위조 증표로 길드를 속여 왔다. 소문이 나면 길드에서 쫓겨나 투기장에 팔린다. 주인공은 그를 어떻게 지킬까. 레녹스는 약속대로 대성당 통행패를 건넨다. 그리고 다음 달 별의 의식 날짜가 발표된다. 티오의 의식이다.\n\n[핵심 공개] 레온은 위조 증표를 가진 빈손이다.\n\n이 장면에서 회수할 복선: 레온의 눈치\n레온 역시 위조 증표를 가진 빈손이었음이 그라츠의 코끝에서 드러난다.\n\n장면 제약: 레온의 비밀은 이 사건에서 길드에 알려지지 않는다.",
        "required": true,
        "sequence": 43,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e43_manor",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e42_forged-c1",
            "description": "그라츠의 한마디로 레온이 숨겨 온 비밀이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e42_forged-c2",
            "description": "주인공이 레온의 비밀을 두고 자신의 태도를 보인다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e42_forged-c3",
            "description": "레녹스가 대성당 통행패를 건네고, 별의 의식 날짜가 발표된다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e42_forged-constraints",
            "description": "레온의 비밀은 이 사건에서 길드에 알려지지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "늑대의 코",
        "summary": "결승의 흥분 뒤, 그라츠가 레온의 냄새를 맡는다. \"…저 궁수도 우리 쪽이군.\" 레온은 빈손이다. 위조 증표로 길드를 속여 왔다. 소문이 나면 길드에서 쫓겨나 투기장에 팔린다. 주인공은 그를 어떻게 지킬까. 레녹스는 약속대로 대성당 통행패를 건넨다. 그리고 다음 달 별의 의식 날짜가 발표된다. 티오의 의식이다.\n\n[핵심 공개] 레온은 위조 증표를 가진 빈손이다.\n\n이 장면에서 회수할 복선: 레온의 눈치\n레온 역시 위조 증표를 가진 빈손이었음이 그라츠의 코끝에서 드러난다.\n\n장면 제약: 레온의 비밀은 이 사건에서 길드에 알려지지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "그라츠의 한마디로 레온이 숨겨 온 비밀이 드러난다.\n\n주인공이 레온의 비밀을 두고 자신의 태도를 보인다.\n\n레녹스가 대성당 통행패를 건네고, 별의 의식 날짜가 발표된다.",
          "selectionScope": "",
          "constraints": "레온의 비밀은 이 사건에서 길드에 알려지지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e42_forged-c1",
              "text": "그라츠의 한마디로 레온이 숨겨 온 비밀이 드러난다."
            },
            {
              "id": "e42_forged-c2",
              "text": "주인공이 레온의 비밀을 두고 자신의 태도를 보인다."
            },
            {
              "id": "e42_forged-c3",
              "text": "레녹스가 대성당 통행패를 건네고, 별의 의식 날짜가 발표된다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e42_forged-constraints",
            "description": "레온의 비밀은 이 사건에서 길드에 알려지지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e43_manor",
        "name": "아스트레아 저택",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 만찬에 가지 않으면, 노인이 직접 손님방을 찾아와 차를 권하고, 그를 부르러 온 시종의 한마디로 정체가 드러난다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "레녹스의 통행패로 들어선 상층 구역. 흰 대리석과 남색 별 장식. 귀족들은 아이가 받을 가호를 이미 안다는 듯 자랑한다. \"우리 애는 〈불씨〉를 받을 거래요.\" 이졸데의 옛 친구들이 다가온다. 가호를 잃었다면 노골적인 경멸, 지켰다면 '빈손과 어울리는 영애'라는 수군거림. 이졸데가 흔들리는 순간, 흑갈색 머리의 영애가 그 앞을 막아선다. \"이졸데는 제 친구예요.\" 에스텔이다. 어릴 적 사교계의 '별과 불꽃'. 두 영애가 오랜만에 티격태격한다. 에스텔은 의식 경호를 맡은 모험가라는 명목으로 일행을 아스트레아 저택에 묵게 한다. 현관 홀에는 젊은 부부의 초상화. \"동부 변경에서 잃었대요. 저는 기억도 안 나요.\" 만찬에는 흰 수염의 다정한 노인이 함께한다. 손녀의 빵을 손수 잘라 주고, 주인공에게 아랫동네의 삶을 묻고, 조용히 말한다. \"가호는 질서란다, 젊은이. 질서가 없으면 사람은 사랑하는 것을 지키지 못하지.\" 손녀의 머리를 쓰다듬는 그의 손은 크고 따뜻하다. 만찬이 끝날 무렵 시종이 그를 부른다. \"대주교 예하, 내일 예행 준비가 끝났습니다.\" 에스텔의 할아버지는 대주교 그레고르다.\n\n[핵심 공개] 에스텔의 할아버지는 대주교 그레고르다.\n\n[히로인 강화] 이졸데가 옛 상층 사회에서 흔들리는 모습을 짧게 보여 준다.\n\n이 장면에 심을 복선: 현관의 초상화\n아스트레아 저택 현관의 젊은 부부 초상화와 '동부 변경에서 잃었대요'라는 에스텔의 말을 가볍게 지나가게 한다.\n그 부부가 17년 전 내전의 불에 죽은 에스텔의 부모이며, 그 밤이 그레고르를 바꾸었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 손녀를 쓰다듬는 손\n그레고르가 크고 따뜻한 손으로 손녀의 머리를 쓰다듬는 모습을 다정하게만 그린다.\n그 손이 아이들에게 장부의 가호를 넣던 축복의 손이었음을 에스텔이 그의 앞에서 말한다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 이 사건에서 싸움은 벌어지지 않는다. 만찬은 소동 없이 끝난다.",
        "required": true,
        "sequence": 44,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e44_cathedral",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e43_manor-c1",
            "description": "일행이 상층 구역에 들어서고, 귀족들이 아이가 받을 가호를 미리 안다는 이상한 점이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e43_manor-c2",
            "description": "이졸데가 옛 사교계의 냉대를 견디고, 에스텔이 그녀의 편에 선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e43_manor-c3",
            "description": "에스텔이 일행을 저택에 묵게 하고, 만찬에서 그녀의 할아버지가 일행을 맞는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e43_manor-c4",
            "description": "에스텔의 할아버지가 누구인지 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e43_manor-constraints",
            "description": "이 사건에서 싸움은 벌어지지 않는다. 만찬은 소동 없이 끝난다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "아스트레아 저택",
        "summary": "레녹스의 통행패로 들어선 상층 구역. 흰 대리석과 남색 별 장식. 귀족들은 아이가 받을 가호를 이미 안다는 듯 자랑한다. \"우리 애는 〈불씨〉를 받을 거래요.\" 이졸데의 옛 친구들이 다가온다. 가호를 잃었다면 노골적인 경멸, 지켰다면 '빈손과 어울리는 영애'라는 수군거림. 이졸데가 흔들리는 순간, 흑갈색 머리의 영애가 그 앞을 막아선다. \"이졸데는 제 친구예요.\" 에스텔이다. 어릴 적 사교계의 '별과 불꽃'. 두 영애가 오랜만에 티격태격한다. 에스텔은 의식 경호를 맡은 모험가라는 명목으로 일행을 아스트레아 저택에 묵게 한다. 현관 홀에는 젊은 부부의 초상화. \"동부 변경에서 잃었대요. 저는 기억도 안 나요.\" 만찬에는 흰 수염의 다정한 노인이 함께한다. 손녀의 빵을 손수 잘라 주고, 주인공에게 아랫동네의 삶을 묻고, 조용히 말한다. \"가호는 질서란다, 젊은이. 질서가 없으면 사람은 사랑하는 것을 지키지 못하지.\" 손녀의 머리를 쓰다듬는 그의 손은 크고 따뜻하다. 만찬이 끝날 무렵 시종이 그를 부른다. \"대주교 예하, 내일 예행 준비가 끝났습니다.\" 에스텔의 할아버지는 대주교 그레고르다.\n\n[핵심 공개] 에스텔의 할아버지는 대주교 그레고르다.\n\n[히로인 강화] 이졸데가 옛 상층 사회에서 흔들리는 모습을 짧게 보여 준다.\n\n이 장면에 심을 복선: 현관의 초상화\n아스트레아 저택 현관의 젊은 부부 초상화와 '동부 변경에서 잃었대요'라는 에스텔의 말을 가볍게 지나가게 한다.\n그 부부가 17년 전 내전의 불에 죽은 에스텔의 부모이며, 그 밤이 그레고르를 바꾸었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 손녀를 쓰다듬는 손\n그레고르가 크고 따뜻한 손으로 손녀의 머리를 쓰다듬는 모습을 다정하게만 그린다.\n그 손이 아이들에게 장부의 가호를 넣던 축복의 손이었음을 에스텔이 그의 앞에서 말한다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 이 사건에서 싸움은 벌어지지 않는다. 만찬은 소동 없이 끝난다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "일행이 상층 구역에 들어서고, 귀족들이 아이가 받을 가호를 미리 안다는 이상한 점이 드러난다.\n\n이졸데가 옛 사교계의 냉대를 견디고, 에스텔이 그녀의 편에 선다.\n\n에스텔이 일행을 저택에 묵게 하고, 만찬에서 그녀의 할아버지가 일행을 맞는다.\n\n에스텔의 할아버지가 누구인지 드러난다.",
          "selectionScope": "",
          "constraints": "이 사건에서 싸움은 벌어지지 않는다. 만찬은 소동 없이 끝난다.",
          "success": "",
          "unmet": "주인공이 만찬에 가지 않으면, 노인이 직접 손님방을 찾아와 차를 권하고, 그를 부르러 온 시종의 한마디로 정체가 드러난다.",
          "closureConditions": [
            {
              "id": "e43_manor-c1",
              "text": "일행이 상층 구역에 들어서고, 귀족들이 아이가 받을 가호를 미리 안다는 이상한 점이 드러난다."
            },
            {
              "id": "e43_manor-c2",
              "text": "이졸데가 옛 사교계의 냉대를 견디고, 에스텔이 그녀의 편에 선다."
            },
            {
              "id": "e43_manor-c3",
              "text": "에스텔이 일행을 저택에 묵게 하고, 만찬에서 그녀의 할아버지가 일행을 맞는다."
            },
            {
              "id": "e43_manor-c4",
              "text": "에스텔의 할아버지가 누구인지 드러난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e43_manor-constraints",
            "description": "이 사건에서 싸움은 벌어지지 않는다. 만찬은 소동 없이 끝난다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e44_cathedral",
        "name": "별의 대성당",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "별의 의식 예행. 어젯밤 빵을 잘라 주던 노인이 별자리 예복을 입고 대주교로서 설교한다. \"가호는 질서입니다. 나는 가호가 무작위로 나뉘던 땅에서 피가 흐르는 것을 보았습니다.\" 그 곁에 나긋한 미소의 이단심문관 로잘린. 그리고 기적의 상징, 세 개의 가호를 가진 성녀 셀레네. 은백색 머리, 창백한 얼굴. 리네가 그 이름에 얼어붙는다. 성좌교가 성녀 후보로 데려간 언니의 이름이 셀레네였다. 셀레네는 리네를 보지 않는다. 보지 않으려 애쓴다. 제단 옆 낭독대에는 별읽기 무녀의 흰 예복을 입은 에스텔이 서서 예행 아이들의 빛을 읽는다. 성녀가 지나갈 때, 에스텔은 눈을 피한다.\n\n[핵심 공개] 성녀의 이름은 리네의 언니와 같은 셀레네다.\n\n이 장면에 심을 복선: 피가 흐르는 땅\n그레고르의 설교 속 '가호가 무작위로 나뉘던 땅에서 피가 흐르는 것을 보았습니다'를 의례적인 문구처럼 들려준다.\n17년 전 동부 변경의 내전에서 아들 부부를 잃은 밤이 그레고르의 질서의 뿌리였음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 성녀에게서 눈을 피하는 무녀\n낭독대의 에스텔이 성녀가 지나갈 때 눈을 피하는 모습만 보여 준다.\n에스텔이 성녀의 하나뿐인 자리에서 빛 셋이 겹쳐 타는 것을 보고도 침묵했다고, 실피의 고백 곁에서 털어놓는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 성녀는 이 사건에서 리네와 말을 섞지 않는다. 로잘린은 이 사건에서 주인공을 체포하지 않는다. 에스텔은 이 사건에서 일행과 아는 척하지 않는다.",
        "required": true,
        "sequence": 45,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e45_saint_hands",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e44_cathedral-c1",
            "description": "일행이 대성당에서 별의 의식 예행을 본다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e44_cathedral-c2",
            "description": "그레고르의 설교가 있고, 이단심문관 로잘린이 등장한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e44_cathedral-c3",
            "description": "성녀가 등장하고, 리네가 그 이름에 얼어붙는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e44_cathedral-c4",
            "description": "낭독대의 에스텔이 성녀에게서 눈을 피한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e44_cathedral-constraints",
            "description": "성녀는 이 사건에서 리네와 말을 섞지 않는다. 로잘린은 이 사건에서 주인공을 체포하지 않는다. 에스텔은 이 사건에서 일행과 아는 척하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "별의 대성당",
        "summary": "별의 의식 예행. 어젯밤 빵을 잘라 주던 노인이 별자리 예복을 입고 대주교로서 설교한다. \"가호는 질서입니다. 나는 가호가 무작위로 나뉘던 땅에서 피가 흐르는 것을 보았습니다.\" 그 곁에 나긋한 미소의 이단심문관 로잘린. 그리고 기적의 상징, 세 개의 가호를 가진 성녀 셀레네. 은백색 머리, 창백한 얼굴. 리네가 그 이름에 얼어붙는다. 성좌교가 성녀 후보로 데려간 언니의 이름이 셀레네였다. 셀레네는 리네를 보지 않는다. 보지 않으려 애쓴다. 제단 옆 낭독대에는 별읽기 무녀의 흰 예복을 입은 에스텔이 서서 예행 아이들의 빛을 읽는다. 성녀가 지나갈 때, 에스텔은 눈을 피한다.\n\n[핵심 공개] 성녀의 이름은 리네의 언니와 같은 셀레네다.\n\n이 장면에 심을 복선: 피가 흐르는 땅\n그레고르의 설교 속 '가호가 무작위로 나뉘던 땅에서 피가 흐르는 것을 보았습니다'를 의례적인 문구처럼 들려준다.\n17년 전 동부 변경의 내전에서 아들 부부를 잃은 밤이 그레고르의 질서의 뿌리였음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에 심을 복선: 성녀에게서 눈을 피하는 무녀\n낭독대의 에스텔이 성녀가 지나갈 때 눈을 피하는 모습만 보여 준다.\n에스텔이 성녀의 하나뿐인 자리에서 빛 셋이 겹쳐 타는 것을 보고도 침묵했다고, 실피의 고백 곁에서 털어놓는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 성녀는 이 사건에서 리네와 말을 섞지 않는다. 로잘린은 이 사건에서 주인공을 체포하지 않는다. 에스텔은 이 사건에서 일행과 아는 척하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "일행이 대성당에서 별의 의식 예행을 본다.\n\n그레고르의 설교가 있고, 이단심문관 로잘린이 등장한다.\n\n성녀가 등장하고, 리네가 그 이름에 얼어붙는다.\n\n낭독대의 에스텔이 성녀에게서 눈을 피한다.",
          "selectionScope": "",
          "constraints": "성녀는 이 사건에서 리네와 말을 섞지 않는다. 로잘린은 이 사건에서 주인공을 체포하지 않는다. 에스텔은 이 사건에서 일행과 아는 척하지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e44_cathedral-c1",
              "text": "일행이 대성당에서 별의 의식 예행을 본다."
            },
            {
              "id": "e44_cathedral-c2",
              "text": "그레고르의 설교가 있고, 이단심문관 로잘린이 등장한다."
            },
            {
              "id": "e44_cathedral-c3",
              "text": "성녀가 등장하고, 리네가 그 이름에 얼어붙는다."
            },
            {
              "id": "e44_cathedral-c4",
              "text": "낭독대의 에스텔이 성녀에게서 눈을 피한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e44_cathedral-constraints",
            "description": "성녀는 이 사건에서 리네와 말을 섞지 않는다. 로잘린은 이 사건에서 주인공을 체포하지 않는다. 에스텔은 이 사건에서 일행과 아는 척하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e45_saint_hands",
        "name": "성녀의 손",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "모험가 축복식. 줄을 선 모험가들 머리 위에 성녀가 손을 얹는다. 주인공 차례, 셀레네는 이유를 모르는 듯 그의 손을 오래 본다. 갈라진 손마디, 차가운 손가락, 미세한 떨림. \"그 손으로… 무엇을 하실 건가요.\" 로맨스를 확정하지 말고 '구해야 할지도 모르는 사람'이라는 인상을 남긴다.\n\n[히로인 강화] 셀레네는 첫 대면에서 이유를 모르는 듯 시우의 손을 오래 보고, 시우는 갈라진 손마디와 창백한 안색을 기억한다. 로맨스를 확정하지 말고 '구해야 할지도 모르는 사람'이라는 인상을 심는다.\n\n이 장면에 심을 복선: 성녀의 갈라진 손\n셀레네의 갈라진 손마디, 차가운 손가락, 미세한 떨림을 주인공이 기억하게 한다.\n그 손이 빈 가면의 손이었고, 억지로 넣은 가호가 그녀를 태우고 있었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 셀레네는 이 사건에서 성녀의 일 외의 행동을 하지 않는다.",
        "required": true,
        "sequence": 46,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e46_inquisition",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e45_saint_hands-c1",
            "description": "셀레네가 주인공에게 축복을 내리며 그의 손을 본다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e45_saint_hands-c2",
            "description": "셀레네의 갈라진 손마디와 창백한 안색이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e45_saint_hands-c3",
            "description": "셀레네가 주인공에게 수수께끼 같은 말을 남긴다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e45_saint_hands-constraints",
            "description": "셀레네는 이 사건에서 성녀의 일 외의 행동을 하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "성녀의 손",
        "summary": "모험가 축복식. 줄을 선 모험가들 머리 위에 성녀가 손을 얹는다. 주인공 차례, 셀레네는 이유를 모르는 듯 그의 손을 오래 본다. 갈라진 손마디, 차가운 손가락, 미세한 떨림. \"그 손으로… 무엇을 하실 건가요.\" 로맨스를 확정하지 말고 '구해야 할지도 모르는 사람'이라는 인상을 남긴다.\n\n[히로인 강화] 셀레네는 첫 대면에서 이유를 모르는 듯 시우의 손을 오래 보고, 시우는 갈라진 손마디와 창백한 안색을 기억한다. 로맨스를 확정하지 말고 '구해야 할지도 모르는 사람'이라는 인상을 심는다.\n\n이 장면에 심을 복선: 성녀의 갈라진 손\n셀레네의 갈라진 손마디, 차가운 손가락, 미세한 떨림을 주인공이 기억하게 한다.\n그 손이 빈 가면의 손이었고, 억지로 넣은 가호가 그녀를 태우고 있었음이 드러난다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n장면 제약: 셀레네는 이 사건에서 성녀의 일 외의 행동을 하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "셀레네가 주인공에게 축복을 내리며 그의 손을 본다.\n\n셀레네의 갈라진 손마디와 창백한 안색이 드러난다.\n\n셀레네가 주인공에게 수수께끼 같은 말을 남긴다.",
          "selectionScope": "",
          "constraints": "셀레네는 이 사건에서 성녀의 일 외의 행동을 하지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e45_saint_hands-c1",
              "text": "셀레네가 주인공에게 축복을 내리며 그의 손을 본다."
            },
            {
              "id": "e45_saint_hands-c2",
              "text": "셀레네의 갈라진 손마디와 창백한 안색이 드러난다."
            },
            {
              "id": "e45_saint_hands-c3",
              "text": "셀레네가 주인공에게 수수께끼 같은 말을 남긴다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e45_saint_hands-constraints",
            "description": "셀레네는 이 사건에서 성녀의 일 외의 행동을 하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e46_inquisition",
        "name": "이단심문",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 거짓말을 들키면, 레녹스의 통행패를 본 로잘린이 '왕자님의 손님이니 오늘은 보내 드리죠'라며 웃는다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "로잘린이 주인공을 '면담'에 부른다. 거짓말을 냄새로 맡는 〈거짓말 냄새〉. 거짓말을 하면 끝이다. 주인공은 거짓말 없이 진실을 피해 가는 말싸움을 해야 한다. 질문을 되묻기, 사실만 말하기, 말하지 않기. 로잘린의 미소가 단 한 번 진짜가 된다. \"저도 한때는 빈손이었답니다.\" 그녀는 주인공을 놓아주며 경고한다.\n\n이 장면에 심을 복선: 저도 한때는 빈손이었답니다\n로잘린의 미소가 단 한 번 진짜가 되는 순간을 짧게 남긴다.\n로잘린이 평생 따른 그레고르에게서 처음으로 거짓말 냄새를 맡는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 로잘린은 이 사건에서 주인공을 해치거나 가두지 않는다.",
        "required": true,
        "sequence": 47,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e47_rine_night",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e46_inquisition-c1",
            "description": "로잘린이 주인공을 심문한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e46_inquisition-c2",
            "description": "주인공이 거짓말을 하지 않거나 들키지 않고 심문을 넘긴다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e46_inquisition-c3",
            "description": "로잘린의 미소가 한 번 진짜가 된다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e46_inquisition-constraints",
            "description": "로잘린은 이 사건에서 주인공을 해치거나 가두지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "이단심문",
        "summary": "로잘린이 주인공을 '면담'에 부른다. 거짓말을 냄새로 맡는 〈거짓말 냄새〉. 거짓말을 하면 끝이다. 주인공은 거짓말 없이 진실을 피해 가는 말싸움을 해야 한다. 질문을 되묻기, 사실만 말하기, 말하지 않기. 로잘린의 미소가 단 한 번 진짜가 된다. \"저도 한때는 빈손이었답니다.\" 그녀는 주인공을 놓아주며 경고한다.\n\n이 장면에 심을 복선: 저도 한때는 빈손이었답니다\n로잘린의 미소가 단 한 번 진짜가 되는 순간을 짧게 남긴다.\n로잘린이 평생 따른 그레고르에게서 처음으로 거짓말 냄새를 맡는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 로잘린은 이 사건에서 주인공을 해치거나 가두지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "로잘린이 주인공을 심문한다.\n\n주인공이 거짓말을 하지 않거나 들키지 않고 심문을 넘긴다.\n\n로잘린의 미소가 한 번 진짜가 된다.",
          "selectionScope": "",
          "constraints": "로잘린은 이 사건에서 주인공을 해치거나 가두지 않는다.",
          "success": "",
          "unmet": "주인공이 거짓말을 들키면, 레녹스의 통행패를 본 로잘린이 '왕자님의 손님이니 오늘은 보내 드리죠'라며 웃는다.",
          "closureConditions": [
            {
              "id": "e46_inquisition-c1",
              "text": "로잘린이 주인공을 심문한다."
            },
            {
              "id": "e46_inquisition-c2",
              "text": "주인공이 거짓말을 하지 않거나 들키지 않고 심문을 넘긴다."
            },
            {
              "id": "e46_inquisition-c3",
              "text": "로잘린의 미소가 한 번 진짜가 된다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e46_inquisition-constraints",
            "description": "로잘린은 이 사건에서 주인공을 해치거나 가두지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e47_rine_night",
        "name": "리네의 밤",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "리네가 언니를 만나겠다며 대성당에 몰래 들어가려다 붙잡힐 뻔한다. 주인공이 막거나 함께 간다. 대성당 지붕 위에서 리네가 엄마의 노래를 부른다. 종탑 어딘가에서 같은 노래가 아주 작게 흘러나온다. 리네의 눈물, 그리고 주인공의 대답.\n\n장면 제약: 셀레네는 이 사건에서 모습을 드러내지 않는다.",
        "required": true,
        "sequence": 48,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e48_unmask",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e47_rine_night-c1",
            "description": "리네가 언니를 만나려 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e47_rine_night-c2",
            "description": "대성당 지붕에서 리네가 엄마의 노래를 부르고, 어딘가에서 같은 노래가 들린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e47_rine_night-c3",
            "description": "주인공이 리네에게 무언가를 약속하거나 곁을 지킨다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e47_rine_night-constraints",
            "description": "셀레네는 이 사건에서 모습을 드러내지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "리네의 밤",
        "summary": "리네가 언니를 만나겠다며 대성당에 몰래 들어가려다 붙잡힐 뻔한다. 주인공이 막거나 함께 간다. 대성당 지붕 위에서 리네가 엄마의 노래를 부른다. 종탑 어딘가에서 같은 노래가 아주 작게 흘러나온다. 리네의 눈물, 그리고 주인공의 대답.\n\n장면 제약: 셀레네는 이 사건에서 모습을 드러내지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "리네가 언니를 만나려 한다.\n\n대성당 지붕에서 리네가 엄마의 노래를 부르고, 어딘가에서 같은 노래가 들린다.\n\n주인공이 리네에게 무언가를 약속하거나 곁을 지킨다.",
          "selectionScope": "",
          "constraints": "셀레네는 이 사건에서 모습을 드러내지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e47_rine_night-c1",
              "text": "리네가 언니를 만나려 한다."
            },
            {
              "id": "e47_rine_night-c2",
              "text": "대성당 지붕에서 리네가 엄마의 노래를 부르고, 어딘가에서 같은 노래가 들린다."
            },
            {
              "id": "e47_rine_night-c3",
              "text": "주인공이 리네에게 무언가를 약속하거나 곁을 지킨다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e47_rine_night-constraints",
            "description": "셀레네는 이 사건에서 모습을 드러내지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e48_unmask",
        "name": "가면 아래",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 빈 가면을 쓰러뜨리지 못하면, 리네가 엄마의 노래를 부르며 앞으로 나서고, 그 노래에 빈 가면이 멈칫한 틈에 주인공의 일격이 들어간다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "빈 가면이 마침내 리네를 찾아온다. 이번엔 물러설 수 없다. 그림자 걸음, 서리 손, 가호 감지. 목표는 빈 가면을 죽이는 것이 아니라 죽이지 않고 멈추는 것이다. 주인공은 동료들과 지금까지 모은 가호와 꾀를 모두 건다.\n쓰러진 빈 가면의 가면이 깨진다. 미모보다 먼저, 리네와 닮은 표정과 손버릇과 노래가 보인다. 성녀 셀레네. 리네의 언니. 성좌교는 빈손이던 그녀의 하나뿐인 자리에 우물의 가호 세 개를 억지로 넣었고, 가호들이 그녀의 몸을 안에서부터 태우고 있다. 살리는 방법은 하나, 가호를 빼앗는 것. 그러려면 주인공은 자기 그릇을 비워야 한다. 모은 힘을 놓아야 한다. 성장의 쾌감을 거꾸로 쓰는 희생의 선택.\n\n[핵심 공개] 빈 가면은 셀레네이며, 억지로 넣은 가호가 그녀를 태우고 있다.\n\n[셀레네 강화] 목표는 셀레네를 죽이는 것이 아니라 '죽이지 않고 멈추는 것'으로 전환된다. 정체 공개는 미모보다 리네와 닮은 표정·손버릇·노래를 먼저 보여 감정을 우선한다. 그녀를 살리려면 시우가 모은 힘을 놓아야 하므로 성장 쾌감을 역으로 사용한 희생 선택으로 만든다.\n\n이 장면에서 회수할 복선: 리네의 빨래 노래\n가면 아래의 셀레네가 같은 노래를 불렀고, 자매가 엄마에게 배운 노래였음이 드러난다.\n\n이 장면에서 회수할 복선: 놓는 것도 실력\n셀레네를 살리려면 모은 힘을 놓아야 하는 순간, 그 말이 성장의 진짜 뜻으로 돌아온다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 성녀의 갈라진 손\n그 손이 빈 가면의 손이었고, 억지로 넣은 가호가 그녀를 태우고 있었음이 드러난다.\n\n장면 제약: 리네는 죽지 않는다. 빈 가면은 이 사건에서 죽지 않는다.",
        "required": true,
        "sequence": 49,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e49b_returned",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e48_unmask-c1",
            "description": "빈 가면이 리네를 노리고, 주인공이 동료들과 맞선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e48_unmask-c2",
            "description": "주인공이 빈 가면을 쓰러뜨리고, 깨진 가면 아래의 얼굴이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e48_unmask-c3",
            "description": "가면 아래 사람의 몸이 안에서부터 망가지고 있다는 것이 분명해진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e48_unmask-c4",
            "description": "주인공이 그 사람을 두고 자신의 선택을 행동으로 보인다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e48_unmask-constraints",
            "description": "리네는 죽지 않는다. 빈 가면은 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "가면 아래",
        "summary": "빈 가면이 마침내 리네를 찾아온다. 이번엔 물러설 수 없다. 그림자 걸음, 서리 손, 가호 감지. 목표는 빈 가면을 죽이는 것이 아니라 죽이지 않고 멈추는 것이다. 주인공은 동료들과 지금까지 모은 가호와 꾀를 모두 건다.\n쓰러진 빈 가면의 가면이 깨진다. 미모보다 먼저, 리네와 닮은 표정과 손버릇과 노래가 보인다. 성녀 셀레네. 리네의 언니. 성좌교는 빈손이던 그녀의 하나뿐인 자리에 우물의 가호 세 개를 억지로 넣었고, 가호들이 그녀의 몸을 안에서부터 태우고 있다. 살리는 방법은 하나, 가호를 빼앗는 것. 그러려면 주인공은 자기 그릇을 비워야 한다. 모은 힘을 놓아야 한다. 성장의 쾌감을 거꾸로 쓰는 희생의 선택.\n\n[핵심 공개] 빈 가면은 셀레네이며, 억지로 넣은 가호가 그녀를 태우고 있다.\n\n[셀레네 강화] 목표는 셀레네를 죽이는 것이 아니라 '죽이지 않고 멈추는 것'으로 전환된다. 정체 공개는 미모보다 리네와 닮은 표정·손버릇·노래를 먼저 보여 감정을 우선한다. 그녀를 살리려면 시우가 모은 힘을 놓아야 하므로 성장 쾌감을 역으로 사용한 희생 선택으로 만든다.\n\n이 장면에서 회수할 복선: 리네의 빨래 노래\n가면 아래의 셀레네가 같은 노래를 불렀고, 자매가 엄마에게 배운 노래였음이 드러난다.\n\n이 장면에서 회수할 복선: 놓는 것도 실력\n셀레네를 살리려면 모은 힘을 놓아야 하는 순간, 그 말이 성장의 진짜 뜻으로 돌아온다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 성녀의 갈라진 손\n그 손이 빈 가면의 손이었고, 억지로 넣은 가호가 그녀를 태우고 있었음이 드러난다.\n\n장면 제약: 리네는 죽지 않는다. 빈 가면은 이 사건에서 죽지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "빈 가면이 리네를 노리고, 주인공이 동료들과 맞선다.\n\n주인공이 빈 가면을 쓰러뜨리고, 깨진 가면 아래의 얼굴이 드러난다.\n\n가면 아래 사람의 몸이 안에서부터 망가지고 있다는 것이 분명해진다.\n\n주인공이 그 사람을 두고 자신의 선택을 행동으로 보인다.",
          "selectionScope": "",
          "constraints": "리네는 죽지 않는다. 빈 가면은 이 사건에서 죽지 않는다.",
          "success": "",
          "unmet": "주인공이 빈 가면을 쓰러뜨리지 못하면, 리네가 엄마의 노래를 부르며 앞으로 나서고, 그 노래에 빈 가면이 멈칫한 틈에 주인공의 일격이 들어간다.",
          "closureConditions": [
            {
              "id": "e48_unmask-c1",
              "text": "빈 가면이 리네를 노리고, 주인공이 동료들과 맞선다."
            },
            {
              "id": "e48_unmask-c2",
              "text": "주인공이 빈 가면을 쓰러뜨리고, 깨진 가면 아래의 얼굴이 드러난다."
            },
            {
              "id": "e48_unmask-c3",
              "text": "가면 아래 사람의 몸이 안에서부터 망가지고 있다는 것이 분명해진다."
            },
            {
              "id": "e48_unmask-c4",
              "text": "주인공이 그 사람을 두고 자신의 선택을 행동으로 보인다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e48_unmask-constraints",
            "description": "리네는 죽지 않는다. 빈 가면은 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e49a_sister",
        "name": "언니",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 셀레네가 깨어나지 못하면, 잠결에 엄마의 노래를 부르며 장부와 티오에 대해 띄엄띄엄 말한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "가호를 잃은 셀레네는 빈손으로 돌아왔다. 숨이 고르게 돌아오고, 7년 만에 동생의 이름을 부른다. 자매의 재회. 무표정하던 얼굴이 처음으로 무너진다. 긴장 뒤의 보상처럼, 셀레네가 뜨거운 수프나 리네의 잔소리에 당황하는 평범한 생활 장면. 주인공에게는 생명의 빚 때문에 바로 호감을 보이지 않고, 작은 신뢰의 변화만 보인다. 셀레네가 아는 것: 성녀는 대성당의 실험이었고, 대주교는 '장부'로 모든 아이의 가호를 미리 정한다. 다음 의식의 티오의 이름 옆에도 무언가가 적혀 있다. 주인공의 그릇은 세 개의 가호를 품으며 한 칸 넓어졌다. 성녀가 사라진 것을 안 성좌교가 움직이기 시작한다.\n\n[관계 보상] 재회 뒤 셀레네가 뜨거운 수프나 리네의 잔소리에 당황하는 평범한 생활 장면을 넣어 긴장 뒤 보상을 준다. 시우에게는 생명의 빚 때문에 즉시 호감을 갖지 않고 작은 신뢰 변화만 보인다.\n\n장면 제약: 셀레네는 이 사건에서 죽지 않는다.",
        "required": true,
        "sequence": 50,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e50_dorothy",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e49a_sister-c1",
            "description": "셀레네가 깨어나 리네와 재회한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e49a_sister-c2",
            "description": "셀레네가 대성당의 장부와 티오에 대한 계획을 알려 준다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e49a_sister-c3",
            "description": "성좌교가 성녀의 실종을 알고 추적을 시작한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e49a_sister-constraints",
            "description": "셀레네는 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "언니",
        "summary": "가호를 잃은 셀레네는 빈손으로 돌아왔다. 숨이 고르게 돌아오고, 7년 만에 동생의 이름을 부른다. 자매의 재회. 무표정하던 얼굴이 처음으로 무너진다. 긴장 뒤의 보상처럼, 셀레네가 뜨거운 수프나 리네의 잔소리에 당황하는 평범한 생활 장면. 주인공에게는 생명의 빚 때문에 바로 호감을 보이지 않고, 작은 신뢰의 변화만 보인다. 셀레네가 아는 것: 성녀는 대성당의 실험이었고, 대주교는 '장부'로 모든 아이의 가호를 미리 정한다. 다음 의식의 티오의 이름 옆에도 무언가가 적혀 있다. 주인공의 그릇은 세 개의 가호를 품으며 한 칸 넓어졌다. 성녀가 사라진 것을 안 성좌교가 움직이기 시작한다.\n\n[관계 보상] 재회 뒤 셀레네가 뜨거운 수프나 리네의 잔소리에 당황하는 평범한 생활 장면을 넣어 긴장 뒤 보상을 준다. 시우에게는 생명의 빚 때문에 즉시 호감을 갖지 않고 작은 신뢰 변화만 보인다.\n\n장면 제약: 셀레네는 이 사건에서 죽지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "셀레네가 깨어나 리네와 재회한다.\n\n셀레네가 대성당의 장부와 티오에 대한 계획을 알려 준다.\n\n성좌교가 성녀의 실종을 알고 추적을 시작한다.",
          "selectionScope": "",
          "constraints": "셀레네는 이 사건에서 죽지 않는다.",
          "success": "",
          "unmet": "셀레네가 깨어나지 못하면, 잠결에 엄마의 노래를 부르며 장부와 티오에 대해 띄엄띄엄 말한다.",
          "closureConditions": [
            {
              "id": "e49a_sister-c1",
              "text": "셀레네가 깨어나 리네와 재회한다."
            },
            {
              "id": "e49a_sister-c2",
              "text": "셀레네가 대성당의 장부와 티오에 대한 계획을 알려 준다."
            },
            {
              "id": "e49a_sister-c3",
              "text": "성좌교가 성녀의 실종을 알고 추적을 시작한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e49a_sister-constraints",
            "description": "셀레네는 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e49b_returned",
        "name": "돌아간 성녀",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 쪽지를 놓치면, 티오가 깨진 가면 조각 틈에 끼어 있던 쪽지를 주워 온다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "주인공은 셀레네의 가호를 가져오지 못했다(혹은 가져오지 않았다). 셀레네는 피를 토하며 그림자 속으로 사라져 대성당으로 돌아간다. 남은 것은 깨진 가면 조각과 그녀가 떨어뜨린 쪽지 한 장. \"티오를 의식에 보내지 마.\" 리네는 언니를 또 잃었다. 주인공은 셀레네가 다음 의식까지 버티지 못하리라는 것을 안다. 그리고 성좌교는 이제 빈 가면을 쓰러뜨린 자의 얼굴을 안다.\n\n장면 제약: 셀레네는 이 사건에서 죽지 않는다.",
        "required": true,
        "sequence": 51,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e50_dorothy",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e49b_returned-c1",
            "description": "셀레네가 대성당으로 돌아간다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e49b_returned-c2",
            "description": "셀레네가 남긴 쪽지로 티오가 위험하다는 것을 알게 된다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e49b_returned-c3",
            "description": "주인공과 리네가 다음 행동을 정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e49b_returned-constraints",
            "description": "셀레네는 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "돌아간 성녀",
        "summary": "주인공은 셀레네의 가호를 가져오지 못했다(혹은 가져오지 않았다). 셀레네는 피를 토하며 그림자 속으로 사라져 대성당으로 돌아간다. 남은 것은 깨진 가면 조각과 그녀가 떨어뜨린 쪽지 한 장. \"티오를 의식에 보내지 마.\" 리네는 언니를 또 잃었다. 주인공은 셀레네가 다음 의식까지 버티지 못하리라는 것을 안다. 그리고 성좌교는 이제 빈 가면을 쓰러뜨린 자의 얼굴을 안다.\n\n장면 제약: 셀레네는 이 사건에서 죽지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "셀레네가 대성당으로 돌아간다.\n\n셀레네가 남긴 쪽지로 티오가 위험하다는 것을 알게 된다.\n\n주인공과 리네가 다음 행동을 정한다.",
          "selectionScope": "",
          "constraints": "셀레네는 이 사건에서 죽지 않는다.",
          "success": "",
          "unmet": "주인공이 쪽지를 놓치면, 티오가 깨진 가면 조각 틈에 끼어 있던 쪽지를 주워 온다.",
          "closureConditions": [
            {
              "id": "e49b_returned-c1",
              "text": "셀레네가 대성당으로 돌아간다."
            },
            {
              "id": "e49b_returned-c2",
              "text": "셀레네가 남긴 쪽지로 티오가 위험하다는 것을 알게 된다."
            },
            {
              "id": "e49b_returned-c3",
              "text": "주인공과 리네가 다음 행동을 정한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e49b_returned-constraints",
            "description": "셀레네는 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e50_dorothy",
        "name": "새어 나간 계획",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 도로시를 붙잡지 못하면, 도로시가 그날 밤 스스로 다락을 찾아와 엘라의 병원 영수증을 내밀며 고백한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "대주교의 장부를 훔칠 계획을 세운다. 레녹스의 도면, 나나의 자물쇠 따기, 셀레네가 함께라면 내부 구조. 에스텔은 서고 열쇠의 본을 떠 온다. 할아버지를 배신하는 일인 줄 알면서도, 짧게만 말한다. \"할아버지의 서고에 무엇이 있는지, 이제는 봐야겠어요.\" 그런데 빈 가면이 잿골목을 덮쳤던 날처럼, 이 계획도 새어 나갈지 모른다. 레녹스가 와인 잔을 흔들며 덫을 제안한다. 의심 가는 사람마다 서로 다른 '잠입 날짜'를 흘려, 성좌교 전령이 어느 날짜에 움직이는지 보자는 것. 사흘 뒤 성기사들이 매복한 곳은 도로시에게만 알려 준 날짜의 서고 뒷문이다. 길드 뒤편에서 쪽지를 건네던 도로시를 붙잡는다. 그녀는 정보원이었다. 잿골목 소년의 소문을 넘긴 것이 빈 가면의 습격과 오스의 죽음을 불렀다. 병든 여동생 엘라의 치료비 때문이었다. 주인공을 챙긴 마음과 엘라를 살려야 했던 선택은 둘 다 진짜다. 그녀를 어떻게 할지는 주인공의 몫이다. 진짜 잠입 날짜는 아무에게도 말하지 않은 내일 밤이다.\n\n[핵심 공개] 계획을 흘려 온 정보원은 도로시였다(엘라의 치료비 때문에).\n\n[반전 과밀 완화] 도로시는 시우를 챙긴 마음과 여동생을 살려야 했던 선택이 모두 진짜였음을 보여 준다.\n\n이 장면에서 회수할 복선: 도로시의 쪽지와 엘라\n도로시가 엘라의 치료비 때문에 성좌교의 정보원이 되었고, 그 쪽지가 빈 가면의 습격을 불렀음이 드러난다.\n\n장면 제약: 도로시는 이 사건에서 죽지 않는다.",
        "required": true,
        "sequence": 52,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e51_ledger",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e50_dorothy-c1",
            "description": "장부를 훔칠 계획을 세우고, 에스텔이 서고 열쇠를 내준다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e50_dorothy-c2",
            "description": "계획이 새는 곳을 찾기 위해 덫을 놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e50_dorothy-c3",
            "description": "덫에 걸린 사람이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e50_dorothy-c4",
            "description": "주인공이 그 사람을 어떻게 할지 정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e50_dorothy-constraints",
            "description": "도로시는 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "새어 나간 계획",
        "summary": "대주교의 장부를 훔칠 계획을 세운다. 레녹스의 도면, 나나의 자물쇠 따기, 셀레네가 함께라면 내부 구조. 에스텔은 서고 열쇠의 본을 떠 온다. 할아버지를 배신하는 일인 줄 알면서도, 짧게만 말한다. \"할아버지의 서고에 무엇이 있는지, 이제는 봐야겠어요.\" 그런데 빈 가면이 잿골목을 덮쳤던 날처럼, 이 계획도 새어 나갈지 모른다. 레녹스가 와인 잔을 흔들며 덫을 제안한다. 의심 가는 사람마다 서로 다른 '잠입 날짜'를 흘려, 성좌교 전령이 어느 날짜에 움직이는지 보자는 것. 사흘 뒤 성기사들이 매복한 곳은 도로시에게만 알려 준 날짜의 서고 뒷문이다. 길드 뒤편에서 쪽지를 건네던 도로시를 붙잡는다. 그녀는 정보원이었다. 잿골목 소년의 소문을 넘긴 것이 빈 가면의 습격과 오스의 죽음을 불렀다. 병든 여동생 엘라의 치료비 때문이었다. 주인공을 챙긴 마음과 엘라를 살려야 했던 선택은 둘 다 진짜다. 그녀를 어떻게 할지는 주인공의 몫이다. 진짜 잠입 날짜는 아무에게도 말하지 않은 내일 밤이다.\n\n[핵심 공개] 계획을 흘려 온 정보원은 도로시였다(엘라의 치료비 때문에).\n\n[반전 과밀 완화] 도로시는 시우를 챙긴 마음과 여동생을 살려야 했던 선택이 모두 진짜였음을 보여 준다.\n\n이 장면에서 회수할 복선: 도로시의 쪽지와 엘라\n도로시가 엘라의 치료비 때문에 성좌교의 정보원이 되었고, 그 쪽지가 빈 가면의 습격을 불렀음이 드러난다.\n\n장면 제약: 도로시는 이 사건에서 죽지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "장부를 훔칠 계획을 세우고, 에스텔이 서고 열쇠를 내준다.\n\n계획이 새는 곳을 찾기 위해 덫을 놓는다.\n\n덫에 걸린 사람이 드러난다.\n\n주인공이 그 사람을 어떻게 할지 정한다.",
          "selectionScope": "",
          "constraints": "도로시는 이 사건에서 죽지 않는다.",
          "success": "",
          "unmet": "주인공이 도로시를 붙잡지 못하면, 도로시가 그날 밤 스스로 다락을 찾아와 엘라의 병원 영수증을 내밀며 고백한다.",
          "closureConditions": [
            {
              "id": "e50_dorothy-c1",
              "text": "장부를 훔칠 계획을 세우고, 에스텔이 서고 열쇠를 내준다."
            },
            {
              "id": "e50_dorothy-c2",
              "text": "계획이 새는 곳을 찾기 위해 덫을 놓는다."
            },
            {
              "id": "e50_dorothy-c3",
              "text": "덫에 걸린 사람이 드러난다."
            },
            {
              "id": "e50_dorothy-c4",
              "text": "주인공이 그 사람을 어떻게 할지 정한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e50_dorothy-constraints",
            "description": "도로시는 이 사건에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e51_ledger",
        "name": "대주교의 장부",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 장부를 통째로 가져오지 못해도, 주인공이 스마트폰 카메라로 핵심 장을 찍는다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "대성당 서고 잠입. 에스텔이 순찰의 순서와 서가의 위치를 안내한다. 장부의 진실은 한꺼번에 쏟지 않고 한 장씩 넘기며 드러난다. 첫 장, 다음 의식에 나올 귀족 아이들의 이름 옆에 이미 가호가 적혀 있다. 카일의 아버지가 자랑하던 '미리 정해진 가호'는 자랑이 아니라 장부의 한 줄이었다. 아이들의 빛이 축복을 받은 뒤에야 켜진다던 에스텔의 의문도 여기서 풀린다. 둘째 장, '회수'라는 칸. 우물이 모자라면 이단으로 몬 평민 가호자를 처형해 가호를 거둔다. 처형된 이름들이 끝없이 이어진다. 서고를 지키는 성기사들이 있다.\n\n[핵심 공개] ① 별의 의식은 운명이 아니라 장부의 배정이다. ② 우물이 모자라면 평민 가호자를 이단으로 몰아 처형하고 가호를 거둔다.\n\n[반전 과밀 완화] 도로시의 배신→배정제→마르타의 가호→티오 실험체 지정을 단계적으로 공개한다.\n\n이 장면에서 회수할 복선: 축복 뒤에 켜지는 빛\n장부로 별의 의식이 대주교의 손을 거친 배정이었음이 드러난다.\n\n이 장면에서 회수할 복선: 미리 정해진 가호\n별의 의식이 운명이 아니라 장부의 배정이라는 진실로 이어진다.\n\n장면 제약: 그레고르는 이 사건에 직접 나타나지 않는다. 티오를 포함한 빈손 아이들의 배정 명단과 특정 인물(마르타 등)의 회수 기록은 이 사건에서 아직 읽지 않는다.",
        "required": true,
        "sequence": 53,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e52_kyle_gift",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e51_ledger-c1",
            "description": "일행이 서고에 잠입해 장부를 찾는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e51_ledger-c2",
            "description": "장부의 첫 장에서 별의 의식에 얽힌 기록이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e51_ledger-c3",
            "description": "장부의 둘째 장에서 '회수'라는 칸의 뜻이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e51_ledger-constraints",
            "description": "그레고르는 이 사건에 직접 나타나지 않는다. 티오를 포함한 빈손 아이들의 배정 명단과 특정 인물(마르타 등)의 회수 기록은 이 사건에서 아직 읽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "대주교의 장부",
        "summary": "대성당 서고 잠입. 에스텔이 순찰의 순서와 서가의 위치를 안내한다. 장부의 진실은 한꺼번에 쏟지 않고 한 장씩 넘기며 드러난다. 첫 장, 다음 의식에 나올 귀족 아이들의 이름 옆에 이미 가호가 적혀 있다. 카일의 아버지가 자랑하던 '미리 정해진 가호'는 자랑이 아니라 장부의 한 줄이었다. 아이들의 빛이 축복을 받은 뒤에야 켜진다던 에스텔의 의문도 여기서 풀린다. 둘째 장, '회수'라는 칸. 우물이 모자라면 이단으로 몬 평민 가호자를 처형해 가호를 거둔다. 처형된 이름들이 끝없이 이어진다. 서고를 지키는 성기사들이 있다.\n\n[핵심 공개] ① 별의 의식은 운명이 아니라 장부의 배정이다. ② 우물이 모자라면 평민 가호자를 이단으로 몰아 처형하고 가호를 거둔다.\n\n[반전 과밀 완화] 도로시의 배신→배정제→마르타의 가호→티오 실험체 지정을 단계적으로 공개한다.\n\n이 장면에서 회수할 복선: 축복 뒤에 켜지는 빛\n장부로 별의 의식이 대주교의 손을 거친 배정이었음이 드러난다.\n\n이 장면에서 회수할 복선: 미리 정해진 가호\n별의 의식이 운명이 아니라 장부의 배정이라는 진실로 이어진다.\n\n장면 제약: 그레고르는 이 사건에 직접 나타나지 않는다. 티오를 포함한 빈손 아이들의 배정 명단과 특정 인물(마르타 등)의 회수 기록은 이 사건에서 아직 읽지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "일행이 서고에 잠입해 장부를 찾는다.\n\n장부의 첫 장에서 별의 의식에 얽힌 기록이 드러난다.\n\n장부의 둘째 장에서 '회수'라는 칸의 뜻이 드러난다.",
          "selectionScope": "",
          "constraints": "그레고르는 이 사건에 직접 나타나지 않는다. 티오를 포함한 빈손 아이들의 배정 명단과 특정 인물(마르타 등)의 회수 기록은 이 사건에서 아직 읽지 않는다.",
          "success": "",
          "unmet": "장부를 통째로 가져오지 못해도, 주인공이 스마트폰 카메라로 핵심 장을 찍는다.",
          "closureConditions": [
            {
              "id": "e51_ledger-c1",
              "text": "일행이 서고에 잠입해 장부를 찾는다."
            },
            {
              "id": "e51_ledger-c2",
              "text": "장부의 첫 장에서 별의 의식에 얽힌 기록이 드러난다."
            },
            {
              "id": "e51_ledger-c3",
              "text": "장부의 둘째 장에서 '회수'라는 칸의 뜻이 드러난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e51_ledger-constraints",
            "description": "그레고르는 이 사건에 직접 나타나지 않는다. 티오를 포함한 빈손 아이들의 배정 명단과 특정 인물(마르타 등)의 회수 기록은 이 사건에서 아직 읽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e52_kyle_gift",
        "name": "카일의 가호",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "장부의 한 줄. \"회수: 마르타(잿골목) 〈굳힘〉 → 배정: 반스 남작가 카일.\" 카일이 그 자리에 있다면 직접 읽고, 아니라면 주인공이 전해야 한다. 카일이 무너진다. 그의 정의가 누군가의 처형 위에 서 있었다. 리네의 얼굴. 카일은 가호를 돌려주고 싶어 한다. 리네의 대답은 지금은 받지 않겠다, 받겠다, 혹은 생각할 시간이 필요하다.\n\n[핵심 공개] 카일의 〈굳힘〉은 처형된 리네 엄마의 가호였다.\n\n이 장면에서 회수할 복선: 눈을 마주치면 멈추게 하던 엄마\n그 가호 〈굳힘〉이 엄마의 처형 뒤 카일에게 배정되었음이 드러난다.\n\n장면 제약: 카일은 이 사건에서 죽지 않는다. 리네의 대답을 대신 정하지 않고 리네 자신의 판단으로 쓴다.",
        "required": true,
        "sequence": 54,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e53_tio_name",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e52_kyle_gift-c1",
            "description": "장부의 한 줄이 카일의 가호가 어디서 왔는지 밝힌다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e52_kyle_gift-c2",
            "description": "카일이 그 사실 앞에서 무너지고 자신의 마음을 말한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e52_kyle_gift-c3",
            "description": "리네가 카일에게 대답한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e52_kyle_gift-constraints",
            "description": "카일은 이 사건에서 죽지 않는다. 리네의 대답을 대신 정하지 않고 리네 자신의 판단으로 쓴다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "카일의 가호",
        "summary": "장부의 한 줄. \"회수: 마르타(잿골목) 〈굳힘〉 → 배정: 반스 남작가 카일.\" 카일이 그 자리에 있다면 직접 읽고, 아니라면 주인공이 전해야 한다. 카일이 무너진다. 그의 정의가 누군가의 처형 위에 서 있었다. 리네의 얼굴. 카일은 가호를 돌려주고 싶어 한다. 리네의 대답은 지금은 받지 않겠다, 받겠다, 혹은 생각할 시간이 필요하다.\n\n[핵심 공개] 카일의 〈굳힘〉은 처형된 리네 엄마의 가호였다.\n\n이 장면에서 회수할 복선: 눈을 마주치면 멈추게 하던 엄마\n그 가호 〈굳힘〉이 엄마의 처형 뒤 카일에게 배정되었음이 드러난다.\n\n장면 제약: 카일은 이 사건에서 죽지 않는다. 리네의 대답을 대신 정하지 않고 리네 자신의 판단으로 쓴다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "장부의 한 줄이 카일의 가호가 어디서 왔는지 밝힌다.\n\n카일이 그 사실 앞에서 무너지고 자신의 마음을 말한다.\n\n리네가 카일에게 대답한다.",
          "selectionScope": "",
          "constraints": "카일은 이 사건에서 죽지 않는다. 리네의 대답을 대신 정하지 않고 리네 자신의 판단으로 쓴다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e52_kyle_gift-c1",
              "text": "장부의 한 줄이 카일의 가호가 어디서 왔는지 밝힌다."
            },
            {
              "id": "e52_kyle_gift-c2",
              "text": "카일이 그 사실 앞에서 무너지고 자신의 마음을 말한다."
            },
            {
              "id": "e52_kyle_gift-c3",
              "text": "리네가 카일에게 대답한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e52_kyle_gift-constraints",
            "description": "카일은 이 사건에서 죽지 않는다. 리네의 대답을 대신 정하지 않고 리네 자신의 판단으로 쓴다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e53_tio_name",
        "name": "티오의 이름",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "장부의 마지막 장. 다음 의식 명단, 티오의 이름 옆: '빈손 배정 — 성녀 후보 실험체'. 빈손 가정의 의식 헌금이 성녀 실험에 쓰였다는 기록. 셀레네가 겪은 일이 티오에게 일어난다. 리네가 깡통에 모으던 동전들이 떠오른다. 티오의 이름 옆에는 한 줄이 더 있다. '낭독: 별이 이 아이를 성녀의 길로 불렀다 — 별읽기 무녀.' 에스텔이 읽어 온 '별의 뜻'은 모두 이 목록의 대본이었다. 그녀는 자기 목소리로 티오의 운명을 선포하게 되어 있었다. 에스텔의 손에서 장부가 미끄러진다. 그리고 경보의 종소리.\n\n[핵심 공개] ① 티오는 성녀 후보 실험체로 배정되어 있다. ② 별읽기 무녀의 낭독은 장부의 대본이었다.\n\n[반전 과밀 완화] 마지막에 티오 항목을 공개해 다음 사건 긴박감으로 연결한다.\n\n이 장면에 심을 복선: 무녀의 대본\n장부의 낭독 목록에 적힌 '별이 이 아이를 성녀의 길로 불렀다'를 보여 준다.\n의식장에서 에스텔이 대본 대신 자기 말로 진실을 읽는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에서 회수할 복선: 깡통 속 의식 헌금\n빈손 가정의 의식 헌금이 성녀 실험에 쓰였다는 장부 기록으로 뒤집힌다.",
        "required": true,
        "sequence": 55,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e54_rosalind",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e53_tio_name-c1",
            "description": "장부에서 티오에 대한 기록이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e53_tio_name-c2",
            "description": "리네가 모으던 의식 헌금이 어디에 쓰였는지 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e53_tio_name-c3",
            "description": "다음 의식에서 별읽기 무녀가 읽을 문장이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e53_tio_name-c4",
            "description": "서고 침입이 발각되어 경보가 울린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "티오의 이름",
        "summary": "장부의 마지막 장. 다음 의식 명단, 티오의 이름 옆: '빈손 배정 — 성녀 후보 실험체'. 빈손 가정의 의식 헌금이 성녀 실험에 쓰였다는 기록. 셀레네가 겪은 일이 티오에게 일어난다. 리네가 깡통에 모으던 동전들이 떠오른다. 티오의 이름 옆에는 한 줄이 더 있다. '낭독: 별이 이 아이를 성녀의 길로 불렀다 — 별읽기 무녀.' 에스텔이 읽어 온 '별의 뜻'은 모두 이 목록의 대본이었다. 그녀는 자기 목소리로 티오의 운명을 선포하게 되어 있었다. 에스텔의 손에서 장부가 미끄러진다. 그리고 경보의 종소리.\n\n[핵심 공개] ① 티오는 성녀 후보 실험체로 배정되어 있다. ② 별읽기 무녀의 낭독은 장부의 대본이었다.\n\n[반전 과밀 완화] 마지막에 티오 항목을 공개해 다음 사건 긴박감으로 연결한다.\n\n이 장면에 심을 복선: 무녀의 대본\n장부의 낭독 목록에 적힌 '별이 이 아이를 성녀의 길로 불렀다'를 보여 준다.\n의식장에서 에스텔이 대본 대신 자기 말로 진실을 읽는다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에서 회수할 복선: 깡통 속 의식 헌금\n빈손 가정의 의식 헌금이 성녀 실험에 쓰였다는 장부 기록으로 뒤집힌다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "장부에서 티오에 대한 기록이 드러난다.\n\n리네가 모으던 의식 헌금이 어디에 쓰였는지 드러난다.\n\n다음 의식에서 별읽기 무녀가 읽을 문장이 드러난다.\n\n서고 침입이 발각되어 경보가 울린다.",
          "selectionScope": "",
          "constraints": "",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e53_tio_name-c1",
              "text": "장부에서 티오에 대한 기록이 드러난다."
            },
            {
              "id": "e53_tio_name-c2",
              "text": "리네가 모으던 의식 헌금이 어디에 쓰였는지 드러난다."
            },
            {
              "id": "e53_tio_name-c3",
              "text": "다음 의식에서 별읽기 무녀가 읽을 문장이 드러난다."
            },
            {
              "id": "e53_tio_name-c4",
              "text": "서고 침입이 발각되어 경보가 울린다."
            }
          ]
        },
        "policyConstraints": [],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e54_rosalind",
        "name": "로잘린",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 탈출이 막히면, 나나와 그라츠가 납골당 환기구를 부수고 길을 연다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "지하 납골당 추격전. 로잘린의 사슬 채찍, 거짓말 냄새, 성기사들의 〈빛 방패〉. 〈메아리〉 같은 가호로 속이고, 동료들이 길을 연다. 쫓기던 일행이 막다른 창고로 뛰어든다. 선반마다 희미하게 빛나는 돌들. 하나하나에 별 모양 자국이 찍혀 있다. 하수구와 늪의 마수 사체에서 본 바로 그 표식이다. 창고 밖에서는 성좌교 문장이 찍힌 수레가 돌을 싣고 있다. 늪 바닥에 남아 있던 그 바퀴 자국. 약한 가호는 '가호석'에 담겨 숲과 늪에 버려지고, 그걸 삼킨 짐승이 마수가 된다. 여럿을 삼키면 누더기 왕이 된다. 주인공의 손이 돌에 닿자, 버려진다는 것을 아는 마음들이 한꺼번에 밀려온다. 그 틈에 사슬이 날아든다. 추격 속에 로잘린의 과거가 조각조각 드러난다. 굶어 죽어 가던 잿골목 소녀, 그녀에게 손을 내민 대주교. 일행은 대성당을 빠져나온다.\n\n[핵심 공개] 별 모양 자국은 버려진 가호석의 표식이고, 마수와 누더기 왕은 성좌교가 버린 가호에서 생겼다.\n\n이 장면에서 회수할 복선: 마수 사체의 별 모양 자국\n쫓기던 일행이 가호석 창고에서, 별 모양 자국이 버려진 가호석의 표식이고 누더기 왕도 거기서 생겼음을 본다.\n\n장면 제약: 로잘린은 이 사건에서 죽지 않는다. 일행은 창고에 오래 머물지 못한다(추격이 이어진다).",
        "required": true,
        "sequence": 56,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e55_core",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e54_rosalind-c1",
            "description": "로잘린과 성기사들이 일행을 추격한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e54_rosalind-c2",
            "description": "쫓기던 일행이 지하 창고에서 뜻밖의 것을 본다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e54_rosalind-c3",
            "description": "주인공이 로잘린과 맞선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e54_rosalind-c4",
            "description": "일행이 대성당을 빠져나온다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e54_rosalind-constraints",
            "description": "로잘린은 이 사건에서 죽지 않는다. 일행은 창고에 오래 머물지 못한다(추격이 이어진다).",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "로잘린",
        "summary": "지하 납골당 추격전. 로잘린의 사슬 채찍, 거짓말 냄새, 성기사들의 〈빛 방패〉. 〈메아리〉 같은 가호로 속이고, 동료들이 길을 연다. 쫓기던 일행이 막다른 창고로 뛰어든다. 선반마다 희미하게 빛나는 돌들. 하나하나에 별 모양 자국이 찍혀 있다. 하수구와 늪의 마수 사체에서 본 바로 그 표식이다. 창고 밖에서는 성좌교 문장이 찍힌 수레가 돌을 싣고 있다. 늪 바닥에 남아 있던 그 바퀴 자국. 약한 가호는 '가호석'에 담겨 숲과 늪에 버려지고, 그걸 삼킨 짐승이 마수가 된다. 여럿을 삼키면 누더기 왕이 된다. 주인공의 손이 돌에 닿자, 버려진다는 것을 아는 마음들이 한꺼번에 밀려온다. 그 틈에 사슬이 날아든다. 추격 속에 로잘린의 과거가 조각조각 드러난다. 굶어 죽어 가던 잿골목 소녀, 그녀에게 손을 내민 대주교. 일행은 대성당을 빠져나온다.\n\n[핵심 공개] 별 모양 자국은 버려진 가호석의 표식이고, 마수와 누더기 왕은 성좌교가 버린 가호에서 생겼다.\n\n이 장면에서 회수할 복선: 마수 사체의 별 모양 자국\n쫓기던 일행이 가호석 창고에서, 별 모양 자국이 버려진 가호석의 표식이고 누더기 왕도 거기서 생겼음을 본다.\n\n장면 제약: 로잘린은 이 사건에서 죽지 않는다. 일행은 창고에 오래 머물지 못한다(추격이 이어진다).",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "로잘린과 성기사들이 일행을 추격한다.\n\n쫓기던 일행이 지하 창고에서 뜻밖의 것을 본다.\n\n주인공이 로잘린과 맞선다.\n\n일행이 대성당을 빠져나온다.",
          "selectionScope": "",
          "constraints": "로잘린은 이 사건에서 죽지 않는다. 일행은 창고에 오래 머물지 못한다(추격이 이어진다).",
          "success": "",
          "unmet": "탈출이 막히면, 나나와 그라츠가 납골당 환기구를 부수고 길을 연다.",
          "closureConditions": [
            {
              "id": "e54_rosalind-c1",
              "text": "로잘린과 성기사들이 일행을 추격한다."
            },
            {
              "id": "e54_rosalind-c2",
              "text": "쫓기던 일행이 지하 창고에서 뜻밖의 것을 본다."
            },
            {
              "id": "e54_rosalind-c3",
              "text": "주인공이 로잘린과 맞선다."
            },
            {
              "id": "e54_rosalind-c4",
              "text": "일행이 대성당을 빠져나온다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e54_rosalind-constraints",
            "description": "로잘린은 이 사건에서 죽지 않는다. 일행은 창고에 오래 머물지 못한다(추격이 이어진다).",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e55_core",
        "name": "우물의 핵",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "은신처에서 장부의 맨 앞장을 다시 본다. 300년 전 기록: '우물의 핵 — 빈손의 왕의 그릇.' 실피가 처음으로 운다. 그를 지키지 못했다고. 그 곁에서 에스텔도 입을 연다. 성녀의 하나뿐인 자리에서 빛 셋이 겹쳐 타는 것을 몇 년 동안 보았다고. 보고도 읽지 않았다고. 지키지 못한 엘프와 보고도 말하지 못한 무녀가 나란히 앉아 있다. 셀레네가 곁에 있다면 조용히 고개를 젓는다. \"보였어도, 아무도 꺼낼 수 없었을 거예요.\" 리네는 아무 말 없이 창밖만 본다. 일기 마지막 장 '나는 아직 우물 안에 있다'의 뜻이 반쯤 드러난다. 실피도 정확히는 모른다. 주인공은 결심한다. 별의 의식에서 티오를 구하고, 우물을 마주하겠다고.\n\n[핵심 공개] 우물의 핵은 빈손의 왕의 그릇이다.\n\n이 장면에서 회수할 복선: 성녀에게서 눈을 피하는 무녀\n에스텔이 성녀의 하나뿐인 자리에서 빛 셋이 겹쳐 타는 것을 보고도 침묵했다고, 실피의 고백 곁에서 털어놓는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 빈손의 왕의 이름은 이 사건에서 나오지 않는다. 리네는 이 사건에서 에스텔을 탓하지도 감싸지도 않는다.",
        "required": true,
        "sequence": 57,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e56_grandfather",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e55_core-c1",
            "description": "장부 맨 앞장의 '우물의 핵' 기록을 확인한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e55_core-c2",
            "description": "실피가 빈손의 왕을 지키지 못한 과거를 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e55_core-c3",
            "description": "에스텔이 보고도 침묵했던 것을 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e55_core-c4",
            "description": "주인공이 별의 의식에서 할 일을 결심한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e55_core-constraints",
            "description": "빈손의 왕의 이름은 이 사건에서 나오지 않는다. 리네는 이 사건에서 에스텔을 탓하지도 감싸지도 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "우물의 핵",
        "summary": "은신처에서 장부의 맨 앞장을 다시 본다. 300년 전 기록: '우물의 핵 — 빈손의 왕의 그릇.' 실피가 처음으로 운다. 그를 지키지 못했다고. 그 곁에서 에스텔도 입을 연다. 성녀의 하나뿐인 자리에서 빛 셋이 겹쳐 타는 것을 몇 년 동안 보았다고. 보고도 읽지 않았다고. 지키지 못한 엘프와 보고도 말하지 못한 무녀가 나란히 앉아 있다. 셀레네가 곁에 있다면 조용히 고개를 젓는다. \"보였어도, 아무도 꺼낼 수 없었을 거예요.\" 리네는 아무 말 없이 창밖만 본다. 일기 마지막 장 '나는 아직 우물 안에 있다'의 뜻이 반쯤 드러난다. 실피도 정확히는 모른다. 주인공은 결심한다. 별의 의식에서 티오를 구하고, 우물을 마주하겠다고.\n\n[핵심 공개] 우물의 핵은 빈손의 왕의 그릇이다.\n\n이 장면에서 회수할 복선: 성녀에게서 눈을 피하는 무녀\n에스텔이 성녀의 하나뿐인 자리에서 빛 셋이 겹쳐 타는 것을 보고도 침묵했다고, 실피의 고백 곁에서 털어놓는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 빈손의 왕의 이름은 이 사건에서 나오지 않는다. 리네는 이 사건에서 에스텔을 탓하지도 감싸지도 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "장부 맨 앞장의 '우물의 핵' 기록을 확인한다.\n\n실피가 빈손의 왕을 지키지 못한 과거를 털어놓는다.\n\n에스텔이 보고도 침묵했던 것을 털어놓는다.\n\n주인공이 별의 의식에서 할 일을 결심한다.",
          "selectionScope": "",
          "constraints": "빈손의 왕의 이름은 이 사건에서 나오지 않는다. 리네는 이 사건에서 에스텔을 탓하지도 감싸지도 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e55_core-c1",
              "text": "장부 맨 앞장의 '우물의 핵' 기록을 확인한다."
            },
            {
              "id": "e55_core-c2",
              "text": "실피가 빈손의 왕을 지키지 못한 과거를 털어놓는다."
            },
            {
              "id": "e55_core-c3",
              "text": "에스텔이 보고도 침묵했던 것을 털어놓는다."
            },
            {
              "id": "e55_core-c4",
              "text": "주인공이 별의 의식에서 할 일을 결심한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e55_core-constraints",
            "description": "빈손의 왕의 이름은 이 사건에서 나오지 않는다. 리네는 이 사건에서 에스텔을 탓하지도 감싸지도 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e56_grandfather",
        "name": "할아버지의 별",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 천문대에 가지 않으면, 새벽녘 비에 젖은 에스텔이 은신처 문을 두드리며 할아버지에게 들은 이야기를 털어놓는다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "탈출한 다음 날 밤. 에스텔은 저택 천문대로 할아버지를 찾아가기로 한다. 주인공에게 부탁한다. \"제가 도망치지 않게, 거기서 봐 주세요.\" 주인공은 천문대 난간의 그림자에 숨는다. 별을 보던 그레고르가 손녀를 맞는다. 에스텔은 장부를 보았다고 말한다. 그레고르는 부정하지 않는다. 대신 17년 전 동부 변경의 밤을 이야기한다. 가호가 무작위로 나뉘던 땅, 하루아침에 〈불꽃〉을 얻은 농부, 불타는 저택, 현관 초상화 속 아들 부부, 품 안의 갓난아기. \"나는 너를 그 불 속에서 꺼냈다. 다시는 그런 불이 없게 하는 것이 내 일이다.\" 에스텔은 울면서도 고개를 젓는다. \"할아버지는 저를 불 속에서 꺼내 주셨어요. 그 대신 다른 아이들을 넣으셨어요.\" 그녀는 별 머리핀을 탁자에 내려놓고 저택을 떠난다. 은신처의 동료들이 비에 젖은 흑갈색 머리의 그녀를 맞는다. 진료소 빨래터에서 부딪친 뒤 처음으로 리네와 에스텔이 마주 앉는다. \"네 할아버지가 한 일은 네가 한 게 아니야. 근데 네가 읽은 건 네가 한 거야.\" 에스텔은 그 말을 피하지 않는다. 리네가 먼저 마른 수건을 내민다. 처음으로 '우리'가 된 동료들의 밤, 웃음과 음식과 티격태격. 그리고 새벽, 대성당의 종이 일곱 번 울린다. 선포의 종이다.\n\n[핵심 공개] 그레고르는 17년 전 동부 변경의 내전에서 아들 부부를 잃었고, 그 밤이 그의 질서의 뿌리다.\n\n이 장면에서 회수할 복선: '별의 뜻'으로 끌려간 엄마\n리네가 '네가 읽은 건 네가 한 거야'라고 말하고, 에스텔이 그 말을 피하지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 현관의 초상화\n그 부부가 17년 전 내전의 불에 죽은 에스텔의 부모이며, 그 밤이 그레고르를 바꾸었음이 드러난다.\n\n이 장면에서 회수할 복선: 피가 흐르는 땅\n17년 전 동부 변경의 내전에서 아들 부부를 잃은 밤이 그레고르의 질서의 뿌리였음이 드러난다.\n\n장면 제약: 주인공은 이 사건에서 그레고르와 싸우지 않는다. 그레고르는 이 사건에서 손녀를 해치지 않는다.",
        "required": true,
        "sequence": 58,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e57_wanted",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e56_grandfather-c1",
            "description": "에스텔이 할아버지와 마주하고, 주인공이 그 자리를 지켜본다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e56_grandfather-c2",
            "description": "그레고르가 자신이 질서를 믿게 된 과거를 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e56_grandfather-c3",
            "description": "에스텔이 자신의 선택을 하고 저택을 떠난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e56_grandfather-c4",
            "description": "동료들이 은신처에서 에스텔을 맞고, 새벽에 선포의 종이 울린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e56_grandfather-constraints",
            "description": "주인공은 이 사건에서 그레고르와 싸우지 않는다. 그레고르는 이 사건에서 손녀를 해치지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "할아버지의 별",
        "summary": "탈출한 다음 날 밤. 에스텔은 저택 천문대로 할아버지를 찾아가기로 한다. 주인공에게 부탁한다. \"제가 도망치지 않게, 거기서 봐 주세요.\" 주인공은 천문대 난간의 그림자에 숨는다. 별을 보던 그레고르가 손녀를 맞는다. 에스텔은 장부를 보았다고 말한다. 그레고르는 부정하지 않는다. 대신 17년 전 동부 변경의 밤을 이야기한다. 가호가 무작위로 나뉘던 땅, 하루아침에 〈불꽃〉을 얻은 농부, 불타는 저택, 현관 초상화 속 아들 부부, 품 안의 갓난아기. \"나는 너를 그 불 속에서 꺼냈다. 다시는 그런 불이 없게 하는 것이 내 일이다.\" 에스텔은 울면서도 고개를 젓는다. \"할아버지는 저를 불 속에서 꺼내 주셨어요. 그 대신 다른 아이들을 넣으셨어요.\" 그녀는 별 머리핀을 탁자에 내려놓고 저택을 떠난다. 은신처의 동료들이 비에 젖은 흑갈색 머리의 그녀를 맞는다. 진료소 빨래터에서 부딪친 뒤 처음으로 리네와 에스텔이 마주 앉는다. \"네 할아버지가 한 일은 네가 한 게 아니야. 근데 네가 읽은 건 네가 한 거야.\" 에스텔은 그 말을 피하지 않는다. 리네가 먼저 마른 수건을 내민다. 처음으로 '우리'가 된 동료들의 밤, 웃음과 음식과 티격태격. 그리고 새벽, 대성당의 종이 일곱 번 울린다. 선포의 종이다.\n\n[핵심 공개] 그레고르는 17년 전 동부 변경의 내전에서 아들 부부를 잃었고, 그 밤이 그의 질서의 뿌리다.\n\n이 장면에서 회수할 복선: '별의 뜻'으로 끌려간 엄마\n리네가 '네가 읽은 건 네가 한 거야'라고 말하고, 에스텔이 그 말을 피하지 않는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 현관의 초상화\n그 부부가 17년 전 내전의 불에 죽은 에스텔의 부모이며, 그 밤이 그레고르를 바꾸었음이 드러난다.\n\n이 장면에서 회수할 복선: 피가 흐르는 땅\n17년 전 동부 변경의 내전에서 아들 부부를 잃은 밤이 그레고르의 질서의 뿌리였음이 드러난다.\n\n장면 제약: 주인공은 이 사건에서 그레고르와 싸우지 않는다. 그레고르는 이 사건에서 손녀를 해치지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "에스텔이 할아버지와 마주하고, 주인공이 그 자리를 지켜본다.\n\n그레고르가 자신이 질서를 믿게 된 과거를 털어놓는다.\n\n에스텔이 자신의 선택을 하고 저택을 떠난다.\n\n동료들이 은신처에서 에스텔을 맞고, 새벽에 선포의 종이 울린다.",
          "selectionScope": "",
          "constraints": "주인공은 이 사건에서 그레고르와 싸우지 않는다. 그레고르는 이 사건에서 손녀를 해치지 않는다.",
          "success": "",
          "unmet": "주인공이 천문대에 가지 않으면, 새벽녘 비에 젖은 에스텔이 은신처 문을 두드리며 할아버지에게 들은 이야기를 털어놓는다.",
          "closureConditions": [
            {
              "id": "e56_grandfather-c1",
              "text": "에스텔이 할아버지와 마주하고, 주인공이 그 자리를 지켜본다."
            },
            {
              "id": "e56_grandfather-c2",
              "text": "그레고르가 자신이 질서를 믿게 된 과거를 털어놓는다."
            },
            {
              "id": "e56_grandfather-c3",
              "text": "에스텔이 자신의 선택을 하고 저택을 떠난다."
            },
            {
              "id": "e56_grandfather-c4",
              "text": "동료들이 은신처에서 에스텔을 맞고, 새벽에 선포의 종이 울린다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e56_grandfather-constraints",
            "description": "주인공은 이 사건에서 그레고르와 싸우지 않는다. 그레고르는 이 사건에서 손녀를 해치지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e57_wanted",
        "name": "수배",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 사냥꾼을 쓰러뜨리지 못하면, 브로크나 그라츠가 골목 어귀에서 사냥꾼의 뒷덜미를 잡아 던진다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "선포의 종이 울린 아침. 성좌교가 왕도 곳곳에 방을 붙인다. '빈손의 왕이 돌아왔다. 가호를 훔치는 자를 신고하라.' 현상금 금화 백 닢. 방에는 한 줄이 더 있다. '빈손의 왕이 아스트레아 공작가의 별읽기 무녀를 납치했다.' 에스텔은 당장 나가서 아니라고 말하겠다고 하지만, 모습을 보이는 순간 저택으로 끌려간다. 수배 초상은 피핀이 전기에 넣으려고 그린 그림을 성좌교가 베낀 것이라, 턱은 두 배로 각지고 눈빛은 세 배로 비장하다. 리네는 배를 잡고 웃고, 이졸데는 \"실물이 낫네요\" 했다가 얼굴을 붉힌다. 그러나 웃음은 오래가지 않는다. 늘 인사하던 빵집 아주머니가 방을 한참 올려다보고, 현상금 사냥꾼이 골목에 들어온다. 그리고 기사단의 체포 명령을 받은 카일이 다락 앞에 선다. 리네는 주인공을 무작정 감싸지 않는다. 그가 빼앗은 것들, 그가 만든 빈손들을 먼저 인정한 뒤 자기 판단으로 편을 든다.\n\n[연독 강화] 피핀이 그린 과장된 수배 초상과 리네·이졸데 반응으로 잠깐 웃긴 뒤, 실제 주민이 현상금 때문에 흔들리는 모습으로 즉시 긴장으로 바꾼다. 리네는 시우를 맹목적으로 감싸지 않고 그의 잘못까지 인정한 뒤 자기 판단으로 편을 든다.\n\n장면 제약: 카일은 이 사건에서 죽지 않는다. 주인공은 이 사건에서 붙잡히지 않는다.",
        "required": true,
        "sequence": 59,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e58_alley_speech",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e57_wanted-c1",
            "description": "성좌교가 주인공을 '돌아온 빈손의 왕'으로 수배한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e57_wanted-c2",
            "description": "선포문에 에스텔에 대한 거짓이 적혀 있다는 것이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e57_wanted-c3",
            "description": "현상금 때문에 흔들리는 잿골목 사람들의 모습이 나온다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e57_wanted-c4",
            "description": "주인공이 현상금 사냥꾼과 맞서고, 그의 가호를 가져올지 정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e57_wanted-c5",
            "description": "카일이 기사단의 명령 앞에서 자신의 선택을 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e57_wanted-constraints",
            "description": "카일은 이 사건에서 죽지 않는다. 주인공은 이 사건에서 붙잡히지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "수배",
        "summary": "선포의 종이 울린 아침. 성좌교가 왕도 곳곳에 방을 붙인다. '빈손의 왕이 돌아왔다. 가호를 훔치는 자를 신고하라.' 현상금 금화 백 닢. 방에는 한 줄이 더 있다. '빈손의 왕이 아스트레아 공작가의 별읽기 무녀를 납치했다.' 에스텔은 당장 나가서 아니라고 말하겠다고 하지만, 모습을 보이는 순간 저택으로 끌려간다. 수배 초상은 피핀이 전기에 넣으려고 그린 그림을 성좌교가 베낀 것이라, 턱은 두 배로 각지고 눈빛은 세 배로 비장하다. 리네는 배를 잡고 웃고, 이졸데는 \"실물이 낫네요\" 했다가 얼굴을 붉힌다. 그러나 웃음은 오래가지 않는다. 늘 인사하던 빵집 아주머니가 방을 한참 올려다보고, 현상금 사냥꾼이 골목에 들어온다. 그리고 기사단의 체포 명령을 받은 카일이 다락 앞에 선다. 리네는 주인공을 무작정 감싸지 않는다. 그가 빼앗은 것들, 그가 만든 빈손들을 먼저 인정한 뒤 자기 판단으로 편을 든다.\n\n[연독 강화] 피핀이 그린 과장된 수배 초상과 리네·이졸데 반응으로 잠깐 웃긴 뒤, 실제 주민이 현상금 때문에 흔들리는 모습으로 즉시 긴장으로 바꾼다. 리네는 시우를 맹목적으로 감싸지 않고 그의 잘못까지 인정한 뒤 자기 판단으로 편을 든다.\n\n장면 제약: 카일은 이 사건에서 죽지 않는다. 주인공은 이 사건에서 붙잡히지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "성좌교가 주인공을 '돌아온 빈손의 왕'으로 수배한다.\n\n선포문에 에스텔에 대한 거짓이 적혀 있다는 것이 드러난다.\n\n현상금 때문에 흔들리는 잿골목 사람들의 모습이 나온다.\n\n주인공이 현상금 사냥꾼과 맞서고, 그의 가호를 가져올지 정한다.\n\n카일이 기사단의 명령 앞에서 자신의 선택을 한다.",
          "selectionScope": "",
          "constraints": "카일은 이 사건에서 죽지 않는다. 주인공은 이 사건에서 붙잡히지 않는다.",
          "success": "",
          "unmet": "주인공이 사냥꾼을 쓰러뜨리지 못하면, 브로크나 그라츠가 골목 어귀에서 사냥꾼의 뒷덜미를 잡아 던진다.",
          "closureConditions": [
            {
              "id": "e57_wanted-c1",
              "text": "성좌교가 주인공을 '돌아온 빈손의 왕'으로 수배한다."
            },
            {
              "id": "e57_wanted-c2",
              "text": "선포문에 에스텔에 대한 거짓이 적혀 있다는 것이 드러난다."
            },
            {
              "id": "e57_wanted-c3",
              "text": "현상금 때문에 흔들리는 잿골목 사람들의 모습이 나온다."
            },
            {
              "id": "e57_wanted-c4",
              "text": "주인공이 현상금 사냥꾼과 맞서고, 그의 가호를 가져올지 정한다."
            },
            {
              "id": "e57_wanted-c5",
              "text": "카일이 기사단의 명령 앞에서 자신의 선택을 한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e57_wanted-constraints",
            "description": "카일은 이 사건에서 죽지 않는다. 주인공은 이 사건에서 붙잡히지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e58_alley_speech",
        "name": "잿골목의 밤",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 끝내 말을 아끼면, 리네가 먼저 '이 사람을 부른 건 나야'라고 털어놓고, 사람들의 시선이 둘에게 쏠린 채 대답을 기다린다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "그날 밤 오스의 옛 진료소 앞 공터에 잿골목 사람들이 모인다. 등불 몇 개, 굳은 얼굴들. \"네가 정말 그 빈손의 왕이야?\" \"우리 가호도 빼앗을 거냐?\" \"금화 백 닢이면 애들 겨울을 난다고.\" 주인공이 지금까지 한 일이 그대로 돌아온다. 그가 빈손으로 만든 사람들의 이름이 오르내리고, 그가 지킨 아이들의 엄마들이 있다. 주인공은 무엇을 말할 것인가. 힘을 숨길지, 잘못까지 밝힐지, 무엇을 약속할지. 리네는 빨래 통 위에 올라서는 대신 그의 옆에 선다. '납치당한' 공작가 영애가 두건을 벗고 그 반대편에 서자, 사람들이 더 크게 술렁인다. 사람들의 마음은 말보다 그가 지금까지 한 일로 기운다.\n\n장면 제약: 이 사건에서 잿골목 사람들과 주인공 사이에 칼부림은 일어나지 않는다.",
        "required": true,
        "sequence": 60,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e59b_sold",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e58_alley_speech-c1",
            "description": "잿골목 사람들이 모여 주인공에 대한 두려움과 현상금 이야기를 꺼낸다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e58_alley_speech-c2",
            "description": "주인공이 사람들 앞에서 자신의 입장을 밝힌다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e58_alley_speech-c3",
            "description": "사람들의 반응이 정해진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e58_alley_speech-constraints",
            "description": "이 사건에서 잿골목 사람들과 주인공 사이에 칼부림은 일어나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "잿골목의 밤",
        "summary": "그날 밤 오스의 옛 진료소 앞 공터에 잿골목 사람들이 모인다. 등불 몇 개, 굳은 얼굴들. \"네가 정말 그 빈손의 왕이야?\" \"우리 가호도 빼앗을 거냐?\" \"금화 백 닢이면 애들 겨울을 난다고.\" 주인공이 지금까지 한 일이 그대로 돌아온다. 그가 빈손으로 만든 사람들의 이름이 오르내리고, 그가 지킨 아이들의 엄마들이 있다. 주인공은 무엇을 말할 것인가. 힘을 숨길지, 잘못까지 밝힐지, 무엇을 약속할지. 리네는 빨래 통 위에 올라서는 대신 그의 옆에 선다. '납치당한' 공작가 영애가 두건을 벗고 그 반대편에 서자, 사람들이 더 크게 술렁인다. 사람들의 마음은 말보다 그가 지금까지 한 일로 기운다.\n\n장면 제약: 이 사건에서 잿골목 사람들과 주인공 사이에 칼부림은 일어나지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "잿골목 사람들이 모여 주인공에 대한 두려움과 현상금 이야기를 꺼낸다.\n\n주인공이 사람들 앞에서 자신의 입장을 밝힌다.\n\n사람들의 반응이 정해진다.",
          "selectionScope": "",
          "constraints": "이 사건에서 잿골목 사람들과 주인공 사이에 칼부림은 일어나지 않는다.",
          "success": "",
          "unmet": "주인공이 끝내 말을 아끼면, 리네가 먼저 '이 사람을 부른 건 나야'라고 털어놓고, 사람들의 시선이 둘에게 쏠린 채 대답을 기다린다.",
          "closureConditions": [
            {
              "id": "e58_alley_speech-c1",
              "text": "잿골목 사람들이 모여 주인공에 대한 두려움과 현상금 이야기를 꺼낸다."
            },
            {
              "id": "e58_alley_speech-c2",
              "text": "주인공이 사람들 앞에서 자신의 입장을 밝힌다."
            },
            {
              "id": "e58_alley_speech-c3",
              "text": "사람들의 반응이 정해진다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e58_alley_speech-constraints",
            "description": "이 사건에서 잿골목 사람들과 주인공 사이에 칼부림은 일어나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e59a_lanterns",
        "name": "잿골목의 등불",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "침묵을 깬 건 빵집 아주머니다. 그녀가 자기 등불을 주인공 발치에 내려놓는다. 유리의 진료소에서 다리를 고친 짐꾼이, 잿쥐의 밤에 살아남은 아이들의 엄마가, 빨래터의 아낙들이 차례로 등불을 든다. 브로크가 곁에 있다면 야경단이 골목 어귀를 지킨다. 그들이 하는 말은 하나다. \"의식 날, 우리도 광장에 간다.\" 빈손들이 처음으로 숨지 않기로 한 밤. 티오는 막대기 검을 등불 옆에 세운다.",
        "required": true,
        "sequence": 61,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e61_eve",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e59a_lanterns-c1",
            "description": "잿골목 사람들이 등불을 들고 주인공 편에 서기로 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e59a_lanterns-c2",
            "description": "의식 날 광장에 함께 가자는 약속이 나온다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e59a_lanterns-c3",
            "description": "티오나 아이들이 그 약속에 함께하는 모습이 나온다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "잿골목의 등불",
        "summary": "침묵을 깬 건 빵집 아주머니다. 그녀가 자기 등불을 주인공 발치에 내려놓는다. 유리의 진료소에서 다리를 고친 짐꾼이, 잿쥐의 밤에 살아남은 아이들의 엄마가, 빨래터의 아낙들이 차례로 등불을 든다. 브로크가 곁에 있다면 야경단이 골목 어귀를 지킨다. 그들이 하는 말은 하나다. \"의식 날, 우리도 광장에 간다.\" 빈손들이 처음으로 숨지 않기로 한 밤. 티오는 막대기 검을 등불 옆에 세운다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "잿골목 사람들이 등불을 들고 주인공 편에 서기로 한다.\n\n의식 날 광장에 함께 가자는 약속이 나온다.\n\n티오나 아이들이 그 약속에 함께하는 모습이 나온다.",
          "selectionScope": "",
          "constraints": "",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e59a_lanterns-c1",
              "text": "잿골목 사람들이 등불을 들고 주인공 편에 서기로 한다."
            },
            {
              "id": "e59a_lanterns-c2",
              "text": "의식 날 광장에 함께 가자는 약속이 나온다."
            },
            {
              "id": "e59a_lanterns-c3",
              "text": "티오나 아이들이 그 약속에 함께하는 모습이 나온다."
            }
          ]
        },
        "policyConstraints": [],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e59b_sold",
        "name": "팔려 간 밤",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 밀고자를 알아내지 못하면, 나나가 그림자 시장에서 금화를 바꾸러 온 사람의 이름을 물어 온다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "모임은 굳은 침묵으로 흩어진다. 그리고 그날 밤, 누군가가 주인공을 판다. 「곰발의 원한」을 지났다면 그것은 브로크다. 아니라면 주인공이 빈손으로 만든 사람(가릭이나 베른)이다. 성기사들이 세탁장 다락을 급습한다. 주인공은 나나와 그라츠의 도움으로 에스텔의 손을 잡고 지붕을 넘어 빠져나오지만, 리네와 티오가 끌려간다. 리네는 끌려가면서도 소리친다. \"바보야, 뒤돌아보지 말고 뛰어!\" 밀고자는 금화를 쥐고도 웃지 못한다.\n\n장면 제약: 리네와 티오는 다치더라도 죽지 않는다. 주인공은 이 사건에서 붙잡히지 않는다.",
        "required": true,
        "sequence": 62,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e61_eve",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e59b_sold-c1",
            "description": "누군가 주인공을 성좌교에 밀고한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e59b_sold-c2",
            "description": "성기사들이 다락을 급습하고, 주인공 일행이 소중한 사람을 빼앗긴다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e59b_sold-c3",
            "description": "주인공이 빠져나오고, 밀고자의 정체가 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e59b_sold-constraints",
            "description": "리네와 티오는 다치더라도 죽지 않는다. 주인공은 이 사건에서 붙잡히지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "팔려 간 밤",
        "summary": "모임은 굳은 침묵으로 흩어진다. 그리고 그날 밤, 누군가가 주인공을 판다. 「곰발의 원한」을 지났다면 그것은 브로크다. 아니라면 주인공이 빈손으로 만든 사람(가릭이나 베른)이다. 성기사들이 세탁장 다락을 급습한다. 주인공은 나나와 그라츠의 도움으로 에스텔의 손을 잡고 지붕을 넘어 빠져나오지만, 리네와 티오가 끌려간다. 리네는 끌려가면서도 소리친다. \"바보야, 뒤돌아보지 말고 뛰어!\" 밀고자는 금화를 쥐고도 웃지 못한다.\n\n장면 제약: 리네와 티오는 다치더라도 죽지 않는다. 주인공은 이 사건에서 붙잡히지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "누군가 주인공을 성좌교에 밀고한다.\n\n성기사들이 다락을 급습하고, 주인공 일행이 소중한 사람을 빼앗긴다.\n\n주인공이 빠져나오고, 밀고자의 정체가 드러난다.",
          "selectionScope": "",
          "constraints": "리네와 티오는 다치더라도 죽지 않는다. 주인공은 이 사건에서 붙잡히지 않는다.",
          "success": "",
          "unmet": "주인공이 밀고자를 알아내지 못하면, 나나가 그림자 시장에서 금화를 바꾸러 온 사람의 이름을 물어 온다.",
          "closureConditions": [
            {
              "id": "e59b_sold-c1",
              "text": "누군가 주인공을 성좌교에 밀고한다."
            },
            {
              "id": "e59b_sold-c2",
              "text": "성기사들이 다락을 급습하고, 주인공 일행이 소중한 사람을 빼앗긴다."
            },
            {
              "id": "e59b_sold-c3",
              "text": "주인공이 빠져나오고, 밀고자의 정체가 드러난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e59b_sold-constraints",
            "description": "리네와 티오는 다치더라도 죽지 않는다. 주인공은 이 사건에서 붙잡히지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e61_eve",
        "name": "의식 전야",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 망설이면, 지붕 위에서 리네가 '거기 서 있지 말고 올라와, 바보야' 하고 부른다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "의식 전날. 레녹스의 낡은 사냥 별장이 마지막 은신처가 된다. 작전은 짧게 맞춘다. 레녹스의 근위대, 나나와 그라츠의 하수도 길, 레온의 종탑 활자리, 유리의 임시 진료소, 실피가 아는 우물 옛길, 도로시가 빼낸 기사단 배치, 피핀의 노래, 기사단 안에서 문 하나를 열어 둘 카일. 에스텔은 낭독대의 위치를 짚는다. \"내일 저 자리에는 제가 서야 해요.\" 리네와 티오가 붙잡혀 있다면 작전의 첫 줄은 단상 위 두 사람을 되찾는 것이다. 누가 와 있고 누가 없는지는 지금까지 주인공이 걸어온 길이 정한다.\n밤이 되면 별장은 이상하게 조용하다. 나나는 그라츠의 어깨에 기대 졸고, 피핀은 가사를 고치고, 레온은 화살 깃을 다듬는다. 그리고 네 곳에 불이 켜져 있다. 지붕에는 늘 그랬듯 리네가 먼저 올라가 있다(붙잡혀 있다면, 지붕은 비어 있고 대성당 종탑 쪽에서 낮은 노랫소리가 바람에 실려 온다). 망루에는 망원경도 없이 별을 올려다보는 에스텔. 훈련장에서는 검이 바람을 가르는 소리. 종탑 창가에는 셀레네(곁에 없다면, 대성당 종탑의 창 하나에 불이 켜져 있다). 마지막 밤을 누구와 보낼지는 주인공이 정한다. 찾아간 사람과 나눈 약속은 내일 광장에서 돌아온다.\n\n[히로인 보상] 의식 전야는 관계 보상 구간이다. 리네가 기본적으로 지붕에 먼저 와 있고, 선택에 따라 이졸데 또는 셀레네와 별도 짧은 대화가 가능하다.\n\n장면 제약: 그레고르는 이 사건에 나타나지 않는다.",
        "required": true,
        "sequence": 63,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e62a_eve_rine",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e61_eve-c1",
            "description": "동료들이 의식 날의 작전을 짧게 맞춘다(리네와 티오가 붙잡혀 있다면 구출이 첫 줄이다).",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e61_eve-c2",
            "description": "동료들이 각자 전야를 보내는 모습이 짧게 스친다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e61_eve-c3",
            "description": "주인공이 이 밤을 누구에게 찾아갈지 정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e61_eve-constraints",
            "description": "그레고르는 이 사건에 나타나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "의식 전야",
        "summary": "의식 전날. 레녹스의 낡은 사냥 별장이 마지막 은신처가 된다. 작전은 짧게 맞춘다. 레녹스의 근위대, 나나와 그라츠의 하수도 길, 레온의 종탑 활자리, 유리의 임시 진료소, 실피가 아는 우물 옛길, 도로시가 빼낸 기사단 배치, 피핀의 노래, 기사단 안에서 문 하나를 열어 둘 카일. 에스텔은 낭독대의 위치를 짚는다. \"내일 저 자리에는 제가 서야 해요.\" 리네와 티오가 붙잡혀 있다면 작전의 첫 줄은 단상 위 두 사람을 되찾는 것이다. 누가 와 있고 누가 없는지는 지금까지 주인공이 걸어온 길이 정한다.\n밤이 되면 별장은 이상하게 조용하다. 나나는 그라츠의 어깨에 기대 졸고, 피핀은 가사를 고치고, 레온은 화살 깃을 다듬는다. 그리고 네 곳에 불이 켜져 있다. 지붕에는 늘 그랬듯 리네가 먼저 올라가 있다(붙잡혀 있다면, 지붕은 비어 있고 대성당 종탑 쪽에서 낮은 노랫소리가 바람에 실려 온다). 망루에는 망원경도 없이 별을 올려다보는 에스텔. 훈련장에서는 검이 바람을 가르는 소리. 종탑 창가에는 셀레네(곁에 없다면, 대성당 종탑의 창 하나에 불이 켜져 있다). 마지막 밤을 누구와 보낼지는 주인공이 정한다. 찾아간 사람과 나눈 약속은 내일 광장에서 돌아온다.\n\n[히로인 보상] 의식 전야는 관계 보상 구간이다. 리네가 기본적으로 지붕에 먼저 와 있고, 선택에 따라 이졸데 또는 셀레네와 별도 짧은 대화가 가능하다.\n\n장면 제약: 그레고르는 이 사건에 나타나지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "동료들이 의식 날의 작전을 짧게 맞춘다(리네와 티오가 붙잡혀 있다면 구출이 첫 줄이다).\n\n동료들이 각자 전야를 보내는 모습이 짧게 스친다.\n\n주인공이 이 밤을 누구에게 찾아갈지 정한다.",
          "selectionScope": "",
          "constraints": "그레고르는 이 사건에 나타나지 않는다.",
          "success": "",
          "unmet": "주인공이 망설이면, 지붕 위에서 리네가 '거기 서 있지 말고 올라와, 바보야' 하고 부른다.",
          "closureConditions": [
            {
              "id": "e61_eve-c1",
              "text": "동료들이 의식 날의 작전을 짧게 맞춘다(리네와 티오가 붙잡혀 있다면 구출이 첫 줄이다)."
            },
            {
              "id": "e61_eve-c2",
              "text": "동료들이 각자 전야를 보내는 모습이 짧게 스친다."
            },
            {
              "id": "e61_eve-c3",
              "text": "주인공이 이 밤을 누구에게 찾아갈지 정한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e61_eve-constraints",
            "description": "그레고르는 이 사건에 나타나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e62a_eve_rine",
        "name": "지붕 위의 리네",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "지붕 위, 별이 낮다. 리네가 무릎을 끌어안고 묻는다. \"돌아갈 길이 생기면… 갈 거야?\" 그녀가 부른 사람, 그녀 때문에 모든 걸 잃은 사람에게 처음으로 묻는 질문이다. 대답은 주인공의 몫이다. 리네가 붙잡혀 있다면, 주인공은 대성당 지붕을 타고 올라가 종탑 감옥의 창살 너머에서 같은 질문을 듣는다. 손가락 끝만 겨우 닿는 거리. 엄마의 노래가 둘 사이를 오간다. 이야기 끝에 리네는 머리를 묶던 낡은 머리끈을 풀어 그의 손목에 묶는다(창살 너머라면 손가락 끝으로 겨우). \"내일 이거 돌려주러 와. 꼭.\"\n\n[히로인 보상] 리네는 '돌아갈 길이 생기면 갈 거야?'를 이야기할 수 있다. 시우의 연애 감정은 플레이어가 정한다.\n\n장면 제약: 리네가 붙잡혀 있다면 이 사건에서 탈출하지 않는다. 주인공의 연애 감정은 대신 정하지 않는다.",
        "required": true,
        "sequence": 64,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e63_ceremony",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e62a_eve_rine-c1",
            "description": "리네와 주인공이 단둘이 이야기한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62a_eve_rine-c2",
            "description": "리네가 돌아갈 길이 생기면 갈 거냐고 묻는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62a_eve_rine-c3",
            "description": "주인공이 대답하고, 리네가 그의 손목에 머리끈을 묶어 준다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62a_eve_rine-constraints",
            "description": "리네가 붙잡혀 있다면 이 사건에서 탈출하지 않는다. 주인공의 연애 감정은 대신 정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "지붕 위의 리네",
        "summary": "지붕 위, 별이 낮다. 리네가 무릎을 끌어안고 묻는다. \"돌아갈 길이 생기면… 갈 거야?\" 그녀가 부른 사람, 그녀 때문에 모든 걸 잃은 사람에게 처음으로 묻는 질문이다. 대답은 주인공의 몫이다. 리네가 붙잡혀 있다면, 주인공은 대성당 지붕을 타고 올라가 종탑 감옥의 창살 너머에서 같은 질문을 듣는다. 손가락 끝만 겨우 닿는 거리. 엄마의 노래가 둘 사이를 오간다. 이야기 끝에 리네는 머리를 묶던 낡은 머리끈을 풀어 그의 손목에 묶는다(창살 너머라면 손가락 끝으로 겨우). \"내일 이거 돌려주러 와. 꼭.\"\n\n[히로인 보상] 리네는 '돌아갈 길이 생기면 갈 거야?'를 이야기할 수 있다. 시우의 연애 감정은 플레이어가 정한다.\n\n장면 제약: 리네가 붙잡혀 있다면 이 사건에서 탈출하지 않는다. 주인공의 연애 감정은 대신 정하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "리네와 주인공이 단둘이 이야기한다.\n\n리네가 돌아갈 길이 생기면 갈 거냐고 묻는다.\n\n주인공이 대답하고, 리네가 그의 손목에 머리끈을 묶어 준다.",
          "selectionScope": "",
          "constraints": "리네가 붙잡혀 있다면 이 사건에서 탈출하지 않는다. 주인공의 연애 감정은 대신 정하지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e62a_eve_rine-c1",
              "text": "리네와 주인공이 단둘이 이야기한다."
            },
            {
              "id": "e62a_eve_rine-c2",
              "text": "리네가 돌아갈 길이 생기면 갈 거냐고 묻는다."
            },
            {
              "id": "e62a_eve_rine-c3",
              "text": "주인공이 대답하고, 리네가 그의 손목에 머리끈을 묶어 준다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e62a_eve_rine-constraints",
            "description": "리네가 붙잡혀 있다면 이 사건에서 탈출하지 않는다. 주인공의 연애 감정은 대신 정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e62b_eve_isolde",
        "name": "훈련장의 이졸데",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "달빛 아래 훈련장. 이졸데가 혼자 검을 휘두른다. 불꽃이 없는 검(가호를 잃었다면), 혹은 불꽃을 일부러 끈 검. 왜 가호 없이 검을 드느냐고 묻는다면 그녀는 처음으로 귀족 말투를 내려놓는다. 가문이 사랑한 건 자신이 아니라 〈불꽃 왕관〉이었다고. 그래서 가호가 없어도 서 있을 수 있다는 걸 증명하고 싶다고. \"내일 이기면… 재대결은 그다음이에요.\" 그녀는 장갑 한 짝을 벗어 그의 가슴팍에 던진다. 결투 신청의 증표다. \"재대결 신청이에요. 그러니까 내일 쓰러지면 용서 안 해요.\" 그 약속이 무엇을 뜻하는지는 주인공이 정한다.\n\n[히로인 보상] 이졸데는 가호 없이 검을 든 이유를 이야기할 수 있다. 시우의 연애 감정은 플레이어가 정한다.\n\n장면 제약: 주인공의 연애 감정은 대신 정하지 않는다.",
        "required": true,
        "sequence": 65,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e63_ceremony",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e62b_eve_isolde-c1",
            "description": "주인공이 훈련장의 이졸데를 찾아간다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62b_eve_isolde-c2",
            "description": "이졸데가 가호 없이 검을 드는 이유를 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62b_eve_isolde-c3",
            "description": "이졸데가 재대결의 증표로 장갑을 건넨다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62b_eve_isolde-constraints",
            "description": "주인공의 연애 감정은 대신 정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "훈련장의 이졸데",
        "summary": "달빛 아래 훈련장. 이졸데가 혼자 검을 휘두른다. 불꽃이 없는 검(가호를 잃었다면), 혹은 불꽃을 일부러 끈 검. 왜 가호 없이 검을 드느냐고 묻는다면 그녀는 처음으로 귀족 말투를 내려놓는다. 가문이 사랑한 건 자신이 아니라 〈불꽃 왕관〉이었다고. 그래서 가호가 없어도 서 있을 수 있다는 걸 증명하고 싶다고. \"내일 이기면… 재대결은 그다음이에요.\" 그녀는 장갑 한 짝을 벗어 그의 가슴팍에 던진다. 결투 신청의 증표다. \"재대결 신청이에요. 그러니까 내일 쓰러지면 용서 안 해요.\" 그 약속이 무엇을 뜻하는지는 주인공이 정한다.\n\n[히로인 보상] 이졸데는 가호 없이 검을 든 이유를 이야기할 수 있다. 시우의 연애 감정은 플레이어가 정한다.\n\n장면 제약: 주인공의 연애 감정은 대신 정하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 훈련장의 이졸데를 찾아간다.\n\n이졸데가 가호 없이 검을 드는 이유를 털어놓는다.\n\n이졸데가 재대결의 증표로 장갑을 건넨다.",
          "selectionScope": "",
          "constraints": "주인공의 연애 감정은 대신 정하지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e62b_eve_isolde-c1",
              "text": "주인공이 훈련장의 이졸데를 찾아간다."
            },
            {
              "id": "e62b_eve_isolde-c2",
              "text": "이졸데가 가호 없이 검을 드는 이유를 털어놓는다."
            },
            {
              "id": "e62b_eve_isolde-c3",
              "text": "이졸데가 재대결의 증표로 장갑을 건넨다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e62b_eve_isolde-constraints",
            "description": "주인공의 연애 감정은 대신 정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e62c_eve_selene",
        "name": "종탑의 셀레네",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 종탑에 닿지 못하면, 셀레네가 창밖으로 엄마의 노래를 흥얼거려 길을 알려 준다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "셀레네가 곁에 있다면, 별장 종탑에서 그녀가 서툴게 수프를 식히며 말한다. 처음으로 '내일 이후'를 생각해 본다고. 빵을 굽고 싶다고. 리네와 같은 방을 쓰고 싶다고. 셀레네가 대성당으로 돌아갔다면, 주인공은 대성당 종탑으로 숨어든다. 창백한 얼굴, 피 묻은 손수건. 그녀는 자신이 아니라 티오를 구하라고 하며 〈성언〉의 틈을 알려 준다. \"자리가 비어 있는 사람만 묶여요. 그리고… 그분 목소리가 들리는 동안만.\" 그리고 처음으로 작게 웃는다. \"그 손… 이번엔 무엇을 하실 건가요.\" 헤어지기 전, 셀레네는 리네도 끝까지 배우지 못한 엄마 노래의 마지막 소절을 그에게 가르쳐 준다. \"리네한테… 언젠가 전해 주세요.\"\n\n[히로인 보상] 셀레네는 처음 얻은 미래를 이야기할 수 있다. 시우의 연애 감정은 플레이어가 정한다.\n\n장면 제약: 셀레네는 이 사건에서 죽지 않는다. 주인공의 연애 감정은 대신 정하지 않는다.",
        "required": true,
        "sequence": 66,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e63_ceremony",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e62c_eve_selene-c1",
            "description": "주인공이 셀레네를 찾아간다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62c_eve_selene-c2",
            "description": "셀레네가 처음 꿈꾸는 미래나 〈성언〉의 비밀을 이야기한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62c_eve_selene-c3",
            "description": "셀레네가 처음으로 웃고, 엄마 노래의 마지막 소절을 주인공에게 맡긴다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62c_eve_selene-constraints",
            "description": "셀레네는 이 사건에서 죽지 않는다. 주인공의 연애 감정은 대신 정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "종탑의 셀레네",
        "summary": "셀레네가 곁에 있다면, 별장 종탑에서 그녀가 서툴게 수프를 식히며 말한다. 처음으로 '내일 이후'를 생각해 본다고. 빵을 굽고 싶다고. 리네와 같은 방을 쓰고 싶다고. 셀레네가 대성당으로 돌아갔다면, 주인공은 대성당 종탑으로 숨어든다. 창백한 얼굴, 피 묻은 손수건. 그녀는 자신이 아니라 티오를 구하라고 하며 〈성언〉의 틈을 알려 준다. \"자리가 비어 있는 사람만 묶여요. 그리고… 그분 목소리가 들리는 동안만.\" 그리고 처음으로 작게 웃는다. \"그 손… 이번엔 무엇을 하실 건가요.\" 헤어지기 전, 셀레네는 리네도 끝까지 배우지 못한 엄마 노래의 마지막 소절을 그에게 가르쳐 준다. \"리네한테… 언젠가 전해 주세요.\"\n\n[히로인 보상] 셀레네는 처음 얻은 미래를 이야기할 수 있다. 시우의 연애 감정은 플레이어가 정한다.\n\n장면 제약: 셀레네는 이 사건에서 죽지 않는다. 주인공의 연애 감정은 대신 정하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 셀레네를 찾아간다.\n\n셀레네가 처음 꿈꾸는 미래나 〈성언〉의 비밀을 이야기한다.\n\n셀레네가 처음으로 웃고, 엄마 노래의 마지막 소절을 주인공에게 맡긴다.",
          "selectionScope": "",
          "constraints": "셀레네는 이 사건에서 죽지 않는다. 주인공의 연애 감정은 대신 정하지 않는다.",
          "success": "",
          "unmet": "주인공이 종탑에 닿지 못하면, 셀레네가 창밖으로 엄마의 노래를 흥얼거려 길을 알려 준다.",
          "closureConditions": [
            {
              "id": "e62c_eve_selene-c1",
              "text": "주인공이 셀레네를 찾아간다."
            },
            {
              "id": "e62c_eve_selene-c2",
              "text": "셀레네가 처음 꿈꾸는 미래나 〈성언〉의 비밀을 이야기한다."
            },
            {
              "id": "e62c_eve_selene-c3",
              "text": "셀레네가 처음으로 웃고, 엄마 노래의 마지막 소절을 주인공에게 맡긴다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e62c_eve_selene-constraints",
            "description": "셀레네는 이 사건에서 죽지 않는다. 주인공의 연애 감정은 대신 정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e62d_eve_estelle",
        "name": "망루의 에스텔",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 말을 아끼면, 에스텔이 그의 손을 잡아 자기 눈 위에 얹으며 '지금은 아무것도 안 보여요. 그러니까 말해 주세요'라고 한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "별장 망루. 에스텔이 무릎을 끌어안고 별을 본다. 저 별은 뱃사람의 별, 저건 '빈 잔'이라 불리는 별자리. 별 이야기를 하다 말고 그녀가 주인공을 돌아본다. \"저는 평생 사람의 속을 읽었어요. 그래서 아무도 저한테 속을 보여 주지 않았어요. 당신은… 제가 다 보는 걸 알면서도 도망가지 않았어요.\" 그녀의 별빛 눈에 그의 가슴속 등잔들이 비친다. \"내일이면 이 빛들, 다 나눠 주겠죠. 그럼 당신 안은 비어 버릴 거예요.\" 잠시 침묵. \"그래도 저는 당신을 볼 수 있을까요. 빛이 아니라, 당신을.\" 대답은 주인공의 몫이다. 그리고 부탁한다. \"내일 당신 안이 다 비는 순간, 저를 봐 주세요. 그때 제가 당신을 읽을게요. 빛이 아니라.\" 내일 그녀는 낭독대에 선다. 처음으로 대본이 아닌 자기 말을 읽기 위해.\n\n장면 제약: 주인공의 연애 감정은 대신 정하지 않는다.",
        "required": true,
        "sequence": 67,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e63_ceremony",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e62d_eve_estelle-c1",
            "description": "주인공이 망루의 에스텔을 찾아간다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62d_eve_estelle-c2",
            "description": "에스텔이 별읽기의 눈으로 살아온 외로움을 털어놓는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62d_eve_estelle-c3",
            "description": "두 사람 사이에 내일을 위한 약속이 생긴다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e62d_eve_estelle-constraints",
            "description": "주인공의 연애 감정은 대신 정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "망루의 에스텔",
        "summary": "별장 망루. 에스텔이 무릎을 끌어안고 별을 본다. 저 별은 뱃사람의 별, 저건 '빈 잔'이라 불리는 별자리. 별 이야기를 하다 말고 그녀가 주인공을 돌아본다. \"저는 평생 사람의 속을 읽었어요. 그래서 아무도 저한테 속을 보여 주지 않았어요. 당신은… 제가 다 보는 걸 알면서도 도망가지 않았어요.\" 그녀의 별빛 눈에 그의 가슴속 등잔들이 비친다. \"내일이면 이 빛들, 다 나눠 주겠죠. 그럼 당신 안은 비어 버릴 거예요.\" 잠시 침묵. \"그래도 저는 당신을 볼 수 있을까요. 빛이 아니라, 당신을.\" 대답은 주인공의 몫이다. 그리고 부탁한다. \"내일 당신 안이 다 비는 순간, 저를 봐 주세요. 그때 제가 당신을 읽을게요. 빛이 아니라.\" 내일 그녀는 낭독대에 선다. 처음으로 대본이 아닌 자기 말을 읽기 위해.\n\n장면 제약: 주인공의 연애 감정은 대신 정하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 망루의 에스텔을 찾아간다.\n\n에스텔이 별읽기의 눈으로 살아온 외로움을 털어놓는다.\n\n두 사람 사이에 내일을 위한 약속이 생긴다.",
          "selectionScope": "",
          "constraints": "주인공의 연애 감정은 대신 정하지 않는다.",
          "success": "",
          "unmet": "주인공이 말을 아끼면, 에스텔이 그의 손을 잡아 자기 눈 위에 얹으며 '지금은 아무것도 안 보여요. 그러니까 말해 주세요'라고 한다.",
          "closureConditions": [
            {
              "id": "e62d_eve_estelle-c1",
              "text": "주인공이 망루의 에스텔을 찾아간다."
            },
            {
              "id": "e62d_eve_estelle-c2",
              "text": "에스텔이 별읽기의 눈으로 살아온 외로움을 털어놓는다."
            },
            {
              "id": "e62d_eve_estelle-c3",
              "text": "두 사람 사이에 내일을 위한 약속이 생긴다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e62d_eve_estelle-constraints",
            "description": "주인공의 연애 감정은 대신 정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e63_ceremony",
        "name": "별의 의식",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 단상에 다가가지 못하면, 레온의 화살이 단상의 성좌기를 꿰뚫고 광장의 시선이 한꺼번에 주인공에게 쏠린다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "별의 의식 날. 대성당 앞 광장. 흰 옷을 입은 열 살 아이들이 줄을 서고, 그 줄 끝에 티오가 있다(붙잡혀 있다면, 리네와 함께 단상 기둥에 묶여 있다). 광장 가장자리를 메운 사람들. 등불을 든 빈손들일 수도, 겁에 질린 구경꾼들일 수도 있다. 낭독대는 비어 있다. 그레고르가 단상에 올라 선언한다. \"별읽기 무녀는 빈손의 왕에게 붙잡혀 있다. 오늘은 내가 별을 읽겠다.\" 그리고 처음으로 그의 가호가 드러난다. 〈성언〉. \"빈손들이여, 무릎을 꿇어라.\" 그의 목소리가 대성당의 반향을 타고 광장 끝까지 울린다. 광장의 빈손들이 일제히 무릎을 꿇는다. 레온이, 빈손이 된 사람들이, 의식 전의 아이들이. 서 있는 것은 가호를 가진 자, 자리가 아예 없는 수인과 엘프(나나와 그라츠, 실피), 그리고 다른 세계에서 온 주인공뿐이다. 그리고 주인공이 놓은 가호를 받은 리네도. 그레고르의 계획은 분명하다. 무릎 꿇은 빈손들에게 '빈손의 왕'을 붙잡으라 명하고, 티오를 다음 성녀 실험체로 데려가는 것.\n\n[핵심 공개] 그레고르의 가호는 빈자리가 있는 사람을 목소리로 묶는 〈성언〉이다.\n\n[클라이맥스 강화] 지금까지 얻고 놓고 건넨 가호와 동료 관계가 전투 해법으로 돌아오게 한다.\n\n장면 제약: 티오와 리네는 이 사건에서 죽지 않는다. 그레고르의 가호는 다른 세계에서 온 주인공에게 통하지 않는다.",
        "required": true,
        "sequence": 68,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e64_kneel",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e63_ceremony-c1",
            "description": "별의 의식이 시작되고 티오가 의식에 선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e63_ceremony-c2",
            "description": "그레고르가 자신의 가호를 드러내고 광장의 빈손들이 무릎을 꿇는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e63_ceremony-c3",
            "description": "그레고르가 빈손들에게 주인공을 붙잡으라 명하거나 티오를 데려가려 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e63_ceremony-constraints",
            "description": "티오와 리네는 이 사건에서 죽지 않는다. 그레고르의 가호는 다른 세계에서 온 주인공에게 통하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "별의 의식",
        "summary": "별의 의식 날. 대성당 앞 광장. 흰 옷을 입은 열 살 아이들이 줄을 서고, 그 줄 끝에 티오가 있다(붙잡혀 있다면, 리네와 함께 단상 기둥에 묶여 있다). 광장 가장자리를 메운 사람들. 등불을 든 빈손들일 수도, 겁에 질린 구경꾼들일 수도 있다. 낭독대는 비어 있다. 그레고르가 단상에 올라 선언한다. \"별읽기 무녀는 빈손의 왕에게 붙잡혀 있다. 오늘은 내가 별을 읽겠다.\" 그리고 처음으로 그의 가호가 드러난다. 〈성언〉. \"빈손들이여, 무릎을 꿇어라.\" 그의 목소리가 대성당의 반향을 타고 광장 끝까지 울린다. 광장의 빈손들이 일제히 무릎을 꿇는다. 레온이, 빈손이 된 사람들이, 의식 전의 아이들이. 서 있는 것은 가호를 가진 자, 자리가 아예 없는 수인과 엘프(나나와 그라츠, 실피), 그리고 다른 세계에서 온 주인공뿐이다. 그리고 주인공이 놓은 가호를 받은 리네도. 그레고르의 계획은 분명하다. 무릎 꿇은 빈손들에게 '빈손의 왕'을 붙잡으라 명하고, 티오를 다음 성녀 실험체로 데려가는 것.\n\n[핵심 공개] 그레고르의 가호는 빈자리가 있는 사람을 목소리로 묶는 〈성언〉이다.\n\n[클라이맥스 강화] 지금까지 얻고 놓고 건넨 가호와 동료 관계가 전투 해법으로 돌아오게 한다.\n\n장면 제약: 티오와 리네는 이 사건에서 죽지 않는다. 그레고르의 가호는 다른 세계에서 온 주인공에게 통하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "별의 의식이 시작되고 티오가 의식에 선다.\n\n그레고르가 자신의 가호를 드러내고 광장의 빈손들이 무릎을 꿇는다.\n\n그레고르가 빈손들에게 주인공을 붙잡으라 명하거나 티오를 데려가려 한다.",
          "selectionScope": "",
          "constraints": "티오와 리네는 이 사건에서 죽지 않는다. 그레고르의 가호는 다른 세계에서 온 주인공에게 통하지 않는다.",
          "success": "",
          "unmet": "주인공이 단상에 다가가지 못하면, 레온의 화살이 단상의 성좌기를 꿰뚫고 광장의 시선이 한꺼번에 주인공에게 쏠린다.",
          "closureConditions": [
            {
              "id": "e63_ceremony-c1",
              "text": "별의 의식이 시작되고 티오가 의식에 선다."
            },
            {
              "id": "e63_ceremony-c2",
              "text": "그레고르가 자신의 가호를 드러내고 광장의 빈손들이 무릎을 꿇는다."
            },
            {
              "id": "e63_ceremony-c3",
              "text": "그레고르가 빈손들에게 주인공을 붙잡으라 명하거나 티오를 데려가려 한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e63_ceremony-constraints",
            "description": "티오와 리네는 이 사건에서 죽지 않는다. 그레고르의 가호는 다른 세계에서 온 주인공에게 통하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e64_kneel",
        "name": "무릎 꿇은 광장",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 가호를 건네지 못하면, 리네가 먼저 자신이 받은 가호를 티오의 손에 쥐여 주고, 에스텔이 '빛이 켜졌어요!'라고 외치는 순간 주인공이 방법을 깨닫는다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "빈손들이 명령에 묶여 주인공에게 다가온다. 눈에는 눈물, 손에는 몽둥이. 레온도, 빈손이 된 사람들도, 의식 전의 아이들도. 무릎 꿇은 광장에서 서 있는 것은 가호를 가진 자들과, 자리가 아예 없는 나나와 그라츠, 실피뿐이다. 그때 비어 있던 낭독대에 흑갈색 머리의 소녀가 오른다. 별읽기 무녀의 목소리는 광장 끝까지 닿는다. \"저는 3년 동안 대본을 읽었습니다. 이 아이들의 빛은 별이 아니라 대주교 예하의 손에서 옵니다.\" 기사들과 귀족들이 술렁인다. 티오를 감싼 리네가(단상에 묶여 있다면 묶인 채로) 외친다. \"가호 있는 사람은 안 묶여!\" 주인공은 깨닫는다. 〈성언〉은 '자리가 빈 사람'만 묶는다. 그렇다면 빈자리를 채우면 된다. 하지만 그의 그릇에 남은 가호는 손가락으로 셀 만큼뿐이고, 광장의 빈자리는 수천이다. 누구에게 건넬지 골라야 한다. 에스텔이 낭독대에서 빈자리를 읽어 준다. 누가 가장 앞에 있는지, 누구의 자리가 그 가호를 받아 줄 수 있는지. 처음은 티오다(단상에 묶여 있었다면 밧줄을 끊고 그 손부터 잡는다). 장부의 배정이 아니라, 누군가의 손에서 건네진 첫 가호. \"형, 나… 가호 생겼어.\" 그다음은 주인공이 고른다. 위조 증표로 버텨 온 레온일 수도, 가호를 잃고 무릎 꿇은 이졸데나 셀레네일 수도, 그가 빈손으로 만든 사람들(브로크, 가릭, 베른 중 그 자리에 있는 이)에게 빼앗았던 것을 돌려주는 일일 수도 있다. 건넬 때마다 그릇이 비고, 일어선 사람은 무릎 꿇은 사람들 앞을 막아선다. 몇 사람이 일어섰을 뿐인데, 광장의 흐름이 바뀐다. 마지막 가호까지 건넨다면, 그의 가슴은 처음 이 세계에 떨어진 날처럼 비어 있다. 이것이 능력의 진짜 쓰임이다.\n\n[핵심 공개] 〈성언〉은 빈자리가 있는 사람만 묶는다. 빈자리를 채우면 풀린다.\n\n[클라이맥스 강화] 리네는 인질로만 남지 않고 티오를 지키거나 성언의 틈을 알린다. '가호를 건네 빈자리를 채워 성언을 깬다'를 능력 시스템 최고의 보상처럼 연출한다.\n\n이 장면에서 회수할 복선: 빈자리가 있는 사람\n〈성언〉은 빈자리가 있는 사람만 묶으므로, 빈자리를 채워 주는 것이 해법이 된다.\n\n이 장면에서 회수할 복선: 형, 나도 가호 받을 수 있을까?\n의식장에서 티오가 처음 갖게 되는 가호가 장부의 배정이 아니라 누군가의 손에서 건네진 것이 된다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 무녀의 대본\n의식장에서 에스텔이 대본 대신 자기 말로 진실을 읽는다.\n\n장면 제약: 티오와 리네는 죽지 않는다. 주인공은 그릇에 가진 가호 수보다 많은 사람을 일으키지 못하며, 광장 전체가 한꺼번에 풀리지는 않는다. 동료들의 싸움과 레녹스·브로크의 선택은 다음 사건의 몫이다.",
        "required": true,
        "sequence": 69,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e64b_stand",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e64_kneel-c1",
            "description": "〈성언〉에 묶인 빈손들이 주인공을 막아선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e64_kneel-c2",
            "description": "비어 있던 낭독대에 누군가 올라 광장에 말을 건넨다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e64_kneel-c3",
            "description": "주인공이 무릎 꿇은 사람들을 일으켜 세울 방법을 찾아낸다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e64_kneel-c4",
            "description": "주인공이 얼마 남지 않은 가호를 누구에게 건넬지 고르고, 무릎 꿇었던 아이 하나가 처음으로 일어선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e64_kneel-constraints",
            "description": "티오와 리네는 죽지 않는다. 주인공은 그릇에 가진 가호 수보다 많은 사람을 일으키지 못하며, 광장 전체가 한꺼번에 풀리지는 않는다. 동료들의 싸움과 레녹스·브로크의 선택은 다음 사건의 몫이다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "무릎 꿇은 광장",
        "summary": "빈손들이 명령에 묶여 주인공에게 다가온다. 눈에는 눈물, 손에는 몽둥이. 레온도, 빈손이 된 사람들도, 의식 전의 아이들도. 무릎 꿇은 광장에서 서 있는 것은 가호를 가진 자들과, 자리가 아예 없는 나나와 그라츠, 실피뿐이다. 그때 비어 있던 낭독대에 흑갈색 머리의 소녀가 오른다. 별읽기 무녀의 목소리는 광장 끝까지 닿는다. \"저는 3년 동안 대본을 읽었습니다. 이 아이들의 빛은 별이 아니라 대주교 예하의 손에서 옵니다.\" 기사들과 귀족들이 술렁인다. 티오를 감싼 리네가(단상에 묶여 있다면 묶인 채로) 외친다. \"가호 있는 사람은 안 묶여!\" 주인공은 깨닫는다. 〈성언〉은 '자리가 빈 사람'만 묶는다. 그렇다면 빈자리를 채우면 된다. 하지만 그의 그릇에 남은 가호는 손가락으로 셀 만큼뿐이고, 광장의 빈자리는 수천이다. 누구에게 건넬지 골라야 한다. 에스텔이 낭독대에서 빈자리를 읽어 준다. 누가 가장 앞에 있는지, 누구의 자리가 그 가호를 받아 줄 수 있는지. 처음은 티오다(단상에 묶여 있었다면 밧줄을 끊고 그 손부터 잡는다). 장부의 배정이 아니라, 누군가의 손에서 건네진 첫 가호. \"형, 나… 가호 생겼어.\" 그다음은 주인공이 고른다. 위조 증표로 버텨 온 레온일 수도, 가호를 잃고 무릎 꿇은 이졸데나 셀레네일 수도, 그가 빈손으로 만든 사람들(브로크, 가릭, 베른 중 그 자리에 있는 이)에게 빼앗았던 것을 돌려주는 일일 수도 있다. 건넬 때마다 그릇이 비고, 일어선 사람은 무릎 꿇은 사람들 앞을 막아선다. 몇 사람이 일어섰을 뿐인데, 광장의 흐름이 바뀐다. 마지막 가호까지 건넨다면, 그의 가슴은 처음 이 세계에 떨어진 날처럼 비어 있다. 이것이 능력의 진짜 쓰임이다.\n\n[핵심 공개] 〈성언〉은 빈자리가 있는 사람만 묶는다. 빈자리를 채우면 풀린다.\n\n[클라이맥스 강화] 리네는 인질로만 남지 않고 티오를 지키거나 성언의 틈을 알린다. '가호를 건네 빈자리를 채워 성언을 깬다'를 능력 시스템 최고의 보상처럼 연출한다.\n\n이 장면에서 회수할 복선: 빈자리가 있는 사람\n〈성언〉은 빈자리가 있는 사람만 묶으므로, 빈자리를 채워 주는 것이 해법이 된다.\n\n이 장면에서 회수할 복선: 형, 나도 가호 받을 수 있을까?\n의식장에서 티오가 처음 갖게 되는 가호가 장부의 배정이 아니라 누군가의 손에서 건네진 것이 된다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 무녀의 대본\n의식장에서 에스텔이 대본 대신 자기 말로 진실을 읽는다.\n\n장면 제약: 티오와 리네는 죽지 않는다. 주인공은 그릇에 가진 가호 수보다 많은 사람을 일으키지 못하며, 광장 전체가 한꺼번에 풀리지는 않는다. 동료들의 싸움과 레녹스·브로크의 선택은 다음 사건의 몫이다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "〈성언〉에 묶인 빈손들이 주인공을 막아선다.\n\n비어 있던 낭독대에 누군가 올라 광장에 말을 건넨다.\n\n주인공이 무릎 꿇은 사람들을 일으켜 세울 방법을 찾아낸다.\n\n주인공이 얼마 남지 않은 가호를 누구에게 건넬지 고르고, 무릎 꿇었던 아이 하나가 처음으로 일어선다.",
          "selectionScope": "",
          "constraints": "티오와 리네는 죽지 않는다. 주인공은 그릇에 가진 가호 수보다 많은 사람을 일으키지 못하며, 광장 전체가 한꺼번에 풀리지는 않는다. 동료들의 싸움과 레녹스·브로크의 선택은 다음 사건의 몫이다.",
          "success": "",
          "unmet": "주인공이 가호를 건네지 못하면, 리네가 먼저 자신이 받은 가호를 티오의 손에 쥐여 주고, 에스텔이 '빛이 켜졌어요!'라고 외치는 순간 주인공이 방법을 깨닫는다.",
          "closureConditions": [
            {
              "id": "e64_kneel-c1",
              "text": "〈성언〉에 묶인 빈손들이 주인공을 막아선다."
            },
            {
              "id": "e64_kneel-c2",
              "text": "비어 있던 낭독대에 누군가 올라 광장에 말을 건넨다."
            },
            {
              "id": "e64_kneel-c3",
              "text": "주인공이 무릎 꿇은 사람들을 일으켜 세울 방법을 찾아낸다."
            },
            {
              "id": "e64_kneel-c4",
              "text": "주인공이 얼마 남지 않은 가호를 누구에게 건넬지 고르고, 무릎 꿇었던 아이 하나가 처음으로 일어선다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e64_kneel-constraints",
            "description": "티오와 리네는 죽지 않는다. 주인공은 그릇에 가진 가호 수보다 많은 사람을 일으키지 못하며, 광장 전체가 한꺼번에 풀리지는 않는다. 동료들의 싸움과 레녹스·브로크의 선택은 다음 사건의 몫이다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e64b_stand",
        "name": "일어선 광장",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 길이 열리지 않으면, 일어선 빈손들이 한꺼번에 성기사단 앞으로 걸어 나와 사람의 벽이 된다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "일어선 몇 사람을 향해 성기사단이 칼을 뽑는다. 그레고르의 목소리는 여전히 광장을 누르고, 무릎 꿇은 수천은 아직 일어서지 못한다. 〈성언〉에 묶이지 않은 사람들이 먼저 막아선다. 실피가 계피 막대를 내던지며 외친다. \"목소리여! 저놈 목소리만 덮으면 되는 거여!\" 나나와 그라츠가 실피가 일러 준 옛 계단으로 올라 대성당의 큰 종 줄을 끊어 내리자, 종이 미친 듯이 울리며 대주교의 목소리를 덮는다. 목소리가 닿지 않는 동안, 광장의 빈손들이 하나둘 무릎을 편다.\n늘 함께하는 동료들은 이 광장에 반드시 있다. 리네(묶여 있었다면 풀려난 뒤), 낭독대의 에스텔, 나나와 그라츠, 실피, 뒤편 진료소에서 다친 사람을 받는 유리, 그리고 자기 목적을 위해서라도 움직이는 레녹스. 레녹스가 근위대를 이끌고 성기사단 앞을 막아선다. \"왕실은 대성당의 인형이었지. 오늘로 끈을 자른다. 아스트레아 가와의 약혼도 함께.\"\n나머지는 지금까지의 선택이 정한다. 이졸데는 가호를 지켰거나 돌려받았다면 처음부터, 아니라면 종이 울린 뒤에 검을 든다. 레온은 가호를 건네받았다면 종탑 아래에서 활을 쏘고, 아니라면 종이 울린 뒤 일어선다. 카일은 수배 때 주인공 편에 섰다면 기사단 안에서 약속한 문을 열고, 아니라면 기사단 대열에서 칼을 내린다. 셀레네가 곁에 있다면 종소리에 맞춰 엄마의 노래를 부른다. 도로시가 죄를 고백했다면 기사단의 배치가 미리 새어 나와 있다. 등불을 든 잿골목 사람들이 왔다면 그 등불이 광장을 메운다. 브로크는 두 얼굴 중 하나를 보인다. 몸을 던져 길을 열거나, 밀고자로 나타났다가 무너지거나.\n그리고 전야의 약속이 광장으로 돌아온다. 「지붕 위의 리네」를 지났다면, 주인공은 손목의 머리끈을 리네에게 돌려준다(단상에 묶여 있었다면 그 밧줄을 끊으며). 「훈련장의 이졸데」를 지났다면, 이졸데가 말없이 그의 등을 맡는다. \"재대결 전에 쓰러지면 용서 안 해요.\" 「종탑의 셀레네」를 지났다면, 그녀가 일러 준 '목소리'의 틈이 종을 울리는 작전의 열쇠였음이 드러난다. 「망루의 에스텔」을 지났다면, 낭독대의 에스텔이 그를 본다. 가호를 모두 건넸다면 \"이제 빛이 하나도 없어요. 그런데… 당신이 보여요.\" 하나라도 남았다면 \"아직 하나 남았네요. 그것도 당신답게 쓰세요.\" 단상으로 오르는 계단이 열린다.\n\n[핵심 공개] 〈성언〉은 그의 목소리가 들리는 동안만 묶는다. 목소리를 덮으면 광장 전체가 풀린다.\n\n[클라이맥스 강화] 이졸데·셀레네도 각자의 방식으로 길을 연다.\n\n이 장면에서 회수할 복선: 빈손이 된 브로크\n결전에서 브로크가 몸을 던져 길을 열거나 밀고자로 나타났다 무너진다. 그가 어느 쪽인지는 지금까지의 선택이 정한다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 왕실은 대성당의 인형\n레녹스가 광장에서 근위대를 이끌고, 왕실의 끈과 함께 아스트레아 가와의 약혼을 끊는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 티오와 리네는 죽지 않는다. 그레고르는 이 사건에서 쓰러지지 않는다. 지금까지의 선택으로 합류하지 않은 동료를 억지로 등장시키지 않는다.",
        "required": true,
        "sequence": 70,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e65_last_inquiry",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e64b_stand-c1",
            "description": "성기사단이 칼을 뽑고, 〈성언〉에 묶이지 않은 사람들이 먼저 막아선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e64b_stand-c2",
            "description": "종탑에서 판이 뒤집히고, 무릎 꿇었던 사람들이 일어서기 시작한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e64b_stand-c3",
            "description": "동료들이 각자의 방식으로 길을 연다. 누가 함께하는지는 지금까지의 선택에 따른다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e64b_stand-c4",
            "description": "레녹스와 브로크가 이 싸움에서 각자의 선택을 보인다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e64b_stand-c5",
            "description": "전야에 찾아간 사람과의 약속이 장면에 돌아온다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e64b_stand-c6",
            "description": "단상으로 오르는 길이 열린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e64b_stand-constraints",
            "description": "티오와 리네는 죽지 않는다. 그레고르는 이 사건에서 쓰러지지 않는다. 지금까지의 선택으로 합류하지 않은 동료를 억지로 등장시키지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "일어선 광장",
        "summary": "일어선 몇 사람을 향해 성기사단이 칼을 뽑는다. 그레고르의 목소리는 여전히 광장을 누르고, 무릎 꿇은 수천은 아직 일어서지 못한다. 〈성언〉에 묶이지 않은 사람들이 먼저 막아선다. 실피가 계피 막대를 내던지며 외친다. \"목소리여! 저놈 목소리만 덮으면 되는 거여!\" 나나와 그라츠가 실피가 일러 준 옛 계단으로 올라 대성당의 큰 종 줄을 끊어 내리자, 종이 미친 듯이 울리며 대주교의 목소리를 덮는다. 목소리가 닿지 않는 동안, 광장의 빈손들이 하나둘 무릎을 편다.\n늘 함께하는 동료들은 이 광장에 반드시 있다. 리네(묶여 있었다면 풀려난 뒤), 낭독대의 에스텔, 나나와 그라츠, 실피, 뒤편 진료소에서 다친 사람을 받는 유리, 그리고 자기 목적을 위해서라도 움직이는 레녹스. 레녹스가 근위대를 이끌고 성기사단 앞을 막아선다. \"왕실은 대성당의 인형이었지. 오늘로 끈을 자른다. 아스트레아 가와의 약혼도 함께.\"\n나머지는 지금까지의 선택이 정한다. 이졸데는 가호를 지켰거나 돌려받았다면 처음부터, 아니라면 종이 울린 뒤에 검을 든다. 레온은 가호를 건네받았다면 종탑 아래에서 활을 쏘고, 아니라면 종이 울린 뒤 일어선다. 카일은 수배 때 주인공 편에 섰다면 기사단 안에서 약속한 문을 열고, 아니라면 기사단 대열에서 칼을 내린다. 셀레네가 곁에 있다면 종소리에 맞춰 엄마의 노래를 부른다. 도로시가 죄를 고백했다면 기사단의 배치가 미리 새어 나와 있다. 등불을 든 잿골목 사람들이 왔다면 그 등불이 광장을 메운다. 브로크는 두 얼굴 중 하나를 보인다. 몸을 던져 길을 열거나, 밀고자로 나타났다가 무너지거나.\n그리고 전야의 약속이 광장으로 돌아온다. 「지붕 위의 리네」를 지났다면, 주인공은 손목의 머리끈을 리네에게 돌려준다(단상에 묶여 있었다면 그 밧줄을 끊으며). 「훈련장의 이졸데」를 지났다면, 이졸데가 말없이 그의 등을 맡는다. \"재대결 전에 쓰러지면 용서 안 해요.\" 「종탑의 셀레네」를 지났다면, 그녀가 일러 준 '목소리'의 틈이 종을 울리는 작전의 열쇠였음이 드러난다. 「망루의 에스텔」을 지났다면, 낭독대의 에스텔이 그를 본다. 가호를 모두 건넸다면 \"이제 빛이 하나도 없어요. 그런데… 당신이 보여요.\" 하나라도 남았다면 \"아직 하나 남았네요. 그것도 당신답게 쓰세요.\" 단상으로 오르는 계단이 열린다.\n\n[핵심 공개] 〈성언〉은 그의 목소리가 들리는 동안만 묶는다. 목소리를 덮으면 광장 전체가 풀린다.\n\n[클라이맥스 강화] 이졸데·셀레네도 각자의 방식으로 길을 연다.\n\n이 장면에서 회수할 복선: 빈손이 된 브로크\n결전에서 브로크가 몸을 던져 길을 열거나 밀고자로 나타났다 무너진다. 그가 어느 쪽인지는 지금까지의 선택이 정한다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n이 장면에서 회수할 복선: 왕실은 대성당의 인형\n레녹스가 광장에서 근위대를 이끌고, 왕실의 끈과 함께 아스트레아 가와의 약혼을 끊는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 티오와 리네는 죽지 않는다. 그레고르는 이 사건에서 쓰러지지 않는다. 지금까지의 선택으로 합류하지 않은 동료를 억지로 등장시키지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "성기사단이 칼을 뽑고, 〈성언〉에 묶이지 않은 사람들이 먼저 막아선다.\n\n종탑에서 판이 뒤집히고, 무릎 꿇었던 사람들이 일어서기 시작한다.\n\n동료들이 각자의 방식으로 길을 연다. 누가 함께하는지는 지금까지의 선택에 따른다.\n\n레녹스와 브로크가 이 싸움에서 각자의 선택을 보인다.\n\n전야에 찾아간 사람과의 약속이 장면에 돌아온다.\n\n단상으로 오르는 길이 열린다.",
          "selectionScope": "",
          "constraints": "티오와 리네는 죽지 않는다. 그레고르는 이 사건에서 쓰러지지 않는다. 지금까지의 선택으로 합류하지 않은 동료를 억지로 등장시키지 않는다.",
          "success": "",
          "unmet": "길이 열리지 않으면, 일어선 빈손들이 한꺼번에 성기사단 앞으로 걸어 나와 사람의 벽이 된다.",
          "closureConditions": [
            {
              "id": "e64b_stand-c1",
              "text": "성기사단이 칼을 뽑고, 〈성언〉에 묶이지 않은 사람들이 먼저 막아선다."
            },
            {
              "id": "e64b_stand-c2",
              "text": "종탑에서 판이 뒤집히고, 무릎 꿇었던 사람들이 일어서기 시작한다."
            },
            {
              "id": "e64b_stand-c3",
              "text": "동료들이 각자의 방식으로 길을 연다. 누가 함께하는지는 지금까지의 선택에 따른다."
            },
            {
              "id": "e64b_stand-c4",
              "text": "레녹스와 브로크가 이 싸움에서 각자의 선택을 보인다."
            },
            {
              "id": "e64b_stand-c5",
              "text": "전야에 찾아간 사람과의 약속이 장면에 돌아온다."
            },
            {
              "id": "e64b_stand-c6",
              "text": "단상으로 오르는 길이 열린다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e64b_stand-constraints",
            "description": "티오와 리네는 죽지 않는다. 그레고르는 이 사건에서 쓰러지지 않는다. 지금까지의 선택으로 합류하지 않은 동료를 억지로 등장시키지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e65_last_inquiry",
        "name": "로잘린의 마지막 심문",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 로잘린을 넘지 못하면, 로잘린이 채찍을 거두고 길을 비키며 '냄새가… 지독하네요'라고 중얼거린다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "단상으로 오르는 계단을 로잘린이 막는다. 사슬 채찍, 나긋한 미소. \"마지막 심문이에요.\" 그런데 등 뒤에서 그레고르가 광장에 외친다. \"빈손은 모자라서 빈손입니다. 저 아이들은 성녀가 될 영광을 얻을 뿐입니다.\" 로잘린의 코끝이 움찔한다. 거짓말 냄새. 평생 따른 사람에게서, 처음으로. 주인공은 그녀와 싸울 수도, 말로 그 냄새를 확인시킬 수도 있다. 굶어 죽어 가던 잿골목 소녀가 무엇을 고를지는 이 장면에서 정해진다.\n\n이 장면에서 회수할 복선: 저도 한때는 빈손이었답니다\n로잘린이 평생 따른 그레고르에게서 처음으로 거짓말 냄새를 맡는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 그레고르는 이 사건에서 쓰러지지 않는다.",
        "required": true,
        "sequence": 71,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e66_gregor",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e65_last_inquiry-c1",
            "description": "로잘린이 주인공을 막아선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e65_last_inquiry-c2",
            "description": "그레고르의 말에 로잘린이 흔들린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e65_last_inquiry-c3",
            "description": "로잘린이 자신의 선택을 한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e65_last_inquiry-constraints",
            "description": "그레고르는 이 사건에서 쓰러지지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "로잘린의 마지막 심문",
        "summary": "단상으로 오르는 계단을 로잘린이 막는다. 사슬 채찍, 나긋한 미소. \"마지막 심문이에요.\" 그런데 등 뒤에서 그레고르가 광장에 외친다. \"빈손은 모자라서 빈손입니다. 저 아이들은 성녀가 될 영광을 얻을 뿐입니다.\" 로잘린의 코끝이 움찔한다. 거짓말 냄새. 평생 따른 사람에게서, 처음으로. 주인공은 그녀와 싸울 수도, 말로 그 냄새를 확인시킬 수도 있다. 굶어 죽어 가던 잿골목 소녀가 무엇을 고를지는 이 장면에서 정해진다.\n\n이 장면에서 회수할 복선: 저도 한때는 빈손이었답니다\n로잘린이 평생 따른 그레고르에게서 처음으로 거짓말 냄새를 맡는다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 그레고르는 이 사건에서 쓰러지지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "로잘린이 주인공을 막아선다.\n\n그레고르의 말에 로잘린이 흔들린다.\n\n로잘린이 자신의 선택을 한다.",
          "selectionScope": "",
          "constraints": "그레고르는 이 사건에서 쓰러지지 않는다.",
          "success": "",
          "unmet": "주인공이 로잘린을 넘지 못하면, 로잘린이 채찍을 거두고 길을 비키며 '냄새가… 지독하네요'라고 중얼거린다.",
          "closureConditions": [
            {
              "id": "e65_last_inquiry-c1",
              "text": "로잘린이 주인공을 막아선다."
            },
            {
              "id": "e65_last_inquiry-c2",
              "text": "그레고르의 말에 로잘린이 흔들린다."
            },
            {
              "id": "e65_last_inquiry-c3",
              "text": "로잘린이 자신의 선택을 한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e65_last_inquiry-constraints",
            "description": "그레고르는 이 사건에서 쓰러지지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e66_gregor",
        "name": "대주교 그레고르",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 그레고르를 쓰러뜨리지 못하면, 동료들이 한꺼번에 단상으로 뛰어들고 그 틈에 리네의 손이 그레고르의 성좌 지팡이를 쳐낸다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "단상 위, 대주교와 마주한다. 그레고르는 악당처럼 웃지 않는다. 그는 17년 전 동부 변경의 불을 다시 말한다. 그 불 속에서 꺼낸 손녀가 지금 적의 곁에 서 있다. 에스텔이 할아버지 앞으로 나선다. \"할아버지가 저를 불 속에서 꺼내 주셨다는 거 알아요. 이번엔 제가 할아버지를 꺼내 드릴게요.\" 손녀의 머리를 쓰다듬던 그 손이, 아이들의 자리를 정하던 손이다. \"질서 없는 가호는 피를 부릅니다. 나는 그것을 막았을 뿐입니다.\" 그의 〈성언〉은 주인공에게 통하지 않지만, 그는 성기사들의 가호와 우물에서 끌어온 빛으로 싸운다. 주인공은 무적이 아니다. 지금 가진 가호, 남은 동료, 그리고 꾀로 이겨야 한다. 셀레네가 대성당으로 돌아갔다면, 그녀는 이 단상에서 쓰러진다. 그릇을 비워 그녀의 가호를 거둘 마지막 기회다. 「종탑의 셀레네」를 지났다면, 쓰러지는 셀레네의 입술이 전야에 가르쳐 준 노래를 따라 움직인다. 그레고르를 쓰러뜨리면 다시 그 선택이 온다. 그의 〈성언〉을 가져올 것인가.\n\n이 장면에서 회수할 복선: 손녀를 쓰다듬는 손\n그 손이 아이들에게 장부의 가호를 넣던 축복의 손이었음을 에스텔이 그의 앞에서 말한다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 티오와 리네는 죽지 않는다. 그레고르는 우물의 위치를 끝까지 숨기지 못한다.",
        "required": true,
        "sequence": 72,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e67_well",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e66_gregor-c1",
            "description": "주인공이 그레고르와 맞선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e66_gregor-c2",
            "description": "그레고르와 에스텔이 마주하고, 그레고르가 자신의 신념을 끝까지 드러낸다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e66_gregor-c3",
            "description": "주인공이 그레고르를 쓰러뜨리고, 그의 〈성언〉을 어떻게 할지 정한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e66_gregor-constraints",
            "description": "티오와 리네는 죽지 않는다. 그레고르는 우물의 위치를 끝까지 숨기지 못한다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "대주교 그레고르",
        "summary": "단상 위, 대주교와 마주한다. 그레고르는 악당처럼 웃지 않는다. 그는 17년 전 동부 변경의 불을 다시 말한다. 그 불 속에서 꺼낸 손녀가 지금 적의 곁에 서 있다. 에스텔이 할아버지 앞으로 나선다. \"할아버지가 저를 불 속에서 꺼내 주셨다는 거 알아요. 이번엔 제가 할아버지를 꺼내 드릴게요.\" 손녀의 머리를 쓰다듬던 그 손이, 아이들의 자리를 정하던 손이다. \"질서 없는 가호는 피를 부릅니다. 나는 그것을 막았을 뿐입니다.\" 그의 〈성언〉은 주인공에게 통하지 않지만, 그는 성기사들의 가호와 우물에서 끌어온 빛으로 싸운다. 주인공은 무적이 아니다. 지금 가진 가호, 남은 동료, 그리고 꾀로 이겨야 한다. 셀레네가 대성당으로 돌아갔다면, 그녀는 이 단상에서 쓰러진다. 그릇을 비워 그녀의 가호를 거둘 마지막 기회다. 「종탑의 셀레네」를 지났다면, 쓰러지는 셀레네의 입술이 전야에 가르쳐 준 노래를 따라 움직인다. 그레고르를 쓰러뜨리면 다시 그 선택이 온다. 그의 〈성언〉을 가져올 것인가.\n\n이 장면에서 회수할 복선: 손녀를 쓰다듬는 손\n그 손이 아이들에게 장부의 가호를 넣던 축복의 손이었음을 에스텔이 그의 앞에서 말한다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 티오와 리네는 죽지 않는다. 그레고르는 우물의 위치를 끝까지 숨기지 못한다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 그레고르와 맞선다.\n\n그레고르와 에스텔이 마주하고, 그레고르가 자신의 신념을 끝까지 드러낸다.\n\n주인공이 그레고르를 쓰러뜨리고, 그의 〈성언〉을 어떻게 할지 정한다.",
          "selectionScope": "",
          "constraints": "티오와 리네는 죽지 않는다. 그레고르는 우물의 위치를 끝까지 숨기지 못한다.",
          "success": "",
          "unmet": "주인공이 그레고르를 쓰러뜨리지 못하면, 동료들이 한꺼번에 단상으로 뛰어들고 그 틈에 리네의 손이 그레고르의 성좌 지팡이를 쳐낸다.",
          "closureConditions": [
            {
              "id": "e66_gregor-c1",
              "text": "주인공이 그레고르와 맞선다."
            },
            {
              "id": "e66_gregor-c2",
              "text": "그레고르와 에스텔이 마주하고, 그레고르가 자신의 신념을 끝까지 드러낸다."
            },
            {
              "id": "e66_gregor-c3",
              "text": "주인공이 그레고르를 쓰러뜨리고, 그의 〈성언〉을 어떻게 할지 정한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e66_gregor-constraints",
            "description": "티오와 리네는 죽지 않는다. 그레고르는 우물의 위치를 끝까지 숨기지 못한다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e67_well",
        "name": "별의 우물",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "대성당 제단 밑, 실피가 아는 옛길. 계단은 끝없이 내려가고, 벽마다 빛의 실이 흐른다. 수천 개의 가호가 별처럼 떠도는 거대한 공동, 별의 우물. 가호 하나하나에 원래 주인의 마지막 마음이 스친다. 처형당한 마르타의 마음도, 숲에 버려진 이름 없는 가호들도. 그리고 그 한가운데, 모든 빛이 흘러드는 거대한 빛의 그릇. 사람의 형상이 어렴풋하다. 에스텔이 숨을 멈춘다. \"……그 안에, 사람이 있어요. 살아 있어요.\" 주인공의 가슴 속 등잔들이 그것에 공명한다. 실피가 모자를 벗고 오래 고개를 숙인다. 말은 없다.\n\n[핵심 공개] 우물 한가운데의 빛의 그릇 안에 누군가 살아 있다.\n\n이 장면에 심을 복선: 그릇 속의 사람\n에스텔이 빛의 그릇 안에 살아 있는 사람이 있다고 말하게 하되, 그 정체는 밝히지 않는다.\n우물 밑에서 그 사람이 처음으로 말을 걸어온다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에서 회수할 복선: 가호에 남은 마지막 마음\n별의 우물을 떠도는 수천 개의 가호마다 주인의 마지막 마음이 남아 있는 광경으로, 일기의 '빼앗은 가호는 무겁다'가 눈앞에 펼쳐진다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 빛의 그릇 속 존재는 이 사건에서 말을 하거나 움직이지 않는다. 빈손의 왕의 이름은 이 사건에서 나오지 않는다.",
        "required": true,
        "sequence": 73,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e68_hands",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e67_well-c1",
            "description": "일행이 대성당 밑의 별의 우물로 내려간다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e67_well-c2",
            "description": "우물을 떠도는 가호들과 그 주인들의 마지막 마음이 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e67_well-c3",
            "description": "우물 한가운데의 빛의 그릇을 마주한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e67_well-constraints",
            "description": "빛의 그릇 속 존재는 이 사건에서 말을 하거나 움직이지 않는다. 빈손의 왕의 이름은 이 사건에서 나오지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "별의 우물",
        "summary": "대성당 제단 밑, 실피가 아는 옛길. 계단은 끝없이 내려가고, 벽마다 빛의 실이 흐른다. 수천 개의 가호가 별처럼 떠도는 거대한 공동, 별의 우물. 가호 하나하나에 원래 주인의 마지막 마음이 스친다. 처형당한 마르타의 마음도, 숲에 버려진 이름 없는 가호들도. 그리고 그 한가운데, 모든 빛이 흘러드는 거대한 빛의 그릇. 사람의 형상이 어렴풋하다. 에스텔이 숨을 멈춘다. \"……그 안에, 사람이 있어요. 살아 있어요.\" 주인공의 가슴 속 등잔들이 그것에 공명한다. 실피가 모자를 벗고 오래 고개를 숙인다. 말은 없다.\n\n[핵심 공개] 우물 한가운데의 빛의 그릇 안에 누군가 살아 있다.\n\n이 장면에 심을 복선: 그릇 속의 사람\n에스텔이 빛의 그릇 안에 살아 있는 사람이 있다고 말하게 하되, 그 정체는 밝히지 않는다.\n우물 밑에서 그 사람이 처음으로 말을 걸어온다.\n심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.\n\n이 장면에서 회수할 복선: 가호에 남은 마지막 마음\n별의 우물을 떠도는 수천 개의 가호마다 주인의 마지막 마음이 남아 있는 광경으로, 일기의 '빼앗은 가호는 무겁다'가 눈앞에 펼쳐진다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 빛의 그릇 속 존재는 이 사건에서 말을 하거나 움직이지 않는다. 빈손의 왕의 이름은 이 사건에서 나오지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "일행이 대성당 밑의 별의 우물로 내려간다.\n\n우물을 떠도는 가호들과 그 주인들의 마지막 마음이 드러난다.\n\n우물 한가운데의 빛의 그릇을 마주한다.",
          "selectionScope": "",
          "constraints": "빛의 그릇 속 존재는 이 사건에서 말을 하거나 움직이지 않는다. 빈손의 왕의 이름은 이 사건에서 나오지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e67_well-c1",
              "text": "일행이 대성당 밑의 별의 우물로 내려간다."
            },
            {
              "id": "e67_well-c2",
              "text": "우물을 떠도는 가호들과 그 주인들의 마지막 마음이 드러난다."
            },
            {
              "id": "e67_well-c3",
              "text": "우물 한가운데의 빛의 그릇을 마주한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e67_well-constraints",
            "description": "빛의 그릇 속 존재는 이 사건에서 말을 하거나 움직이지 않는다. 빈손의 왕의 이름은 이 사건에서 나오지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e68_hands",
        "name": "빈손의 손",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 끝내 고르지 못하면, 리네가 그의 손을 잡고 '네 손으로 정해. 나도 같이 들게'라고 말하며, 두 사람의 맞잡은 손에서 첫 가호가 건네진다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "우물 앞에서 선택이 온다. 우물을 깨면 가호들이 세상에 무작위로 흩어진다. 해방이자 혼란, 그레고르가 두려워하던 바로 그것. 우물을 삼키면 주인공은 무엇이든 할 수 있는 힘을 얻는다. 그리고 '새로운 빈손의 왕'이 된다. 하나씩 건네면, 그릇이 버티는 만큼만, 느리고 확실하게, 평생에 걸쳐. 동료들은 서로 다른 답을 말한다. 나나는 깨라고, 레녹스는 쥐라고, 에스텔은 \"저는 평생 남이 정한 걸 읽었어요. 이번엔 당신이 정하세요. 제가 끝까지 읽을게요\"라고, 실피는 아무 말도 하지 않는다. 결정은 주인공의 손이다. 우물 가장 깊은 곳에서 독서실 형광등 같은 흰 빛이 한 번 스친 것 같다. 돌아갈 길일지도 모르는 것. 「지붕 위의 리네」를 지났다면, 리네는 전야의 질문을 다시 묻지 않고 머리끈이 풀린 그의 손목만 본다. 그리고 건넬 것이 남아 있다. 카일이 〈굳힘〉을 내어 주었다면 그것을 리네에게 건네는 일은 엄마에게서 빼앗긴 것을 딸에게 돌려주는 일이 되고, 〈불꽃 왕관〉을 이졸데에게 돌려준다면 라이벌의 결산이, 셀레네에게라면 평범한 미래의 시작이 된다. 그리고 에스텔에게 이 밤은, 처음으로 별의 뜻이 아니라 자기 눈으로 본 것을 말하는 날이 된다.\n\n[엔딩 강화] 동료들은 서로 다른 답을 말해 선택의 무게를 살린다. 리네에게 〈굳힘〉을 건네면 엄마에게서 빼앗긴 것을 딸에게 돌려주는 의미를, 이졸데에게 〈불꽃 왕관〉을 돌려주면 라이벌 관계의 결산을, 셀레네에게는 평범한 미래의 시작을 감정 보상으로 살린다.\n\n이 장면에서 회수할 복선: 내 가호 돌려줘요\n결말에서 〈불꽃 왕관〉을 돌려줄지가 라이벌 관계의 결산이 된다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 우물의 핵(빛의 그릇)은 어떤 선택으로도 사라지지 않는다. 죽은 사람은 되살아나지 않는다.",
        "required": true,
        "sequence": 74,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e69_after",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e68_hands-c1",
            "description": "동료들이 우물을 두고 서로 다른 답을 말한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e68_hands-c2",
            "description": "주인공이 우물에 대한 선택을 행동으로 보인다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e68_hands-c3",
            "description": "그 선택의 결과가 우물과 광장에 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e68_hands-constraints",
            "description": "우물의 핵(빛의 그릇)은 어떤 선택으로도 사라지지 않는다. 죽은 사람은 되살아나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "빈손의 손",
        "summary": "우물 앞에서 선택이 온다. 우물을 깨면 가호들이 세상에 무작위로 흩어진다. 해방이자 혼란, 그레고르가 두려워하던 바로 그것. 우물을 삼키면 주인공은 무엇이든 할 수 있는 힘을 얻는다. 그리고 '새로운 빈손의 왕'이 된다. 하나씩 건네면, 그릇이 버티는 만큼만, 느리고 확실하게, 평생에 걸쳐. 동료들은 서로 다른 답을 말한다. 나나는 깨라고, 레녹스는 쥐라고, 에스텔은 \"저는 평생 남이 정한 걸 읽었어요. 이번엔 당신이 정하세요. 제가 끝까지 읽을게요\"라고, 실피는 아무 말도 하지 않는다. 결정은 주인공의 손이다. 우물 가장 깊은 곳에서 독서실 형광등 같은 흰 빛이 한 번 스친 것 같다. 돌아갈 길일지도 모르는 것. 「지붕 위의 리네」를 지났다면, 리네는 전야의 질문을 다시 묻지 않고 머리끈이 풀린 그의 손목만 본다. 그리고 건넬 것이 남아 있다. 카일이 〈굳힘〉을 내어 주었다면 그것을 리네에게 건네는 일은 엄마에게서 빼앗긴 것을 딸에게 돌려주는 일이 되고, 〈불꽃 왕관〉을 이졸데에게 돌려준다면 라이벌의 결산이, 셀레네에게라면 평범한 미래의 시작이 된다. 그리고 에스텔에게 이 밤은, 처음으로 별의 뜻이 아니라 자기 눈으로 본 것을 말하는 날이 된다.\n\n[엔딩 강화] 동료들은 서로 다른 답을 말해 선택의 무게를 살린다. 리네에게 〈굳힘〉을 건네면 엄마에게서 빼앗긴 것을 딸에게 돌려주는 의미를, 이졸데에게 〈불꽃 왕관〉을 돌려주면 라이벌 관계의 결산을, 셀레네에게는 평범한 미래의 시작을 감정 보상으로 살린다.\n\n이 장면에서 회수할 복선: 내 가호 돌려줘요\n결말에서 〈불꽃 왕관〉을 돌려줄지가 라이벌 관계의 결산이 된다.\n가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다.\n\n장면 제약: 우물의 핵(빛의 그릇)은 어떤 선택으로도 사라지지 않는다. 죽은 사람은 되살아나지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "동료들이 우물을 두고 서로 다른 답을 말한다.\n\n주인공이 우물에 대한 선택을 행동으로 보인다.\n\n그 선택의 결과가 우물과 광장에 드러난다.",
          "selectionScope": "",
          "constraints": "우물의 핵(빛의 그릇)은 어떤 선택으로도 사라지지 않는다. 죽은 사람은 되살아나지 않는다.",
          "success": "",
          "unmet": "주인공이 끝내 고르지 못하면, 리네가 그의 손을 잡고 '네 손으로 정해. 나도 같이 들게'라고 말하며, 두 사람의 맞잡은 손에서 첫 가호가 건네진다.",
          "closureConditions": [
            {
              "id": "e68_hands-c1",
              "text": "동료들이 우물을 두고 서로 다른 답을 말한다."
            },
            {
              "id": "e68_hands-c2",
              "text": "주인공이 우물에 대한 선택을 행동으로 보인다."
            },
            {
              "id": "e68_hands-c3",
              "text": "그 선택의 결과가 우물과 광장에 드러난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e68_hands-constraints",
            "description": "우물의 핵(빛의 그릇)은 어떤 선택으로도 사라지지 않는다. 죽은 사람은 되살아나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e69_after",
        "name": "그 후의 잿골목",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "계절이 하나 지난다. 주인공의 선택이 남긴 세상. 유리의 진료소에는 줄이 길고, 도로시는 길드 창구로 돌아와 퇴원한 엘라의 손을 잡고 출근한다. 브로크는 야경단 완장을 차거나, 혹은 아직 골목 끝에서 서성인다. 에스텔은 별읽기 무녀의 예복을 벗고, 진료소 옆 빈 창고에서 빈손 아이들에게 글을 가르친다. 이제 그녀가 읽는 것은 가슴속 빛이 아니라 책이다. 이졸데는 재대결을 신청하고(「훈련장의 이졸데」를 지났다면 그 장갑을 걸고), 살아남았다면 셀레네는 빵을 태운다. 「종탑의 셀레네」를 지났다면 엄마 노래의 마지막 소절이 처음으로 다락에서 끝까지 울린다. 「망루의 에스텔」을 지났다면, 에스텔은 별 대신 그를 보며 별자리 이야기를 한다. 카일은 기사의 맹세를 새로 쓰고, 레온은 진짜 증표를 받는다. 나나와 그라츠는 그림자 시장에 작은 가게를 낸다. 피핀의 노래는 가사가 또 바뀌었다. 레녹스는 약혼 서류를 태운 왕궁에서, 로잘린은 어딘가에서. 그리고 티오가 막대기 검을 들고 달려온다. 아이들이 주인공을 부른다. 처음 이 골목에 떨어진 날, 그것은 모욕이었다. 이제 그 말은 다른 뜻이 되었다. 빈손.\n\n[엔딩 강화] '빈손'이라는 말을 초반과 다른 의미로 되받는다.\n\n장면 제약: 이 사건에서 새로운 적이나 전투가 나오지 않는다.",
        "required": true,
        "sequence": 75,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e70_voice",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e69_after-c1",
            "description": "주인공의 선택 뒤 세상과 잿골목의 변화가 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e69_after-c2",
            "description": "동료들 각자의 그 후가 짧게 스친다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e69_after-c3",
            "description": "'빈손'이라는 말이 처음과 다른 뜻으로 불린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e69_after-constraints",
            "description": "이 사건에서 새로운 적이나 전투가 나오지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "그 후의 잿골목",
        "summary": "계절이 하나 지난다. 주인공의 선택이 남긴 세상. 유리의 진료소에는 줄이 길고, 도로시는 길드 창구로 돌아와 퇴원한 엘라의 손을 잡고 출근한다. 브로크는 야경단 완장을 차거나, 혹은 아직 골목 끝에서 서성인다. 에스텔은 별읽기 무녀의 예복을 벗고, 진료소 옆 빈 창고에서 빈손 아이들에게 글을 가르친다. 이제 그녀가 읽는 것은 가슴속 빛이 아니라 책이다. 이졸데는 재대결을 신청하고(「훈련장의 이졸데」를 지났다면 그 장갑을 걸고), 살아남았다면 셀레네는 빵을 태운다. 「종탑의 셀레네」를 지났다면 엄마 노래의 마지막 소절이 처음으로 다락에서 끝까지 울린다. 「망루의 에스텔」을 지났다면, 에스텔은 별 대신 그를 보며 별자리 이야기를 한다. 카일은 기사의 맹세를 새로 쓰고, 레온은 진짜 증표를 받는다. 나나와 그라츠는 그림자 시장에 작은 가게를 낸다. 피핀의 노래는 가사가 또 바뀌었다. 레녹스는 약혼 서류를 태운 왕궁에서, 로잘린은 어딘가에서. 그리고 티오가 막대기 검을 들고 달려온다. 아이들이 주인공을 부른다. 처음 이 골목에 떨어진 날, 그것은 모욕이었다. 이제 그 말은 다른 뜻이 되었다. 빈손.\n\n[엔딩 강화] '빈손'이라는 말을 초반과 다른 의미로 되받는다.\n\n장면 제약: 이 사건에서 새로운 적이나 전투가 나오지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공의 선택 뒤 세상과 잿골목의 변화가 드러난다.\n\n동료들 각자의 그 후가 짧게 스친다.\n\n'빈손'이라는 말이 처음과 다른 뜻으로 불린다.",
          "selectionScope": "",
          "constraints": "이 사건에서 새로운 적이나 전투가 나오지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e69_after-c1",
              "text": "주인공의 선택 뒤 세상과 잿골목의 변화가 드러난다."
            },
            {
              "id": "e69_after-c2",
              "text": "동료들 각자의 그 후가 짧게 스친다."
            },
            {
              "id": "e69_after-c3",
              "text": "'빈손'이라는 말이 처음과 다른 뜻으로 불린다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e69_after-constraints",
            "description": "이 사건에서 새로운 적이나 전투가 나오지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e70_voice",
        "name": "우물 밑의 목소리",
        "kind": "event",
        "type": "Fixed",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "",
        "followUp": "",
        "description": "그날 밤, 주인공은 다시 우물로 내려간다. 무언가가 그를 부른 것 같아서. 빛의 그릇 앞에 서자, 품속의 일기가 저절로 마지막 장을 펼친다. '나는 아직 우물 안에 있다.' 그릇의 빛이 한 번 맥박친다. 에스텔이 뒤따라 내려왔다면, 그녀의 별빛 눈에 그릇 속 사람이 처음으로 눈을 뜨는 것이 보인다. 그리고 300년 만에 처음으로, 우물 밑에서 목소리가 울린다. 한국어다. 낡은 말투의. \"드디어 왔구려, 고향 사람. 내 이름은 한백이오. 삼백 년을 기다렸소.\" 1부는 여기서 끝난다.\n\n[핵심 공개] 우물 밑의 목소리가 처음으로 말을 걸고 자신의 이름을 밝힌다.\n\n[엔딩 강화] 마지막은 우물 밑 목소리로 끊는다.\n\n이 장면에서 회수할 복선: 나는 아직 우물 안에 있다\n우물 밑에서 빈손의 왕이 직접 말을 걸어온다.\n\n이 장면에서 회수할 복선: 그릇 속의 사람\n우물 밑에서 그 사람이 처음으로 말을 걸어온다.\n\n장면 제약: 목소리의 속내와 목적은 밝히지 않는다. 목소리의 대사는 사건 설명에 주어진 세 문장을 넘지 않는다.",
        "required": true,
        "sequence": 76,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e70_voice-c1",
            "description": "주인공이 다시 우물 앞에 선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e70_voice-c2",
            "description": "일기의 마지막 장이 다시 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e70_voice-c3",
            "description": "우물 밑에서 누군가 처음으로 말을 걸어온다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e70_voice-constraints",
            "description": "목소리의 속내와 목적은 밝히지 않는다. 목소리의 대사는 사건 설명에 주어진 세 문장을 넘지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [
          "한백"
        ],
        "title": "우물 밑의 목소리",
        "summary": "그날 밤, 주인공은 다시 우물로 내려간다. 무언가가 그를 부른 것 같아서. 빛의 그릇 앞에 서자, 품속의 일기가 저절로 마지막 장을 펼친다. '나는 아직 우물 안에 있다.' 그릇의 빛이 한 번 맥박친다. 에스텔이 뒤따라 내려왔다면, 그녀의 별빛 눈에 그릇 속 사람이 처음으로 눈을 뜨는 것이 보인다. 그리고 300년 만에 처음으로, 우물 밑에서 목소리가 울린다. 한국어다. 낡은 말투의. \"드디어 왔구려, 고향 사람. 내 이름은 한백이오. 삼백 년을 기다렸소.\" 1부는 여기서 끝난다.\n\n[핵심 공개] 우물 밑의 목소리가 처음으로 말을 걸고 자신의 이름을 밝힌다.\n\n[엔딩 강화] 마지막은 우물 밑 목소리로 끊는다.\n\n이 장면에서 회수할 복선: 나는 아직 우물 안에 있다\n우물 밑에서 빈손의 왕이 직접 말을 걸어온다.\n\n이 장면에서 회수할 복선: 그릇 속의 사람\n우물 밑에서 그 사람이 처음으로 말을 걸어온다.\n\n장면 제약: 목소리의 속내와 목적은 밝히지 않는다. 목소리의 대사는 사건 설명에 주어진 세 문장을 넘지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 다시 우물 앞에 선다.\n\n일기의 마지막 장이 다시 드러난다.\n\n우물 밑에서 누군가 처음으로 말을 걸어온다.",
          "selectionScope": "",
          "constraints": "목소리의 속내와 목적은 밝히지 않는다. 목소리의 대사는 사건 설명에 주어진 세 문장을 넘지 않는다.",
          "success": "",
          "unmet": "",
          "closureConditions": [
            {
              "id": "e70_voice-c1",
              "text": "주인공이 다시 우물 앞에 선다."
            },
            {
              "id": "e70_voice-c2",
              "text": "일기의 마지막 장이 다시 드러난다."
            },
            {
              "id": "e70_voice-c3",
              "text": "우물 밑에서 누군가 처음으로 말을 걸어온다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e70_voice-constraints",
            "description": "목소리의 속내와 목적은 밝히지 않는다. 목소리의 대사는 사건 설명에 주어진 세 문장을 넘지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      }
    ],
    "hiddenEventClocks": [],
    "hiddenForeshadowings": [
      {
        "id": "FS_01",
        "title": "분필 동그라미와 독서실의 목소리",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e02_attic",
        "reinforcementPlan": "리네 손끝의 분필 가루와 물로 지워지는 골목의 동그라미를 보여 주고, 주인공이 독서실에서 들은 '빼앗을 수 있는 사람을'이라는 목소리를 문득 떠올리게 한다. 이유는 말하지 않는다.",
        "payoffConditions": "e28_circle",
        "payoffResult": "리네가 엄마의 책 속 그림을 따라 분필로 동그라미를 그리고 빌어 주인공을 불렀다는 고백으로 이어진다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_02",
        "title": "깡통 속 의식 헌금",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e02_attic",
        "reinforcementPlan": "리네가 티오의 의식 헌금을 위해 깡통에 동전을 모으는 모습을 생활 장면으로 보여 준다.",
        "payoffConditions": "e53_tio_name",
        "payoffResult": "빈손 가정의 의식 헌금이 성녀 실험에 쓰였다는 장부 기록으로 뒤집힌다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_03",
        "title": "가호에 남은 마지막 마음",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e03_rat",
        "reinforcementPlan": "가호를 가져올 때마다 원래 주인의 마지막 감정이 한순간 스치게 한다.",
        "payoffConditions": "e67_well",
        "payoffResult": "별의 우물을 떠도는 수천 개의 가호마다 주인의 마지막 마음이 남아 있는 광경으로, 일기의 '빼앗은 가호는 무겁다'가 눈앞에 펼쳐진다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_04",
        "title": "리네의 빨래 노래",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e04_day",
        "reinforcementPlan": "빨래를 짜며 흥얼거리는 리네의 낮은 노래를 생활의 소리로만 들려준다.",
        "payoffConditions": "e48_unmask",
        "payoffResult": "가면 아래의 셀레네가 같은 노래를 불렀고, 자매가 엄마에게 배운 노래였음이 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_05",
        "title": "빛을 보는 눈",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e04_day",
        "reinforcementPlan": "에스텔이 이름과 '빛을 보는 눈'만 밝히고, 그 눈이 무엇인지, 왜 성좌교의 사냥을 아는지는 말하지 않게 한다.",
        "payoffConditions": "e18_estelle",
        "payoffResult": "그녀가 아스트레아 공작가의 별읽기 무녀였음이 밝혀진다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_06",
        "title": "빈자리가 있는 사람",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e05_doctor",
        "reinforcementPlan": "오스의 '빈손이란 빈자리가 있는 사람이라는 뜻이기도 하지'를 지나가는 말처럼 남긴다.",
        "payoffConditions": "e64_kneel",
        "payoffResult": "〈성언〉은 빈자리가 있는 사람만 묶으므로, 빈자리를 채워 주는 것이 해법이 된다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_07",
        "title": "두건 소녀의 눈",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e05_doctor",
        "reinforcementPlan": "에스텔이 눈가를 누르며 오스의 비밀 환자로 찾아오는 모습만 보여 주고, 이유는 말하지 않는다.",
        "payoffConditions": "e27_funeral",
        "payoffResult": "에스텔이 별읽기로 상한 눈을 3년 동안 오스에게 몰래 치료받았음이 장례에서 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_08",
        "title": "경전 속 폭군",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e06_fortune",
        "reinforcementPlan": "실피가 들려주는 폭군 빈손의 왕 전설과 '그 손을 불태우라'는 경전 구절을 공포담처럼 남긴다.",
        "payoffConditions": "e33_diary",
        "payoffResult": "일기로 빈손의 왕이 폭군이 아니라 가호를 나눠 주던 사람이었음이 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_09",
        "title": "실피의 점",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e06_fortune",
        "reinforcementPlan": "'넌 빼앗고, 놓고, 결국은 건네게 될 게다'를 장난스러운 점괘처럼 들려준다.",
        "payoffConditions": "e34_giving",
        "payoffResult": "주인공이 처음으로 가호를 건네며 점괘의 마지막 말이 이루어진다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_10",
        "title": "마수 사체의 별 모양 자국",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e07_sewer",
        "reinforcementPlan": "하수구와 늪의 마수 사체에 찍힌 별 모양 자국을 설명 없이 보여 준다.",
        "payoffConditions": "e54_rosalind",
        "payoffResult": "쫓기던 일행이 가호석 창고에서, 별 모양 자국이 버려진 가호석의 표식이고 누더기 왕도 거기서 생겼음을 본다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_11",
        "title": "눈을 마주치면 멈추게 하던 엄마",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e08_toll",
        "reinforcementPlan": "리네가 엄마의 가호를 '눈을 마주치면 사람을 멈추게 했다'고만 기억하게 한다.",
        "payoffConditions": "e52_kyle_gift",
        "payoffResult": "그 가호 〈굳힘〉이 엄마의 처형 뒤 카일에게 배정되었음이 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_12",
        "title": "빈손이 된 브로크",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e09_brokk",
        "reinforcementPlan": "가호를 잃고 무너지는 브로크의 얼굴과 남은 원한을 가볍게 넘기지 않는다.",
        "payoffConditions": "e64b_stand",
        "payoffResult": "결전에서 브로크가 몸을 던져 길을 열거나 밀고자로 나타났다 무너진다. 그가 어느 쪽인지는 지금까지의 선택이 정한다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_13",
        "title": "유리의 소원",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e11_housecall",
        "reinforcementPlan": "할아버지의 떨리는 손과 '나에게도 가호가 있었다면' 하는 유리의 혼잣말을 남긴다.",
        "payoffConditions": "e36_clinic",
        "payoffResult": "유리가 진료소를 다시 열며 자신의 방식으로 할아버지의 뒤를 잇는다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_14",
        "title": "형, 나도 가호 받을 수 있을까?",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e12_tio",
        "reinforcementPlan": "티오의 질문에 주인공이 쉽게 대답하지 못하게 한다.",
        "payoffConditions": "e64_kneel",
        "payoffResult": "의식장에서 티오가 처음 갖게 되는 가호가 장부의 배정이 아니라 누군가의 손에서 건네진 것이 된다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_15",
        "title": "실피 모자 끈의 동전",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e13_sylphie",
        "reinforcementPlan": "구멍 뚫린 낡은 동전이 조선의 상평통보와 닮았다는 것을 주인공만 알아챌 수 있게 한다.",
        "payoffConditions": "e33_diary",
        "payoffResult": "실피가 빈손의 왕의 동료였고 그 동전이 그가 준 것이었음이 밝혀진다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_16",
        "title": "놓는 것도 실력",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e13_sylphie",
        "reinforcementPlan": "실피의 '가득 차면 하나를 놓아야 한다. 놓는 것도 실력이여'를 훈련의 잔소리처럼 남긴다.",
        "payoffConditions": "e48_unmask",
        "payoffResult": "셀레네를 살리려면 모은 힘을 놓아야 하는 순간, 그 말이 성장의 진짜 뜻으로 돌아온다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_17",
        "title": "도로시의 쪽지와 엘라",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e14_stone",
        "reinforcementPlan": "상냥한 도로시가 성좌교 전령에게 쪽지를 건네는 모습을 한 줄로 스치게 하고, 여동생 엘라 이야기를 할 때 가장 환하게 웃으며 치료비가 비싸다는 말을 흘리게 한다.",
        "payoffConditions": "e50_dorothy",
        "payoffResult": "도로시가 엘라의 치료비 때문에 성좌교의 정보원이 되었고, 그 쪽지가 빈 가면의 습격을 불렀음이 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_18",
        "title": "레온의 눈치",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e15_first_quest",
        "reinforcementPlan": "가호 없이 활과 판 읽기로만 싸우는 레온이 주인공을 보고 무언가 눈치챈 듯 웃게 한다.",
        "payoffConditions": "e42_forged",
        "payoffResult": "레온 역시 위조 증표를 가진 빈손이었음이 그라츠의 코끝에서 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_19",
        "title": "놓은 가호의 빛",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e16_full",
        "reinforcementPlan": "놓은 가호가 빛이 되어 어디론가 날아가는 모습과 그날 밤 등불 없이 바느질하는 리네를 나란히 보여 준다.",
        "payoffConditions": "e28_circle",
        "payoffResult": "놓은 가호가 소환의 끈을 따라 리네에게 갔음이 밝혀진다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_20",
        "title": "축복 뒤에 켜지는 빛",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e18_estelle",
        "reinforcementPlan": "에스텔이 '어떤 아이들의 빛은 대주교 예하의 축복을 받은 뒤에야 켜진다'고 지나가듯 묻게 한다.",
        "payoffConditions": "e51_ledger",
        "payoffResult": "장부로 별의 의식이 대주교의 손을 거친 배정이었음이 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_21",
        "title": "피핀의 편지",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e19_pippin",
        "reinforcementPlan": "피핀이 틈만 나면 수첩에 적고 어딘가로 편지를 보내는 모습을 개그로 넘긴다.",
        "payoffConditions": "e38_lennox",
        "payoffResult": "피핀이 제2왕자 레녹스가 붙인 첩자였고, 너무 팬이 되어 보고서를 엉터리로 썼음이 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_22",
        "title": "내 가호 돌려줘요",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e21_after_duel",
        "reinforcementPlan": "이졸데의 '돌려줘요'(혹은 '재대결')를 반복 개그로 쌓아 둔다.",
        "payoffConditions": "e68_hands",
        "payoffResult": "결말에서 〈불꽃 왕관〉을 돌려줄지가 라이벌 관계의 결산이 된다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_23",
        "title": "미리 정해진 가호",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e25_kyle",
        "reinforcementPlan": "카일의 아버지가 '의식 전에 이미 받기로 정해져 있었다'고 자랑하게 한다.",
        "payoffConditions": "e51_ledger",
        "payoffResult": "별의 의식이 운명이 아니라 장부의 배정이라는 진실로 이어진다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_24",
        "title": "가호는 줄 수도 있다",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e26_mask",
        "reinforcementPlan": "죽어 가는 오스가 스스로 〈치유의 손〉을 내어 주는 장면을 슬픔으로만 남긴다.",
        "payoffConditions": "e34_giving",
        "payoffResult": "일기의 방법대로 주인공이 맞잡은 손으로 처음 가호를 건넨다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_25",
        "title": "늑대 송곳니 목걸이",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e29_market",
        "reinforcementPlan": "나나가 목걸이를 만지작거리면서도 사연은 끝내 말하지 않게 한다.",
        "payoffConditions": "e39_nana",
        "payoffResult": "목걸이가 투기장 챔피언 그라츠, 나나 대신 노예가 된 의오빠의 것이었음이 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_26",
        "title": "나는 아직 우물 안에 있다",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e33_diary",
        "reinforcementPlan": "일기의 마지막 장 문장을 뜻을 알 수 없는 채로 남긴다.",
        "payoffConditions": "e70_voice",
        "payoffResult": "우물 밑에서 빈손의 왕이 직접 말을 걸어온다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_27",
        "title": "'별의 뜻'으로 끌려간 엄마",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e36_clinic",
        "reinforcementPlan": "빨래터에서 리네가 '우리 엄마는 별의 뜻이라는 말에 끌려갔어'라고 말하고, 에스텔이 대답하지 못하게 한다.",
        "payoffConditions": "e56_grandfather",
        "payoffResult": "리네가 '네가 읽은 건 네가 한 거야'라고 말하고, 에스텔이 그 말을 피하지 않는다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_28",
        "title": "왕실은 대성당의 인형",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e38_lennox",
        "reinforcementPlan": "레녹스가 와인 잔을 흔들며 '왕실은 대성당의 인형이거든'과 '내 약혼자다. 서류상으로는'을 농담처럼 흘리게 한다.",
        "payoffConditions": "e64b_stand",
        "payoffResult": "레녹스가 광장에서 근위대를 이끌고, 왕실의 끈과 함께 아스트레아 가와의 약혼을 끊는다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_29",
        "title": "현관의 초상화",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e43_manor",
        "reinforcementPlan": "아스트레아 저택 현관의 젊은 부부 초상화와 '동부 변경에서 잃었대요'라는 에스텔의 말을 가볍게 지나가게 한다.",
        "payoffConditions": "e56_grandfather",
        "payoffResult": "그 부부가 17년 전 내전의 불에 죽은 에스텔의 부모이며, 그 밤이 그레고르를 바꾸었음이 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_30",
        "title": "손녀를 쓰다듬는 손",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e43_manor",
        "reinforcementPlan": "그레고르가 크고 따뜻한 손으로 손녀의 머리를 쓰다듬는 모습을 다정하게만 그린다.",
        "payoffConditions": "e66_gregor",
        "payoffResult": "그 손이 아이들에게 장부의 가호를 넣던 축복의 손이었음을 에스텔이 그의 앞에서 말한다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_31",
        "title": "피가 흐르는 땅",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e44_cathedral",
        "reinforcementPlan": "그레고르의 설교 속 '가호가 무작위로 나뉘던 땅에서 피가 흐르는 것을 보았습니다'를 의례적인 문구처럼 들려준다.",
        "payoffConditions": "e56_grandfather",
        "payoffResult": "17년 전 동부 변경의 내전에서 아들 부부를 잃은 밤이 그레고르의 질서의 뿌리였음이 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_32",
        "title": "성녀에게서 눈을 피하는 무녀",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e44_cathedral",
        "reinforcementPlan": "낭독대의 에스텔이 성녀가 지나갈 때 눈을 피하는 모습만 보여 준다.",
        "payoffConditions": "e55_core",
        "payoffResult": "에스텔이 성녀의 하나뿐인 자리에서 빛 셋이 겹쳐 타는 것을 보고도 침묵했다고, 실피의 고백 곁에서 털어놓는다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_33",
        "title": "성녀의 갈라진 손",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e45_saint_hands",
        "reinforcementPlan": "셀레네의 갈라진 손마디, 차가운 손가락, 미세한 떨림을 주인공이 기억하게 한다.",
        "payoffConditions": "e48_unmask",
        "payoffResult": "그 손이 빈 가면의 손이었고, 억지로 넣은 가호가 그녀를 태우고 있었음이 드러난다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_34",
        "title": "저도 한때는 빈손이었답니다",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e46_inquisition",
        "reinforcementPlan": "로잘린의 미소가 단 한 번 진짜가 되는 순간을 짧게 남긴다.",
        "payoffConditions": "e65_last_inquiry",
        "payoffResult": "로잘린이 평생 따른 그레고르에게서 처음으로 거짓말 냄새를 맡는다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": "가벼운 복선이다. 장면의 중심이 아니므로 심을 때도 회수할 때도 한두 문장으로 스치듯 다룬다."
      },
      {
        "id": "FS_35",
        "title": "무녀의 대본",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e53_tio_name",
        "reinforcementPlan": "장부의 낭독 목록에 적힌 '별이 이 아이를 성녀의 길로 불렀다'를 보여 준다.",
        "payoffConditions": "e64_kneel",
        "payoffResult": "의식장에서 에스텔이 대본 대신 자기 말로 진실을 읽는다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      },
      {
        "id": "FS_36",
        "title": "그릇 속의 사람",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e67_well",
        "reinforcementPlan": "에스텔이 빛의 그릇 안에 살아 있는 사람이 있다고 말하게 하되, 그 정체는 밝히지 않는다.",
        "payoffConditions": "e70_voice",
        "payoffResult": "우물 밑에서 그 사람이 처음으로 말을 걸어온다.",
        "relatedEntities": "",
        "misdirection": "심는 장면에서는 이 단서의 뜻을 인물이 설명하거나 서술이 풀어 주지 않는다.",
        "notes": ""
      }
    ],
    "hiddenImageTriggers": [],
    "hiddenRisks": "",
    "gmLedger": {
      "worldTruthLedger": "[주인공의 힘 — 규칙]\n1. 주인공은 쓰러뜨린 상대(죽였거나, 의식을 잃었거나, 스스로 패배를 인정한 상대)에게 손을 뻗어 그 가호를 가져올 수 있다. 가져올지 말지는 주인공이 정한다. 상대가 진심으로 내어 주면 싸우지 않아도 넘어온다.\n2. 가호를 빼앗긴 사람은 그 가호를 잃고 빈손이 된다. 이 세계 사람은 자리가 하나뿐이라 가호를 잃으면 신분과 생계를 한꺼번에 잃는다.\n3. 주인공의 그릇은 처음 3칸이다. 가득 차면 하나를 '놓아야' 새 가호를 가져올 수 있다. 그릇은 놓을 줄 아는 만큼 넓어진다.\n4. 놓은 가호는 소환의 끈을 따라 리네에게 간다(리네의 자리가 비어 있을 때). 리네의 자리가 차 있으면 별의 우물로 돌아간다.\n5. 「건네는 손」 사건부터 주인공은 맞잡은 손으로, 자리가 비어 있는 사람(빈손, 의식 전의 아이)에게 가호를 건넬 수 있다. 건넨 가호는 받은 사람의 것이 된다. 수인과 엘프는 자리가 없어 받을 수 없다.\n6. 가호를 가져올 때마다 원래 주인의 마지막 감정 한 조각이 주인공에게 스친다. 사람에게서 빼앗을수록 꿈자리가 사나워진다.\n7. 가호는 정해진 규칙대로만 작동하며 조합은 자유다. 주인공은 강해져도 무적이 아니다.\n8. 이 세계에는 상태창이 없다. 주인공은 가호를 가슴 속 작은 등잔들처럼 느낀다.\n\n[숨은 진실]\n- 주인공을 부른 것은 리네가 그린 분필 동그라미다. 원본은 빈손의 왕이 일기에 남긴 소환진이다.\n- 빈손의 왕은 300년 전 조선에서 떨어진 청년 한백이다. 주인공과 같은 그릇을 가졌다. 그는 귀족의 가호를 빼앗아 빈손들에게 나눠 주다 성인(귀족)들에게 쫓겼다. 성인들은 그를 죽이지 못해 별의 우물 밑바닥에 봉인하고, 그의 그릇을 모든 가호의 저장소로 쓰고 있다. 그는 의식만 남은 채 살아 있다. 엘프 실피는 그의 동료였고, 모자 끈의 낡은 동전(상평통보)은 그가 준 것이다.\n- 별의 의식은 운명이 아니라 배정이다. 대주교의 장부가 아이마다 받을 가호를 미리 정한다. 귀족 아이들에게 강한 가호를 주려고, 우물이 모자라면 평민 가호자를 이단으로 몰아 처형하고 회수한다. 빈손 가정의 의식 헌금은 성녀 실험에 쓰인다.\n- 약한 가호는 '가호석'에 담아 숲과 늪에 버린다. 그 가호를 삼킨 짐승은 마수가 되며, 몸에 별 모양 자국(우물의 표식)이 남는다. 버려진 가호가 한 짐승에게 여럿 뭉치면 '누더기 왕' 같은 괴물이 된다. 빈손은 '모자라서'가 아니라 '정해서' 만들어진다.\n- 리네의 엄마 마르타는 일기 사본을 가졌다는 이유로 처형됐고, 그녀의 〈굳힘〉은 카일에게 배정됐다.\n- 성녀 셀레네는 리네의 언니이자 빈 가면이다. 빈손이던 그녀의 자리에 우물의 가호 세 개를 억지로 넣은 실험체이며, 가호들이 그녀의 몸을 태우고 있다.\n- 에스텔의 〈별읽기〉는 진짜다. 그녀는 사람의 가슴속 가호를 빛으로, 빈자리를 어두운 홈으로 본다. 그러나 의식에서 그녀가 읽는 빛은 대주교가 '축복의 손'으로 방금 넣은 가호이고, 그녀가 낭독하는 문장도 장부의 '낭독 목록'에 미리 적혀 있다. 별읽기 무녀의 낭독은 배정을 별의 뜻으로 꾸미는 무대다. 에스텔은 3년 전부터 어떤 아이들의 빛이 축복을 받은 뒤에야 켜진다는 것을 알아챘지만, 할아버지의 \"보이는 대로만 읽거라\"에 따랐다. 그녀는 성녀 셀레네의 하나뿐인 자리에서 빛 셋이 겹쳐 타는 것도 보았고, 보고도 읽지 않았다. 〈별읽기〉는 많은 빛을 한꺼번에 읽으면 눈을 상하게 해서, 의식 날마다 그녀의 눈에서 피가 비친다. 집안 어른이 걱정할까 봐, 그리고 무녀가 아프다는 소문이 의식을 흔들까 봐 3년 동안 잿골목의 오스에게 몰래 치료받았다.\n- 대주교 그레고르는 아스트레아 공작가의 전 당주이자 에스텔의 할아버지다. 17년 전 가호가 무작위로 나뉘던 동부 변경의 내전에서, 갑자기 〈불꽃〉을 얻은 농부가 지른 불에 아들 부부를 잃고 갓난 손녀 에스텔만 구해 냈다. 그 밤이 그의 질서의 뿌리다. 그는 손녀를 진심으로 사랑하며, 그 사랑과 장부는 그의 안에서 모순되지 않는다.\n- 에스텔과 제2왕자 레녹스는 왕실을 성좌교에 묶어 두려는 그레고르의 뜻으로 정략 약혼을 했다. 둘은 서로를 사랑하지 않는 '서류상의 약혼자'이자, 서로의 처지를 아는 오랜 말동무다. 레녹스는 「일어선 광장」에서 왕실의 끈과 함께 이 약혼을 끊는다.\n- 우물 가장 깊은 곳에는 주인공의 눈에만 독서실 형광등 같은 흰 빛이 한 번 스친다. 원래 세계로 이어질지 모르는 틈이며, 1부에서는 정체를 밝히지 않는다.\n- 대주교 그레고르의 가호 〈성언〉: 자리가 비어 있는 자는 그의 목소리가 들리는 동안 그 목소리로 내린 명령을 거스르지 못한다. 목소리가 닿지 않으면 묶임도 풀린다. 그래서 빈손이 많을수록 다스리기 쉽다. 가호를 가진 사람, 자리가 아예 없는 수인과 엘프, 다른 세계에서 온 주인공에게는 통하지 않는다. 주인공이 한 번에 건넬 수 있는 가호는 그릇에 가진 만큼뿐이라, 결전에서 일으킬 수 있는 사람은 몇 명뿐이다. 광장 전체를 푸는 것은 그의 목소리를 덮는 일(대성당의 큰 종)이고, 수많은 빈손에게 가호를 나누는 일은 우물 앞의 선택으로 넘어간다. 주인공이 놓은 가호를 받은 리네는 성언에 묶이지 않는다. 그레고르가 질서에 매달리는 이유는 17년 전 동부 변경의 내전이다.\n- 레온은 위조 증표를 가진 빈손이다. 도로시는 성좌교의 정보원이며 병든 여동생 엘라의 치료비를 성좌교가 대 준다. 피핀은 레녹스가 붙인 엉터리 첩자다. 로잘린은 그레고르에게 가호를 받은 옛 빈손이다.\n\n[공개 조건 — 정사 진행표]\n- 1권(「빈손」~「돌 등급」): 리네가 소환자라는 사실, 빈손의 왕의 진실은 드러내지 않는다. 「잿쥐의 밤」에 두건 소녀가 처음 스쳐 가고, 「빈손의 하루」에서 이름(에스텔)과 빛을 보는 눈만 밝힌다. 가문과 별읽기 무녀라는 신분은 「별읽는 영애」까지, 대주교와의 관계는 「아스트레아 저택」까지 숨긴다. 경전 속 폭군 전설, 분필 가루, 실피의 동전, 마수의 별 낙인은 단서로만 보인다.\n- 2권(「첫 의뢰」~「놓은 것이 가는 곳」): 놓은 가호의 행방은 「놓은 것이 가는 곳」에서 공개. 그 전에는 리네가 어둠 속을 본다는 '모습'까지만. 레온·도로시·피핀의 비밀은 작은 티만 낸다. 「오스의 장례」에서 에스텔이 오스에게 몰래 눈을 치료받던 환자였다는 것까지 밝힌다. 「별읽는 영애」에서 에스텔이 아스트레아 공작가의 별읽기 무녀라는 것까지 밝힌다. 대주교와의 관계는 아직이다.\n- 3권(「그림자 시장」~「늑대의 코」): 「빈손의 왕의 일기」에서 빈손의 왕이 조선 사람이자 나눠 주던 사람이었다는 것과 실피가 그의 동료였다는 것. 「레녹스의 초대」에서 피핀의 첩자 노릇과 에스텔·레녹스의 서류상 약혼. 「나나의 부탁」에서 그라츠. 「늑대의 코」에서 레온. 그의 이름과 '우물 안에 있다'의 뜻은 아직이다.\n- 4권(「아스트레아 저택」~「할아버지의 별」): 「아스트레아 저택」에서 에스텔의 할아버지가 대주교 그레고르라는 것. 「별의 대성당」에서 성녀의 이름이 리네의 언니 이름과 같다는 것. 「가면 아래」에서 빈 가면이 셀레네. 「새어 나간 계획」에서 도로시. 「대주교의 장부」에서 배정과 처형·회수. 「로잘린」의 추격 중 가호석 창고에서 버려지는 가호(별 모양 자국과 누더기 왕의 정체). 「카일의 가호」에서 마르타의 가호. 「티오의 이름」에서 티오의 배정과 별읽기 무녀의 낭독 목록. 「할아버지의 별」에서 그레고르가 질서를 믿게 된 17년 전의 밤. 「우물의 핵」에서 우물의 핵이 빈손의 왕의 그릇이라는 것.\n- 5권(「수배」~「우물 밑의 목소리」): 「별의 의식」에서 〈성언〉. 「우물 밑의 목소리」에서 빈손의 왕의 목소리와 이름 '한백'.\n\n[결말 변주]\n- 우물에 대한 주인공의 선택이 결말의 중심이다. 우물을 깨면 가호가 무작위로 흩어지는 혼란과 해방이, 우물을 삼키면 압도적인 힘과 '새로운 빈손의 왕'이라는 두려움이, 하나씩 건네면 그릇이 버티는 만큼만의 느리고 확실한 변화가 온다.\n- 동료 10명 이상: 결전에서 동료들이 각자 결정적인 한 장면씩을 맡는다. 적으면 주인공과 리네가 많은 것을 혼자 짊어진다.\n- 빈손이 된 사람 4명 이상: 구해 준 사람들조차 그를 '돌아온 빈손의 왕'이라 부르며 두려워한다. 2명 이하: 잿골목은 그를 '빈손의 손'이라는 애칭으로 부른다.\n- 에스텔의 마음 7 이상: 에스텔이 가문의 이름보다 그의 곁을 택하고, 결말에 둘만의 장면이 들어간다(별을 읽던 눈으로 그를 '읽지 않고' 바라보는 장면). 3 이하: 에스텔은 곁에 남되 한 걸음 떨어져, 그를 아직 '읽어야 할 사람'으로 본다.\n- 리네의 신뢰 9 이상: 리네가 끝까지 그의 손을 잡고 선택을 함께 짊어진다. 4 이하: 리네는 곁에 남지만 \"가끔 네가 무서워\"라고 말한다.\n- 수배 7 이상: 어떤 선택을 하든 귀족들은 그를 적으로 규정하고, 결말에 왕도를 떠나는 장면이 들어갈 수 있다.\n- 「곰발의 귀환」을 지났다면 브로크는 결전에서 몸을 던져 길을 연다. 「곰발의 원한」을 지났다면 그는 밀고자로 나타났다가 마지막에 무너지거나 돌아선다.\n- 「언니」를 지났다면 셀레네가 살아서 함께한다. 「돌아간 성녀」를 지났다면 셀레네는 의식장 단상에서 쓰러지며, 주인공이 그릇을 비워 그녀의 가호를 거두면 살아남지만 오래 앓는다.\n- 「잿골목의 등불」을 지났다면 광장은 등불을 든 빈손들로 가득하다. 「팔려 간 밤」을 지났다면 리네와 티오가 단상에 묶여 있다.\n- 결전 전야에 찾아간 히로인과의 약속이 「일어선 광장」과 결말의 한 장면으로 돌아온다. 리네는 손목에 묶어 준 머리끈(광장에서 돌려준다), 이졸데는 재대결의 증표인 장갑(광장에서 등을 맡기고, 결말에서 재대결), 셀레네는 엄마 노래의 마지막 소절(결말에서 리네에게 전해진다), 에스텔은 '그릇이 다 비는 순간 빛이 아닌 당신을 읽겠다'는 약속(광장에서 이루어진다).\n- 마지막 목소리: \"드디어 왔구려, 고향 사람. 내 이름은 한백이오. 삼백 년을 기다렸소.\" 그의 속내는 1부에서 밝히지 않는다.",
      "hiddenTimeline": "",
      "secretResources": "",
      "plannedTwists": "",
      "forbiddenDisclosures": "",
      "failureEscalationRules": "",
      "continuityNotes": ""
    }
  }
}
~~~