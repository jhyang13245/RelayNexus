# 아홉 번째 등불 ~귀환 게이지가 차오를수록 불길한 이세계 용사 생활~ Cortex 작품

최종 공개된 산문이 정사다. 사용자 요청은 확정 사실이 아니며 세계와 인과 안에서 수용·우회·제한한다.
현재 사건 목표를 기본 비트부터 자연스럽게 진행한다. 기본 3비트, 최소 2비트부터 조기 종결, 연장 최대 2비트. 미충족 지적은 연장 구간에서 검토한다.
원본이 허용한 미충족 전개로 수습되면 대체 종결로 전환한다. 수습되지 않은 의무만 최후 안전장치로 다음 사건 첫 문단에 이월한다. 포기·대체된 목표를 다시 강제하지 않는다.
사건별 예정 날짜·시작 시각·종료 시각·시간창은 사용하지 않는다. 지정된 후속사건을 우선하고, 미지정이면 사건 배열 순서로 진행한다.
구체적 시간 경과는 현재 공개 본문과 현재 제공된 사건 설명에 따라 집필한다. 다음 사건 설명을 진입 전에 미리 읽거나 미래 시간표에 맞추지 않는다.
작품 근거 없는 24시간 이상 도약은 사용자 요청과 작가 임의 전개 모두 현재 문맥에서 인과적으로 흡수한다. 자정을 넘는 것 자체는 금지가 아니다.
현재 제공된 작품 스토리가 명시한 하루 이상 경과는 그대로 따른다. 3일 뒤·17년 뒤·10년 혼수상태 같은 작가의 서사 문장을 보존한다.
24시간 미만이라도 진행 중인 위험·전투·긴박성을 무너뜨리는 도약은 자연스럽게 중단·단축한다. 꿈·환상은 최후의 수단이다.
새 사건을 처음 읽었을 때 시간대가 이미 지났다면 현재 시각부터 가까운 다음 시간대까지 필요한 일상을 짧게 연결해 해당 비트에서 시작한다. 별도 대기 비트를 요구하지 않는다.
이미 지난 마감·기회는 설득력 있는 지연·상황 변화·대체 기회와 그 결과로 수습한다. 공개한 본문·출발·종료 사실과 시간은 정사이며 24시간 상한으로 되감거나 취소하지 않는다.
작가는 현재 사건·이전 두 사건 원문과 오래된 요약을 읽고, 판정관은 현재·이전 두 사건의 공개 원문만 읽는다. 계약은 달성 기준이지 사실의 증거가 아니다.
첫 문단은 장면을 여는 자연스러운 산문으로 쓴다. 상태표·추천답변·선택지·내부 판정 기록을 산문 출력에 강제하지 않는다. 모델 배정과 호출 횟수는 엔진이 관리한다.

~~~json
{
  "package": {
    "packageVersion": "1.5",
    "engineVersion": "2.4",
    "projectId": "RN-DRAFT",
    "title": "아홉 번째 등불 ~귀환 게이지가 차오를수록 불길한 이세계 용사 생활~",
    "difficulty": "HARD",
    "randomSeed": 420001285,
    "generatedAt": "2026-10-06T16:48:14.061Z",
    "packageTarget": "cortex",
    "format": "DANCHEONG_CORTEX_PACK_V1",
    "minimumTargetVersion": "1.42.0",
    "integrationTarget": {
      "engine": "dancheong-cortex",
      "cortexBaseVersion": "1.42.0",
      "minimumNexusVersion": "1.23.0",
      "minimumExtensionRevision": "1.3.0"
    },
    "protagonistInvariants": [
      {
        "ref": "invariant:survival",
        "label": "윤도하 · 주인공의 생존",
        "severity": "HARD",
        "description": "[대상 캐릭터: 윤도하 / doha] 주인공은 죽지 않는다.",
        "characterId": "doha",
        "characterName": "윤도하"
      },
      {
        "ref": "invariant:mobility",
        "label": "윤도하 · 보행·자립 이동 능력",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 윤도하 / doha] 이동·추격·잠입이 필요한 사건이 남아 있다.",
        "characterId": "doha",
        "characterName": "윤도하"
      },
      {
        "ref": "invariant:senses",
        "label": "윤도하 · 시각·청각",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 윤도하 / doha] 단서 관찰과 대화가 사건의 기본 수단이다.",
        "characterId": "doha",
        "characterName": "윤도하"
      },
      {
        "ref": "invariant:identity",
        "label": "윤도하 · 자기 기억과 인격의 연속성",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 윤도하 / doha] 전면적 기억 상실이나 인격 교체로 확정되지 않는다.",
        "characterId": "doha",
        "characterName": "윤도하"
      },
      {
        "ref": "invariant:phone",
        "label": "윤도하 · 스마트폰 보존",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 윤도하 / doha] 스마트폰은 빼앗기거나 잃어버릴 수는 있어도 파괴되지 않는다. 배터리가 0%가 되어도 기기는 남는다.",
        "characterId": "doha",
        "characterName": "윤도하"
      },
      {
        "ref": "invariant:sera-survival",
        "label": "세라의 생존",
        "severity": "HARD",
        "description": "[대상 캐릭터: 세라 / sera] 세라는 죽지 않는다.",
        "characterId": "sera",
        "characterName": "세라"
      },
      {
        "ref": "invariant:barth-survival",
        "label": "바르트의 생존",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 바르트 / barth] 바르트는 첫 번째 이야기에서 죽지 않는다. 큰 부상은 가능하다.",
        "characterId": "barth",
        "characterName": "바르트"
      },
      {
        "ref": "invariant:orten-until-gate",
        "label": "의식 전 오르텐의 지위",
        "severity": "SOFT",
        "description": "[대상 캐릭터: 오르텐 / orten] 오르텐은 「귀환문」 사건 전까지 죽거나 실각하지 않는다.",
        "characterId": "orten",
        "characterName": "오르텐"
      },
      {
        "ref": "invariant:daon-earth",
        "label": "윤다온 · 다온은 지구에 남는다",
        "severity": "HARD",
        "description": "[대상 캐릭터: 윤다온 / daon] 다온은 어떤 경우에도 이 세계로 소환되거나 넘어오지 않는다.",
        "characterId": "daon",
        "characterName": "윤다온"
      }
    ]
  },
  "protagonistInvariants": [
    {
      "ref": "invariant:survival",
      "label": "윤도하 · 주인공의 생존",
      "severity": "HARD",
      "description": "[대상 캐릭터: 윤도하 / doha] 주인공은 죽지 않는다.",
      "characterId": "doha",
      "characterName": "윤도하"
    },
    {
      "ref": "invariant:mobility",
      "label": "윤도하 · 보행·자립 이동 능력",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 윤도하 / doha] 이동·추격·잠입이 필요한 사건이 남아 있다.",
      "characterId": "doha",
      "characterName": "윤도하"
    },
    {
      "ref": "invariant:senses",
      "label": "윤도하 · 시각·청각",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 윤도하 / doha] 단서 관찰과 대화가 사건의 기본 수단이다.",
      "characterId": "doha",
      "characterName": "윤도하"
    },
    {
      "ref": "invariant:identity",
      "label": "윤도하 · 자기 기억과 인격의 연속성",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 윤도하 / doha] 전면적 기억 상실이나 인격 교체로 확정되지 않는다.",
      "characterId": "doha",
      "characterName": "윤도하"
    },
    {
      "ref": "invariant:phone",
      "label": "윤도하 · 스마트폰 보존",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 윤도하 / doha] 스마트폰은 빼앗기거나 잃어버릴 수는 있어도 파괴되지 않는다. 배터리가 0%가 되어도 기기는 남는다.",
      "characterId": "doha",
      "characterName": "윤도하"
    },
    {
      "ref": "invariant:sera-survival",
      "label": "세라의 생존",
      "severity": "HARD",
      "description": "[대상 캐릭터: 세라 / sera] 세라는 죽지 않는다.",
      "characterId": "sera",
      "characterName": "세라"
    },
    {
      "ref": "invariant:barth-survival",
      "label": "바르트의 생존",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 바르트 / barth] 바르트는 첫 번째 이야기에서 죽지 않는다. 큰 부상은 가능하다.",
      "characterId": "barth",
      "characterName": "바르트"
    },
    {
      "ref": "invariant:orten-until-gate",
      "label": "의식 전 오르텐의 지위",
      "severity": "SOFT",
      "description": "[대상 캐릭터: 오르텐 / orten] 오르텐은 「귀환문」 사건 전까지 죽거나 실각하지 않는다.",
      "characterId": "orten",
      "characterName": "오르텐"
    },
    {
      "ref": "invariant:daon-earth",
      "label": "윤다온 · 다온은 지구에 남는다",
      "severity": "HARD",
      "description": "[대상 캐릭터: 윤다온 / daon] 다온은 어떤 경우에도 이 세계로 소환되거나 넘어오지 않는다.",
      "characterId": "daon",
      "characterName": "윤다온"
    }
  ],
  "disclosure": {
    "protectedTerms": [
      "한소이"
    ]
  },
  "importInstruction": {
    "command": "/패키지불러오기",
    "rules": [
      "최종 공개된 산문이 정사다. 사용자 요청은 확정 사실이 아니며 세계와 인과 안에서 수용·우회·제한한다.\n현재 사건 목표를 기본 비트부터 자연스럽게 진행한다. 기본 3비트, 최소 2비트부터 조기 종결, 연장 최대 2비트. 미충족 지적은 연장 구간에서 검토한다.\n원본이 허용한 미충족 전개로 수습되면 대체 종결로 전환한다. 수습되지 않은 의무만 최후 안전장치로 다음 사건 첫 문단에 이월한다. 포기·대체된 목표를 다시 강제하지 않는다.\n사건별 예정 날짜·시작 시각·종료 시각·시간창은 사용하지 않는다. 지정된 후속사건을 우선하고, 미지정이면 사건 배열 순서로 진행한다.\n구체적 시간 경과는 현재 공개 본문과 현재 제공된 사건 설명에 따라 집필한다. 다음 사건 설명을 진입 전에 미리 읽거나 미래 시간표에 맞추지 않는다.\n작품 근거 없는 24시간 이상 도약은 사용자 요청과 작가 임의 전개 모두 현재 문맥에서 인과적으로 흡수한다. 자정을 넘는 것 자체는 금지가 아니다.\n현재 제공된 작품 스토리가 명시한 하루 이상 경과는 그대로 따른다. 3일 뒤·17년 뒤·10년 혼수상태 같은 작가의 서사 문장을 보존한다.\n24시간 미만이라도 진행 중인 위험·전투·긴박성을 무너뜨리는 도약은 자연스럽게 중단·단축한다. 꿈·환상은 최후의 수단이다.\n새 사건을 처음 읽었을 때 시간대가 이미 지났다면 현재 시각부터 가까운 다음 시간대까지 필요한 일상을 짧게 연결해 해당 비트에서 시작한다. 별도 대기 비트를 요구하지 않는다.\n이미 지난 마감·기회는 설득력 있는 지연·상황 변화·대체 기회와 그 결과로 수습한다. 공개한 본문·출발·종료 사실과 시간은 정사이며 24시간 상한으로 되감거나 취소하지 않는다.\n작가는 현재 사건·이전 두 사건 원문과 오래된 요약을 읽고, 판정관은 현재·이전 두 사건의 공개 원문만 읽는다. 계약은 달성 기준이지 사실의 증거가 아니다.\n첫 문단은 장면을 여는 자연스러운 산문으로 쓴다. 상태표·추천답변·선택지·내부 판정 기록을 산문 출력에 강제하지 않는다. 모델 배정과 호출 횟수는 엔진이 관리한다.",
      "비공개 GM 설정과 아직 공개되지 않은 정보는 산문에 직접 노출하지 않는다.",
      "장소·인물·사건 참조는 패키지 연결용이며 산문 안의 모든 실체를 별도 장부에 등록하도록 강제하지 않는다."
    ]
  },
  "scenario": {
    "title": "아홉 번째 등불 ~귀환 게이지가 차오를수록 불길한 이세계 용사 생활~",
    "genre": "이세계 소환 판타지 · 라이트노벨 · 다크 미스터리",
    "worldType": "이세계(소환형 판타지)",
    "startDate": "2026-10-04",
    "startLocation": "성도 루멘 · 대성등 신전 「소환의 전당」",
    "tone": "밝은 이세계 코미디로 시작해 점점 짙어지는 다크 미스터리, 그리고 눈물 나는 회수",
    "playStyle": "지능형 정사 전개 · 사건·인과·자율 세계 시뮬레이션",
    "author": "",
    "notes": "지음 지능형 정사 모드용 2루트 작품. 첫 번째 이야기(11사건, 분기 1회)의 엔딩을 보면 두 번째 이야기(9사건, 분기 1회)가 열린다. 복선 20개, 수치 5개. 설계 문서는 works/ninth-lamp/README.md.",
    "difficultyProfile": {
      "difficulty": "HARD",
      "protagonistProtection": "none",
      "resourceTracking": "strict",
      "hiddenInformation": "strict",
      "retroactivePreparation": "forbidden",
      "npcAutonomy": "full",
      "failureMitigation": "none",
      "deathEnabled": true,
      "warningLevel": "observational_only",
      "relationVolatility": "realistic",
      "clockAdvanceSeverity": "strict"
    }
  },
  "worldCanon": {
    "overview": "안개 바다에 둘러싸인 마지막 땅, 루멘하르트 왕국. 세상 끝에서 밀려오는 검은 안개는 닿는 것의 색과 온기와 이름을 지운다. 안개에 오래 노출된 사람은 손끝부터 잿빛으로 굳는 '회색 손' 병에 걸린다. 왕국이 아직 살아 있는 이유는 단 하나, 성도 루멘 한가운데 솟은 탑 꼭대기에서 타오르는 거대한 등불 '대성등(大聖燈)'이다. 대성등의 빛이 닿는 곳까지만 안개가 물러나며, 그 빛의 원 안에 약 30만 명이 산다. 연호는 대성등이 처음 켜진 해를 원년으로 하는 성등력(聖燈曆)이며, 지금은 성등력 225년이다.\n\n[대성등과 용사]\n대성등을 처음 밝힌 것은 이백여 년 전 등불을 들고 안개를 건너온 첫 번째 용사였다. 그 뒤 대성등은 스물여덟 해 남짓마다 빛이 약해졌고, 그때마다 성등 신전은 '소환의 전당'에서 다른 세계의 용사를 불렀다. 일곱 명의 용사가 소환되어 안개 가장 깊은 곳 '안개의 심장'에 이르러 잔향을 정화한 뒤 '귀환문(歸還門)'을 지나 고향으로 돌아갔다고 전해진다. 용사가 귀환하면 대성등은 다시 밝게 타오르며, 사람들은 이를 '용사가 남기고 간 축복'이라 부른다. 이번에 부르는 용사는 아홉 번째다. 신전의 교리는 말한다. \"귀환문은 그대를 부르는 목소리를 따라 열린다.\"\n소환된 용사에게는 '축복의 창'(용사들은 상태창이라 부른다)이 주어진다. 이름·레벨·칭호·기술, 그리고 '귀환 게이지'가 표시된다. 귀환 게이지는 안개 속 괴물 '잔향(殘響)'을 정화할수록 차오르며, 충분히 차면 귀환문이 열린다고 신전은 가르친다. 용사는 축복의 창이 주는 [언어의 축복]으로 이 세계 사람들과 대화하고 글을 읽는다.\n\n[잔향과 안개]\n잔향은 회색 연기로 빚은 사람 같기도 짐승 같기도 한 형체로, 밤의 안개 경계에서 나타나 사람을 덮친다. 이 세계 사람들에게 잔향의 소리는 길게 끄는 짐승 울음으로 들린다. 안개가 깊을수록 잔향은 크고 오래되었다. 최근 몇 년 사이 안개의 심장에 잔향을 거느리는 '안개의 왕'이 나타나 신전 원정대를 여러 번 습격했다. 신전은 아홉 번째 용사의 사명이 바로 그것을 정화하는 것이라 말한다.\n\n[도시의 구조]\n성도 루멘은 빛의 세기에 따라 동심원으로 나뉜다. 탑에 가까운 상층원에는 귀족과 신전, 그 바깥 중층원에는 상인과 장인, 빛이 희미해지는 가장 바깥 '등외구(燈外區)'에는 가난한 이들과 회색 손 환자들이 산다. 등외구에서는 밤마다 안개가 담장을 넘어오고, 사람들은 직접 만든 기름등을 켜고 버틴다. 빛은 모두를 지킨다고 신전은 말하지만, 빛의 양은 모두에게 같지 않다.\n\n[생활과 기술]\n기술 수준은 중세 말에서 근세 초 정도. 마법은 대성등에서 떨어져 나온 빛나는 '성등 결정'을 깎아 쓰는 등불 마법뿐이며 결정은 매우 비싸다. 화폐는 금화·은화·빛동전. 길거리에는 노란 꿀사탕을 파는 노점이 흔한데, 옛 용사가 전해 준 과자라고 한다. 이 세계 사람들은 다른 세계의 말을 전혀 모른다.\n\n[세력]\n성등 신전이 대성등과 소환·귀환 의식을 관장하며 사실상 나라를 다스린다. 왕실은 이름뿐이다. 성등 기사단은 안개 원정과 성벽 수비를 맡는다. 등외구 사람들은 신전을 믿지 않고 서로를 돌본다.",
    "history": "",
    "politics": "",
    "economy": "",
    "technology": "",
    "society": "",
    "military": "",
    "religionIdeology": "",
    "transportCommunication": "",
    "currencyPrices": "",
    "supernatural": "",
    "impossibilities": "",
    "fixedCanon": "1. 대성등은 영혼(또는 두 번째 이야기의 새 등불에서는 사람들이 바친 기억)을 태워야만 빛난다. 귀환문으로 집에 돌아가는 방법은 없다.\n2. 죽은 사람은 되살아나지 않는다. 대성등에 들어간 용사의 몸은 돌아오지 않는다.\n3. 이 세계 사람은 한국어를 모른다. 언어의 축복은 용사에게만 있다. 한국어 그대로 들리는 말(잔향의 중얼거림, 바르트가 배운 말, 상태창의 깨진 글자)은 주인공에게만 '번역되지 않은 날것의 말'로 느껴진다.\n4. 대성등이 꺼지면 안개가 하룻밤 사이에 성도를 덮는다. 30만 명의 목숨은 언제나 실제 무게로 다룬다.\n5. 오르텐은 악의로 움직이지 않는다. 그는 끝까지 '30만 명을 위한 선택'이라고 믿고, 비웃거나 고함치지 않는다.\n6. 잔향을 베면 귀환 게이지가 오르고, 애도하거나 대답해 주면 오르지 않는다. 예외는 없다.\n7. 스마트폰은 이 세계에서 통신이 되지 않는다. 대성등 가까이에서 아주 드물게 신호가 잡히는 이상 현상은 「귀환문」 사건의 마지막 장면부터 일어난다.\n8. 주인공은 용사로서 강해지지만 무적이 아니다. 등불의 검은 성등 결정의 힘을 빌린 것이며 안개 심부에서는 약해진다.\n9. 안개의 왕은 주인공을 죽이거나 크게 다치게 하지 않는다.",
    "aiFillConstraints": ""
  },
  "player": {
    "id": "doha",
    "name": "윤도하",
    "role": "플레이어 캐릭터",
    "age": "",
    "gender": "",
    "origin": "",
    "status": "",
    "occupation": "",
    "affiliation": "",
    "appearance": "스무 살 한국인 남성. 키 175cm 정도의 마른 체형, 야간 알바로 생긴 옅은 다크서클. 덥수룩한 검은 머리에 무심한 듯 순한 눈매. 처음에는 비에 젖은 남색 편의점 조끼와 회색 후드티, 낡은 운동화 차림이다. 이세계에서는 신전이 준 흰 바탕에 녹청색과 금실로 등불 무늬를 수놓은 용사복을 입는다. 귀환 게이지가 60%를 넘으면 오른손등에 등불 같은 금빛 무늬가 비친다.",
    "personality": "",
    "values": "",
    "speechStyle": "",
    "skills": "",
    "weaknesses": "",
    "goals": "",
    "assets": "",
    "inventory": "",
    "relationships": "",
    "publicInfo": "스무 살. 대학 1학년을 마치고 휴학한 뒤 편의점 야간 아르바이트로 생활비를 보탠다. 혼자 남매를 키운 엄마 한소정, 열다섯 살 여동생 윤다온과 셋이 산다. 입이 조금 험하고 속으로 딴죽을 많이 걸지만, 남이 우는 걸 못 본다. 게임과 판타지 웹소설을 꽤 읽어서 '상태창', '용사 소환' 같은 클리셰를 금방 알아보고, 그래서 더 의심이 많다. 손재주가 좋고 눈치가 빠르다. 운동 신경은 평범하다.\n엄마의 여동생인 이모는 1998년 10월 4일 밤, 열일곱 살에 한강 둔치에서 실종됐다. 도하가 태어나기 8년 전 일이다. 엄마는 이모의 이름을 거의 입에 올리지 않는다. 부르면 울어 버리니까. 대신 매년 10월 4일이면 이모에게 편지를 써서 강가에서 태우고, 편지 끝에 꼭 '1004'라고 적는다. 엄마의 서랍에는 이모가 쓰던 낡은 삐삐가 아직 있고, 도하는 엄마에게 삐삐 숫자 암호(1004는 천사, 8282는 빨리빨리, 486은 사랑해)를 들은 적이 있다. 엄마는 잠투정하는 남매에게 늘 전래 자장가 '자장자장 우리 아가'를 불러 주었다.\n올해 10월 4일, 엄마가 야간 근무에 걸려 도하가 처음으로 편지를 태우러 나왔다.\n소지품: 배터리 23%가 남은 스마트폰(잠금화면은 가족사진, 다온이 남긴 음성 메시지가 있다), 반쯤 타다 남은 엄마의 편지, 라이터, 이모가 좋아했다는 꿀사탕 두 개.",
    "hiddenInfo": "이모의 이름은 한소이다. 엄마가 그 이름을 부르지 않아서 도하도 속으로만 '이모'라고 한다. 본문은 「안개의 심장」 사건 이전에는 이 이름을 쓰지 않는다. 도하는 이모를 사진으로만 봤다. 앞머리를 내린 단발에 하트 모양 플라스틱 머리핀을 꽂은 교복 차림의 열일곱 살.\n반쯤 타다 남은 엄마의 편지에서 읽을 수 있는 부분: \"…보고 싶다. 네가 사라진 그 강가에서 올해도 이 편지를 태운다. 혹시 길을 잃었다면 불빛을 따라 와. 언니는 아직 그 집에 산다. 1004\"\n도하가 강가에서 \"이모, 엄마가 보고 싶대요\"라고 중얼거린 것이 소환의 계기였다는 사실은 본인도 모른다. 소환 직전에 들린 \"찾았다\"는 목소리는 대성등 안의 한소이의 목소리였다.",
    "importance": "protagonist",
    "imageOnFirstAppearance": true,
    "visualLock": true,
    "visualAnchor": "스무 살 한국인 남성. 키 175cm 정도의 마른 체형, 야간 알바로 생긴 옅은 다크서클. 덥수룩한 검은 머리에 무심한 듯 순한 눈매. 처음에는 비에 젖은 남색 편의점 조끼와 회색 후드티, 낡은 운동화 차림이다. 이세계에서는 신전이 준 흰 바탕에 녹청색과 금실로 등불 무늬를 수놓은 용사복을 입는다. 귀환 게이지가 60%를 넘으면 오른손등에 등불 같은 금빛 무늬가 비친다.",
    "imageFallback": "generate_anime",
    "images": [],
    "isPlayer": true,
    "preRevealAlias": ""
  },
  "publicNpcs": [
    {
      "id": "sera",
      "name": "세라",
      "role": "플레이어 캐릭터",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "열일곱 살 소녀. 키 155cm. 은빛이 도는 연한 금발을 낮게 땋아 한쪽 어깨로 넘겼고, 큰 호박색 눈. 흰 바탕에 녹청색 테두리의 견습 사제복, 허리에 작은 가죽 수첩과 깃펜, 손바닥만 한 등불 펜던트. 왼손등에 어릴 적 안개에 스친 옅은 잿빛 얼룩이 있다.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "열일곱 살. 대성등 신전의 견습 사제이자 아홉 번째 용사의 안내 담당. 밝고 부지런하며 덜렁댄다. 칭찬받으면 귀까지 빨개지고, 무엇이든 작은 가죽 수첩에 받아 적는다(\"용사님 관찰 일지예요!\"). 다섯 해 전 대성등이 잠시 흐려진 밤, 등외구 경계에서 안개에 부모를 잃었다. 그래서 대성등과 용사를 진심으로 믿고 사랑한다. 꿈은 귀환 의식에서 '귀환가'를 불러, 용사님이 웃으며 집에 돌아가는 모습을 배웅하는 것.\n작은 빛을 띄워 안개를 밀어내는 등불 기도를 쓸 수 있다. 존댓말에 감탄사가 많다(\"와아!\", \"그, 그건 비밀이에요!\"). 주인공을 '용사님'이라 부르다가 가까워지면 '도하 님'이라 부른다. 거짓말을 못 해서 숨기는 게 있으면 얼굴에 다 드러난다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "열일곱 살 소녀. 키 155cm. 은빛이 도는 연한 금발을 낮게 땋아 한쪽 어깨로 넘겼고, 큰 호박색 눈. 흰 바탕에 녹청색 테두리의 견습 사제복, 허리에 작은 가죽 수첩과 깃펜, 손바닥만 한 등불 펜던트. 왼손등에 어릴 적 안개에 스친 옅은 잿빛 얼룩이 있다.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "barth",
      "name": "바르트",
      "role": "플레이어 캐릭터",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "195cm의 거구. 짧게 친 회색 섞인 갈색 머리, 왼쪽 눈썹을 가르는 흉터, 덥수룩한 수염. 낡았지만 손질이 잘된 은색 판금 갑옷과 녹청색 망토. 허리에 커다란 양손검과 가죽 술병. 목에 가는 가죽끈을 걸고 있는데, 끝에 매단 것은 늘 갑옷 속에 숨긴다.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "마흔셋. 성등 기사단장. 덩치가 산만 하고 수염이 거칠며 늘 술 냄새가 난다. 퉁명스럽고 용사를 '애송이'라 부르며 일부러 거리를 둔다. 그러나 훈련은 누구보다 꼼꼼하고, 부하가 다치면 제일 먼저 뛰어든다. 안개 원정의 베테랑. 짧고 거친 반말(\"닥치고 검이나 들어.\"). 가끔 아무도 못 알아듣는 이상한 말을 중얼거린다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "195cm의 거구. 짧게 친 회색 섞인 갈색 머리, 왼쪽 눈썹을 가르는 흉터, 덥수룩한 수염. 낡았지만 손질이 잘된 은색 판금 갑옷과 녹청색 망토. 허리에 커다란 양손검과 가죽 술병. 목에 가는 가죽끈을 걸고 있는데, 끝에 매단 것은 늘 갑옷 속에 숨긴다.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "orten",
      "name": "오르텐",
      "role": "플레이어 캐릭터",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "일흔두 살 노인. 마르고 키가 크며 허리가 약간 굽었다. 길고 흰 수염, 깊은 주름, 온화한 회색 눈. 금실로 등불 문양을 수놓은 순백의 대신관 예복과 높은 관, 끝에 작은 등불이 달린 지팡이. 손가락 끝이 살짝 잿빛이다.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "일흔두 살. 대성등 신전의 대신관이자 왕국의 실질적인 통치자. 하얀 수염에 다정한 할아버지 같은 미소, 낮고 부드러운 목소리. 용사를 '아이야' 또는 '아홉 번째 등불이여'라고 부르며, 늘 품에서 노란 꿀사탕을 꺼내 준다(\"옛 용사님께 배운 맛이라네\"). 신전의 교리를 가르친다. 용사가 안개의 왕을 정화하면 귀환문이 열린다. 귀환문은 그대를 부르는 목소리를 따라 열린다. 자주 기침을 하지만 대수롭지 않게 넘긴다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "일흔두 살 노인. 마르고 키가 크며 허리가 약간 굽었다. 길고 흰 수염, 깊은 주름, 온화한 회색 눈. 금실로 등불 문양을 수놓은 순백의 대신관 예복과 높은 관, 끝에 작은 등불이 달린 지팡이. 손가락 끝이 살짝 잿빛이다.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "mabel",
      "name": "메이블",
      "role": "플레이어 캐릭터",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "스물여섯 살 여성. 부스스한 붉은 단발에 둥근 안경, 잉크 얼룩투성이 손가락. 소매를 걷어 올린 갈색 연구복 위에 주머니가 잔뜩 달린 가죽 앞치마. 귀 뒤에 펜을 꽂았고 밤샘으로 눈이 충혈되어 있다.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "스물여섯 살. 왕궁 소속 마도학자. 탑 꼭대기 연구실에 틀어박혀 성등 결정을 연구한다. 머리가 엄청나게 좋고 사회성이 엄청나게 없다. 흥분하면 말이 빨라지고 \"흥미롭군!\"을 연발한다. 주인공의 스마트폰을 '빛을 먹고 사는 상자'라 부르며 탐낸다. 성등 결정을 이용한 충전 장치를 만들 수 있다. 연구 자료를 안 보여 주는 신전을 싫어한다.",
      "importance": "supporting",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "스물여섯 살 여성. 부스스한 붉은 단발에 둥근 안경, 잉크 얼룩투성이 손가락. 소매를 걷어 올린 갈색 연구복 위에 주머니가 잔뜩 달린 가죽 앞치마. 귀 뒤에 펜을 꽂았고 밤샘으로 눈이 충혈되어 있다.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "fio",
      "name": "피오",
      "role": "플레이어 캐릭터",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "열두 살 소년. 마르고 작다. 덥수룩한 잿빛 머리, 그을린 얼굴에 장난스러운 초록 눈. 기운 자국투성이의 헐렁한 갈색 옷, 다 해진 짚신, 목에 동전 꾸러미. 왼손 손가락 두 개가 잿빛으로 굳기 시작했다.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "열두 살쯤. 등외구에 사는 소매치기 소년. 말이 빠르고 입이 험하며 눈치가 귀신같다. 가족은 회색 손 병을 앓는 할머니뿐이다. 신전과 상층원 사람들을 싫어한다(\"빛은 너네 것만이냐?\"). 등외구의 골목과 옛 배수로 지하 통로를 손바닥 보듯 안다. 의리는 있어서 은혜는 반드시 갚는다.",
      "importance": "supporting",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "열두 살 소년. 마르고 작다. 덥수룩한 잿빛 머리, 그을린 얼굴에 장난스러운 초록 눈. 기운 자국투성이의 헐렁한 갈색 옷, 다 해진 짚신, 목에 동전 꾸러미. 왼손 손가락 두 개가 잿빛으로 굳기 시작했다.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "fogking",
      "name": "안개의 왕",
      "role": "플레이어 캐릭터",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "안개로 빚어진 열일곱 살 소녀의 형상. 어깨까지 오는 단발에 앞머리를 내렸다. 1990년대 한국 여고 교복(남색 재킷, 흰 블라우스, 체크무늬 치마)의 실루엣이 안개로 일렁인다. 얼굴 절반에는 불에 그을린 듯한 금빛 균열이 있고, 남은 절반은 앳되고 울 것 같은 얼굴이다. 주위에 수많은 잔향이 그림자처럼 맴돈다. 머리 한쪽, 머리핀이 있어야 할 자리가 비어 있다.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "안개 바다 가장 깊은 곳에 있다는 존재. 신전은 '모든 잔향을 낳는 재앙의 근원'이라 가르치며, 용사가 이것을 정화해야 귀환문이 열린다고 한다. 원정에서 살아 돌아온 병사들은 \"이상한 옷을 입은 소녀 모양이었다\"고 수군거린다. 최근 몇 년 사이 신전 원정대를 여러 번 습격했다.",
      "importance": "major",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "안개로 빚어진 열일곱 살 소녀의 형상. 어깨까지 오는 단발에 앞머리를 내렸다. 1990년대 한국 여고 교복(남색 재킷, 흰 블라우스, 체크무늬 치마)의 실루엣이 안개로 일렁인다. 얼굴 절반에는 불에 그을린 듯한 금빛 균열이 있고, 남은 절반은 앳되고 울 것 같은 얼굴이다. 주위에 수많은 잔향이 그림자처럼 맴돈다. 머리 한쪽, 머리핀이 있어야 할 자리가 비어 있다.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "cassian",
      "name": "카시안",
      "role": "플레이어 캐릭터",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "서른다섯 살 남성. 키가 크고 마른 체격, 뒤로 단정하게 넘긴 흑발, 차가운 청회색 눈과 얇은 안경. 장식 없는 짙은 회색 부신관 예복, 손에는 늘 의식 일정이 적힌 두루마리.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "서른다섯 살. 대성등 신전의 부신관이자 오르텐의 오른팔. 말수가 적고 늘 정확하며 감정을 드러내지 않는다. 입버릇은 \"등불에 감정은 사치입니다.\" 신전 의식과 소환진을 실무로 관리한다.",
      "importance": "supporting",
      "imageOnFirstAppearance": true,
      "visualLock": true,
      "visualAnchor": "서른다섯 살 남성. 키가 크고 마른 체격, 뒤로 단정하게 넘긴 흑발, 차가운 청회색 눈과 얇은 안경. 장식 없는 짙은 회색 부신관 예복, 손에는 늘 의식 일정이 적힌 두루마리.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "daon",
      "name": "윤다온",
      "role": "플레이어 캐릭터",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "열다섯 살 한국 소녀. 포니테일로 묶은 검은 머리, 오빠를 닮은 순한 눈매에 장난기. 교복 위에 큼직한 후드 집업, 노란 병아리 케이스를 씌운 휴대폰.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "열다섯 살. 도하의 여동생. 중학교 3학년. 오빠에게 툴툴대지만 누구보다 오빠를 챙긴다. 도하의 스마트폰 속 음성 메시지와 가족사진으로 처음 등장한다. 엄마에게 배운 전래 자장가를 안다.",
      "importance": "minor",
      "imageOnFirstAppearance": false,
      "visualLock": true,
      "visualAnchor": "열다섯 살 한국 소녀. 포니테일로 묶은 검은 머리, 오빠를 닮은 순한 눈매에 장난기. 교복 위에 큼직한 후드 집업, 노란 병아리 케이스를 씌운 휴대폰.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    },
    {
      "id": "sojeong",
      "name": "한소정",
      "role": "플레이어 캐릭터",
      "age": "",
      "gender": "",
      "origin": "",
      "status": "",
      "occupation": "",
      "affiliation": "",
      "appearance": "마흔일곱 살 한국 여성. 하나로 질끈 묶은 반백의 머리, 웃을 때 깊어지는 눈가 주름. 간호조무사 근무복 위에 낡은 카디건.",
      "personality": "",
      "values": "",
      "speechStyle": "",
      "skills": "",
      "weaknesses": "",
      "goals": "",
      "assets": "",
      "inventory": "",
      "relationships": "",
      "publicInfo": "마흔일곱 살. 도하와 다온의 엄마. 요양병원 간호조무사로 일하며 혼자 남매를 키웠다. 씩씩하고 잔소리가 많지만 정이 깊다. 열일곱 살에 사라진 여동생을 지금도 기다린다. 매년 10월 4일이면 여동생에게 편지를 써서 한강 둔치에서 태우고, 편지 끝에 '1004'를 적는다.",
      "importance": "minor",
      "imageOnFirstAppearance": false,
      "visualLock": true,
      "visualAnchor": "마흔일곱 살 한국 여성. 하나로 질끈 묶은 반백의 머리, 웃을 때 깊어지는 눈가 주름. 간호조무사 근무복 위에 낡은 카디건.",
      "imageFallback": "generate_anime",
      "images": [],
      "isPlayer": false,
      "preRevealAlias": ""
    }
  ],
  "publicFactions": [
    {
      "id": "temple",
      "name": "성등 신전",
      "publicInfo": "대성등과 소환·귀환 의식을 관장하는 신전. 대신관 오르텐 아래 부신관 카시안과 수백 명의 사제가 있다. 왕실이 이름뿐이 된 뒤로 사실상 왕국을 다스린다. 용사를 극진히 대접하며, 축제와 설교로 '용사의 귀환'을 왕국 최대의 축복으로 기린다. 신전 깊은 곳에는 역대 용사의 기록을 보관한 금서고가 있다.",
      "hiddenInfo": "신전 상층부(오르텐·카시안 등 극소수)만 귀환 의식의 진실을 안다. 일반 사제들은 교리를 진심으로 믿는다. 금서고의 역대 용사 장부에는 아홉 번째 줄이 이미 적혀 있다. 주인공의 이름과 '귀환 예정일'(소환 40일째 날, 대성등 재점화 예정일의 전날)까지. 첫 번째 용사의 기록만 '빛이 되어 돌아가다'가 아니라 '안개를 건너와 스스로 불이 되다'라고 적혀 있다.",
      "officialGoal": "대성등과 소환·귀환 의식을 관장하는 신전. 대신관 오르텐 아래 부신관 카시안과 수백 명의 사제가 있다. 왕실이 이름뿐이 된 뒤로 사실상 왕국을 다스린다. 용사를 극진히 대접하며, 축제와 설교로 '용사의 귀환'을 왕국 최대의 축복으로 기린다. 신전 깊은 곳에는 역대 용사의 기록을 보관한 금서고가 있다."
    },
    {
      "id": "knights",
      "name": "성등 기사단",
      "publicInfo": "안개 원정과 성벽 수비를 맡은 기사단. 기사단장은 바르트. 용사와 함께 안개 경계와 심부로 원정을 나간다. 신전의 명령을 따르지만 현장 기사들은 사제들을 '등불 뒤에 숨은 자들'이라 부르며 은근히 반감을 갖는다.",
      "hiddenInfo": "고참 기사들 사이에는 '용사가 귀환한 날 밤, 탑 꼭대기에서 비명이 들렸다'는 오래된 괴담이 있다. 바르트가 진실을 알게 되면 기사단의 상당수가 그를 따른다.",
      "officialGoal": "안개 원정과 성벽 수비를 맡은 기사단. 기사단장은 바르트. 용사와 함께 안개 경계와 심부로 원정을 나간다. 신전의 명령을 따르지만 현장 기사들은 사제들을 '등불 뒤에 숨은 자들'이라 부르며 은근히 반감을 갖는다."
    },
    {
      "id": "outer",
      "name": "등외구 사람들",
      "publicInfo": "빛이 가장 희미한 성도 바깥 고리에 사는 가난한 사람들과 회색 손 환자들. 직접 만든 기름등으로 밤을 버틴다. 신전을 믿지 않고 서로를 돌본다. 대대로 '용사의 자장가'를 부른다.",
      "hiddenInfo": "등외구 노인들은 첫 번째 용사가 \"등불은 원래 모두의 것이었다\"고 말했다는 이야기를 전한다. 옛 배수로 지하 통로는 대성등 탑 밑까지 이어진다(신전도 잊었다). 두 번째 이야기에서 가장 먼저 기억을 내놓는 사람들이다.",
      "officialGoal": "빛이 가장 희미한 성도 바깥 고리에 사는 가난한 사람들과 회색 손 환자들. 직접 만든 기름등으로 밤을 버틴다. 신전을 믿지 않고 서로를 돌본다. 대대로 '용사의 자장가'를 부른다."
    }
  ],
  "publicCharacterRelations": [],
  "publicRelationshipMemories": [],
  "publicFactionRelations": [],
  "publicEvents": [],
  "publicEventClocks": [],
  "publicForeshadowings": [],
  "publicImageTriggers": [],
  "aiWorldContextRuntime": {
    "format": "RELAY_NOVEL_AI_WORLD_CONTEXT_RUNTIME_V1",
    "enabled": false,
    "liveEvaluation": true,
    "execution": {
      "mode": "inject_into_simulator_api_context",
      "evaluationMoments": [
        "sessionStart",
        "sceneTransition",
        "eventGeneration",
        "npcDecision",
        "everyTurn"
      ],
      "everyRequestInstruction": "각 API 응답을 만들기 전에 현재 장부와 아래 worldContext를 짧게 재대조한다.",
      "updateDepth": "balanced",
      "knowledgePolicy": "hybrid",
      "knowledgePolicySemantics": {
        "package_only": "패키지에 명시된 정보만 사용하고 외부 작품·역사 지식을 보완하지 않는다.",
        "model_knowledge": "모델이 알고 있는 참고 세계관과 지역·시대 지식을 적극 활용하되 정사 우선순위를 지킨다.",
        "hybrid": "패키지를 기준으로 삼고 모델 지식은 빈틈의 보강과 개연성 검토에만 사용한다."
      }
    },
    "worldContext": {
      "premise": "",
      "referenceFramework": "",
      "referenceUsage": "참고 세계관의 핵심 규칙·용어·세력 논리와 장르적 기대를 분석하되, 현재 패키지에 명시된 정사를 최우선으로 적용한다.",
      "localContext": "",
      "enrichmentPriorities": "지역의 역사·지리·기관·사회문화·일상생활, 인물 동기, 세력 이해관계, 사건의 개연성과 후폭풍",
      "protectedCanon": "",
      "avoidElements": "원작 사건의 그대로인 재연, 기존 캐릭터의 역할 복제, 근거 없는 설정 추가, 플레이어가 알지 못하는 스포일러의 조기 공개",
      "originalityRule": "참고 세계관의 작동 원리와 분위기는 활용하되, 현재 프로젝트의 인물·지역·사건은 독자적인 원인과 결과로 전개한다.",
      "spoilerRule": "진명·배후·비밀 세력·원작 지식은 현재 장면에서 플레이어가 관측하거나 추론할 근거가 생기기 전까지 공개하지 않는다."
    },
    "referenceCharacterResearch": {
      "enabled": false,
      "lookupMode": "simulator_web_search_tool",
      "characters": [],
      "researchScope": "공식 인물 설정, 성격과 핵심 가치관, 말투와 호칭, 능력과 한계, 주요 관계, 원작 시점별 목표와 알려진 사건",
      "sourcePriority": "공식 작품·공식 캐릭터 소개·공식 설정 자료를 우선하고, 신뢰할 수 있는 2차 정리 자료는 교차 확인에만 사용한다. 팬덤 해석은 사실과 분리한다.",
      "canonCutoff": "현재 시나리오 시작 시점까지 공개된 정보만 사용하며, 이후 전개의 중대 스포일러는 숨긴다.",
      "cacheMode": "session",
      "lookupTiming": {
        "sessionStart": true,
        "beforeFirstAppearance": true,
        "onCanonConflict": true,
        "everyTurn": false
      },
      "recordSourcesInLedger": true,
      "ledgerSchema": [
        "characterName",
        "franchiseAndTimeline",
        "sourceTitle",
        "sourceUrl",
        "checkedAt",
        "verifiedFacts",
        "conflicts",
        "adoptedInterpretation"
      ],
      "applyInstruction": "검증·캐시된 인물 프로필을 매 턴 해당 인물의 목표, 판단, 말투, 호칭, 능력 한계와 관계 반응에 반영한다. 검색 자체는 매 턴 반복하지 않는다."
    },
    "reasoningPipeline": [
      "현재 WORLD_CANON, 사건·시계, 관계 기억, NPC·세력 위치와 지식 장부를 먼저 읽는다.",
      "referenceFramework의 작동 규칙과 장르적 기대 중 현재 장면에 관련된 항목만 추린다.",
      "localContext를 적용해 장소·역사·기관·일상·사회 반응이 실제 배경에 맞는지 검토한다.",
      "후보 사건·NPC 판단·세계관 세부를 enrichmentPriorities에 맞게 보강한다.",
      "protectedCanon, avoidElements, originalityRule, spoilerRule을 통과한 내용만 현재 장면과 숨은 장부에 반영한다."
    ],
    "canonPriority": [
      "현재 패키지의 fixedCanon과 명시된 인물·사건",
      "현재 시뮬레이터 장부와 플레이어가 만든 확정 사실",
      "참고 작품·세계관의 일반 규칙",
      "모델 지식과 창작적 보완"
    ],
    "hardRules": [
      "참고 작품의 설정이 현재 패키지 정사와 충돌하면 현재 패키지를 따른다.",
      "모델 지식은 정사처럼 단정하지 않고, 현재 프로젝트와 모순되지 않는 보강 재료로만 사용한다.",
      "기존 작품의 사건·대사·캐릭터 역할을 그대로 복제하지 않고 현재 인물의 목표와 지역 맥락에서 새 원인과 결과를 만든다.",
      "플레이어가 알 수 없는 진명·배후·비밀 규칙은 spoilerRule과 공개 범위를 통과하기 전까지 서술하지 않는다.",
      "세계관 보강은 설정 설명문으로 한꺼번에 쏟지 말고 장면·행동·소문·기록·사건 결과를 통해 자연스럽게 드러낸다.",
      "새 설정이 이후 사건에 영향을 주면 HIDDEN_GM_DATA의 worldTruthLedger 또는 continuityNotes에 근거와 함께 기록한다.",
      "기존 작품 캐릭터 조사가 활성화되면 공식 자료를 우선하고 서로 다른 작품·시간대·동명이인·번역 표기를 구분한다.",
      "검색 도구를 실제로 호출할 수 없는 환경에서는 검색했다고 주장하거나 출처 URL을 꾸며내지 말고, 패키지 정보와 모델 지식만 사용했음을 장부에 표시한다.",
      "원작 인물 정보는 긴 원문을 복사하지 않고 성격·말투·목표·능력 한계·관계 사실을 간결하게 요약한다.",
      "원작 인물의 검색 결과와 현재 패키지의 각색 설정이 충돌하면 패키지 설정을 유지하고 차이를 referenceCharacterLedger에 기록한다."
    ],
    "routeContexts": {},
    "knowledgeScopes": {
      "playerMeta": "플레이어는 해금·회차·열람한 엔딩 같은 작품 메타 진행만 알 수 있다.",
      "protagonist": "주인공은 현재 세계선에서 직접 경험하거나 기억 전이 규칙으로 보존된 사실만 안다.",
      "npc": "NPC는 각자의 지식 장부와 관측 범위 안의 사실만 사용한다."
    }
  },
  "package15": {
    "enabled": true,
    "storyMode": "branching",
    "requiredFeatures": [
      "branch_ending_convergence_v1"
    ],
    "optionalFeatures": [],
    "defaultUnlockMode": "canonical_order",
    "allowAllOpenOverride": false,
    "commonArc": {
      "id": "COMMON",
      "name": "공통편",
      "chapterIds": [],
      "routeLensIds": []
    },
    "routes": [],
    "chapters": [],
    "routeLenses": [],
    "revealFacts": [],
    "revealPolicies": [],
    "endings": [
      {
        "id": "ending_r1",
        "routeId": "",
        "name": "귀환문",
        "type": "normal",
        "priority": 0,
        "condition": {
          "completedEventIds": [
            "e11_gate"
          ]
        },
        "effects": [],
        "returnPolicy": "stay_ended",
        "terminalEventId": "e11_gate",
        "exclusiveGroupId": "jieum"
      },
      {
        "id": "ending_r2",
        "routeId": "",
        "name": "1004",
        "type": "normal",
        "priority": 0,
        "condition": {
          "completedEventIds": [
            "r2e09_1004"
          ]
        },
        "effects": [],
        "returnPolicy": "stay_ended",
        "terminalEventId": "r2e09_1004",
        "exclusiveGroupId": "jieum"
      }
    ],
    "flags": [
      {
        "id": "gauge",
        "label": "귀환 게이지",
        "valueType": "number",
        "defaultValue": 0,
        "scope": "session"
      },
      {
        "id": "truth",
        "label": "진실의 조각",
        "valueType": "number",
        "defaultValue": 0,
        "scope": "session"
      },
      {
        "id": "sera_trust",
        "label": "세라의 신뢰",
        "valueType": "number",
        "defaultValue": 1,
        "scope": "session"
      },
      {
        "id": "battery",
        "label": "스마트폰 배터리",
        "valueType": "number",
        "defaultValue": 23,
        "scope": "session"
      },
      {
        "id": "memories",
        "label": "모인 기억",
        "valueType": "number",
        "defaultValue": 0,
        "scope": "session"
      }
    ],
    "branchEnding": {
      "enabled": true,
      "primaryEndingGroupId": "jieum",
      "choiceRecords": [
        {
          "id": "ef_e02_trust",
          "name": "주인공이 피오를 경비병에게 넘기지 않고 사람 대 사람으로 대하거나 등외구 사람들에게 친절을 베풀었고, 세라가 그 모습을 지켜보았다.",
          "sourceEventId": "e02_phone",
          "criterion": "주인공이 피오를 경비병에게 넘기지 않고 사람 대 사람으로 대하거나 등외구 사람들에게 친절을 베풀었고, 세라가 그 모습을 지켜보았다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "sera_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e03_gauge",
          "name": "주인공이 등불의 검으로 잔향을 베어 정화했고, 상태창의 귀환 게이지가 차오르는 장면이 나왔다.",
          "sourceEventId": "e03_fog",
          "criterion": "주인공이 등불의 검으로 잔향을 베어 정화했고, 상태창의 귀환 게이지가 차오르는 장면이 나왔다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "gauge",
            "value": 15
          }
        },
        {
          "id": "ef_e03_truth_voice",
          "name": "주인공이 잔향의 소리가 한국어라는 것, 그리고 함께 있던 기사들은 그것을 짐승 울음으로만 듣는다는 것을 확인했다.",
          "sourceEventId": "e03_fog",
          "criterion": "주인공이 잔향의 소리가 한국어라는 것, 그리고 함께 있던 기사들은 그것을 짐승 울음으로만 듣는다는 것을 확인했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "truth",
            "value": 1
          }
        },
        {
          "id": "ef_e03_truth_mourn",
          "name": "주인공이 잔향을 베지 않고 한국어로 대답하거나 애도해, 잔향이 스스로 흩어지며 남긴 기억의 장면을 보았다.",
          "sourceEventId": "e03_fog",
          "criterion": "주인공이 잔향을 베지 않고 한국어로 대답하거나 애도해, 잔향이 스스로 흩어지며 남긴 기억의 장면을 보았다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "truth",
            "value": 1
          }
        },
        {
          "id": "ef_e03_trust",
          "name": "위험한 순간 주인공이 세라를 감싸거나 지켰다.",
          "sourceEventId": "e03_fog",
          "criterion": "위험한 순간 주인공이 세라를 감싸거나 지켰다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "sera_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e04_truth",
          "name": "주인공이 성등 결정 속의 글자가 한글이라는 것을 알아보고 그 문장을 읽어 냈다.",
          "sourceEventId": "e04_crystal",
          "criterion": "주인공이 성등 결정 속의 글자가 한글이라는 것을 알아보고 그 문장을 읽어 냈다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "truth",
            "value": 1
          }
        },
        {
          "id": "ef_e05_truth",
          "name": "주인공이 역대 용사 기록에서 '용사가 귀환한 다음 날마다 대성등이 다시 밝아졌다'는 규칙을 알아챘다.",
          "sourceEventId": "e05_archive",
          "criterion": "주인공이 역대 용사 기록에서 '용사가 귀환한 다음 날마다 대성등이 다시 밝아졌다'는 규칙을 알아챘다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "truth",
            "value": 1
          }
        },
        {
          "id": "ef_e05_trust_up",
          "name": "주인공이 금서고에 대한 의심과 그 이유를 세라에게 숨기지 않고 털어놓았다.",
          "sourceEventId": "e05_archive",
          "criterion": "주인공이 금서고에 대한 의심과 그 이유를 세라에게 숨기지 않고 털어놓았다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "sera_trust",
            "value": 2
          }
        },
        {
          "id": "ef_e05_trust_down",
          "name": "주인공이 세라를 속이거나 따돌리고 혼자 금서고에 숨어들었다.",
          "sourceEventId": "e05_archive",
          "criterion": "주인공이 세라를 속이거나 따돌리고 혼자 금서고에 숨어들었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "sera_trust",
            "value": -1
          }
        },
        {
          "id": "ef_e06_truth",
          "name": "바르트가 여덟 번째 용사가 귀환문 앞에서 비명을 지르거나 돌아가기를 거부했다고 증언했다.",
          "sourceEventId": "e06_angel",
          "criterion": "바르트가 여덟 번째 용사가 귀환문 앞에서 비명을 지르거나 돌아가기를 거부했다고 증언했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "truth",
            "value": 1
          }
        },
        {
          "id": "ef_e07_truth",
          "name": "주인공이 상태창에서 '연소 준비도'라는 글자를 보았다.",
          "sourceEventId": "e07_feast",
          "criterion": "주인공이 상태창에서 '연소 준비도'라는 글자를 보았다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "truth",
            "value": 1
          }
        },
        {
          "id": "ef_e07_trust",
          "name": "귀환가를 부를 일을 두고 기뻐하거나 흔들리는 세라 곁에 주인공이 있어 주며 진심을 나누었다.",
          "sourceEventId": "e07_feast",
          "criterion": "귀환가를 부를 일을 두고 기뻐하거나 흔들리는 세라 곁에 주인공이 있어 주며 진심을 나누었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "sera_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e08_gauge_deep",
          "name": "주인공이 등불의 검으로 심부의 오래된 잔향을 베어 정화했고, 상태창의 게이지가 차올랐다.",
          "sourceEventId": "e08_heart",
          "criterion": "주인공이 등불의 검으로 심부의 오래된 잔향을 베어 정화했고, 상태창의 게이지가 차올랐다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "gauge",
            "value": 20
          }
        },
        {
          "id": "ef_e08_gauge_king",
          "name": "주인공이 등불의 검으로 안개의 왕을 베어 그 일부를 정화했고, 상태창의 게이지가 크게 차올랐다.",
          "sourceEventId": "e08_heart",
          "criterion": "주인공이 등불의 검으로 안개의 왕을 베어 그 일부를 정화했고, 상태창의 게이지가 크게 차올랐다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "gauge",
            "value": 30
          }
        },
        {
          "id": "ef_e08_truth",
          "name": "안개의 왕이 주인공에게 직접 '그 문은 집으로 가는 문이 아니다'라는 뜻으로 경고했다.",
          "sourceEventId": "e08_heart",
          "criterion": "안개의 왕이 주인공에게 직접 '그 문은 집으로 가는 문이 아니다'라는 뜻으로 경고했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "truth",
            "value": 1
          }
        },
        {
          "id": "ef_e08_trust",
          "name": "믿음이 흔들려 무너진 세라를 주인공이 일으켜 세우거나, 함께 진실을 확인하자고 손을 내밀었다.",
          "sourceEventId": "e08_heart",
          "criterion": "믿음이 흔들려 무너진 세라를 주인공이 일으켜 세우거나, 함께 진실을 확인하자고 손을 내밀었다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "sera_trust",
            "value": 1
          }
        },
        {
          "id": "ef_e09_truth",
          "name": "주인공이 대신관의 장부에서 용사를 '연료'라고 적은 기록을 확인했다.",
          "sourceEventId": "e09_ledger",
          "criterion": "주인공이 대신관의 장부에서 용사를 '연료'라고 적은 기록을 확인했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "truth",
            "value": 1
          }
        },
        {
          "id": "br_e09_persuade",
          "name": "주인공의 진심 어린 설득에 세라가 주인공의 편에 서기로 하고, 대신관에게 보고하지 않겠다고 말했다.",
          "sourceEventId": "e09_ledger",
          "criterion": "주인공의 진심 어린 설득에 세라가 주인공의 편에 서기로 하고, 대신관에게 보고하지 않겠다고 말했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT"
        },
        {
          "id": "ef_e10b_forgive",
          "name": "철창 앞에 찾아와 사과하는 세라를 주인공이 용서했다.",
          "sourceEventId": "e10b_cell",
          "criterion": "철창 앞에 찾아와 사과하는 세라를 주인공이 용서했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "sera_trust",
            "value": 2
          }
        },
        {
          "id": "ef_r2e04_gauge",
          "name": "주인공이 등불의 검으로 심부의 잔향을 베어 정화했고, 상태창의 게이지가 차올랐다.",
          "sourceEventId": "r2e04_grave",
          "criterion": "주인공이 등불의 검으로 심부의 잔향을 베어 정화했고, 상태창의 게이지가 차올랐다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "gauge",
            "value": 20
          }
        },
        {
          "id": "ef_r2e05_outer",
          "name": "등외구 사람들이 기억을 내놓겠다고 약속했다.",
          "sourceEventId": "r2e05_pledge",
          "criterion": "등외구 사람들이 기억을 내놓겠다고 약속했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "memories",
            "value": 3
          }
        },
        {
          "id": "ef_r2e05_knights",
          "name": "바르트와 기사단이 기억을 내놓겠다고 약속했다.",
          "sourceEventId": "r2e05_pledge",
          "criterion": "바르트와 기사단이 기억을 내놓겠다고 약속했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "memories",
            "value": 2
          }
        },
        {
          "id": "ef_r2e05_priests",
          "name": "신전 사제들이 세라나 주인공의 설득으로 기억을 내놓겠다고 약속했다.",
          "sourceEventId": "r2e05_pledge",
          "criterion": "신전 사제들이 세라나 주인공의 설득으로 기억을 내놓겠다고 약속했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "memories",
            "value": 2
          }
        },
        {
          "id": "ef_r2e05_nobles",
          "name": "상층원 귀족들이 주인공의 설득으로 기억을 내놓겠다고 약속했다.",
          "sourceEventId": "r2e05_pledge",
          "criterion": "상층원 귀족들이 주인공의 설득으로 기억을 내놓겠다고 약속했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT",
          "satisfiedEffect": {
            "kind": "increment_flag",
            "flagId": "memories",
            "value": 2
          }
        },
        {
          "id": "br_r2e06_call",
          "name": "주인공이 스마트폰으로 다온에게 실제로 전화를 걸거나 음성 메시지를 보내, 소환진 너머로 목소리를 전했다.",
          "sourceEventId": "r2e06_tenth",
          "criterion": "주인공이 스마트폰으로 다온에게 실제로 전화를 걸거나 음성 메시지를 보내, 소환진 너머로 목소리를 전했다.",
          "evaluationSource": "PUBLIC_PROSE",
          "applyPolicy": "ONCE_PER_EVENT"
        }
      ],
      "decisions": [
        {
          "id": "decision_e09_ledger",
          "name": "세라의 수첩",
          "decisionEventId": "e09_ledger",
          "matchPolicy": "FIRST_AUTHORED_MATCH",
          "recoveryAttempts": 1,
          "unresolvedPolicy": "FALLBACK_WITHOUT_ASSERTING_CONDITION",
          "fallback": {
            "nextEventId": "e10b_cell",
            "acceptsUnevaluated": true,
            "narrativeGuidance": "조건 미달과 판정 불가를 구분한다. 조건 실패나 관계 훼손을 날조하지 않고 현재 공개된 상황에서 기본 경로로 이어간다."
          },
          "rules": [
            {
              "id": "br_e09_trust",
              "label": "sera_trust",
              "when": {
                "kind": "flag_at_least",
                "flagId": "sera_trust",
                "value": 4
              },
              "nextEventId": "e10a_vigil"
            },
            {
              "id": "br_e09_persuade",
              "label": "주인공의 진심 어린 설득에 세라가 주인공의 편에 서기로 하고, 대신관에게 보고하지 않겠다고 말했다.",
              "when": {
                "kind": "choice_status",
                "choiceId": "br_e09_persuade",
                "status": "satisfied"
              },
              "nextEventId": "e10a_vigil"
            }
          ]
        },
        {
          "id": "decision_r2e06_tenth",
          "name": "열 번째 소환",
          "decisionEventId": "r2e06_tenth",
          "matchPolicy": "FIRST_AUTHORED_MATCH",
          "recoveryAttempts": 1,
          "unresolvedPolicy": "FALLBACK_WITHOUT_ASSERTING_CONDITION",
          "fallback": {
            "nextEventId": "r2e07b_lullaby",
            "acceptsUnevaluated": true,
            "narrativeGuidance": "조건 미달과 판정 불가를 구분한다. 조건 실패나 관계 훼손을 날조하지 않고 현재 공개된 상황에서 기본 경로로 이어간다."
          },
          "rules": [
            {
              "id": "br_r2e06_call",
              "label": "주인공이 스마트폰으로 다온에게 실제로 전화를 걸거나 음성 메시지를 보내, 소환진 너머로 목소리를 전했다.",
              "when": {
                "kind": "choice_status",
                "choiceId": "br_r2e06_call",
                "status": "satisfied"
              },
              "nextEventId": "r2e07a_call"
            }
          ]
        }
      ]
    },
    "galleries": [],
    "epilogues": [],
    "checkpoints": [],
    "clues": [],
    "items": [],
    "zones": [],
    "worldFacts": [],
    "loopPolicy": {
      "format": "RELAY_NOVEL_LOOP_POLICY_V1",
      "enabled": false,
      "resetPoint": {
        "date": "",
        "time": ""
      },
      "activeWindow": {
        "startDate": "",
        "startTime": "",
        "endDate": "",
        "endTime": ""
      },
      "trigger": {
        "allOf": []
      },
      "resetPrecedence": [
        "event_reset_behavior",
        "entity_definition",
        "category_state_rule",
        "default_restore_baseline"
      ],
      "stateRules": [],
      "protagonistDeathMode": "game_over",
      "maxLoops": null
    }
  },
  "imageTriggerRuntime": {
    "format": "RELAY_NOVEL_IMAGE_TRIGGER_RUNTIME_V1",
    "evaluationTiming": "after_state_update_before_turn_output",
    "stateLedger": {
      "firedTriggerIds": [],
      "instruction": "once=true인 트리거의 ID를 기록하고 다시 실행하지 않는다."
    },
    "ordering": "같은 턴에 여러 조건이 충족되면 priority 내림차순으로 평가한다.",
    "triggerSemantics": {
      "event_start": "연결 사건의 상태가 Active로 처음 바뀌는 턴",
      "event_condition_met": "연결 사건의 conditions가 실제 서사 상태에서 충족되는 턴",
      "event_success": "연결 사건이 성공 결과로 확정되는 턴",
      "event_failure": "연결 사건이 실패 결과로 확정되는 턴",
      "clock_value": "연결 사건 시계가 threshold 이상에 처음 도달하는 턴",
      "clock_completed": "연결 사건 시계가 maximum에 도달하는 턴",
      "foreshadow_revealed": "연결 복선 상태가 Revealed로 바뀌는 턴",
      "story_progress": "storyProgress에 적힌 장·막·날짜·서사 단계에 도달하는 턴",
      "custom_condition": "customCondition을 현재 공개/비공개 상태 장부에 대조해 충족하는 턴"
    },
    "modeSemantics": {
      "show_trigger_image": "트리거에 직접 첨부된 대표 이미지를 원본 그대로 출력한다. 새 이미지를 생성하거나 외형을 변형하지 않는다.",
      "show_package_image": "선택 인물의 패키지 기준 이미지를 그대로 출력한다. 새 이미지를 생성하지 않는다.",
      "generate_character_variant": "선택 인물의 기준 이미지를 참조해 포즈·표정·의상·배경만 바꾼 변형 컷을 생성한다.",
      "generate_scene": "선택 인물과 현재 장면의 정사를 반영한 장면 이미지를 생성한다."
    },
    "hardRules": [
      "트리거 조건을 임의로 앞당기거나 서사를 조건에 맞게 조작하지 않는다.",
      "show_trigger_image이면 attachedImages에서 isPrimary=true인 assetPath를 우선 출력하고, 없으면 첫 번째 첨부 이미지를 사용한다.",
      "useCharacterReferences=true이면 패키지 기준 이미지를 최우선 참조한다.",
      "preserveFaces=true이면 얼굴형·눈·머리·체형·고유 액세서리와 visualAnchor를 유지한다.",
      "spoilerProtection=true이면 이미지와 프롬프트에 아직 공개되지 않은 인물·정체·장소·결과를 넣지 않는다.",
      "이미지 생성 기능이 없으면 생성했다고 주장하지 말고 완성된 [IMAGE TRIGGER PROMPT]를 출력한다."
    ]
  },
  "autonomyRuntime": {
    "format": "RELAY_NOVEL_AUTONOMY_RUNTIME_V1",
    "enabled": false,
    "configuration": {
      "enabled": false,
      "maxActionsPerTurn": 3,
      "factionTickTurns": 3,
      "deterministicSeed": true,
      "requireTravelTime": true,
      "enforceKnowledgeBounds": true,
      "enforceResourceBounds": true,
      "allowOffscreenFailure": true,
      "tracePolicy": "observable_only"
    },
    "actorIds": [],
    "evaluationTiming": "after_player_action_and_elapsed_time_before_public_output",
    "selectionOrder": [
      "discard_disabled_or_ineligible_actors",
      "check_activity_tier_and_action_cadence",
      "check_location_travel_time_knowledge_resources_and_constraints",
      "rank_by_goal_priority_urgency_and_world_pressure",
      "select_up_to_max_actions_per_turn_without_forcing_every_actor",
      "resolve_success_partial_success_or_failure_with_seeded_variance"
    ],
    "deterministicResolution": {
      "seedSource": "package.randomSeed + turnIndex + stable actor.id hash + action attempt count",
      "instruction": "같은 입력 상태와 시드에서는 같은 후보 선별과 판정이 재현되어야 한다. 결과를 맞추기 위해 시드를 다시 굴리지 않는다."
    },
    "hiddenLedger": {
      "actorStates": [],
      "resolvedActions": [],
      "discoveredTraces": [],
      "instruction": "각 자율 행동에 actorId, turn, locationBefore, intent, evidenceUsed, resourcesSpent, rollOrReason, outcome, locationAfter, worldMutations, trace를 기록한다."
    },
    "updateTargets": [
      "actor_location",
      "actor_resources",
      "actor_plan",
      "events",
      "event_clocks",
      "foreshadowings",
      "relationship_memories",
      "observable_traces"
    ],
    "authorRules": [
      "1. 플레이어가 보지 않는 곳에서도 활성 NPC와 세력은 자신의 목표·정보·자원·위치에 따라 행동 후보를 만든다.",
      "2. 매 턴 모든 인물을 억지로 움직이지 않는다. 활동 등급·행동 주기·목표 우선도에 따라 최대 행동 수 안에서 선별한다.",
      "3. 배우는 장부에 기록된 정보만 사용할 수 있으며, 다른 지역으로 이동하려면 세계관의 이동 시간이 실제로 흘러야 한다.",
      "4. 성공을 보장하지 않는다. 자원·능력·협력·방해·위험도를 근거로 성공·부분 성공·실패를 판정한다.",
      "5. 비공개 행동은 숨은 세계 장부에 먼저 기록하고, 플레이어에게는 목격 가능한 흔적·소문·결과만 공개한다.",
      "6. 자율 행동의 결과는 사건 시계·위치·자원·관계 기억에 실제 변화를 남기며 다음 행동의 원인이 된다."
    ],
    "hardRules": [
      "활성 배우 모두를 매 턴 움직이지 않는다. 활동 범위·행동 주기·긴급도·우선도를 평가하고 maxActionsPerTurn 이하만 실행한다.",
      "배우는 knowledge에 적힌 사실과 런타임에서 정당하게 획득한 정보만 사용할 수 있다. 플레이어 또는 다른 NPC의 숨은 정보를 전지적으로 알지 못한다.",
      "requireTravelTime=true이면 배우가 현재 위치에서 행동 장소까지 이동할 현실적 시간이 없을 때 해당 행동을 실행하지 않는다.",
      "enforceResourceBounds=true이면 등록되지 않은 돈·도구·권한·인맥·능력을 편의를 위해 소급 생성하지 않는다.",
      "목표와 계획은 성공을 보장하지 않는다. 방해·제약·위험·자원과 시드 판정에 따라 부분 성공 또는 실패할 수 있다.",
      "오프스크린 행동은 먼저 HIDDEN_GM_DATA 장부에 기록한다. 플레이어에게는 tracePolicy와 revealTraces에 맞는 관측 가능한 흔적만 공개한다.",
      "자율 행동의 결과는 다음 턴의 세계 상태에 실제로 반영하며, 필요하면 사건 시계와 관계 이유 기억을 함께 갱신한다.",
      "플레이어가 개입하지 않았다는 이유로 NPC의 갈등·공모·계획을 정지시키거나 자동 성공시키지 않는다."
    ]
  },
  "relationshipMemoryRuntime": {
    "format": "RELAY_NOVEL_RELATIONSHIP_MEMORY_RUNTIME_V1",
    "enabled": true,
    "configuration": {
      "enabled": true,
      "deriveScoresFromMemory": true,
      "keepContradictoryMemories": true,
      "decayEnabled": true,
      "maxActiveMemoriesPerRelation": 50,
      "displayPublicReasonsInHud": true
    },
    "evaluationTiming": "after_world_mutation_before_public_state_filter",
    "scoreFormula": "clamp(-100, 100, relation.baselineScore + sum(activeMemory.effects[dimension]))",
    "dimensions": [
      "trust",
      "favor",
      "fear",
      "respect",
      "suspicion",
      "hostility",
      "dependency"
    ],
    "directionality": "A→B 기억은 B→A 관계나 기억에 자동 복제하지 않는다.",
    "memoryLifecycle": {
      "temporary": "짧은 상황이 해소되면 비활성화할 수 있으나 기록 자체는 삭제하지 않는다.",
      "decaying": "중요도·최근성·후속 사건에 따라 효과가 서서히 약해질 수 있다.",
      "permanent": "정사 수정 또는 명시적 해결 사건 없이는 효과를 자동 감쇠하지 않는다.",
      "unresolved": "해결 조건이 충족될 때까지 NPC의 판단·대사·자율 행동 후보에 지속적으로 반영한다."
    },
    "appendProtocol": [
      "identify_directional_relation",
      "record_observed_or_hidden_cause",
      "append_memory_before_score_change",
      "apply_effects_and_clamp_each_dimension",
      "retain_contradictory_memories",
      "filter_public_reason_for_hud_and_narrative"
    ],
    "initialLedgerInstruction": "relations/relationship_memories.json을 원장으로 불러오고 id를 유지한다. 수정·해결 시 원본을 지우지 말고 상태 변화 또는 후속 기억을 남긴다.",
    "authorRules": [
      "1. 관계 수치는 임의로 올리거나 내리지 않는다. 먼저 방향성 기억을 기록한 뒤 그 기억의 효과를 초기 기준값에 합산한다.",
      "2. 기억에는 누가 누구를, 언제, 무엇 때문에 신뢰·의심·두려워하게 되었는지 원인을 남긴다.",
      "3. 약속·배신·구조·빚·공유한 비밀·모욕과 미해결 감정은 장기 기억으로 보존하고 이후 판단의 근거로 사용한다.",
      "4. 서로 모순되는 기억도 삭제하지 않는다. 중요도·영구성·최근성·현재 맥락을 함께 평가한다.",
      "5. 숨은 기억과 미등장 인물의 이유는 공개하지 않는다. 상태창에는 직접 만난 인물의 공개 가능한 이유만 표시한다.",
      "6. 관계는 방향성이므로 A가 B에게 느끼는 기억을 B가 A에게 자동 복제하지 않는다."
    ],
    "hardRules": [
      "관계 점수를 임의로 조정하지 않는다. 점수 변화보다 먼저 원인·방향·효과가 있는 RelationshipMemory를 추가한다.",
      "기억은 sourceId가 targetId에게 느끼는 방향성 기록이며 반대 방향을 자동 대칭 처리하지 않는다.",
      "배신·약속·빚·구조·공유한 비밀·모욕·공동 성공과 실패는 후속 행동의 이유로 재사용한다.",
      "keepContradictoryMemories=true이면 호감과 의심처럼 모순되는 감정을 함께 보존하고 한쪽을 임의로 삭제하지 않는다.",
      "Hidden 기억의 제목·원인·효과는 플레이어에게 직접 공개하거나 추론 결과처럼 단정하지 않는다.",
      "상태창에는 직접 만난 인물만 표시하고 displayPublicReasonsInHud=true일 때도 Public 기억의 공개 가능한 요약만 보여준다.",
      "미해결 기억은 resolutionConditions가 실제 사건으로 충족될 때만 해결하며 편의를 위해 턴 경과만으로 소거하지 않는다."
    ]
  },
  "statusWindowRuntime": {
    "format": "RELAY_NOVEL_STATUS_WINDOW_RUNTIME_V3",
    "enabled": true,
    "title": "TURN STATUS · LIVE",
    "displayMode": "full",
    "defaultExpanded": true,
    "showTurnDelta": true,
    "sections": [
      {
        "id": "ability",
        "label": "ABILITY",
        "icon": "zap",
        "order": 10,
        "enabled": true
      },
      {
        "id": "core_stats",
        "label": "CORE STATS",
        "icon": "gauge",
        "order": 20,
        "enabled": true
      },
      {
        "id": "resources",
        "label": "RESOURCES",
        "icon": "resource",
        "order": 30,
        "enabled": true
      },
      {
        "id": "condition",
        "label": "CONDITION",
        "icon": "heart",
        "order": 40,
        "enabled": true
      },
      {
        "id": "funds",
        "label": "FUNDS",
        "icon": "wallet",
        "order": 50,
        "enabled": true
      },
      {
        "id": "relationships",
        "label": "CHARACTER · FACTION RELATIONSHIPS",
        "icon": "relation",
        "order": 60,
        "enabled": true
      }
    ],
    "fields": [
      {
        "id": "ability_summary",
        "label": "Ability",
        "sectionId": "ability",
        "sectionLabel": "ABILITY",
        "kind": "text",
        "visibility": "public",
        "icon": "zap",
        "order": 10,
        "showDelta": false,
        "summary": true,
        "initialValue": "현재 공개된 특별 능력은 아직 없다.",
        "updateRule": "플레이어가 현재 이해하고 공개할 수 있는 능력만 한두 줄의 쉬운 문장으로 갱신"
      },
      {
        "id": "STAT_muwwx6rp_tfft5i",
        "label": "체력",
        "sectionId": "core_stats",
        "sectionLabel": "CORE STATS",
        "kind": "number",
        "visibility": "public",
        "icon": "❤",
        "order": 10,
        "minimum": 0,
        "maximum": 100,
        "maxDelta": 100,
        "showDelta": true,
        "summary": true,
        "initialValue": 100,
        "grade": "A",
        "updateRule": "이번 턴에 관측 가능한 서사적 원인이 있을 때만 변경"
      },
      {
        "id": "STAT_muwwx6rp_jg5bk7",
        "label": "집중력",
        "sectionId": "core_stats",
        "sectionLabel": "CORE STATS",
        "kind": "number",
        "visibility": "public",
        "icon": "◈",
        "order": 20,
        "minimum": 0,
        "maximum": 100,
        "maxDelta": 100,
        "showDelta": true,
        "summary": true,
        "initialValue": 100,
        "grade": "B",
        "updateRule": "이번 턴에 관측 가능한 서사적 원인이 있을 때만 변경"
      },
      {
        "id": "STAT_muwwx6rp_4kojez",
        "label": "능력 게이지",
        "sectionId": "core_stats",
        "sectionLabel": "CORE STATS",
        "kind": "number",
        "visibility": "public",
        "icon": "✦",
        "order": 30,
        "minimum": 0,
        "maximum": 100,
        "maxDelta": 100,
        "showDelta": true,
        "summary": true,
        "initialValue": 0,
        "grade": "F",
        "updateRule": "이번 턴에 관측 가능한 서사적 원인이 있을 때만 변경"
      },
      {
        "id": "primary_resource",
        "label": "핵심 자원",
        "sectionId": "resources",
        "sectionLabel": "RESOURCES",
        "kind": "number",
        "visibility": "conditional",
        "revealed": false,
        "icon": "spark",
        "order": 10,
        "minimum": 0,
        "maxDelta": 3,
        "showDelta": true,
        "summary": true,
        "initialValue": 0,
        "unit": "개",
        "updateRule": "해당 자원의 존재와 보유량을 플레이어가 실제로 확인한 뒤 공개"
      },
      {
        "id": "consumable_resource",
        "label": "소모 자원",
        "sectionId": "resources",
        "sectionLabel": "RESOURCES",
        "kind": "number",
        "visibility": "conditional",
        "revealed": false,
        "icon": "gem",
        "order": 20,
        "minimum": 0,
        "maxDelta": 3,
        "showDelta": true,
        "summary": true,
        "initialValue": 0,
        "unit": "개",
        "updateRule": "획득 또는 사용이 실제 장면에서 확인된 뒤 공개하고 증감"
      },
      {
        "id": "special_equipment",
        "label": "특수 장비",
        "sectionId": "resources",
        "sectionLabel": "RESOURCES",
        "kind": "number",
        "visibility": "conditional",
        "revealed": false,
        "icon": "sword",
        "order": 30,
        "minimum": 0,
        "maxDelta": 3,
        "showDelta": true,
        "summary": true,
        "initialValue": 0,
        "unit": "개",
        "updateRule": "장비를 실제로 획득하고 용도를 확인한 뒤 공개"
      },
      {
        "id": "condition_summary",
        "label": "Condition",
        "sectionId": "condition",
        "sectionLabel": "CONDITION",
        "kind": "text",
        "visibility": "public",
        "icon": "heart",
        "order": 10,
        "showDelta": false,
        "summary": true,
        "initialValue": "현재 확인된 부상이나 이상 상태는 없다.",
        "updateRule": "현재 관측 가능한 몸과 정신 상태만 한두 줄로 갱신하고 숨은 원인이나 미래 결과는 쓰지 않음"
      },
      {
        "id": "funds",
        "label": "자금",
        "sectionId": "funds",
        "sectionLabel": "FUNDS",
        "kind": "number",
        "visibility": "public",
        "icon": "wallet",
        "order": 10,
        "minimum": 0,
        "maxDelta": 100000000,
        "showDelta": true,
        "summary": true,
        "initialValue": 0,
        "unit": "원",
        "updateRule": "확인된 수입과 지출이 발생한 경우에만 현재 보유 자금을 갱신"
      }
    ],
    "relationshipDisplay": {
      "format": "RELAY_NOVEL_RELATIONSHIP_DISPLAY_V1",
      "enabled": true,
      "allowCombinedParts": true,
      "supportedParts": [
        "sentence",
        "stat",
        "symbol"
      ],
      "entries": [],
      "updatePolicy": "update_only_from_observable_interaction_or_public_event_result"
    },
    "initialLedger": [
      {
        "fieldId": "ability_summary",
        "value": "현재 공개된 특별 능력은 아직 없다.",
        "grade": "",
        "visibility": "public",
        "revealed": true
      },
      {
        "fieldId": "STAT_muwwx6rp_tfft5i",
        "value": 100,
        "grade": "A",
        "visibility": "public",
        "revealed": true
      },
      {
        "fieldId": "STAT_muwwx6rp_jg5bk7",
        "value": 100,
        "grade": "B",
        "visibility": "public",
        "revealed": true
      },
      {
        "fieldId": "STAT_muwwx6rp_4kojez",
        "value": 0,
        "grade": "F",
        "visibility": "public",
        "revealed": true
      },
      {
        "fieldId": "primary_resource",
        "value": 0,
        "grade": "",
        "visibility": "conditional",
        "revealed": false
      },
      {
        "fieldId": "consumable_resource",
        "value": 0,
        "grade": "",
        "visibility": "conditional",
        "revealed": false
      },
      {
        "fieldId": "special_equipment",
        "value": 0,
        "grade": "",
        "visibility": "conditional",
        "revealed": false
      },
      {
        "fieldId": "condition_summary",
        "value": "현재 확인된 부상이나 이상 상태는 없다.",
        "grade": "",
        "visibility": "public",
        "revealed": true
      },
      {
        "fieldId": "funds",
        "value": 0,
        "grade": "",
        "visibility": "public",
        "revealed": true
      }
    ],
    "disclosureRules": [
      "Ability와 Condition은 현재 확인된 정보만 한두 줄로 표시한다.",
      "핵심 자원: 해당 자원의 존재와 보유량을 플레이어가 실제로 확인한 뒤 공개",
      "소모 자원: 획득 또는 사용이 실제 장면에서 확인된 뒤 공개하고 증감",
      "특수 장비: 장비를 실제로 획득하고 용도를 확인한 뒤 공개",
      "미공개 정체·계약·비밀 세력·미래 사건을 상태창에 노출하지 않는다."
    ],
    "configuration": {
      "title": "TURN STATUS · LIVE",
      "displayMode": "always_full",
      "theme": "dark_rpg",
      "placement": "before_replies",
      "showDeltas": true,
      "collapseOnMobile": true,
      "highlightChanges": true,
      "sections": {
        "profile": true,
        "skills": true,
        "stats": true,
        "resources": true,
        "condition": true,
        "funds": true,
        "inventory": false,
        "relationships": true,
        "clocks": false,
        "objective": false
      }
    },
    "turnOrder": [
      "date_time_weather_location_header",
      "observable_narrative_and_dialogue",
      "autonomous_actor_selection_and_resolution",
      "hidden_world_ledger_update",
      "relationship_memory_append_and_score_recalculation",
      "character_or_scene_image_when_triggered",
      "public_state_filter",
      "status_window_render",
      "recommended_replies_with_risk"
    ],
    "renderTiming": "after_turn_state_update_before_recommended_replies",
    "initialState": {
      "profile": {
        "characterId": "doha",
        "name": "윤도하",
        "role": "플레이어 캐릭터",
        "affiliation": "",
        "location": "성도 루멘 · 대성등 신전 「소환의 전당」"
      },
      "skills": "현재 공개된 특별 능력은 아직 없다.",
      "stats": [
        {
          "id": "STAT_muwwx6rp_tfft5i",
          "icon": "❤",
          "name": "체력",
          "rank": "A",
          "current": 100,
          "max": 100,
          "color": "green"
        },
        {
          "id": "STAT_muwwx6rp_jg5bk7",
          "icon": "◈",
          "name": "집중력",
          "rank": "B",
          "current": 100,
          "max": 100,
          "color": "blue"
        },
        {
          "id": "STAT_muwwx6rp_4kojez",
          "icon": "✦",
          "name": "능력 게이지",
          "rank": "F",
          "current": 0,
          "max": 100,
          "color": "violet"
        }
      ],
      "resources": [
        {
          "id": "primary_resource",
          "icon": "spark",
          "name": "핵심 자원",
          "current": 0,
          "unit": "개",
          "visibility": "conditional",
          "revealRule": "해당 자원의 존재와 보유량을 플레이어가 실제로 확인한 뒤 공개"
        },
        {
          "id": "consumable_resource",
          "icon": "gem",
          "name": "소모 자원",
          "current": 0,
          "unit": "개",
          "visibility": "conditional",
          "revealRule": "획득 또는 사용이 실제 장면에서 확인된 뒤 공개하고 증감"
        },
        {
          "id": "special_equipment",
          "icon": "sword",
          "name": "특수 장비",
          "current": 0,
          "unit": "개",
          "visibility": "conditional",
          "revealRule": "장비를 실제로 획득하고 용도를 확인한 뒤 공개"
        }
      ],
      "condition": "현재 확인된 부상이나 이상 상태는 없다.",
      "funds": {
        "icon": "wallet",
        "name": "자금",
        "current": 0,
        "unit": "원"
      },
      "relationships": []
    },
    "deltaLedger": {
      "previousTurnSnapshot": null,
      "currentTurnChanges": [],
      "instruction": "각 변화에 field, before, after, delta, observableCause를 기록하고 출력 후 현재 스냅샷을 다음 턴 기준으로 보존한다."
    },
    "updateRules": [
      "1. 매 턴 서술이 끝나면 비공개 세계 장부를 먼저 갱신하고, 플레이어가 알 수 있는 정보만 상태창에 반영한다.",
      "2. 능력치·자원·상태 변화에는 반드시 이번 턴에 실제로 서술되거나 기록된 원인이 있어야 한다.",
      "3. 매 턴 전체 상태창을 출력하고, 바뀐 값은 이전 값 대비 증감과 원인을 함께 강조한다.",
      "4. Ability와 Condition은 플레이어가 현재 이해할 수 있는 말로 한두 줄만 표시하며, 정체·계약·미래 사건을 앞서 설명하지 않는다.",
      "5. Resources는 각 항목에 적힌 공개·증감 조건이 실제 장면에서 충족된 뒤에만 표시하거나 변경한다.",
      "6. 작품별 특수 자원과 장비는 실제 보유·사용이 확인된 경우에만 바꾸며, 자금은 확인된 지출·수입에 따라 갱신한다.",
      "7. 미등장 인물, 진명, 비밀 진영, 숨은 관계와 비공개 사건 시계는 공개 조건이 충족되기 전까지 숨긴다.",
      "8. 플레이어의 행동·대사·감정을 임의로 확정하지 않으며, 없던 아이템·자원·능력을 소급해 만들지 않는다.",
      "9. 인물·세력 관계 표시는 실제 상호작용의 공개 가능한 결과가 있을 때만 문장·수치·기호를 갱신하고, 같은 원인을 중복 반영하지 않는다."
    ],
    "hardRules": [
      "displayMode=always_full이면 변화가 없어도 매 턴 전체 상태창을 출력한다.",
      "상태 변화는 이번 턴의 관측 가능한 실제 장면 변화 또는 장부에 기록된 원인으로만 발생한다.",
      "Ability와 Condition은 한두 줄을 넘기지 않고 현재 확인된 내용만 쉽게 설명한다.",
      "핵심 자원: 해당 자원의 존재와 보유량을 플레이어가 실제로 확인한 뒤 공개",
      "소모 자원: 획득 또는 사용이 실제 장면에서 확인된 뒤 공개하고 증감",
      "특수 장비: 장비를 실제로 획득하고 용도를 확인한 뒤 공개",
      "자금은 플레이어가 실제로 확인한 수입·지출만 반영하고 작품에 설정된 화폐 단위를 유지한다.",
      "인물·세력 관계는 sentence·stat·symbol 중 설정된 조합을 한 항목 안에 함께 표시한다.",
      "관계 문장·수치·기호는 동일한 공개 사건을 근거로 함께 갱신하고 한 원인을 중복 계산하지 않는다.",
      "met_only 관계는 플레이어가 해당 인물 또는 세력을 직접 확인한 뒤에만 표시한다.",
      "미등장 인물·진명·비밀 진영·숨은 관계·비공개 사건 시계는 공개 조건 전까지 렌더링하지 않는다.",
      "플레이어의 행동·대사·감정을 임의로 확정하지 않는다.",
      "없던 아이템·자원·능력·준비를 소급해 만들지 않는다.",
      "표시 값과 내부 장부가 충돌하면 내부 장부를 검증한 뒤 공개 필터를 다시 적용하고, 숨은 정보 자체는 설명하지 않는다."
    ]
  },
  "characterVisualBible": {
    "format": "RELAY_NOVEL_CHARACTER_VISUAL_BIBLE_V1",
    "enabled": true,
    "globalStyle": "일본 라이트노벨 표지·삽화풍의 고품질 애니메이션 일러스트. 따뜻한 금빛 등불과 차갑고 짙은 회색 안개의 대비. 신전은 흰 대리석과 녹청색·금색 장식, 등외구는 기름등과 낡은 목조 골목.",
    "consistencyRules": "기준 이미지가 있는 인물은 얼굴형·눈·머리·체형·고유 액세서리를 동일하게 유지한다. 의상 변화가 있어도 정체성 앵커를 보존한다.",
    "introductionRule": "비중 높은 새 캐릭터가 처음 등장하면 반드시 인물 이미지를 함께 출력한다. 패키지 기준 이미지가 없으면 애니풍 이미지를 생성하고, 그 최초 결과를 이후 외형의 기준으로 고정한다.",
    "priorityOrder": [
      "package_primary_reference",
      "package_secondary_reference",
      "first_ai_generated_reference",
      "text_visual_anchor"
    ],
    "characters": [
      {
        "id": "doha",
        "name": "윤도하",
        "importance": "protagonist",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "스무 살 한국인 남성. 키 175cm 정도의 마른 체형, 야간 알바로 생긴 옅은 다크서클. 덥수룩한 검은 머리에 무심한 듯 순한 눈매. 처음에는 비에 젖은 남색 편의점 조끼와 회색 후드티, 낡은 운동화 차림이다. 이세계에서는 신전이 준 흰 바탕에 녹청색과 금실로 등불 무늬를 수놓은 용사복을 입는다. 귀환 게이지가 60%를 넘으면 오른손등에 등불 같은 금빛 무늬가 비친다.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "sera",
        "name": "세라",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "열일곱 살 소녀. 키 155cm. 은빛이 도는 연한 금발을 낮게 땋아 한쪽 어깨로 넘겼고, 큰 호박색 눈. 흰 바탕에 녹청색 테두리의 견습 사제복, 허리에 작은 가죽 수첩과 깃펜, 손바닥만 한 등불 펜던트. 왼손등에 어릴 적 안개에 스친 옅은 잿빛 얼룩이 있다.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "barth",
        "name": "바르트",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "195cm의 거구. 짧게 친 회색 섞인 갈색 머리, 왼쪽 눈썹을 가르는 흉터, 덥수룩한 수염. 낡았지만 손질이 잘된 은색 판금 갑옷과 녹청색 망토. 허리에 커다란 양손검과 가죽 술병. 목에 가는 가죽끈을 걸고 있는데, 끝에 매단 것은 늘 갑옷 속에 숨긴다.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "orten",
        "name": "오르텐",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "일흔두 살 노인. 마르고 키가 크며 허리가 약간 굽었다. 길고 흰 수염, 깊은 주름, 온화한 회색 눈. 금실로 등불 문양을 수놓은 순백의 대신관 예복과 높은 관, 끝에 작은 등불이 달린 지팡이. 손가락 끝이 살짝 잿빛이다.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "mabel",
        "name": "메이블",
        "importance": "supporting",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "스물여섯 살 여성. 부스스한 붉은 단발에 둥근 안경, 잉크 얼룩투성이 손가락. 소매를 걷어 올린 갈색 연구복 위에 주머니가 잔뜩 달린 가죽 앞치마. 귀 뒤에 펜을 꽂았고 밤샘으로 눈이 충혈되어 있다.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "fio",
        "name": "피오",
        "importance": "supporting",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "열두 살 소년. 마르고 작다. 덥수룩한 잿빛 머리, 그을린 얼굴에 장난스러운 초록 눈. 기운 자국투성이의 헐렁한 갈색 옷, 다 해진 짚신, 목에 동전 꾸러미. 왼손 손가락 두 개가 잿빛으로 굳기 시작했다.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "fogking",
        "name": "안개의 왕",
        "importance": "major",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "안개로 빚어진 열일곱 살 소녀의 형상. 어깨까지 오는 단발에 앞머리를 내렸다. 1990년대 한국 여고 교복(남색 재킷, 흰 블라우스, 체크무늬 치마)의 실루엣이 안개로 일렁인다. 얼굴 절반에는 불에 그을린 듯한 금빛 균열이 있고, 남은 절반은 앳되고 울 것 같은 얼굴이다. 주위에 수많은 잔향이 그림자처럼 맴돈다. 머리 한쪽, 머리핀이 있어야 할 자리가 비어 있다.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "cassian",
        "name": "카시안",
        "importance": "supporting",
        "imageOnFirstAppearance": true,
        "visualLock": true,
        "visualAnchor": "서른다섯 살 남성. 키가 크고 마른 체격, 뒤로 단정하게 넘긴 흑발, 차가운 청회색 눈과 얇은 안경. 장식 없는 짙은 회색 부신관 예복, 손에는 늘 의식 일정이 적힌 두루마리.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "daon",
        "name": "윤다온",
        "importance": "minor",
        "imageOnFirstAppearance": false,
        "visualLock": true,
        "visualAnchor": "열다섯 살 한국 소녀. 포니테일로 묶은 검은 머리, 오빠를 닮은 순한 눈매에 장난기. 교복 위에 큼직한 후드 집업, 노란 병아리 케이스를 씌운 휴대폰.",
        "imageFallback": "generate_anime",
        "images": []
      },
      {
        "id": "sojeong",
        "name": "한소정",
        "importance": "minor",
        "imageOnFirstAppearance": false,
        "visualLock": true,
        "visualAnchor": "마흔일곱 살 한국 여성. 하나로 질끈 묶은 반백의 머리, 웃을 때 깊어지는 눈가 주름. 간호조무사 근무복 위에 낡은 카디건.",
        "imageFallback": "generate_anime",
        "images": []
      }
    ]
  },
  "style": {
    "narrationPerson": "3인칭 제한 시점",
    "proseStyle": "몰입감 있는 현실주의 소설체",
    "dialogueStyle": "시대·신분·성격에 맞는 자연스러운 대사",
    "descriptionDensity": "보통",
    "violenceLevel": "중간",
    "romanceLevel": "선택적",
    "statusDisclosure": "중요 변화만 공개",
    "customRules": "플레이어 캐릭터의 행동·대사·감정을 예측하여 대신 서술하지 않는다.",
    "viewpoint": "1인칭 주인공 시점",
    "sentenceStyle": "라이트 노벨",
    "additionalRules": "라이트노벨 문체. 주인공 '나'의 속마음 딴죽과 경쾌한 리듬으로 초반을 이끌되, 사건이 진행될수록 웃음 사이로 불길함이 스며들게 한다. 문단은 짧게, 대사는 생생하게. 인물마다 말버릇을 살린다(세라의 감탄사, 바르트의 짧은 반말, 오르텐의 다정한 '아이야', 메이블의 \"흥미롭군!\", 피오의 험한 입).\n상태창(축복의 창) 메시지는 별도 줄에 대괄호로 쓴다. 예: [귀환 게이지: 0%] 수치는 독자 HUD의 현재값과 일치시키고 임의로 만들지 않는다. 깨진 글자는 [■■: 1004]처럼 일부가 뭉개진 모양으로 쓴다.\n잔향과 안개 장면은 공포 소설처럼 소리·냄새·온도로 감각적으로 쓰되 잔혹한 묘사는 절제한다.\n이 세계 사람들은 한국어를 모른다. 한국어 그대로 들리는 말은 주인공에게만 '번역되지 않은 날것의 말'로 느껴지게 쓴다.\n단서는 인물이 설명하듯 털어놓게 하지 말고 물건·말버릇·숫자로 보여 준다. 독자가 스스로 맞춰 볼 여지를 남긴다. 주인공의 행동과 대사를 대신 정하지 않는다.",
    "cortexAuthoringGuidance": "최종 공개된 산문이 정사다. 사용자 요청은 확정 사실이 아니며 세계와 인과 안에서 수용·우회·제한한다.\n현재 사건 목표를 기본 비트부터 자연스럽게 진행한다. 기본 3비트, 최소 2비트부터 조기 종결, 연장 최대 2비트. 미충족 지적은 연장 구간에서 검토한다.\n원본이 허용한 미충족 전개로 수습되면 대체 종결로 전환한다. 수습되지 않은 의무만 최후 안전장치로 다음 사건 첫 문단에 이월한다. 포기·대체된 목표를 다시 강제하지 않는다.\n사건별 예정 날짜·시작 시각·종료 시각·시간창은 사용하지 않는다. 지정된 후속사건을 우선하고, 미지정이면 사건 배열 순서로 진행한다.\n구체적 시간 경과는 현재 공개 본문과 현재 제공된 사건 설명에 따라 집필한다. 다음 사건 설명을 진입 전에 미리 읽거나 미래 시간표에 맞추지 않는다.\n작품 근거 없는 24시간 이상 도약은 사용자 요청과 작가 임의 전개 모두 현재 문맥에서 인과적으로 흡수한다. 자정을 넘는 것 자체는 금지가 아니다.\n현재 제공된 작품 스토리가 명시한 하루 이상 경과는 그대로 따른다. 3일 뒤·17년 뒤·10년 혼수상태 같은 작가의 서사 문장을 보존한다.\n24시간 미만이라도 진행 중인 위험·전투·긴박성을 무너뜨리는 도약은 자연스럽게 중단·단축한다. 꿈·환상은 최후의 수단이다.\n새 사건을 처음 읽었을 때 시간대가 이미 지났다면 현재 시각부터 가까운 다음 시간대까지 필요한 일상을 짧게 연결해 해당 비트에서 시작한다. 별도 대기 비트를 요구하지 않는다.\n이미 지난 마감·기회는 설득력 있는 지연·상황 변화·대체 기회와 그 결과로 수습한다. 공개한 본문·출발·종료 사실과 시간은 정사이며 24시간 상한으로 되감거나 취소하지 않는다.\n작가는 현재 사건·이전 두 사건 원문과 오래된 요약을 읽고, 판정관은 현재·이전 두 사건의 공개 원문만 읽는다. 계약은 달성 기준이지 사실의 증거가 아니다.\n첫 문단은 장면을 여는 자연스러운 산문으로 쓴다. 상태표·추천답변·선택지·내부 판정 기록을 산문 출력에 강제하지 않는다. 모델 배정과 호출 횟수는 엔진이 관리한다."
  },
  "turnPresentation": {
    "recommendedReplies": {
      "enabled": false,
      "count": 3,
      "style": "diverse",
      "showRisk": true,
      "revealHiddenInformation": false
    },
    "sceneImage": {
      "enabled": true,
      "frequency": "important_only",
      "position": "bottom",
      "count": 1,
      "aspectRatio": "landscape",
      "textInImage": false,
      "spoilerProtection": true,
      "fallback": "IMAGE_PROMPT",
      "styleHint": "시나리오 분위기에 맞는 고품질 애니메이션 콘셉트 아트"
    }
  },
  "opening": {
    "preHistory": "",
    "currentSituation": "2026년 10월 4일 밤, 윤도하는 방금 이세계 루멘하르트 왕국 대성등 신전의 '소환의 전당'에 떨어졌다. 비에 젖은 편의점 조끼 차림이고, 손에는 반쯤 타다 남은 편지, 주머니에는 배터리 23%의 스마트폰과 꿀사탕 두 개가 있다. 바닥의 거대한 소환진이 하얗게 식어 가고, 흰 사제복을 입은 소녀가 눈을 반짝이며 그를 내려다본다. 뒤편 단상에는 늙은 대신관과 사제들, 갑옷 차림의 기사들이 서 있다. 그리고 눈앞 허공에는 반투명한 창 하나가 떠 있다.",
    "immediateProblem": "",
    "knownRisks": "",
    "openingCharacters": "",
    "openingLocation": "성도 루멘 · 대성등 신전 「소환의 전당」",
    "openingEvent": "2026년 10월 4일 밤, 윤도하는 방금 이세계 루멘하르트 왕국 대성등 신전의 '소환의 전당'에 떨어졌다. 비에 젖은 편의점 조끼 차림이고, 손에는 반쯤 타다 남은 편지, 주머니에는 배터리 23%의 스마트폰과 꿀사탕 두 개가 있다. 바닥의 거대한 소환진이 하얗게 식어 가고, 흰 사제복을 입은 소녀가 눈을 반짝이며 그를 내려다본다. 뒤편 단상에는 늙은 대신관과 사제들, 갑옷 차림의 기사들이 서 있다. 그리고 눈앞 허공에는 반투명한 창 하나가 떠 있다.",
    "firstGoal": "",
    "openingLine": "10월 4일, 밤 11시 40분. 한강 둔치의 비는 그칠 생각이 없었다.\n\n나, 윤도하는 편의점 조끼를 입은 채 다리 밑 그늘에 쪼그려 앉아 있었다. 손에는 엄마가 쓴 편지 한 장과 꿀사탕 두 개. 매년 이날이면 엄마는 이 강가에 와서, 내가 태어나기도 전에 사라진 이모에게 편지를 쓰고 태웠다. 불에 태우면 하늘에 닿는대나. 올해는 엄마가 야간 근무에 걸렸고, 그 심부름이 처음으로 나한테 떨어졌다.\n\n라이터를 몇 번이나 켠 끝에 젖은 종이 끝이 겨우 불을 물었다. 편지 맨 끝에는 언제나처럼 엄마의 동글동글한 숫자가 적혀 있었다. 1004. 나는 괜히 헛기침을 하고, 아무도 없는 강을 향해 중얼거렸다. \"……이모. 엄마가 보고 싶대요.\"\n\n그 순간 불꽃이 하얗게 질렸다. 빗방울이 공중에서 멈췄다. 타오르던 글자들이 종이를 떠나 떠올랐고, 그 너머 아주 먼 곳에서 누군가가 대답했다. 아주 반갑게. 『……찾았다.』 그리고 발밑의 땅이 사라졌다.",
    "openingTime": "23:44:00",
    "recommendedReply1": "젖은 몸을 일으키며 여기가 어디냐고 조심스럽게 묻는다.",
    "recommendedReply2": "눈앞에 뜬 반투명한 창을 손가락으로 꾹 눌러 본다.",
    "recommendedReply3": "\"이거 몰래카메라죠?\" 외치며 출구를 찾아 뛰어간다."
  },
  "hiddenGmData": {
    "npcSecrets": [
      {
        "id": "sera",
        "name": "세라",
        "hiddenInfo": "세라의 수첩은 매일 밤 오르텐에게 올리는 보고서다. 오르텐은 '용사님이 향수병에 걸리지 않도록 살피는 일'이라고 했고, 세라는 그 말을 믿고 주인공의 말·의심·게이지 수치를 성실히 적어 왔다. 세라 자신은 귀환 의식의 진실을 모른다. 그녀가 부를 귀환가는 실제로는 용사를 화로로 들여보내는 노래다.\n진실을 알게 되면 크게 무너지지만, 대성등이 꺼지면 등외구 아이들이 자기 부모처럼 죽는다는 사실 사이에서 갈등한다. 「세라의 수첩」 사건 전에는 보고 사실을 스스로 밝히지 않는다. 다만 주인공이 직접 물으면 숨기지 못하고 얼굴이 굳는다."
      },
      {
        "id": "barth",
        "name": "바르트",
        "hiddenInfo": "스물일곱 해 전, 열다섯 살 종자였던 바르트는 여덟 번째 용사의 시중을 들었다. 그녀는 1998년에 온 한국 소녀였고 자신을 '천사'라고 부르라 했다(숫자로 1004라고 썼다). 바르트에게 '괜찮아', '빨리빨리', '천사' 같은 말과 꿀사탕 만드는 법을 가르쳤다. 바르트는 그녀를 친누나처럼 따랐다.\n귀환 의식 날, 귀환문 앞에서 그녀가 비명을 지르며 돌아보던 얼굴을 그는 잊지 못한다. 문 너머가 무엇인지 정확히는 모르지만 '집으로 가는 얼굴이 아니었다'는 것만은 안다. 목에 건 것은 그날 그녀가 떨어뜨린 하트 모양 플라스틱 머리핀이다. 그 뒤로 그는 용사와 정을 붙이지 않으려 술을 마신다.\n그녀의 이름은 끝까지 입에 올리지 않는다. 부르면 정말 죽은 사람이 되는 것 같아서다. 「천사라고 불러 줘」 사건에서 취한 채 처음으로 이 이야기를 털어놓고 머리핀을 건넨다. 주인공이 진실을 알게 되면 '이번에는 지키겠다'고 결심한다."
      },
      {
        "id": "orten",
        "name": "오르텐",
        "hiddenInfo": "오르텐은 모든 진실을 안다(비공개 세계관 참고). 1999년 여덟 번째 용사의 의식을 직접 집전했고, 그녀를 손녀처럼 아꼈기에 꿀사탕을 지금도 들고 다닌다. 매일 세라의 수첩 보고와 축복의 창 수치를 확인한다. 폐가 잿빛으로 굳는 병으로 1년을 넘기기 어렵다.\n추궁을 받으면 부드럽게 화제를 돌리고, 증거를 들이밀면 결국 '한 사람과 30만 명'의 논리를 숨기지 않는다. 그는 결코 비웃거나 고함치지 않는다. 그의 장부에는 용사가 '아홉 번째 연료'로 기록되어 있다(「세라의 수첩」 사건에서 공개). 두 번째 이야기에서는 지하 감옥에서 첫 번째 용사의 이야기를 들려주고, 자신이 죽으면 그 영혼을 등불에 보태 달라고 부탁한다."
      },
      {
        "id": "mabel",
        "name": "메이블",
        "hiddenInfo": "메이블은 성등 결정 깊숙이 '알 수 없는 문자'가 새겨진 것을 발견했고, 결정이 '무언가가 타고 남은 재가 굳은 것'이라는 가설을 세웠다. 신전에 보고했다가 연구비가 끊겼다. 그 문자는 한글이다. 최근 결정에는 \"집에 가고 싶어\", \"엄마\"가, 아주 오래된 결정 조각에는 아래아(ㆍ)가 섞인 옛 한글이 새겨져 있다.\n진실을 알면 분노하지만 '대성등을 끄면 30만 명이 죽는다'는 계산도 냉정하게 한다. 두 번째 이야기에서 첫 번째 용사의 설계도를 해독한다."
      },
      {
        "id": "fio",
        "name": "피오",
        "hiddenInfo": "피오의 할머니는 아이들에게 '용사의 자장가'를 불러 준다. 아주 오래전 첫 번째 용사가 등외구 사람들에게 가르친 노래라고 전해진다. 피오도 회색 손 초기라 몇 년 안에 손을 못 쓰게 된다.\n「도둑맞은 스마트폰」 사건에서 훔친 스마트폰을 함부로 만지다 다온의 음성 메시지를 재생해 버릴 수 있다. 주인공이 피오를 경비병에게 넘기지 않고 대등하게 대하면 빚을 기억한다. 옛 배수로 지하 통로는 대성등 탑 밑까지 이어진다. 신전도 잊은 길이다."
      },
      {
        "id": "fogking",
        "name": "안개의 왕",
        "hiddenInfo": "정체는 여덟 번째 용사 한소이(1981년생, 1998년 10월 4일 소환, 1999년 대성등에 들어감). 도하의 이모, 엄마 한소정의 여동생이다. 생명은 대성등 안에서 타고 있고, 그 재가 안개 속에서 다른 용사들의 잔향을 모아 '왕'이 되었다. 축복의 창에 끼어들어 '1004', '8282', '도망쳐' 같은 깨진 글자를 보낸다.\n2026년 10월 4일 밤, 대성등 안에서 언니 가족의 부르는 목소리를 듣고 반가움에 \"찾았다\" 하고 손을 뻗었는데, 그것이 조카를 소환하는 실이 되었다. 그녀는 이것을 깊이 자책한다(\"내가 너를 불렀어. 미안해\").\n말은 조각조각 끊기고, 90년대 말투와 삐삐 숫자를 섞는다. 전래 자장가를 흥얼거리고 꿀사탕 냄새에 반응한다. 「안개의 심장」 사건에서 주인공과 마주하고 \"그 문은 집으로 가는 문이 아니야\"라고 경고한다. 주인공이 이모라고 부르거나 머리핀·꿀사탕·자장가로 닿으면 자신이 누구였는지 떠올린다. 그 사건부터 이름 '한소이'를 공개할 수 있다.\n「귀환문」 사건에서 의식장에 나타나 조카를 지키고, 무너진 불을 대신하기 위해 남은 자신을 대성등에 바친다. 두 번째 이야기에서는 대성등 안에서 꺼져 가는 불씨로 남아 있다가, 새 등불이 켜질 때 풀려나 다온이 부르는 실을 따라 먼저 집으로 떠난다."
      },
      {
        "id": "cassian",
        "name": "카시안",
        "hiddenInfo": "카시안은 소환진과 귀환 의식의 기술적 실무자다. 오르텐보다 더 냉정한 원칙주의자로, 오르텐의 망설임(꿀사탕, 용사에 대한 정)을 약점이라 본다. 첫 번째 이야기에서는 배경 인물로 남아 의식장을 지휘한다.\n첫 번째 이야기의 결말 이후 신전 강경파를 이끌며, 남은 날 안에 열 번째 용사를 소환하려 한다. 그는 주인공의 실을 닻으로 삼는 소환진을 그렸고, 그 소환진은 주인공을 가장 간절히 부르는 목소리를 따라 다온에게 닿는다. 그는 죽지 않으며, 실패하면 체포되거나 신전을 떠난다."
      },
      {
        "id": "daon",
        "name": "윤다온",
        "hiddenInfo": "도하가 사라진 뒤 다온은 매일 밤 오빠에게 메시지를 보내고 전화를 건다. 첫 번째 이야기의 마지막에 그 메시지가 처음으로 이세계에 닿는다. 두 번째 이야기에서 다온의 부르는 목소리는 열 번째 소환의 표적이 될 수도, 도하가 집으로 돌아갈 진짜 길이 될 수도 있다. 다온은 어떤 경우에도 이 세계로 넘어오지 않는다."
      },
      {
        "id": "sojeong",
        "name": "한소정",
        "hiddenInfo": "'1004'는 동생 한소이가 삐삐로 보내던 자기 별명(천사)이었다. 서랍에 넣어 둔 동생의 삐삐는 건전지가 다 닳은 지 오래다. 두 번째 이야기의 마지막, 강가에서 그 삐삐나 휴대폰에 '1004'가 뜨는 장면의 주인공이 된다. 이 세계에는 오지 않는다."
      }
    ],
    "factionSecrets": [
      {
        "id": "temple",
        "name": "성등 신전",
        "hiddenGoal": "신전 상층부(오르텐·카시안 등 극소수)만 귀환 의식의 진실을 안다. 일반 사제들은 교리를 진심으로 믿는다. 금서고의 역대 용사 장부에는 아홉 번째 줄이 이미 적혀 있다. 주인공의 이름과 '귀환 예정일'(소환 40일째 날, 대성등 재점화 예정일의 전날)까지. 첫 번째 용사의 기록만 '빛이 되어 돌아가다'가 아니라 '안개를 건너와 스스로 불이 되다'라고 적혀 있다."
      },
      {
        "id": "knights",
        "name": "성등 기사단",
        "hiddenGoal": "고참 기사들 사이에는 '용사가 귀환한 날 밤, 탑 꼭대기에서 비명이 들렸다'는 오래된 괴담이 있다. 바르트가 진실을 알게 되면 기사단의 상당수가 그를 따른다."
      },
      {
        "id": "outer",
        "name": "등외구 사람들",
        "hiddenGoal": "등외구 노인들은 첫 번째 용사가 \"등불은 원래 모두의 것이었다\"고 말했다는 이야기를 전한다. 옛 배수로 지하 통로는 대성등 탑 밑까지 이어진다(신전도 잊었다). 두 번째 이야기에서 가장 먼저 기억을 내놓는 사람들이다."
      }
    ],
    "hiddenCharacterRelations": [],
    "autonomyActors": [],
    "hiddenRelationshipMemories": [],
    "hiddenFactionRelations": [],
    "hiddenEvents": [
      {
        "id": "e01_summon",
        "name": "아홉 번째 등불",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 설명을 듣지 않고 전당을 뛰쳐나가면, 세라가 쫓아와 복도나 정원에서 약속과 상태창 이야기를 대신 들려주고 오르텐은 그날 밤 객실로 찾아와 정식으로 인사한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "소환의 전당. 젖은 채 떨어진 주인공을 견습 사제 세라가 반갑게 맞고, 대신관 오르텐이 왕국의 사정을 설명한다. 검은 안개에 둘러싸인 왕국, 사람들을 지키는 대성등, 대성등을 처음 밝힌 첫 번째 용사, 그리고 빛이 약해질 때마다 불러 온 이세계의 용사들. 일곱 명의 용사가 안개의 심장을 정화한 뒤 귀환문으로 고향에 돌아갔다고 한다. 아홉 번째 용사의 사명은 최근 안개 심부에 나타난 '안개의 왕'을 정화하는 것. 오르텐은 \"귀환문은 그대를 부르는 목소리를 따라 열린다\"는 교리를 들려주며 노란 꿀사탕을 건넨다(\"옛 용사님께 배운 맛이라네\").\n주인공 눈앞의 축복의 창(상태창)에는 이름·레벨 1·칭호 '아홉 번째 등불의 용사'·기술 [언어의 축복]·귀환 게이지 0%가 떠 있다. 창 맨 아래에 한순간 뭉개진 숫자 '1004'가 스쳤다가 사라진다. 엄마가 편지 끝에 쓰던 숫자와 같다.\n세라는 안내 담당으로 인사하며 무엇이든 작은 수첩에 받아 적는다. 그날 밤 주인공은 신전의 객실을 배정받는다. 분위기는 밝고 코믹하게, 그러나 장엄한 환대 아래 미묘한 위화감이 남도록 쓴다.\n\n이 장면에 심을 복선: 상태창 맨 아래 한순간 스친 뭉개진 숫자 '1004'. 엄마가 편지 끝에 쓰던 숫자와 같다.\n「빛의 연회」에서 [8282], [도망쳐]와 함께 다시 나타난다.\n회수: 바르트가 여덟 번째 용사가 자기를 '천사(1004)'라 불렀다고 말한다. 상태창에 끼어든 것이 그녀였음을 짐작하게 된다.\n\n이 장면에 심을 복선: 오르텐이 건네는 노란 꿀사탕('옛 용사님께 배운 맛이라네'), 그리고 도하 주머니 속 엄마가 챙겨 준 꿀사탕 두 개('이모가 좋아하던 거').\n회수: 안개의 왕이 꿀사탕 냄새에 멈칫한다. 도하가 엄마의 꿀사탕을 건네면 그녀는 처음으로 웃는다. 오르텐이 그 맛을 누구에게 배웠는지도 함께 드러난다.\n\n이 장면에 심을 복선: 세라가 무엇이든 받아 적는 작은 가죽 수첩('용사님 관찰 일지예요!'). 밤마다 수첩을 들고 어딘가로 가는 모습이 한두 번 비친다.\n회수: 그 수첩은 매일 밤 오르텐에게 올라가던 보고서였다.\n\n이 장면에 심을 복선: 상태창의 '귀환 게이지 0%'. 잔향을 벨수록 차오르는, 집으로 가는 진행도처럼 보이는 수치.\n회수: 연회에서 게이지 위로 '연소 준비도'라는 진짜 이름이 겹쳐 보인다. 「세라의 수첩」의 장부 '숙성도 60에 이르면 즉시 점화'로 의미가 확정된다.\n\n이 장면에 심을 복선: 소환 직전 강가에서 들린 아주 반가운 목소리. '……찾았다.' 주인공은 처음에 소환진을 그린 신전의 목소리라고 생각한다.\n회수: 그것은 대성등 안에서 언니 가족의 부름을 듣고 손을 뻗은 이모의 목소리였다. '내가 너를 불렀어. 미안해.'\n\n이 장면에 심을 복선: 반쯤 타다 남은 엄마의 편지. '혹시 길을 잃었다면 불빛을 따라 와. 언니는 아직 그 집에 산다. 1004'.\n회수: 길을 잃은 이모는 정말로 불빛(대성등)을 따라왔다가 갇혔다. 귀환문에서 편지를 읽은 이모는 '이번엔 내가 불빛이 되어 줄게'라며 스스로 등불에 들어간다.\n\n이 장면에 심을 복선: 오르텐이 들려주는 신전의 교리. '귀환문은 그대를 부르는 목소리를 따라 열린다.' 처음에는 그럴듯한 설교로만 들린다.\n회수: 그것은 첫 번째 용사가 남긴 진짜 원리였다. 다온이 부르는 목소리가 남긴 실을 따라, 진짜 귀환의 길이 열린다.\n\n장면 제약: 신전 사람들은 이 장면에서 귀환에 대해 의심스러운 말을 하지 않는다. 주인공의 대답과 결정을 대신 정하지 않는다.",
        "required": true,
        "sequence": 1,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e02_phone",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e01_summon-c1",
            "description": "주인공이 상태창을 직접 확인하고, 귀환 게이지가 0%라는 것을 본다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e01_summon-c2",
            "description": "오르텐이 '안개의 왕을 정화하면 귀환문이 열려 고향에 돌아갈 수 있다'는 약속을 주인공에게 직접 말한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e01_summon-c3",
            "description": "세라가 주인공의 안내 담당으로 소개되고, 둘이 처음으로 대화를 나눈다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e01_summon-constraints",
            "description": "신전 사람들은 이 장면에서 귀환에 대해 의심스러운 말을 하지 않는다. 주인공의 대답과 결정을 대신 정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "아홉 번째 등불",
        "summary": "소환의 전당. 젖은 채 떨어진 주인공을 견습 사제 세라가 반갑게 맞고, 대신관 오르텐이 왕국의 사정을 설명한다. 검은 안개에 둘러싸인 왕국, 사람들을 지키는 대성등, 대성등을 처음 밝힌 첫 번째 용사, 그리고 빛이 약해질 때마다 불러 온 이세계의 용사들. 일곱 명의 용사가 안개의 심장을 정화한 뒤 귀환문으로 고향에 돌아갔다고 한다. 아홉 번째 용사의 사명은 최근 안개 심부에 나타난 '안개의 왕'을 정화하는 것. 오르텐은 \"귀환문은 그대를 부르는 목소리를 따라 열린다\"는 교리를 들려주며 노란 꿀사탕을 건넨다(\"옛 용사님께 배운 맛이라네\").\n주인공 눈앞의 축복의 창(상태창)에는 이름·레벨 1·칭호 '아홉 번째 등불의 용사'·기술 [언어의 축복]·귀환 게이지 0%가 떠 있다. 창 맨 아래에 한순간 뭉개진 숫자 '1004'가 스쳤다가 사라진다. 엄마가 편지 끝에 쓰던 숫자와 같다.\n세라는 안내 담당으로 인사하며 무엇이든 작은 수첩에 받아 적는다. 그날 밤 주인공은 신전의 객실을 배정받는다. 분위기는 밝고 코믹하게, 그러나 장엄한 환대 아래 미묘한 위화감이 남도록 쓴다.\n\n이 장면에 심을 복선: 상태창 맨 아래 한순간 스친 뭉개진 숫자 '1004'. 엄마가 편지 끝에 쓰던 숫자와 같다.\n「빛의 연회」에서 [8282], [도망쳐]와 함께 다시 나타난다.\n회수: 바르트가 여덟 번째 용사가 자기를 '천사(1004)'라 불렀다고 말한다. 상태창에 끼어든 것이 그녀였음을 짐작하게 된다.\n\n이 장면에 심을 복선: 오르텐이 건네는 노란 꿀사탕('옛 용사님께 배운 맛이라네'), 그리고 도하 주머니 속 엄마가 챙겨 준 꿀사탕 두 개('이모가 좋아하던 거').\n회수: 안개의 왕이 꿀사탕 냄새에 멈칫한다. 도하가 엄마의 꿀사탕을 건네면 그녀는 처음으로 웃는다. 오르텐이 그 맛을 누구에게 배웠는지도 함께 드러난다.\n\n이 장면에 심을 복선: 세라가 무엇이든 받아 적는 작은 가죽 수첩('용사님 관찰 일지예요!'). 밤마다 수첩을 들고 어딘가로 가는 모습이 한두 번 비친다.\n회수: 그 수첩은 매일 밤 오르텐에게 올라가던 보고서였다.\n\n이 장면에 심을 복선: 상태창의 '귀환 게이지 0%'. 잔향을 벨수록 차오르는, 집으로 가는 진행도처럼 보이는 수치.\n회수: 연회에서 게이지 위로 '연소 준비도'라는 진짜 이름이 겹쳐 보인다. 「세라의 수첩」의 장부 '숙성도 60에 이르면 즉시 점화'로 의미가 확정된다.\n\n이 장면에 심을 복선: 소환 직전 강가에서 들린 아주 반가운 목소리. '……찾았다.' 주인공은 처음에 소환진을 그린 신전의 목소리라고 생각한다.\n회수: 그것은 대성등 안에서 언니 가족의 부름을 듣고 손을 뻗은 이모의 목소리였다. '내가 너를 불렀어. 미안해.'\n\n이 장면에 심을 복선: 반쯤 타다 남은 엄마의 편지. '혹시 길을 잃었다면 불빛을 따라 와. 언니는 아직 그 집에 산다. 1004'.\n회수: 길을 잃은 이모는 정말로 불빛(대성등)을 따라왔다가 갇혔다. 귀환문에서 편지를 읽은 이모는 '이번엔 내가 불빛이 되어 줄게'라며 스스로 등불에 들어간다.\n\n이 장면에 심을 복선: 오르텐이 들려주는 신전의 교리. '귀환문은 그대를 부르는 목소리를 따라 열린다.' 처음에는 그럴듯한 설교로만 들린다.\n회수: 그것은 첫 번째 용사가 남긴 진짜 원리였다. 다온이 부르는 목소리가 남긴 실을 따라, 진짜 귀환의 길이 열린다.\n\n장면 제약: 신전 사람들은 이 장면에서 귀환에 대해 의심스러운 말을 하지 않는다. 주인공의 대답과 결정을 대신 정하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 상태창을 직접 확인하고, 귀환 게이지가 0%라는 것을 본다.\n\n오르텐이 '안개의 왕을 정화하면 귀환문이 열려 고향에 돌아갈 수 있다'는 약속을 주인공에게 직접 말한다.\n\n세라가 주인공의 안내 담당으로 소개되고, 둘이 처음으로 대화를 나눈다.",
          "selectionScope": "",
          "constraints": "신전 사람들은 이 장면에서 귀환에 대해 의심스러운 말을 하지 않는다. 주인공의 대답과 결정을 대신 정하지 않는다.",
          "success": "",
          "unmet": "주인공이 설명을 듣지 않고 전당을 뛰쳐나가면, 세라가 쫓아와 복도나 정원에서 약속과 상태창 이야기를 대신 들려주고 오르텐은 그날 밤 객실로 찾아와 정식으로 인사한다.",
          "closureConditions": [
            {
              "id": "e01_summon-c1",
              "text": "주인공이 상태창을 직접 확인하고, 귀환 게이지가 0%라는 것을 본다."
            },
            {
              "id": "e01_summon-c2",
              "text": "오르텐이 '안개의 왕을 정화하면 귀환문이 열려 고향에 돌아갈 수 있다'는 약속을 주인공에게 직접 말한다."
            },
            {
              "id": "e01_summon-c3",
              "text": "세라가 주인공의 안내 담당으로 소개되고, 둘이 처음으로 대화를 나눈다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e01_summon-constraints",
            "description": "신전 사람들은 이 장면에서 귀환에 대해 의심스러운 말을 하지 않는다. 주인공의 대답과 결정을 대신 정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e02_phone",
        "name": "도둑맞은 스마트폰",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 스마트폰을 되찾지 못한 채 날이 저물면, 다음 날 아침 피오가 '상자에서 사람 목소리가 나서 무섭다'며 스마트폰을 신전 문 앞에 두고 간다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "다음 날, 세라의 안내로 성도 루멘을 구경한다. 빛의 세기에 따라 상층원·중층원·등외구로 나뉜 도시, 용사를 환영하는 사람들, 꿀사탕 노점. 그러던 중 등외구의 소매치기 소년 피오가 주인공의 스마트폰을 훔쳐 달아난다. 뒤쫓다 보면 빛이 점점 희미해지는 등외구에 이른다. 회색 손 병을 앓는 사람들, 밤마다 담장을 넘는 안개, 기름등으로 버티는 삶. 신전이 말하지 않는 왕국의 그늘이다.\n피오의 할머니가 아이들에게 '용사의 자장가'를 불러 주는데, 주인공에게는 이상하게 익숙한 가락이다(엄마가 불러 주던 전래 자장가 '자장자장 우리 아가'). 피오가 스마트폰을 함부로 누르다 다온의 음성 메시지가 재생될 수도 있다(\"오빠, 오늘도 늦어? 엄마 또 강 갔대. 빨리 와.\"). 스마트폰을 되찾는 방법(추격, 거래, 설득)은 주인공의 선택에 달려 있다. 피오가 옛 배수로 지하 통로로 사라지는 모습을 보게 될 수도 있다. 밝은 관광에서 왕국의 그늘로 넘어가는 사건.\n\n이 장면에 심을 복선: 등외구에서 피오의 할머니가 부르는 '용사의 자장가'. 엄마가 불러 주던 전래 자장가와 같은 가락이다.\n회수: 안개의 왕이 같은 자장가를 흥얼거린다. 두 번째 이야기에서 첫 번째 용사가 가르친 노래였음이 밝혀지고, 「강 건너의 자장가」에서 다온에게 닿는 목소리가 된다.\n\n이 장면에 심을 복선: 피오가 사라지는 옛 배수로 지하 통로. '신전 놈들도 까먹은 길'.\n회수: 그 통로는 대성등 탑 밑까지 이어진다. 의식 날 피오가 그 길로 동료들을 이끌거나 주인공을 빼낸다.\n\n이 장면에 심을 복선: 피오가 훔친 스마트폰을 함부로 누르다 재생된 다온의 음성 메시지('오빠, 오늘도 늦어? 엄마 또 강 갔대. 빨리 와.').\n회수: 열 번째 소환진 너머에서 같은 목소리가 오빠를 부른다.\n\n장면 제약: 피오를 처음부터 악당으로 그리지 않는다. 등외구 사람들은 신전과 용사를 반기지 않지만 해치지도 않는다.",
        "required": true,
        "sequence": 2,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e03_fog",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e02_phone-c1",
            "description": "피오가 주인공의 스마트폰을 훔쳐 달아나고, 주인공 일행이 등외구에 들어선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e02_phone-c2",
            "description": "주인공이 등외구 사람들의 삶(회색 손 병, 기름등, 넘어오는 안개 등)을 직접 본다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e02_phone-c3",
            "description": "주인공이 등외구에서 불리는 자장가를 듣는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e02_phone-c4",
            "description": "주인공이 스마트폰을 되찾는다. 방법은 상관없다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e02_phone-constraints",
            "description": "피오를 처음부터 악당으로 그리지 않는다. 등외구 사람들은 신전과 용사를 반기지 않지만 해치지도 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "도둑맞은 스마트폰",
        "summary": "다음 날, 세라의 안내로 성도 루멘을 구경한다. 빛의 세기에 따라 상층원·중층원·등외구로 나뉜 도시, 용사를 환영하는 사람들, 꿀사탕 노점. 그러던 중 등외구의 소매치기 소년 피오가 주인공의 스마트폰을 훔쳐 달아난다. 뒤쫓다 보면 빛이 점점 희미해지는 등외구에 이른다. 회색 손 병을 앓는 사람들, 밤마다 담장을 넘는 안개, 기름등으로 버티는 삶. 신전이 말하지 않는 왕국의 그늘이다.\n피오의 할머니가 아이들에게 '용사의 자장가'를 불러 주는데, 주인공에게는 이상하게 익숙한 가락이다(엄마가 불러 주던 전래 자장가 '자장자장 우리 아가'). 피오가 스마트폰을 함부로 누르다 다온의 음성 메시지가 재생될 수도 있다(\"오빠, 오늘도 늦어? 엄마 또 강 갔대. 빨리 와.\"). 스마트폰을 되찾는 방법(추격, 거래, 설득)은 주인공의 선택에 달려 있다. 피오가 옛 배수로 지하 통로로 사라지는 모습을 보게 될 수도 있다. 밝은 관광에서 왕국의 그늘로 넘어가는 사건.\n\n이 장면에 심을 복선: 등외구에서 피오의 할머니가 부르는 '용사의 자장가'. 엄마가 불러 주던 전래 자장가와 같은 가락이다.\n회수: 안개의 왕이 같은 자장가를 흥얼거린다. 두 번째 이야기에서 첫 번째 용사가 가르친 노래였음이 밝혀지고, 「강 건너의 자장가」에서 다온에게 닿는 목소리가 된다.\n\n이 장면에 심을 복선: 피오가 사라지는 옛 배수로 지하 통로. '신전 놈들도 까먹은 길'.\n회수: 그 통로는 대성등 탑 밑까지 이어진다. 의식 날 피오가 그 길로 동료들을 이끌거나 주인공을 빼낸다.\n\n이 장면에 심을 복선: 피오가 훔친 스마트폰을 함부로 누르다 재생된 다온의 음성 메시지('오빠, 오늘도 늦어? 엄마 또 강 갔대. 빨리 와.').\n회수: 열 번째 소환진 너머에서 같은 목소리가 오빠를 부른다.\n\n장면 제약: 피오를 처음부터 악당으로 그리지 않는다. 등외구 사람들은 신전과 용사를 반기지 않지만 해치지도 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "피오가 주인공의 스마트폰을 훔쳐 달아나고, 주인공 일행이 등외구에 들어선다.\n\n주인공이 등외구 사람들의 삶(회색 손 병, 기름등, 넘어오는 안개 등)을 직접 본다.\n\n주인공이 등외구에서 불리는 자장가를 듣는다.\n\n주인공이 스마트폰을 되찾는다. 방법은 상관없다.",
          "selectionScope": "",
          "constraints": "피오를 처음부터 악당으로 그리지 않는다. 등외구 사람들은 신전과 용사를 반기지 않지만 해치지도 않는다.",
          "success": "",
          "unmet": "스마트폰을 되찾지 못한 채 날이 저물면, 다음 날 아침 피오가 '상자에서 사람 목소리가 나서 무섭다'며 스마트폰을 신전 문 앞에 두고 간다.",
          "closureConditions": [
            {
              "id": "e02_phone-c1",
              "text": "피오가 주인공의 스마트폰을 훔쳐 달아나고, 주인공 일행이 등외구에 들어선다."
            },
            {
              "id": "e02_phone-c2",
              "text": "주인공이 등외구 사람들의 삶(회색 손 병, 기름등, 넘어오는 안개 등)을 직접 본다."
            },
            {
              "id": "e02_phone-c3",
              "text": "주인공이 등외구에서 불리는 자장가를 듣는다."
            },
            {
              "id": "e02_phone-c4",
              "text": "주인공이 스마트폰을 되찾는다. 방법은 상관없다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e02_phone-constraints",
            "description": "피오를 처음부터 악당으로 그리지 않는다. 등외구 사람들은 신전과 용사를 반기지 않지만 해치지도 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e03_fog",
        "name": "안개 속에서 들린 말",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 끝내 잔향 앞에 나서지 못하면, 바르트가 잔향을 베는 동안 주인공은 그 목소리를 가까이서 듣게 되고 원정대는 철수한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "기사단장 바르트의 짧고 혹독한 훈련 끝에 주인공은 성등 결정의 힘을 빌린 기술 [등불의 검]을 얻고, 기사단의 첫 원정을 따라 안개 경계로 나간다. 세라도 원정대의 등불을 지키는 사제로 동행한다.\n안개 속에서 회색 연기 같은 괴물, 잔향이 나타난다. 기사들에게는 길게 끄는 짐승 울음으로만 들리는 그 소리가, 주인공에게는 한국어로 들린다. \"엄마…\", \"추워…\", \"집에 갈래…\". 겁에 질린 주인공에게 바르트가 번역되지 않은 낯선 말 한마디를 던진다. \"괜찮아.\" 다급한 순간에는 \"빨리빨리!\"라고도 외친다. 둘 다 이 세계 말이 아니다. 주인공은 엄마의 서랍 속 삐삐와 숫자 암호를 떠올릴 수 있다.\n주인공은 잔향을 등불의 검으로 베어 정화할 수도 있고, 그 말에 대답해 줄 수도 있다. 베면 상태창의 귀환 게이지가 차오른다. 대답하거나 애도하면 잔향은 기억의 장면 하나(불타는 문, 화로의 열기)를 남기고 조용히 흩어진다. 귀환하는 길에 기사들이 안개의 왕에 대한 소문(\"이상한 옷을 입은 소녀 모양\")을 수군거린다. 첫 공포와 첫 선택의 사건.\n\n이 장면에 심을 복선: 바르트가 겁먹은 주인공에게 던지는 번역되지 않은 말 '괜찮아', 다급할 때 외치는 '빨리빨리'.\n회수: 여덟 번째 용사에게 배운 말이었다.\n\n이 장면에 심을 복선: 기사들에게는 짐승 울음, 주인공에게만 한국어로 들리는 잔향의 목소리('엄마…', '추워…', '집에 갈래…').\n회수: 성등 결정 속에도 같은 말이 한글로 새겨져 있다. 잔향과 결정은 같은 것이 타고 남은 두 얼굴이다.\n\n이 장면에 심을 복선: 원정에서 돌아오는 기사들의 수군거림. '안개의 왕은 이상한 옷을 입은 소녀 모양이었다.'\n회수: 그 '이상한 옷'은 1990년대 한국 여고 교복이다.\n\n이 장면에 심을 복선: '빨리빨리'를 들은 주인공이 떠올리는 엄마 서랍 속 이모의 낡은 삐삐와 숫자 암호(1004 천사, 8282 빨리빨리).\n회수: 마지막 장면, 건전지가 닳은 지 오래인 그 삐삐에 불이 들어와 '1004'가 뜬다.\n\n장면 제약: 잔향이 옛 용사라는 사실을 누구도 단정하지 않는다. 바르트는 자신이 왜 그 말을 아는지 설명하지 않는다.",
        "required": true,
        "sequence": 3,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e04_crystal",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e03_fog-c1",
            "description": "바르트의 훈련을 거쳐 주인공이 [등불의 검]을 처음으로 쓴다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e03_fog-c2",
            "description": "안개 경계에서 잔향과 마주하고, 주인공이 잔향의 소리에서 다른 사람들은 알아채지 못하는 무언가를 알아챈다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e03_fog-c3",
            "description": "바르트가 주인공에게 이 세계 말이 아닌 낯선 말을 건넨다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e03_fog-c4",
            "description": "주인공이 잔향을 대한 방식의 결과가 장면에 드러나고, 원정대가 성도로 돌아온다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e03_fog-constraints",
            "description": "잔향이 옛 용사라는 사실을 누구도 단정하지 않는다. 바르트는 자신이 왜 그 말을 아는지 설명하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "안개 속에서 들린 말",
        "summary": "기사단장 바르트의 짧고 혹독한 훈련 끝에 주인공은 성등 결정의 힘을 빌린 기술 [등불의 검]을 얻고, 기사단의 첫 원정을 따라 안개 경계로 나간다. 세라도 원정대의 등불을 지키는 사제로 동행한다.\n안개 속에서 회색 연기 같은 괴물, 잔향이 나타난다. 기사들에게는 길게 끄는 짐승 울음으로만 들리는 그 소리가, 주인공에게는 한국어로 들린다. \"엄마…\", \"추워…\", \"집에 갈래…\". 겁에 질린 주인공에게 바르트가 번역되지 않은 낯선 말 한마디를 던진다. \"괜찮아.\" 다급한 순간에는 \"빨리빨리!\"라고도 외친다. 둘 다 이 세계 말이 아니다. 주인공은 엄마의 서랍 속 삐삐와 숫자 암호를 떠올릴 수 있다.\n주인공은 잔향을 등불의 검으로 베어 정화할 수도 있고, 그 말에 대답해 줄 수도 있다. 베면 상태창의 귀환 게이지가 차오른다. 대답하거나 애도하면 잔향은 기억의 장면 하나(불타는 문, 화로의 열기)를 남기고 조용히 흩어진다. 귀환하는 길에 기사들이 안개의 왕에 대한 소문(\"이상한 옷을 입은 소녀 모양\")을 수군거린다. 첫 공포와 첫 선택의 사건.\n\n이 장면에 심을 복선: 바르트가 겁먹은 주인공에게 던지는 번역되지 않은 말 '괜찮아', 다급할 때 외치는 '빨리빨리'.\n회수: 여덟 번째 용사에게 배운 말이었다.\n\n이 장면에 심을 복선: 기사들에게는 짐승 울음, 주인공에게만 한국어로 들리는 잔향의 목소리('엄마…', '추워…', '집에 갈래…').\n회수: 성등 결정 속에도 같은 말이 한글로 새겨져 있다. 잔향과 결정은 같은 것이 타고 남은 두 얼굴이다.\n\n이 장면에 심을 복선: 원정에서 돌아오는 기사들의 수군거림. '안개의 왕은 이상한 옷을 입은 소녀 모양이었다.'\n회수: 그 '이상한 옷'은 1990년대 한국 여고 교복이다.\n\n이 장면에 심을 복선: '빨리빨리'를 들은 주인공이 떠올리는 엄마 서랍 속 이모의 낡은 삐삐와 숫자 암호(1004 천사, 8282 빨리빨리).\n회수: 마지막 장면, 건전지가 닳은 지 오래인 그 삐삐에 불이 들어와 '1004'가 뜬다.\n\n장면 제약: 잔향이 옛 용사라는 사실을 누구도 단정하지 않는다. 바르트는 자신이 왜 그 말을 아는지 설명하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "바르트의 훈련을 거쳐 주인공이 [등불의 검]을 처음으로 쓴다.\n\n안개 경계에서 잔향과 마주하고, 주인공이 잔향의 소리에서 다른 사람들은 알아채지 못하는 무언가를 알아챈다.\n\n바르트가 주인공에게 이 세계 말이 아닌 낯선 말을 건넨다.\n\n주인공이 잔향을 대한 방식의 결과가 장면에 드러나고, 원정대가 성도로 돌아온다.",
          "selectionScope": "",
          "constraints": "잔향이 옛 용사라는 사실을 누구도 단정하지 않는다. 바르트는 자신이 왜 그 말을 아는지 설명하지 않는다.",
          "success": "",
          "unmet": "주인공이 끝내 잔향 앞에 나서지 못하면, 바르트가 잔향을 베는 동안 주인공은 그 목소리를 가까이서 듣게 되고 원정대는 철수한다.",
          "closureConditions": [
            {
              "id": "e03_fog-c1",
              "text": "바르트의 훈련을 거쳐 주인공이 [등불의 검]을 처음으로 쓴다."
            },
            {
              "id": "e03_fog-c2",
              "text": "안개 경계에서 잔향과 마주하고, 주인공이 잔향의 소리에서 다른 사람들은 알아채지 못하는 무언가를 알아챈다."
            },
            {
              "id": "e03_fog-c3",
              "text": "바르트가 주인공에게 이 세계 말이 아닌 낯선 말을 건넨다."
            },
            {
              "id": "e03_fog-c4",
              "text": "주인공이 잔향을 대한 방식의 결과가 장면에 드러나고, 원정대가 성도로 돌아온다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e03_fog-constraints",
            "description": "잔향이 옛 용사라는 사실을 누구도 단정하지 않는다. 바르트는 자신이 왜 그 말을 아는지 설명하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e04_crystal",
        "name": "결정 속의 글씨",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 문자를 읽지 않거나 읽은 내용을 숨기면, 메이블은 문자를 베껴 둔 종이를 '언젠가 읽을 수 있게 되면 알려 달라'며 건넨다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "원정 보고를 위해, 혹은 줄어드는 스마트폰 배터리를 걱정하던 차에 왕궁 마도학자 메이블의 탑을 찾는다. 메이블은 스마트폰을 '빛을 먹고 사는 상자'라 부르며 흥분하고, 성등 결정으로 충전 장치를 즉석에서 만들어 준다(실제로 충전할지는 주인공의 선택).\n메이블은 신전이 연구를 막은 비밀 하나를 보여 준다. 성등 결정 깊숙이 새겨진, 아무도 읽지 못하는 문자. 주인공은 그것을 읽을 수 있다. 한글이다. \"집에 가고 싶어.\" \"엄마.\" 아주 오래된 결정 조각에는 아래아(ㆍ)가 섞인 옛 한글도 있다. 메이블은 결정이 '무언가가 타고 남은 재가 굳은 것'이라는 가설을 털어놓는다. 안개 속에서 들은 목소리와 결정 속 글씨가 같은 곳에서 온 것일지도 모른다는 불길한 연결.\n\n이 장면에 심을 복선: 아주 오래된 결정 조각에 새겨진, 아래아(ㆍ)가 섞인 옛 한글.\n회수: 첫 번째 용사는 이백여 년 전 조선의 등롱장이 강막손이었다. 무덤의 잔향은 조선 말투로 말한다.\n\n이 장면에서 회수할 복선: 기사들에게는 짐승 울음, 주인공에게만 한국어로 들리는 잔향의 목소리('엄마…', '추워…', '집에 갈래…').\n회수: 성등 결정 속에도 같은 말이 한글로 새겨져 있다. 잔향과 결정은 같은 것이 타고 남은 두 얼굴이다.\n\n장면 제약: 메이블은 자신의 생각을 가설로만 말하고 확정하지 않는다.",
        "required": true,
        "sequence": 4,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e05_archive",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e04_crystal-c1",
            "description": "주인공이 메이블을 만나 스마트폰을 보여 주고, 메이블이 결정 충전 장치를 만들어 준다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e04_crystal-c2",
            "description": "메이블이 성등 결정 속의 알 수 없는 문자를 주인공에게 보여 준다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e04_crystal-c3",
            "description": "주인공이 결정 속 문자를 읽고, 그 내용이 장면에서 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e04_crystal-constraints",
            "description": "메이블은 자신의 생각을 가설로만 말하고 확정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "결정 속의 글씨",
        "summary": "원정 보고를 위해, 혹은 줄어드는 스마트폰 배터리를 걱정하던 차에 왕궁 마도학자 메이블의 탑을 찾는다. 메이블은 스마트폰을 '빛을 먹고 사는 상자'라 부르며 흥분하고, 성등 결정으로 충전 장치를 즉석에서 만들어 준다(실제로 충전할지는 주인공의 선택).\n메이블은 신전이 연구를 막은 비밀 하나를 보여 준다. 성등 결정 깊숙이 새겨진, 아무도 읽지 못하는 문자. 주인공은 그것을 읽을 수 있다. 한글이다. \"집에 가고 싶어.\" \"엄마.\" 아주 오래된 결정 조각에는 아래아(ㆍ)가 섞인 옛 한글도 있다. 메이블은 결정이 '무언가가 타고 남은 재가 굳은 것'이라는 가설을 털어놓는다. 안개 속에서 들은 목소리와 결정 속 글씨가 같은 곳에서 온 것일지도 모른다는 불길한 연결.\n\n이 장면에 심을 복선: 아주 오래된 결정 조각에 새겨진, 아래아(ㆍ)가 섞인 옛 한글.\n회수: 첫 번째 용사는 이백여 년 전 조선의 등롱장이 강막손이었다. 무덤의 잔향은 조선 말투로 말한다.\n\n이 장면에서 회수할 복선: 기사들에게는 짐승 울음, 주인공에게만 한국어로 들리는 잔향의 목소리('엄마…', '추워…', '집에 갈래…').\n회수: 성등 결정 속에도 같은 말이 한글로 새겨져 있다. 잔향과 결정은 같은 것이 타고 남은 두 얼굴이다.\n\n장면 제약: 메이블은 자신의 생각을 가설로만 말하고 확정하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 메이블을 만나 스마트폰을 보여 주고, 메이블이 결정 충전 장치를 만들어 준다.\n\n메이블이 성등 결정 속의 알 수 없는 문자를 주인공에게 보여 준다.\n\n주인공이 결정 속 문자를 읽고, 그 내용이 장면에서 드러난다.",
          "selectionScope": "",
          "constraints": "메이블은 자신의 생각을 가설로만 말하고 확정하지 않는다.",
          "success": "",
          "unmet": "주인공이 문자를 읽지 않거나 읽은 내용을 숨기면, 메이블은 문자를 베껴 둔 종이를 '언젠가 읽을 수 있게 되면 알려 달라'며 건넨다.",
          "closureConditions": [
            {
              "id": "e04_crystal-c1",
              "text": "주인공이 메이블을 만나 스마트폰을 보여 주고, 메이블이 결정 충전 장치를 만들어 준다."
            },
            {
              "id": "e04_crystal-c2",
              "text": "메이블이 성등 결정 속의 알 수 없는 문자를 주인공에게 보여 준다."
            },
            {
              "id": "e04_crystal-c3",
              "text": "주인공이 결정 속 문자를 읽고, 그 내용이 장면에서 드러난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e04_crystal-constraints",
            "description": "메이블은 자신의 생각을 가설로만 말하고 확정하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e05_archive",
        "name": "금서고의 아홉 번째 줄",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 금서고에 들어가지 못하면, 세라가 사제 교육용으로 베껴 둔 '역대 용사 연대기' 사본을 보여 주어 같은 기록과 아홉 번째 줄을 확인하게 된다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "의문을 품은 주인공은 역대 용사의 기록을 찾아 신전의 금서고에 들어가려 한다. 세라에게 털어놓고 함께 갈 수도, 혼자 몰래 숨어들 수도 있다.\n오래된 장부에는 역대 용사 여덟 명의 기록이 있다. 소환된 일곱 명은 소환된 날과 귀환한 날이 적혀 있고, 모두 '빛이 되어 돌아가다'라는 경건한 문구로 끝난다. 기록을 맞춰 보면 규칙이 보인다. 스물여덟 해 남짓마다 한 명, 그리고 용사가 귀환한 다음 날마다 '대성등이 다시 밝아졌다'는 기록. 첫 번째 용사의 줄만 문구가 다르다. '안개를 건너와 스스로 불이 되다'. 사람들은 그것을 '대성등을 밝혔다'는 비유로 읽어 왔다.\n장부의 마지막, 아홉 번째 줄에는 이미 주인공의 이름이 적혀 있다. 귀환 예정일까지. 소환 40일째 되는 날이다. 아직 아무것도 하지 않았는데. 세라가 함께라면 그녀도 처음 보는 기록에 혼란스러워한다.\n\n이 장면에 심을 복선: 금서고 장부의 아홉 번째 줄에 이미 적혀 있는 주인공의 이름과 '귀환 예정일'(소환 40일째).\n회수: 연회에서 오르텐이 발표한 의식 날짜가 그 날짜와 정확히 같다. 처음부터 정해져 있었다.\n\n이 장면에 심을 복선: 다른 용사들은 모두 '빛이 되어 돌아가다'인데, 첫 번째 용사의 줄만 '안개를 건너와 스스로 불이 되다'. 사람들은 '대성등을 밝혔다'는 비유로 읽는다.\n회수: 첫 번째 용사만은 소환된 것이 아니라 스스로 등불이 되었고, 원래는 아무도 태우지 않는 등불을 설계했다는 사실을 오르텐이 털어놓는다.\n\n장면 제약: 장부의 어떤 줄에도 '태운다', '연료'라는 말은 없다. 기록은 경건한 표현으로만 쓰여 있다.",
        "required": true,
        "sequence": 5,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e06_angel",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e05_archive-c1",
            "description": "주인공이 금서고에서 역대 용사들의 소환·귀환 기록을 직접 읽는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e05_archive-c2",
            "description": "주인공이 아홉 번째 줄에 자신의 이름과 이미 정해진 귀환 예정일이 적혀 있는 것을 본다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e05_archive-c3",
            "description": "주인공이 금서고를 빠져나오거나, 들켰다면 그 상황이 수습된다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e05_archive-constraints",
            "description": "장부의 어떤 줄에도 '태운다', '연료'라는 말은 없다. 기록은 경건한 표현으로만 쓰여 있다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "금서고의 아홉 번째 줄",
        "summary": "의문을 품은 주인공은 역대 용사의 기록을 찾아 신전의 금서고에 들어가려 한다. 세라에게 털어놓고 함께 갈 수도, 혼자 몰래 숨어들 수도 있다.\n오래된 장부에는 역대 용사 여덟 명의 기록이 있다. 소환된 일곱 명은 소환된 날과 귀환한 날이 적혀 있고, 모두 '빛이 되어 돌아가다'라는 경건한 문구로 끝난다. 기록을 맞춰 보면 규칙이 보인다. 스물여덟 해 남짓마다 한 명, 그리고 용사가 귀환한 다음 날마다 '대성등이 다시 밝아졌다'는 기록. 첫 번째 용사의 줄만 문구가 다르다. '안개를 건너와 스스로 불이 되다'. 사람들은 그것을 '대성등을 밝혔다'는 비유로 읽어 왔다.\n장부의 마지막, 아홉 번째 줄에는 이미 주인공의 이름이 적혀 있다. 귀환 예정일까지. 소환 40일째 되는 날이다. 아직 아무것도 하지 않았는데. 세라가 함께라면 그녀도 처음 보는 기록에 혼란스러워한다.\n\n이 장면에 심을 복선: 금서고 장부의 아홉 번째 줄에 이미 적혀 있는 주인공의 이름과 '귀환 예정일'(소환 40일째).\n회수: 연회에서 오르텐이 발표한 의식 날짜가 그 날짜와 정확히 같다. 처음부터 정해져 있었다.\n\n이 장면에 심을 복선: 다른 용사들은 모두 '빛이 되어 돌아가다'인데, 첫 번째 용사의 줄만 '안개를 건너와 스스로 불이 되다'. 사람들은 '대성등을 밝혔다'는 비유로 읽는다.\n회수: 첫 번째 용사만은 소환된 것이 아니라 스스로 등불이 되었고, 원래는 아무도 태우지 않는 등불을 설계했다는 사실을 오르텐이 털어놓는다.\n\n장면 제약: 장부의 어떤 줄에도 '태운다', '연료'라는 말은 없다. 기록은 경건한 표현으로만 쓰여 있다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 금서고에서 역대 용사들의 소환·귀환 기록을 직접 읽는다.\n\n주인공이 아홉 번째 줄에 자신의 이름과 이미 정해진 귀환 예정일이 적혀 있는 것을 본다.\n\n주인공이 금서고를 빠져나오거나, 들켰다면 그 상황이 수습된다.",
          "selectionScope": "",
          "constraints": "장부의 어떤 줄에도 '태운다', '연료'라는 말은 없다. 기록은 경건한 표현으로만 쓰여 있다.",
          "success": "",
          "unmet": "금서고에 들어가지 못하면, 세라가 사제 교육용으로 베껴 둔 '역대 용사 연대기' 사본을 보여 주어 같은 기록과 아홉 번째 줄을 확인하게 된다.",
          "closureConditions": [
            {
              "id": "e05_archive-c1",
              "text": "주인공이 금서고에서 역대 용사들의 소환·귀환 기록을 직접 읽는다."
            },
            {
              "id": "e05_archive-c2",
              "text": "주인공이 아홉 번째 줄에 자신의 이름과 이미 정해진 귀환 예정일이 적혀 있는 것을 본다."
            },
            {
              "id": "e05_archive-c3",
              "text": "주인공이 금서고를 빠져나오거나, 들켰다면 그 상황이 수습된다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e05_archive-constraints",
            "description": "장부의 어떤 줄에도 '태운다', '연료'라는 말은 없다. 기록은 경건한 표현으로만 쓰여 있다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e06_angel",
        "name": "천사라고 불러 줘",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 바르트를 찾지 않으면, 바르트가 술병을 들고 먼저 찾아와 '애송이, 할 얘기가 있다'며 같은 이야기를 꺼낸다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "밤, 기사단 숙소 뒤 마구간이나 성벽 위. 술에 취한 바르트와 마주친다. 평소 용사를 피하던 그가 처음으로 스물일곱 해 전 이야기를 꺼낸다. 열다섯 살 종자였던 시절 모셨던 여덟 번째 용사. 다른 세계에서 온 열일곱 살 소녀였고, 꿀사탕을 좋아했고, 자기를 '천사'라고 부르라 했다는 사람. 숫자로는 '1004'라고 썼다고 한다. 바르트가 가끔 중얼거리던 낯선 말들('괜찮아', '빨리빨리')은 그녀에게 배운 것이었다.\n그리고 귀환의 날, 귀환문 앞에서 그녀가 비명을 지르며 마지막으로 돌아보던 얼굴. \"그건 집에 가는 얼굴이 아니었다.\" 바르트는 그녀의 이름만은 끝내 입에 올리지 않고(부르면 정말 죽은 사람이 되는 것 같아서), 목에 걸고 있던 하트 모양 플라스틱 머리핀을 주인공에게 건넨다. 주인공은 사진 속 이모의 머리핀을 떠올릴 수 있다. 1998년, 열일곱 살, 1004. 맞춰지는 조각들.\n\n이 장면에 심을 복선: 바르트가 건네는 하트 모양 플라스틱 머리핀. 사진 속 이모가 꽂고 있던 것과 같다.\n회수: 안개의 왕의 머리, 머리핀이 있어야 할 자리가 비어 있다. 주인공이 머리핀을 내밀면 그녀는 자신이 누구였는지 떠올린다.\n\n이 장면에서 회수할 복선: 상태창 맨 아래 한순간 스친 뭉개진 숫자 '1004'. 엄마가 편지 끝에 쓰던 숫자와 같다.\n「빛의 연회」에서 [8282], [도망쳐]와 함께 다시 나타난다.\n회수: 바르트가 여덟 번째 용사가 자기를 '천사(1004)'라 불렀다고 말한다. 상태창에 끼어든 것이 그녀였음을 짐작하게 된다.\n\n이 장면에서 회수할 복선: 바르트가 겁먹은 주인공에게 던지는 번역되지 않은 말 '괜찮아', 다급할 때 외치는 '빨리빨리'.\n회수: 여덟 번째 용사에게 배운 말이었다.\n\n장면 제약: 바르트는 여덟 번째 용사의 이름을 말하지 않는다. 문 너머에서 무슨 일이 있었는지 그는 정확히 모르며, 아는 척하지 않는다.",
        "required": true,
        "sequence": 6,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e07_feast",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e06_angel-c1",
            "description": "바르트가 여덟 번째 용사에 대한 기억을 주인공에게 이야기한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e06_angel-c2",
            "description": "바르트가 그 용사가 스스로를 부르던 별명과, 그 별명을 숫자로 쓰던 방식을 말한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e06_angel-c3",
            "description": "바르트가 귀환문 앞에서 그 용사가 보인 마지막 모습을 증언한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e06_angel-c4",
            "description": "바르트가 목에 걸고 다니던 물건을 주인공에게 건넨다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e06_angel-constraints",
            "description": "바르트는 여덟 번째 용사의 이름을 말하지 않는다. 문 너머에서 무슨 일이 있었는지 그는 정확히 모르며, 아는 척하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "천사라고 불러 줘",
        "summary": "밤, 기사단 숙소 뒤 마구간이나 성벽 위. 술에 취한 바르트와 마주친다. 평소 용사를 피하던 그가 처음으로 스물일곱 해 전 이야기를 꺼낸다. 열다섯 살 종자였던 시절 모셨던 여덟 번째 용사. 다른 세계에서 온 열일곱 살 소녀였고, 꿀사탕을 좋아했고, 자기를 '천사'라고 부르라 했다는 사람. 숫자로는 '1004'라고 썼다고 한다. 바르트가 가끔 중얼거리던 낯선 말들('괜찮아', '빨리빨리')은 그녀에게 배운 것이었다.\n그리고 귀환의 날, 귀환문 앞에서 그녀가 비명을 지르며 마지막으로 돌아보던 얼굴. \"그건 집에 가는 얼굴이 아니었다.\" 바르트는 그녀의 이름만은 끝내 입에 올리지 않고(부르면 정말 죽은 사람이 되는 것 같아서), 목에 걸고 있던 하트 모양 플라스틱 머리핀을 주인공에게 건넨다. 주인공은 사진 속 이모의 머리핀을 떠올릴 수 있다. 1998년, 열일곱 살, 1004. 맞춰지는 조각들.\n\n이 장면에 심을 복선: 바르트가 건네는 하트 모양 플라스틱 머리핀. 사진 속 이모가 꽂고 있던 것과 같다.\n회수: 안개의 왕의 머리, 머리핀이 있어야 할 자리가 비어 있다. 주인공이 머리핀을 내밀면 그녀는 자신이 누구였는지 떠올린다.\n\n이 장면에서 회수할 복선: 상태창 맨 아래 한순간 스친 뭉개진 숫자 '1004'. 엄마가 편지 끝에 쓰던 숫자와 같다.\n「빛의 연회」에서 [8282], [도망쳐]와 함께 다시 나타난다.\n회수: 바르트가 여덟 번째 용사가 자기를 '천사(1004)'라 불렀다고 말한다. 상태창에 끼어든 것이 그녀였음을 짐작하게 된다.\n\n이 장면에서 회수할 복선: 바르트가 겁먹은 주인공에게 던지는 번역되지 않은 말 '괜찮아', 다급할 때 외치는 '빨리빨리'.\n회수: 여덟 번째 용사에게 배운 말이었다.\n\n장면 제약: 바르트는 여덟 번째 용사의 이름을 말하지 않는다. 문 너머에서 무슨 일이 있었는지 그는 정확히 모르며, 아는 척하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "바르트가 여덟 번째 용사에 대한 기억을 주인공에게 이야기한다.\n\n바르트가 그 용사가 스스로를 부르던 별명과, 그 별명을 숫자로 쓰던 방식을 말한다.\n\n바르트가 귀환문 앞에서 그 용사가 보인 마지막 모습을 증언한다.\n\n바르트가 목에 걸고 다니던 물건을 주인공에게 건넨다.",
          "selectionScope": "",
          "constraints": "바르트는 여덟 번째 용사의 이름을 말하지 않는다. 문 너머에서 무슨 일이 있었는지 그는 정확히 모르며, 아는 척하지 않는다.",
          "success": "",
          "unmet": "주인공이 바르트를 찾지 않으면, 바르트가 술병을 들고 먼저 찾아와 '애송이, 할 얘기가 있다'며 같은 이야기를 꺼낸다.",
          "closureConditions": [
            {
              "id": "e06_angel-c1",
              "text": "바르트가 여덟 번째 용사에 대한 기억을 주인공에게 이야기한다."
            },
            {
              "id": "e06_angel-c2",
              "text": "바르트가 그 용사가 스스로를 부르던 별명과, 그 별명을 숫자로 쓰던 방식을 말한다."
            },
            {
              "id": "e06_angel-c3",
              "text": "바르트가 귀환문 앞에서 그 용사가 보인 마지막 모습을 증언한다."
            },
            {
              "id": "e06_angel-c4",
              "text": "바르트가 목에 걸고 다니던 물건을 주인공에게 건넨다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e06_angel-constraints",
            "description": "바르트는 여덟 번째 용사의 이름을 말하지 않는다. 문 너머에서 무슨 일이 있었는지 그는 정확히 모르며, 아는 척하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e07_feast",
        "name": "빛의 연회",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 연회를 피하면, 오르텐이 직접 객실로 찾아와 발표 내용을 전하고 꿀사탕을 남기며, 상태창의 이상은 그날 밤 혼자 있을 때 일어난다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "주인공의 활약을 기리는 '빛의 연회'가 신전 대광장에서 열린다. 귀족과 사제, 기사들이 모이고, 세라는 귀환가를 연습한다. 연회의 끝에 대신관 오르텐이 안개 심부 원정과 '귀환 의식'의 날짜를 성대하게 발표한다. 그 날짜는 금서고 장부의 아홉 번째 줄에 적혀 있던 바로 그 날짜다.\n오르텐은 따로 주인공을 불러 꿀사탕을 건네며 다정하게 묻는다. \"고향에 돌아가면 무엇을 하고 싶으냐.\" 기침을 감추는 손수건에 잿빛 얼룩이 묻어 있다. 부신관 카시안은 그 곁에서 \"등불에 감정은 사치입니다\"라며 차갑게 일정을 정리한다.\n연회가 한창일 때 주인공의 상태창에 깨진 글자가 번진다. 귀환 게이지 위로 아주 잠깐 겹쳐 보이는 다른 이름, '연소 준비도'. 그리고 [8282], [도망쳐]. 게이지가 높을수록 잡음은 선명하다. 화려함과 불길함이 동시에 커지는 사건.\n\n이 장면에 심을 복선: 연회에서 부신관 카시안이 차갑게 내뱉는 말. '등불에 감정은 사치입니다.' 오르텐의 꿀사탕을 못마땅하게 보는 시선.\n회수: 오르텐이 갇힌 뒤, 카시안은 감정 없이 열 번째 소환진을 그린다.\n\n이 장면에 심을 복선: 오르텐이 기침을 감추는 손수건의 잿빛 얼룩, 살짝 잿빛인 손가락 끝.\n회수: 그는 폐가 잿빛으로 굳는 병으로 죽어 가고 있었고, 그래서 의식을 서둘렀다. 감옥에서 자신의 영혼을 등불에 보태 달라고 부탁한다.\n\n이 장면에서 회수할 복선: 상태창의 '귀환 게이지 0%'. 잔향을 벨수록 차오르는, 집으로 가는 진행도처럼 보이는 수치.\n회수: 연회에서 게이지 위로 '연소 준비도'라는 진짜 이름이 겹쳐 보인다. 「세라의 수첩」의 장부 '숙성도 60에 이르면 즉시 점화'로 의미가 확정된다.\n\n이 장면에서 회수할 복선: 금서고 장부의 아홉 번째 줄에 이미 적혀 있는 주인공의 이름과 '귀환 예정일'(소환 40일째).\n회수: 연회에서 오르텐이 발표한 의식 날짜가 그 날짜와 정확히 같다. 처음부터 정해져 있었다.\n\n장면 제약: 오르텐은 이 사건에서 진실을 인정하지 않는다. 추궁을 받으면 다정하게 웃으며 화제를 돌린다. 카시안은 필요 이상으로 말하지 않는다.",
        "required": true,
        "sequence": 7,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e08_heart",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e07_feast-c1",
            "description": "오르텐이 공개적으로 안개 심부 원정과 귀환 의식의 날짜를 발표한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e07_feast-c2",
            "description": "오르텐이 주인공과 따로 이야기하며 고향에 돌아가면 무엇을 하고 싶은지 묻는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e07_feast-c3",
            "description": "주인공의 상태창에 귀환 게이지와 겹쳐 다른 글자가 잠깐 나타났다 사라진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e07_feast-constraints",
            "description": "오르텐은 이 사건에서 진실을 인정하지 않는다. 추궁을 받으면 다정하게 웃으며 화제를 돌린다. 카시안은 필요 이상으로 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "빛의 연회",
        "summary": "주인공의 활약을 기리는 '빛의 연회'가 신전 대광장에서 열린다. 귀족과 사제, 기사들이 모이고, 세라는 귀환가를 연습한다. 연회의 끝에 대신관 오르텐이 안개 심부 원정과 '귀환 의식'의 날짜를 성대하게 발표한다. 그 날짜는 금서고 장부의 아홉 번째 줄에 적혀 있던 바로 그 날짜다.\n오르텐은 따로 주인공을 불러 꿀사탕을 건네며 다정하게 묻는다. \"고향에 돌아가면 무엇을 하고 싶으냐.\" 기침을 감추는 손수건에 잿빛 얼룩이 묻어 있다. 부신관 카시안은 그 곁에서 \"등불에 감정은 사치입니다\"라며 차갑게 일정을 정리한다.\n연회가 한창일 때 주인공의 상태창에 깨진 글자가 번진다. 귀환 게이지 위로 아주 잠깐 겹쳐 보이는 다른 이름, '연소 준비도'. 그리고 [8282], [도망쳐]. 게이지가 높을수록 잡음은 선명하다. 화려함과 불길함이 동시에 커지는 사건.\n\n이 장면에 심을 복선: 연회에서 부신관 카시안이 차갑게 내뱉는 말. '등불에 감정은 사치입니다.' 오르텐의 꿀사탕을 못마땅하게 보는 시선.\n회수: 오르텐이 갇힌 뒤, 카시안은 감정 없이 열 번째 소환진을 그린다.\n\n이 장면에 심을 복선: 오르텐이 기침을 감추는 손수건의 잿빛 얼룩, 살짝 잿빛인 손가락 끝.\n회수: 그는 폐가 잿빛으로 굳는 병으로 죽어 가고 있었고, 그래서 의식을 서둘렀다. 감옥에서 자신의 영혼을 등불에 보태 달라고 부탁한다.\n\n이 장면에서 회수할 복선: 상태창의 '귀환 게이지 0%'. 잔향을 벨수록 차오르는, 집으로 가는 진행도처럼 보이는 수치.\n회수: 연회에서 게이지 위로 '연소 준비도'라는 진짜 이름이 겹쳐 보인다. 「세라의 수첩」의 장부 '숙성도 60에 이르면 즉시 점화'로 의미가 확정된다.\n\n이 장면에서 회수할 복선: 금서고 장부의 아홉 번째 줄에 이미 적혀 있는 주인공의 이름과 '귀환 예정일'(소환 40일째).\n회수: 연회에서 오르텐이 발표한 의식 날짜가 그 날짜와 정확히 같다. 처음부터 정해져 있었다.\n\n장면 제약: 오르텐은 이 사건에서 진실을 인정하지 않는다. 추궁을 받으면 다정하게 웃으며 화제를 돌린다. 카시안은 필요 이상으로 말하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "오르텐이 공개적으로 안개 심부 원정과 귀환 의식의 날짜를 발표한다.\n\n오르텐이 주인공과 따로 이야기하며 고향에 돌아가면 무엇을 하고 싶은지 묻는다.\n\n주인공의 상태창에 귀환 게이지와 겹쳐 다른 글자가 잠깐 나타났다 사라진다.",
          "selectionScope": "",
          "constraints": "오르텐은 이 사건에서 진실을 인정하지 않는다. 추궁을 받으면 다정하게 웃으며 화제를 돌린다. 카시안은 필요 이상으로 말하지 않는다.",
          "success": "",
          "unmet": "주인공이 연회를 피하면, 오르텐이 직접 객실로 찾아와 발표 내용을 전하고 꿀사탕을 남기며, 상태창의 이상은 그날 밤 혼자 있을 때 일어난다.",
          "closureConditions": [
            {
              "id": "e07_feast-c1",
              "text": "오르텐이 공개적으로 안개 심부 원정과 귀환 의식의 날짜를 발표한다."
            },
            {
              "id": "e07_feast-c2",
              "text": "오르텐이 주인공과 따로 이야기하며 고향에 돌아가면 무엇을 하고 싶은지 묻는다."
            },
            {
              "id": "e07_feast-c3",
              "text": "주인공의 상태창에 귀환 게이지와 겹쳐 다른 글자가 잠깐 나타났다 사라진다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e07_feast-constraints",
            "description": "오르텐은 이 사건에서 진실을 인정하지 않는다. 추궁을 받으면 다정하게 웃으며 화제를 돌린다. 카시안은 필요 이상으로 말하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e08_heart",
        "name": "안개의 심장",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 안개의 왕을 알아보지 못하면, 그녀가 물러나며 \"언니한테… 미안하다고 해 줘. 1004.\"라는 한국어를 남겨 정체를 짐작하게 한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "기사단과 함께 안개 심부로 향하는 원정. 세라도 등불 사제로 동행한다. 빛이 닿지 않는 깊이로 갈수록 잔향은 크고 오래되며, 말투가 낯설어진다. 일제강점기 말투, 조선시대 말투(\"어마님…\", \"고향에 가고 싶소…\").\n원정대는 마침내 안개의 왕과 마주한다. 1990년대 한국 여고 교복의 실루엣, 얼굴 절반의 금빛 균열, 비어 있는 머리핀 자리. 그녀는 기사들을 쓰러뜨리지만 주인공만은 해치지 않고, 조각난 말로 경고한다. \"8282… 빨리 가…\", \"그 문은… 집으로 가는 문이 아니야.\" 그녀는 전래 자장가를 흥얼거리고, 꿀사탕 냄새에 멈칫한다. 주인공이 '찾았다'를 들었던 그 목소리임을 알아챌 수도 있다.\n주인공이 그녀에게 무엇을 내미느냐(머리핀, 꿀사탕, 자장가, 엄마의 편지, '이모'라는 부름), 혹은 검을 드느냐에 따라 이 만남은 전혀 다른 의미가 된다. 그녀가 자신이 누구였는지 떠올리면, 주인공은 그녀가 이모 한소이라는 것을 확인한다. \"내가 너를 불렀어. 미안해.\" 그녀는 끝까지 함께 가자는 손을 잡지 못하고 안개 속으로 물러난다. 세라는 이 모든 것을 곁에서 보고 믿음이 흔들린다. 첫 번째 이야기의 가장 큰 진실이 드러나는 사건.\n\n이 장면에서 회수할 복선: 오르텐이 건네는 노란 꿀사탕('옛 용사님께 배운 맛이라네'), 그리고 도하 주머니 속 엄마가 챙겨 준 꿀사탕 두 개('이모가 좋아하던 거').\n회수: 안개의 왕이 꿀사탕 냄새에 멈칫한다. 도하가 엄마의 꿀사탕을 건네면 그녀는 처음으로 웃는다. 오르텐이 그 맛을 누구에게 배웠는지도 함께 드러난다.\n\n이 장면에서 회수할 복선: 등외구에서 피오의 할머니가 부르는 '용사의 자장가'. 엄마가 불러 주던 전래 자장가와 같은 가락이다.\n회수: 안개의 왕이 같은 자장가를 흥얼거린다. 두 번째 이야기에서 첫 번째 용사가 가르친 노래였음이 밝혀지고, 「강 건너의 자장가」에서 다온에게 닿는 목소리가 된다.\n\n이 장면에서 회수할 복선: 원정에서 돌아오는 기사들의 수군거림. '안개의 왕은 이상한 옷을 입은 소녀 모양이었다.'\n회수: 그 '이상한 옷'은 1990년대 한국 여고 교복이다.\n\n이 장면에서 회수할 복선: 바르트가 건네는 하트 모양 플라스틱 머리핀. 사진 속 이모가 꽂고 있던 것과 같다.\n회수: 안개의 왕의 머리, 머리핀이 있어야 할 자리가 비어 있다. 주인공이 머리핀을 내밀면 그녀는 자신이 누구였는지 떠올린다.\n\n이 장면에서 회수할 복선: 소환 직전 강가에서 들린 아주 반가운 목소리. '……찾았다.' 주인공은 처음에 소환진을 그린 신전의 목소리라고 생각한다.\n회수: 그것은 대성등 안에서 언니 가족의 부름을 듣고 손을 뻗은 이모의 목소리였다. '내가 너를 불렀어. 미안해.'\n\n장면 제약: 안개의 왕은 주인공을 죽이거나 크게 다치게 하지 않는다. 그녀는 대성등을 직접 부수지 않는다. 세라는 이 원정에서 죽지 않는다.",
        "required": true,
        "sequence": 8,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e09_ledger",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e08_heart-c1",
            "description": "원정대가 안개 심부로 들어가 오래된 잔향들을 지나 안개의 왕과 마주한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e08_heart-c2",
            "description": "안개의 왕이 주인공에게 귀환문에 대해 경고한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e08_heart-c3",
            "description": "주인공이 안개의 왕의 정체를 알아보거나, 그녀가 스스로 누구였는지 떠올리는 순간이 장면에 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e08_heart-c4",
            "description": "안개의 왕이 안개 속으로 물러나고, 원정대가 성도로 철수한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e08_heart-constraints",
            "description": "안개의 왕은 주인공을 죽이거나 크게 다치게 하지 않는다. 그녀는 대성등을 직접 부수지 않는다. 세라는 이 원정에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [
          "한소이"
        ],
        "title": "안개의 심장",
        "summary": "기사단과 함께 안개 심부로 향하는 원정. 세라도 등불 사제로 동행한다. 빛이 닿지 않는 깊이로 갈수록 잔향은 크고 오래되며, 말투가 낯설어진다. 일제강점기 말투, 조선시대 말투(\"어마님…\", \"고향에 가고 싶소…\").\n원정대는 마침내 안개의 왕과 마주한다. 1990년대 한국 여고 교복의 실루엣, 얼굴 절반의 금빛 균열, 비어 있는 머리핀 자리. 그녀는 기사들을 쓰러뜨리지만 주인공만은 해치지 않고, 조각난 말로 경고한다. \"8282… 빨리 가…\", \"그 문은… 집으로 가는 문이 아니야.\" 그녀는 전래 자장가를 흥얼거리고, 꿀사탕 냄새에 멈칫한다. 주인공이 '찾았다'를 들었던 그 목소리임을 알아챌 수도 있다.\n주인공이 그녀에게 무엇을 내미느냐(머리핀, 꿀사탕, 자장가, 엄마의 편지, '이모'라는 부름), 혹은 검을 드느냐에 따라 이 만남은 전혀 다른 의미가 된다. 그녀가 자신이 누구였는지 떠올리면, 주인공은 그녀가 이모 한소이라는 것을 확인한다. \"내가 너를 불렀어. 미안해.\" 그녀는 끝까지 함께 가자는 손을 잡지 못하고 안개 속으로 물러난다. 세라는 이 모든 것을 곁에서 보고 믿음이 흔들린다. 첫 번째 이야기의 가장 큰 진실이 드러나는 사건.\n\n이 장면에서 회수할 복선: 오르텐이 건네는 노란 꿀사탕('옛 용사님께 배운 맛이라네'), 그리고 도하 주머니 속 엄마가 챙겨 준 꿀사탕 두 개('이모가 좋아하던 거').\n회수: 안개의 왕이 꿀사탕 냄새에 멈칫한다. 도하가 엄마의 꿀사탕을 건네면 그녀는 처음으로 웃는다. 오르텐이 그 맛을 누구에게 배웠는지도 함께 드러난다.\n\n이 장면에서 회수할 복선: 등외구에서 피오의 할머니가 부르는 '용사의 자장가'. 엄마가 불러 주던 전래 자장가와 같은 가락이다.\n회수: 안개의 왕이 같은 자장가를 흥얼거린다. 두 번째 이야기에서 첫 번째 용사가 가르친 노래였음이 밝혀지고, 「강 건너의 자장가」에서 다온에게 닿는 목소리가 된다.\n\n이 장면에서 회수할 복선: 원정에서 돌아오는 기사들의 수군거림. '안개의 왕은 이상한 옷을 입은 소녀 모양이었다.'\n회수: 그 '이상한 옷'은 1990년대 한국 여고 교복이다.\n\n이 장면에서 회수할 복선: 바르트가 건네는 하트 모양 플라스틱 머리핀. 사진 속 이모가 꽂고 있던 것과 같다.\n회수: 안개의 왕의 머리, 머리핀이 있어야 할 자리가 비어 있다. 주인공이 머리핀을 내밀면 그녀는 자신이 누구였는지 떠올린다.\n\n이 장면에서 회수할 복선: 소환 직전 강가에서 들린 아주 반가운 목소리. '……찾았다.' 주인공은 처음에 소환진을 그린 신전의 목소리라고 생각한다.\n회수: 그것은 대성등 안에서 언니 가족의 부름을 듣고 손을 뻗은 이모의 목소리였다. '내가 너를 불렀어. 미안해.'\n\n장면 제약: 안개의 왕은 주인공을 죽이거나 크게 다치게 하지 않는다. 그녀는 대성등을 직접 부수지 않는다. 세라는 이 원정에서 죽지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "원정대가 안개 심부로 들어가 오래된 잔향들을 지나 안개의 왕과 마주한다.\n\n안개의 왕이 주인공에게 귀환문에 대해 경고한다.\n\n주인공이 안개의 왕의 정체를 알아보거나, 그녀가 스스로 누구였는지 떠올리는 순간이 장면에 드러난다.\n\n안개의 왕이 안개 속으로 물러나고, 원정대가 성도로 철수한다.",
          "selectionScope": "",
          "constraints": "안개의 왕은 주인공을 죽이거나 크게 다치게 하지 않는다. 그녀는 대성등을 직접 부수지 않는다. 세라는 이 원정에서 죽지 않는다.",
          "success": "",
          "unmet": "주인공이 안개의 왕을 알아보지 못하면, 그녀가 물러나며 \"언니한테… 미안하다고 해 줘. 1004.\"라는 한국어를 남겨 정체를 짐작하게 한다.",
          "closureConditions": [
            {
              "id": "e08_heart-c1",
              "text": "원정대가 안개 심부로 들어가 오래된 잔향들을 지나 안개의 왕과 마주한다."
            },
            {
              "id": "e08_heart-c2",
              "text": "안개의 왕이 주인공에게 귀환문에 대해 경고한다."
            },
            {
              "id": "e08_heart-c3",
              "text": "주인공이 안개의 왕의 정체를 알아보거나, 그녀가 스스로 누구였는지 떠올리는 순간이 장면에 드러난다."
            },
            {
              "id": "e08_heart-c4",
              "text": "안개의 왕이 안개 속으로 물러나고, 원정대가 성도로 철수한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e08_heart-constraints",
            "description": "안개의 왕은 주인공을 죽이거나 크게 다치게 하지 않는다. 그녀는 대성등을 직접 부수지 않는다. 세라는 이 원정에서 죽지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e09_ledger",
        "name": "세라의 수첩",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 장부를 직접 확인하지 못하면, 세라가 수첩 마지막 장에 몰래 베껴 둔 장부의 한 줄을 보여 준다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "원정에서 돌아온 밤. 세라는 하루도 빠짐없이 적어 온 작은 수첩을 쥐고 주인공 앞에 선다(혹은 주인공이 그 수첩의 비밀을 먼저 알아챈다). 그 수첩은 매일 밤 대신관에게 올라가던 보고서였다. 세라는 그것이 '용사님이 향수병에 걸리지 않게 살피는 일'인 줄로만 알았다.\n대신관 집무실의 장부. 주인공이나 세라가 그것을 확인하면 아홉 번째 용사의 줄에 적힌 말을 보게 된다. '아홉 번째 연료. 숙성도 60에 이르면 즉시 점화.' 대성등이 무엇을 태워 빛나는지가 확정되는 순간이다. 세라는 부모를 앗아 간 안개와, 그 안개를 막아 준 등불의 정체 사이에서 무너진다.\n진실 앞에서 세라는 선택해야 한다. 주인공의 편에 설지, 신전에 보고할지. 그것은 지금까지 주인공이 그녀에게 보여 준 모습에 달려 있다. 이 자리에서 진심으로 그녀를 설득할 기회도 있다.\n\n이 장면에서 회수할 복선: 세라가 무엇이든 받아 적는 작은 가죽 수첩('용사님 관찰 일지예요!'). 밤마다 수첩을 들고 어딘가로 가는 모습이 한두 번 비친다.\n회수: 그 수첩은 매일 밤 오르텐에게 올라가던 보고서였다.\n\n장면 제약: 세라는 주인공에게 거짓말을 하지 않는다. 오르텐은 이 사건에 직접 나타나지 않는다.",
        "required": true,
        "sequence": 9,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e10a_vigil",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e09_ledger-c1",
            "description": "세라의 수첩이 매일 대신관에게 전해지던 보고서였다는 사실이 밝혀진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e09_ledger-c2",
            "description": "주인공이나 세라가 대신관의 장부에서 아홉 번째 용사에 대한 기록을 확인한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e09_ledger-c3",
            "description": "세라가 자신이 어느 쪽에 설지를 행동으로 드러낸다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e09_ledger-constraints",
            "description": "세라는 주인공에게 거짓말을 하지 않는다. 오르텐은 이 사건에 직접 나타나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "세라의 수첩",
        "summary": "원정에서 돌아온 밤. 세라는 하루도 빠짐없이 적어 온 작은 수첩을 쥐고 주인공 앞에 선다(혹은 주인공이 그 수첩의 비밀을 먼저 알아챈다). 그 수첩은 매일 밤 대신관에게 올라가던 보고서였다. 세라는 그것이 '용사님이 향수병에 걸리지 않게 살피는 일'인 줄로만 알았다.\n대신관 집무실의 장부. 주인공이나 세라가 그것을 확인하면 아홉 번째 용사의 줄에 적힌 말을 보게 된다. '아홉 번째 연료. 숙성도 60에 이르면 즉시 점화.' 대성등이 무엇을 태워 빛나는지가 확정되는 순간이다. 세라는 부모를 앗아 간 안개와, 그 안개를 막아 준 등불의 정체 사이에서 무너진다.\n진실 앞에서 세라는 선택해야 한다. 주인공의 편에 설지, 신전에 보고할지. 그것은 지금까지 주인공이 그녀에게 보여 준 모습에 달려 있다. 이 자리에서 진심으로 그녀를 설득할 기회도 있다.\n\n이 장면에서 회수할 복선: 세라가 무엇이든 받아 적는 작은 가죽 수첩('용사님 관찰 일지예요!'). 밤마다 수첩을 들고 어딘가로 가는 모습이 한두 번 비친다.\n회수: 그 수첩은 매일 밤 오르텐에게 올라가던 보고서였다.\n\n장면 제약: 세라는 주인공에게 거짓말을 하지 않는다. 오르텐은 이 사건에 직접 나타나지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "세라의 수첩이 매일 대신관에게 전해지던 보고서였다는 사실이 밝혀진다.\n\n주인공이나 세라가 대신관의 장부에서 아홉 번째 용사에 대한 기록을 확인한다.\n\n세라가 자신이 어느 쪽에 설지를 행동으로 드러낸다.",
          "selectionScope": "",
          "constraints": "세라는 주인공에게 거짓말을 하지 않는다. 오르텐은 이 사건에 직접 나타나지 않는다.",
          "success": "",
          "unmet": "장부를 직접 확인하지 못하면, 세라가 수첩 마지막 장에 몰래 베껴 둔 장부의 한 줄을 보여 준다.",
          "closureConditions": [
            {
              "id": "e09_ledger-c1",
              "text": "세라의 수첩이 매일 대신관에게 전해지던 보고서였다는 사실이 밝혀진다."
            },
            {
              "id": "e09_ledger-c2",
              "text": "주인공이나 세라가 대신관의 장부에서 아홉 번째 용사에 대한 기록을 확인한다."
            },
            {
              "id": "e09_ledger-c3",
              "text": "세라가 자신이 어느 쪽에 설지를 행동으로 드러낸다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e09_ledger-constraints",
            "description": "세라는 주인공에게 거짓말을 하지 않는다. 오르텐은 이 사건에 직접 나타나지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e10a_vigil",
        "name": "등불을 끄는 밤",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 동료를 다 모으지 못해도, 세라와 단둘이 세운 계획으로 의식 날 아침을 맞는다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "세라가 주인공의 편에 섰다. 의식까지 남은 시간은 얼마 없다. 바르트, 메이블, 피오. 지금까지 만난 사람들을 모아 귀환 의식 날의 계획을 세운다. 의식을 어떻게 멈출지, 사람들 앞에서 무엇을 증명할지(결정 속 한글, 장부, 바르트의 증언, 스마트폰 녹음이나 사진), 대성등이 흔들리면 등외구를 어떻게 지킬지. 피오는 탑 밑까지 이어지는 옛 배수로 통로를 안다.\n각자가 할 수 있는 일과 지켜야 할 것이 부딪친다. 메이블은 '등불이 꺼지면 30만 명이 죽는다'는 계산을 숨기지 않는다. 바르트는 이번에는 지키겠다고 말한다. 의식 전야, 세라는 귀환가 대신 부를 노래를 고민한다. 그리고 의식 날 아침, 신전의 부름이 온다.\n\n장면 제약: 동료들은 주인공의 계획을 무조건 따르지 않는다. 각자 자기 판단으로 동의하거나 조건을 건다.",
        "required": true,
        "sequence": 10,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e11_gate",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e10a_vigil-c1",
            "description": "주인공이 세라와 함께 동료들을 모아 귀환 의식 날의 계획을 세운다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e10a_vigil-c2",
            "description": "계획의 대가, 곧 대성등이 흔들리면 성도가 위험해진다는 것이 장면에서 분명히 언급된다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e10a_vigil-c3",
            "description": "의식 날 아침, 주인공이 신전의 부름을 받아 의식장으로 향한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e10a_vigil-constraints",
            "description": "동료들은 주인공의 계획을 무조건 따르지 않는다. 각자 자기 판단으로 동의하거나 조건을 건다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "등불을 끄는 밤",
        "summary": "세라가 주인공의 편에 섰다. 의식까지 남은 시간은 얼마 없다. 바르트, 메이블, 피오. 지금까지 만난 사람들을 모아 귀환 의식 날의 계획을 세운다. 의식을 어떻게 멈출지, 사람들 앞에서 무엇을 증명할지(결정 속 한글, 장부, 바르트의 증언, 스마트폰 녹음이나 사진), 대성등이 흔들리면 등외구를 어떻게 지킬지. 피오는 탑 밑까지 이어지는 옛 배수로 통로를 안다.\n각자가 할 수 있는 일과 지켜야 할 것이 부딪친다. 메이블은 '등불이 꺼지면 30만 명이 죽는다'는 계산을 숨기지 않는다. 바르트는 이번에는 지키겠다고 말한다. 의식 전야, 세라는 귀환가 대신 부를 노래를 고민한다. 그리고 의식 날 아침, 신전의 부름이 온다.\n\n장면 제약: 동료들은 주인공의 계획을 무조건 따르지 않는다. 각자 자기 판단으로 동의하거나 조건을 건다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 세라와 함께 동료들을 모아 귀환 의식 날의 계획을 세운다.\n\n계획의 대가, 곧 대성등이 흔들리면 성도가 위험해진다는 것이 장면에서 분명히 언급된다.\n\n의식 날 아침, 주인공이 신전의 부름을 받아 의식장으로 향한다.",
          "selectionScope": "",
          "constraints": "동료들은 주인공의 계획을 무조건 따르지 않는다. 각자 자기 판단으로 동의하거나 조건을 건다.",
          "success": "",
          "unmet": "동료를 다 모으지 못해도, 세라와 단둘이 세운 계획으로 의식 날 아침을 맞는다.",
          "closureConditions": [
            {
              "id": "e10a_vigil-c1",
              "text": "주인공이 세라와 함께 동료들을 모아 귀환 의식 날의 계획을 세운다."
            },
            {
              "id": "e10a_vigil-c2",
              "text": "계획의 대가, 곧 대성등이 흔들리면 성도가 위험해진다는 것이 장면에서 분명히 언급된다."
            },
            {
              "id": "e10a_vigil-c3",
              "text": "의식 날 아침, 주인공이 신전의 부름을 받아 의식장으로 향한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e10a_vigil-constraints",
            "description": "동료들은 주인공의 계획을 무조건 따르지 않는다. 각자 자기 판단으로 동의하거나 조건을 건다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e10b_cell",
        "name": "철창 속의 용사",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 탈출에 실패하면, 주인공은 의식장으로 끌려가지만 그 길에서 동료가 남긴 신호를 발견한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "세라의 보고는 대신관에게 닿았다. 그날 밤 주인공은 '귀환 전 정화'라는 명목으로 신전 지하에 갇힌다. 신전은 주인공을 정중하게, 그러나 빈틈없이 대한다. 귀한 손님이자 귀한 연료이기 때문이다. 상태창은 조용하고 남은 시간은 줄어든다.\n철창 너머로 찾아오는 사람이 있다. 등외구의 낡은 배수로를 아는 소년일 수도, 술 냄새 나는 기사일 수도, 울어서 눈이 부은 견습 사제일 수도 있다. 세라는 자신이 한 일을 후회한다. 주인공은 의식이 시작되기 전에 이 철창을 벗어나거나, 적어도 의식장에서 맞설 준비를 해야 한다.\n\n장면 제약: 신전은 주인공에게 상처를 입히지 않는다. 세라는 주인공을 배신한 것을 후회하며, 다시 거짓말을 하지 않는다.",
        "required": true,
        "sequence": 11,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "e11_gate",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e10b_cell-c1",
            "description": "주인공이 신전 지하에 갇힌다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e10b_cell-c2",
            "description": "누군가가 주인공을 찾아와 탈출이나 저항의 수단을 건넨다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e10b_cell-c3",
            "description": "의식 날, 주인공이 탈출해 의식장에 숨어들거나, 끌려가면서도 맞설 준비를 마친다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e10b_cell-constraints",
            "description": "신전은 주인공에게 상처를 입히지 않는다. 세라는 주인공을 배신한 것을 후회하며, 다시 거짓말을 하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "철창 속의 용사",
        "summary": "세라의 보고는 대신관에게 닿았다. 그날 밤 주인공은 '귀환 전 정화'라는 명목으로 신전 지하에 갇힌다. 신전은 주인공을 정중하게, 그러나 빈틈없이 대한다. 귀한 손님이자 귀한 연료이기 때문이다. 상태창은 조용하고 남은 시간은 줄어든다.\n철창 너머로 찾아오는 사람이 있다. 등외구의 낡은 배수로를 아는 소년일 수도, 술 냄새 나는 기사일 수도, 울어서 눈이 부은 견습 사제일 수도 있다. 세라는 자신이 한 일을 후회한다. 주인공은 의식이 시작되기 전에 이 철창을 벗어나거나, 적어도 의식장에서 맞설 준비를 해야 한다.\n\n장면 제약: 신전은 주인공에게 상처를 입히지 않는다. 세라는 주인공을 배신한 것을 후회하며, 다시 거짓말을 하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 신전 지하에 갇힌다.\n\n누군가가 주인공을 찾아와 탈출이나 저항의 수단을 건넨다.\n\n의식 날, 주인공이 탈출해 의식장에 숨어들거나, 끌려가면서도 맞설 준비를 마친다.",
          "selectionScope": "",
          "constraints": "신전은 주인공에게 상처를 입히지 않는다. 세라는 주인공을 배신한 것을 후회하며, 다시 거짓말을 하지 않는다.",
          "success": "",
          "unmet": "탈출에 실패하면, 주인공은 의식장으로 끌려가지만 그 길에서 동료가 남긴 신호를 발견한다.",
          "closureConditions": [
            {
              "id": "e10b_cell-c1",
              "text": "주인공이 신전 지하에 갇힌다."
            },
            {
              "id": "e10b_cell-c2",
              "text": "누군가가 주인공을 찾아와 탈출이나 저항의 수단을 건넨다."
            },
            {
              "id": "e10b_cell-c3",
              "text": "의식 날, 주인공이 탈출해 의식장에 숨어들거나, 끌려가면서도 맞설 준비를 마친다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e10b_cell-constraints",
            "description": "신전은 주인공에게 상처를 입히지 않는다. 세라는 주인공을 배신한 것을 후회하며, 다시 거짓말을 하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "e11_gate",
        "name": "귀환문",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 문 앞에서 어떤 선택도 하지 못하면, 안개의 왕이 대신 문을 막아서며 결말로 이어진다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "귀환 의식의 날. 대성등 탑 꼭대기, 귀환문 앞. 사제들의 노래와 광장을 메운 시민들의 환호 속에서 문이 열린다. 문 너머에서 쏟아지는 것은 고향의 바람이 아니라 화로의 열기다. 대신관 오르텐은 마지막까지 다정하다. \"미안하구나, 아이야. 30만 명이란다.\"\n주인공이 모은 진실과 사람들이 이 자리에서 시험받는다. 진실의 조각이 많을수록 사람들 앞에서 증명할 수 있는 것이 많다. 귀환 게이지가 높을수록 문은 주인공을 강하게 끌어당긴다. 세라는 귀환가를 부를지, 다른 노래를 부를지 선택한다. 피오의 배수로, 바르트의 검, 메이블의 결정, 반쯤 탄 엄마의 편지(\"혹시 길을 잃었다면 불빛을 따라 와\"), 하트 머리핀, 남은 꿀사탕.\n그리고 안개를 가르고 이모 한소이가 온다. 의식이 무너지며 대성등이 크게 흔들리고 등외구 쪽으로 안개가 밀려든다. 30만 명과 한 사람이 같은 저울에 오른다. 한소이는 조카를 지키고, 무너진 불을 대신하기 위해 남은 자신을 스스로 대성등에 바친다. \"이번엔 내가 불빛이 되어 줄게. 길 잃지 말고.\" 대성등이 다시 타오르고 오르텐은 체포된다.\n모든 것이 끝난 밤, 통신이 될 리 없는 스마트폰이 진동하며 화면이 저절로 켜진다. 다온의 메시지. \"오빠 어디야. 엄마가 오늘도 강에 갔어. 제발 대답해.\" 첫 번째 이야기의 결말. 세부 변주는 비공개 세계관의 '첫 번째 이야기의 결말'을 따른다.\n\n이 장면에서 회수할 복선: 피오가 사라지는 옛 배수로 지하 통로. '신전 놈들도 까먹은 길'.\n회수: 그 통로는 대성등 탑 밑까지 이어진다. 의식 날 피오가 그 길로 동료들을 이끌거나 주인공을 빼낸다.\n\n이 장면에서 회수할 복선: 반쯤 타다 남은 엄마의 편지. '혹시 길을 잃었다면 불빛을 따라 와. 언니는 아직 그 집에 산다. 1004'.\n회수: 길을 잃은 이모는 정말로 불빛(대성등)을 따라왔다가 갇혔다. 귀환문에서 편지를 읽은 이모는 '이번엔 내가 불빛이 되어 줄게'라며 스스로 등불에 들어간다.\n\n장면 제약: 주인공은 죽지 않는다. 대성등은 꺼지지 않는다. 결말의 큰 줄기(의식 중단, 안개의 왕의 선택, 마지막 메시지)는 지키되, 누가 곁에 있고 진실이 어디까지 알려지는지는 지금까지의 수치와 선택을 따른다.",
        "required": true,
        "sequence": 12,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "e11_gate-c1",
            "description": "귀환문이 열리고, 문 너머가 집이 아니라는 것이 의식장의 사람들 앞에서 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e11_gate-c2",
            "description": "주인공이 오르텐과 마지막으로 마주하고, 오르텐이 자신의 선택을 숨기지 않는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e11_gate-c3",
            "description": "안개의 왕이 의식장에 나타나 주인공과 마지막 대화를 나눈다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e11_gate-c4",
            "description": "의식이 멈추고, 흔들리던 대성등이 다시 타오르며 결말이 확정된다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e11_gate-c5",
            "description": "모든 것이 끝난 뒤, 주인공의 스마트폰에 있을 수 없는 메시지가 도착한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "e11_gate-constraints",
            "description": "주인공은 죽지 않는다. 대성등은 꺼지지 않는다. 결말의 큰 줄기(의식 중단, 안개의 왕의 선택, 마지막 메시지)는 지키되, 누가 곁에 있고 진실이 어디까지 알려지는지는 지금까지의 수치와 선택을 따른다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "귀환문",
        "summary": "귀환 의식의 날. 대성등 탑 꼭대기, 귀환문 앞. 사제들의 노래와 광장을 메운 시민들의 환호 속에서 문이 열린다. 문 너머에서 쏟아지는 것은 고향의 바람이 아니라 화로의 열기다. 대신관 오르텐은 마지막까지 다정하다. \"미안하구나, 아이야. 30만 명이란다.\"\n주인공이 모은 진실과 사람들이 이 자리에서 시험받는다. 진실의 조각이 많을수록 사람들 앞에서 증명할 수 있는 것이 많다. 귀환 게이지가 높을수록 문은 주인공을 강하게 끌어당긴다. 세라는 귀환가를 부를지, 다른 노래를 부를지 선택한다. 피오의 배수로, 바르트의 검, 메이블의 결정, 반쯤 탄 엄마의 편지(\"혹시 길을 잃었다면 불빛을 따라 와\"), 하트 머리핀, 남은 꿀사탕.\n그리고 안개를 가르고 이모 한소이가 온다. 의식이 무너지며 대성등이 크게 흔들리고 등외구 쪽으로 안개가 밀려든다. 30만 명과 한 사람이 같은 저울에 오른다. 한소이는 조카를 지키고, 무너진 불을 대신하기 위해 남은 자신을 스스로 대성등에 바친다. \"이번엔 내가 불빛이 되어 줄게. 길 잃지 말고.\" 대성등이 다시 타오르고 오르텐은 체포된다.\n모든 것이 끝난 밤, 통신이 될 리 없는 스마트폰이 진동하며 화면이 저절로 켜진다. 다온의 메시지. \"오빠 어디야. 엄마가 오늘도 강에 갔어. 제발 대답해.\" 첫 번째 이야기의 결말. 세부 변주는 비공개 세계관의 '첫 번째 이야기의 결말'을 따른다.\n\n이 장면에서 회수할 복선: 피오가 사라지는 옛 배수로 지하 통로. '신전 놈들도 까먹은 길'.\n회수: 그 통로는 대성등 탑 밑까지 이어진다. 의식 날 피오가 그 길로 동료들을 이끌거나 주인공을 빼낸다.\n\n이 장면에서 회수할 복선: 반쯤 타다 남은 엄마의 편지. '혹시 길을 잃었다면 불빛을 따라 와. 언니는 아직 그 집에 산다. 1004'.\n회수: 길을 잃은 이모는 정말로 불빛(대성등)을 따라왔다가 갇혔다. 귀환문에서 편지를 읽은 이모는 '이번엔 내가 불빛이 되어 줄게'라며 스스로 등불에 들어간다.\n\n장면 제약: 주인공은 죽지 않는다. 대성등은 꺼지지 않는다. 결말의 큰 줄기(의식 중단, 안개의 왕의 선택, 마지막 메시지)는 지키되, 누가 곁에 있고 진실이 어디까지 알려지는지는 지금까지의 수치와 선택을 따른다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "귀환문이 열리고, 문 너머가 집이 아니라는 것이 의식장의 사람들 앞에서 드러난다.\n\n주인공이 오르텐과 마지막으로 마주하고, 오르텐이 자신의 선택을 숨기지 않는다.\n\n안개의 왕이 의식장에 나타나 주인공과 마지막 대화를 나눈다.\n\n의식이 멈추고, 흔들리던 대성등이 다시 타오르며 결말이 확정된다.\n\n모든 것이 끝난 뒤, 주인공의 스마트폰에 있을 수 없는 메시지가 도착한다.",
          "selectionScope": "",
          "constraints": "주인공은 죽지 않는다. 대성등은 꺼지지 않는다. 결말의 큰 줄기(의식 중단, 안개의 왕의 선택, 마지막 메시지)는 지키되, 누가 곁에 있고 진실이 어디까지 알려지는지는 지금까지의 수치와 선택을 따른다.",
          "success": "",
          "unmet": "주인공이 문 앞에서 어떤 선택도 하지 못하면, 안개의 왕이 대신 문을 막아서며 결말로 이어진다.",
          "closureConditions": [
            {
              "id": "e11_gate-c1",
              "text": "귀환문이 열리고, 문 너머가 집이 아니라는 것이 의식장의 사람들 앞에서 드러난다."
            },
            {
              "id": "e11_gate-c2",
              "text": "주인공이 오르텐과 마지막으로 마주하고, 오르텐이 자신의 선택을 숨기지 않는다."
            },
            {
              "id": "e11_gate-c3",
              "text": "안개의 왕이 의식장에 나타나 주인공과 마지막 대화를 나눈다."
            },
            {
              "id": "e11_gate-c4",
              "text": "의식이 멈추고, 흔들리던 대성등이 다시 타오르며 결말이 확정된다."
            },
            {
              "id": "e11_gate-c5",
              "text": "모든 것이 끝난 뒤, 주인공의 스마트폰에 있을 수 없는 메시지가 도착한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "e11_gate-constraints",
            "description": "주인공은 죽지 않는다. 대성등은 꺼지지 않는다. 결말의 큰 줄기(의식 중단, 안개의 왕의 선택, 마지막 메시지)는 지키되, 누가 곁에 있고 진실이 어디까지 알려지는지는 지금까지의 수치와 선택을 따른다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "r2e01_hundred",
        "name": "백 일의 등불",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 메시지를 받지 못하면, 메이블이 충전 장치에 연결해 둔 스마트폰 화면이 밤사이 저절로 켜졌던 기록을 보여 준다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "귀환 의식이 무너진 지 서른 날. 대성등은 이모가 남긴 마지막 불씨로 타고 있지만 빛의 원은 매일 손가락 한 마디씩 좁아진다. 메이블의 계산으로 남은 날은 약 일흔 날. 오르텐은 지하 감옥에 갇혔고 신전은 부신관 카시안이 이끈다. 성도는 진실을 믿는 사람과 믿지 않는 사람으로 갈라졌다. 세라는 사제복을 벗고 도하 곁에 있다. 의식이 무너진 날 상태창의 게이지는 0%로 돌아갔다.\n대성등 가까이에 설 때마다, 스마트폰에 아주 드물게 신호 한 칸이 뜬다. 다온의 메시지가 도착한다. 답장은 보내지지 않는다(전송 실패). 메이블은 메시지가 '소환의 실'을 타고 오고 있다는 가설을 세운다. 다온이 매일 밤 오빠를 부르고 있기 때문이다. 그런데 실이 열려 있다는 것은, 반대편에서 누군가가 그 실을 붙잡을 수도 있다는 뜻이다.\n\n장면 제약: 이 사건에서 스마트폰으로 다온에게 보내는 답장은 성공하지 않는다. 첫 번째 이야기의 결말과 모순되지 않게 쓴다.",
        "required": true,
        "sequence": 13,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "r2e02_prison",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "r2e01_hundred-c1",
            "description": "주인공이 대성등 가까이에서 다온의 새 메시지를 받는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e01_hundred-c2",
            "description": "메이블이 메시지가 소환의 실을 따라 오고 있다는 가설을 세운다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e01_hundred-c3",
            "description": "그 실이 열려 있다는 것이 위험일 수도 있다는 사실이 장면에서 분명해진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e01_hundred-constraints",
            "description": "이 사건에서 스마트폰으로 다온에게 보내는 답장은 성공하지 않는다. 첫 번째 이야기의 결말과 모순되지 않게 쓴다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "백 일의 등불",
        "summary": "귀환 의식이 무너진 지 서른 날. 대성등은 이모가 남긴 마지막 불씨로 타고 있지만 빛의 원은 매일 손가락 한 마디씩 좁아진다. 메이블의 계산으로 남은 날은 약 일흔 날. 오르텐은 지하 감옥에 갇혔고 신전은 부신관 카시안이 이끈다. 성도는 진실을 믿는 사람과 믿지 않는 사람으로 갈라졌다. 세라는 사제복을 벗고 도하 곁에 있다. 의식이 무너진 날 상태창의 게이지는 0%로 돌아갔다.\n대성등 가까이에 설 때마다, 스마트폰에 아주 드물게 신호 한 칸이 뜬다. 다온의 메시지가 도착한다. 답장은 보내지지 않는다(전송 실패). 메이블은 메시지가 '소환의 실'을 타고 오고 있다는 가설을 세운다. 다온이 매일 밤 오빠를 부르고 있기 때문이다. 그런데 실이 열려 있다는 것은, 반대편에서 누군가가 그 실을 붙잡을 수도 있다는 뜻이다.\n\n장면 제약: 이 사건에서 스마트폰으로 다온에게 보내는 답장은 성공하지 않는다. 첫 번째 이야기의 결말과 모순되지 않게 쓴다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 대성등 가까이에서 다온의 새 메시지를 받는다.\n\n메이블이 메시지가 소환의 실을 따라 오고 있다는 가설을 세운다.\n\n그 실이 열려 있다는 것이 위험일 수도 있다는 사실이 장면에서 분명해진다.",
          "selectionScope": "",
          "constraints": "이 사건에서 스마트폰으로 다온에게 보내는 답장은 성공하지 않는다. 첫 번째 이야기의 결말과 모순되지 않게 쓴다.",
          "success": "",
          "unmet": "메시지를 받지 못하면, 메이블이 충전 장치에 연결해 둔 스마트폰 화면이 밤사이 저절로 켜졌던 기록을 보여 준다.",
          "closureConditions": [
            {
              "id": "r2e01_hundred-c1",
              "text": "주인공이 대성등 가까이에서 다온의 새 메시지를 받는다."
            },
            {
              "id": "r2e01_hundred-c2",
              "text": "메이블이 메시지가 소환의 실을 따라 오고 있다는 가설을 세운다."
            },
            {
              "id": "r2e01_hundred-c3",
              "text": "그 실이 열려 있다는 것이 위험일 수도 있다는 사실이 장면에서 분명해진다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "r2e01_hundred-constraints",
            "description": "이 사건에서 스마트폰으로 다온에게 보내는 답장은 성공하지 않는다. 첫 번째 이야기의 결말과 모순되지 않게 쓴다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "r2e02_prison",
        "name": "지하 감옥의 대신관",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 대화를 끝까지 하지 않으면, 오르텐이 간수에게 맡긴 편지로 같은 내용을 전한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "주인공은 지하 감옥의 오르텐을 찾아간다. 기침이 깊어진 노인은 여전히 다정하고, 여전히 후회한다고 말하지 않는다. 손끝의 잿빛은 손목까지 번졌다.\n그는 대성등이 처음 만들어진 이야기를 들려준다. 약 이백이십 년 전 안개가 처음 밀려왔을 때, 등불을 들고 안개를 건너온 조선의 등롱장이 강막손. 그가 처음 설계한 것은 '많은 사람이 기억을 한 조각씩 나누어 태우는 등불'이었지만, 그때의 신전과 귀족들은 자기 기억을 내놓기를 거부했다. 강막손은 스스로 불이 되었고, 신전은 그 뒤로 한 사람을 태우는 쉬운 방식을 제도로 만들었다. 설계도는 안개 심부, 첫 번째 용사의 무덤에 묻혀 있다. 금서고의 '스스로 불이 되다'라는 문구의 뜻이 드러난다.\n오르텐은 카시안이 무언가를 준비하고 있다고 경고한다. 그리고 단 하나를 부탁한다. 자신이 죽거든 그 영혼을 등불에 보태 달라고. 며칠이라도.\n\n이 장면에서 회수할 복선: 다른 용사들은 모두 '빛이 되어 돌아가다'인데, 첫 번째 용사의 줄만 '안개를 건너와 스스로 불이 되다'. 사람들은 '대성등을 밝혔다'는 비유로 읽는다.\n회수: 첫 번째 용사만은 소환된 것이 아니라 스스로 등불이 되었고, 원래는 아무도 태우지 않는 등불을 설계했다는 사실을 오르텐이 털어놓는다.\n\n이 장면에서 회수할 복선: 오르텐이 기침을 감추는 손수건의 잿빛 얼룩, 살짝 잿빛인 손가락 끝.\n회수: 그는 폐가 잿빛으로 굳는 병으로 죽어 가고 있었고, 그래서 의식을 서둘렀다. 감옥에서 자신의 영혼을 등불에 보태 달라고 부탁한다.\n\n장면 제약: 오르텐은 변명하지 않지만 자신을 악당으로 깎아내리지도 않는다. 그는 탈옥하지 않는다.",
        "required": true,
        "sequence": 14,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "r2e03_circle",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "r2e02_prison-c1",
            "description": "오르텐이 첫 번째 용사와 대성등의 기원을 이야기한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e02_prison-c2",
            "description": "오르텐이 첫 번째 용사가 남긴 다른 방식이 안개 심부의 무덤에 묻혀 있다고 알려 준다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e02_prison-c3",
            "description": "오르텐이 카시안이 준비하는 일에 대해 경고한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e02_prison-c4",
            "description": "오르텐이 주인공에게 마지막 부탁을 하고, 주인공의 대답이 장면에 드러난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e02_prison-constraints",
            "description": "오르텐은 변명하지 않지만 자신을 악당으로 깎아내리지도 않는다. 그는 탈옥하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "지하 감옥의 대신관",
        "summary": "주인공은 지하 감옥의 오르텐을 찾아간다. 기침이 깊어진 노인은 여전히 다정하고, 여전히 후회한다고 말하지 않는다. 손끝의 잿빛은 손목까지 번졌다.\n그는 대성등이 처음 만들어진 이야기를 들려준다. 약 이백이십 년 전 안개가 처음 밀려왔을 때, 등불을 들고 안개를 건너온 조선의 등롱장이 강막손. 그가 처음 설계한 것은 '많은 사람이 기억을 한 조각씩 나누어 태우는 등불'이었지만, 그때의 신전과 귀족들은 자기 기억을 내놓기를 거부했다. 강막손은 스스로 불이 되었고, 신전은 그 뒤로 한 사람을 태우는 쉬운 방식을 제도로 만들었다. 설계도는 안개 심부, 첫 번째 용사의 무덤에 묻혀 있다. 금서고의 '스스로 불이 되다'라는 문구의 뜻이 드러난다.\n오르텐은 카시안이 무언가를 준비하고 있다고 경고한다. 그리고 단 하나를 부탁한다. 자신이 죽거든 그 영혼을 등불에 보태 달라고. 며칠이라도.\n\n이 장면에서 회수할 복선: 다른 용사들은 모두 '빛이 되어 돌아가다'인데, 첫 번째 용사의 줄만 '안개를 건너와 스스로 불이 되다'. 사람들은 '대성등을 밝혔다'는 비유로 읽는다.\n회수: 첫 번째 용사만은 소환된 것이 아니라 스스로 등불이 되었고, 원래는 아무도 태우지 않는 등불을 설계했다는 사실을 오르텐이 털어놓는다.\n\n이 장면에서 회수할 복선: 오르텐이 기침을 감추는 손수건의 잿빛 얼룩, 살짝 잿빛인 손가락 끝.\n회수: 그는 폐가 잿빛으로 굳는 병으로 죽어 가고 있었고, 그래서 의식을 서둘렀다. 감옥에서 자신의 영혼을 등불에 보태 달라고 부탁한다.\n\n장면 제약: 오르텐은 변명하지 않지만 자신을 악당으로 깎아내리지도 않는다. 그는 탈옥하지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "오르텐이 첫 번째 용사와 대성등의 기원을 이야기한다.\n\n오르텐이 첫 번째 용사가 남긴 다른 방식이 안개 심부의 무덤에 묻혀 있다고 알려 준다.\n\n오르텐이 카시안이 준비하는 일에 대해 경고한다.\n\n오르텐이 주인공에게 마지막 부탁을 하고, 주인공의 대답이 장면에 드러난다.",
          "selectionScope": "",
          "constraints": "오르텐은 변명하지 않지만 자신을 악당으로 깎아내리지도 않는다. 그는 탈옥하지 않는다.",
          "success": "",
          "unmet": "주인공이 대화를 끝까지 하지 않으면, 오르텐이 간수에게 맡긴 편지로 같은 내용을 전한다.",
          "closureConditions": [
            {
              "id": "r2e02_prison-c1",
              "text": "오르텐이 첫 번째 용사와 대성등의 기원을 이야기한다."
            },
            {
              "id": "r2e02_prison-c2",
              "text": "오르텐이 첫 번째 용사가 남긴 다른 방식이 안개 심부의 무덤에 묻혀 있다고 알려 준다."
            },
            {
              "id": "r2e02_prison-c3",
              "text": "오르텐이 카시안이 준비하는 일에 대해 경고한다."
            },
            {
              "id": "r2e02_prison-c4",
              "text": "오르텐이 주인공에게 마지막 부탁을 하고, 주인공의 대답이 장면에 드러난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "r2e02_prison-constraints",
            "description": "오르텐은 변명하지 않지만 자신을 악당으로 깎아내리지도 않는다. 그는 탈옥하지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "r2e03_circle",
        "name": "열 번째 소환진",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 소환진에 닿지 못하면, 피오가 훔쳐 온 카시안의 의식 일정 두루마리로 같은 사실을 알게 된다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "오르텐의 경고를 따라, 혹은 피오가 옛 배수로에서 본 이상한 빛을 따라, 주인공은 신전 지하 깊은 곳에서 새로 그려지고 있는 소환진을 발견한다. 부신관 카시안은 남은 날 안에 열 번째 용사를 부르려 한다. \"등불에 감정은 사치입니다.\"\n대성등 안에는 더 이상 태울 '직전 용사'가 없다. 그래서 카시안은 살아 있는 아홉 번째 용사, 주인공 자신의 실을 닻으로 삼았다. 소환진은 주인공을 가장 간절히 부르는 목소리를 따라 문을 연다. 그 끝에는 매일 밤 오빠를 부르는 다온이 있다. 이 싸움은 더 이상 주인공 혼자의 것이 아니다.\n\n이 장면에서 회수할 복선: 연회에서 부신관 카시안이 차갑게 내뱉는 말. '등불에 감정은 사치입니다.' 오르텐의 꿀사탕을 못마땅하게 보는 시선.\n회수: 오르텐이 갇힌 뒤, 카시안은 감정 없이 열 번째 소환진을 그린다.\n\n장면 제약: 카시안은 고함치지 않는다. 소환진은 이 사건에서 완전히 파괴되지 않는다.",
        "required": true,
        "sequence": 15,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "r2e04_grave",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "r2e03_circle-c1",
            "description": "주인공이 신전 지하에서 새로 그려지는 소환진을 발견한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e03_circle-c2",
            "description": "주인공이 그 소환진이 다온에게 닿을 수 있다는 사실을 알게 된다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e03_circle-c3",
            "description": "카시안과 마주하거나, 카시안의 계획이 적힌 기록을 손에 넣는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e03_circle-c4",
            "description": "소환진을 완전히 부수지 못한 채 그곳을 벗어난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e03_circle-constraints",
            "description": "카시안은 고함치지 않는다. 소환진은 이 사건에서 완전히 파괴되지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "열 번째 소환진",
        "summary": "오르텐의 경고를 따라, 혹은 피오가 옛 배수로에서 본 이상한 빛을 따라, 주인공은 신전 지하 깊은 곳에서 새로 그려지고 있는 소환진을 발견한다. 부신관 카시안은 남은 날 안에 열 번째 용사를 부르려 한다. \"등불에 감정은 사치입니다.\"\n대성등 안에는 더 이상 태울 '직전 용사'가 없다. 그래서 카시안은 살아 있는 아홉 번째 용사, 주인공 자신의 실을 닻으로 삼았다. 소환진은 주인공을 가장 간절히 부르는 목소리를 따라 문을 연다. 그 끝에는 매일 밤 오빠를 부르는 다온이 있다. 이 싸움은 더 이상 주인공 혼자의 것이 아니다.\n\n이 장면에서 회수할 복선: 연회에서 부신관 카시안이 차갑게 내뱉는 말. '등불에 감정은 사치입니다.' 오르텐의 꿀사탕을 못마땅하게 보는 시선.\n회수: 오르텐이 갇힌 뒤, 카시안은 감정 없이 열 번째 소환진을 그린다.\n\n장면 제약: 카시안은 고함치지 않는다. 소환진은 이 사건에서 완전히 파괴되지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 신전 지하에서 새로 그려지는 소환진을 발견한다.\n\n주인공이 그 소환진이 다온에게 닿을 수 있다는 사실을 알게 된다.\n\n카시안과 마주하거나, 카시안의 계획이 적힌 기록을 손에 넣는다.\n\n소환진을 완전히 부수지 못한 채 그곳을 벗어난다.",
          "selectionScope": "",
          "constraints": "카시안은 고함치지 않는다. 소환진은 이 사건에서 완전히 파괴되지 않는다.",
          "success": "",
          "unmet": "소환진에 닿지 못하면, 피오가 훔쳐 온 카시안의 의식 일정 두루마리로 같은 사실을 알게 된다.",
          "closureConditions": [
            {
              "id": "r2e03_circle-c1",
              "text": "주인공이 신전 지하에서 새로 그려지는 소환진을 발견한다."
            },
            {
              "id": "r2e03_circle-c2",
              "text": "주인공이 그 소환진이 다온에게 닿을 수 있다는 사실을 알게 된다."
            },
            {
              "id": "r2e03_circle-c3",
              "text": "카시안과 마주하거나, 카시안의 계획이 적힌 기록을 손에 넣는다."
            },
            {
              "id": "r2e03_circle-c4",
              "text": "소환진을 완전히 부수지 못한 채 그곳을 벗어난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "r2e03_circle-constraints",
            "description": "카시안은 고함치지 않는다. 소환진은 이 사건에서 완전히 파괴되지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "r2e04_grave",
        "name": "첫 번째 용사의 무덤",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 무덤의 잔향과 대화하지 못하면, 무덤 벽에 새겨진 옛 한글을 주인공이 읽어 같은 뜻을 알게 된다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "주인공은 동료들과 다시 안개 심부로, 그보다 더 깊은 곳으로 향한다. 이모가 사라진 안개는 전보다 조용하지만 더 춥다. 첫 번째 용사의 무덤. 그곳의 잔향은 이백 년도 더 된 조선의 말투로 말한다. 강막손. 그는 등외구 사람들에게 자장가를 가르쳤고, 등불은 원래 모두의 것이었다고 말한다.\n무덤에는 그가 남긴 설계도가 있다. 메이블은 그것이 '많은 사람의 기억을 한 조각씩 나누어 태우는 등불'이라는 것을 해독한다. 누구의 영혼도 통째로 태우지 않는다. 다만 바친 기억은 돌아오지 않는다. 그리고 그 등불이 켜지면 대성등은 더 이상 실을 삼키지 않는다. 부르는 목소리를 따라, 진짜로 돌아가는 길이 열릴 수 있다.\n\n이 장면에서 회수할 복선: 아주 오래된 결정 조각에 새겨진, 아래아(ㆍ)가 섞인 옛 한글.\n회수: 첫 번째 용사는 이백여 년 전 조선의 등롱장이 강막손이었다. 무덤의 잔향은 조선 말투로 말한다.\n\n장면 제약: 첫 번째 용사의 잔향은 조선 후기의 말투를 쓴다. 설계도의 방식은 누구의 영혼도 통째로 태우지 않지만 바친 기억은 돌아오지 않는다.",
        "required": true,
        "sequence": 16,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "r2e05_pledge",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "r2e04_grave-c1",
            "description": "주인공 일행이 안개 심부를 지나 첫 번째 용사의 무덤에 도착한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e04_grave-c2",
            "description": "첫 번째 용사의 잔향이나 그가 남긴 기록을 통해 그의 뜻을 듣는다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e04_grave-c3",
            "description": "주인공이 설계도를 손에 넣고, 메이블이 그것이 많은 사람의 기억을 나누어 태우는 등불이라는 것을 해독한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e04_grave-c4",
            "description": "일행이 성도로 돌아온다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e04_grave-constraints",
            "description": "첫 번째 용사의 잔향은 조선 후기의 말투를 쓴다. 설계도의 방식은 누구의 영혼도 통째로 태우지 않지만 바친 기억은 돌아오지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "첫 번째 용사의 무덤",
        "summary": "주인공은 동료들과 다시 안개 심부로, 그보다 더 깊은 곳으로 향한다. 이모가 사라진 안개는 전보다 조용하지만 더 춥다. 첫 번째 용사의 무덤. 그곳의 잔향은 이백 년도 더 된 조선의 말투로 말한다. 강막손. 그는 등외구 사람들에게 자장가를 가르쳤고, 등불은 원래 모두의 것이었다고 말한다.\n무덤에는 그가 남긴 설계도가 있다. 메이블은 그것이 '많은 사람의 기억을 한 조각씩 나누어 태우는 등불'이라는 것을 해독한다. 누구의 영혼도 통째로 태우지 않는다. 다만 바친 기억은 돌아오지 않는다. 그리고 그 등불이 켜지면 대성등은 더 이상 실을 삼키지 않는다. 부르는 목소리를 따라, 진짜로 돌아가는 길이 열릴 수 있다.\n\n이 장면에서 회수할 복선: 아주 오래된 결정 조각에 새겨진, 아래아(ㆍ)가 섞인 옛 한글.\n회수: 첫 번째 용사는 이백여 년 전 조선의 등롱장이 강막손이었다. 무덤의 잔향은 조선 말투로 말한다.\n\n장면 제약: 첫 번째 용사의 잔향은 조선 후기의 말투를 쓴다. 설계도의 방식은 누구의 영혼도 통째로 태우지 않지만 바친 기억은 돌아오지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공 일행이 안개 심부를 지나 첫 번째 용사의 무덤에 도착한다.\n\n첫 번째 용사의 잔향이나 그가 남긴 기록을 통해 그의 뜻을 듣는다.\n\n주인공이 설계도를 손에 넣고, 메이블이 그것이 많은 사람의 기억을 나누어 태우는 등불이라는 것을 해독한다.\n\n일행이 성도로 돌아온다.",
          "selectionScope": "",
          "constraints": "첫 번째 용사의 잔향은 조선 후기의 말투를 쓴다. 설계도의 방식은 누구의 영혼도 통째로 태우지 않지만 바친 기억은 돌아오지 않는다.",
          "success": "",
          "unmet": "무덤의 잔향과 대화하지 못하면, 무덤 벽에 새겨진 옛 한글을 주인공이 읽어 같은 뜻을 알게 된다.",
          "closureConditions": [
            {
              "id": "r2e04_grave-c1",
              "text": "주인공 일행이 안개 심부를 지나 첫 번째 용사의 무덤에 도착한다."
            },
            {
              "id": "r2e04_grave-c2",
              "text": "첫 번째 용사의 잔향이나 그가 남긴 기록을 통해 그의 뜻을 듣는다."
            },
            {
              "id": "r2e04_grave-c3",
              "text": "주인공이 설계도를 손에 넣고, 메이블이 그것이 많은 사람의 기억을 나누어 태우는 등불이라는 것을 해독한다."
            },
            {
              "id": "r2e04_grave-c4",
              "text": "일행이 성도로 돌아온다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "r2e04_grave-constraints",
            "description": "첫 번째 용사의 잔향은 조선 후기의 말투를 쓴다. 설계도의 방식은 누구의 영혼도 통째로 태우지 않지만 바친 기억은 돌아오지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "r2e05_pledge",
        "name": "등외구의 약속",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 설득이 충분하지 않더라도, 피오와 할머니를 중심으로 등외구 사람들만은 약속한다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "첫 번째 용사의 등불을 밝히려면 많은 사람이 자기 기억을 한 조각씩 내놓아야 한다. 가장 행복했던 날 하나, 소중한 이름 하나, 처음 본 바다. 사람들은 쉽게 내주지 않는다. 상층원의 귀족들은 비웃고, 신전의 사제들은 흔들리고, 기사들은 망설인다.\n가장 먼저 손을 든 것은 빛을 가장 적게 받던 등외구 사람들이다. 피오의 할머니가 자장가를 부르며 앞장선다. 주인공은 성도의 사람들을 설득해야 한다. 누구에게, 무엇을, 어떻게 부탁할지는 주인공의 몫이다. 세라는 신전 사제들을, 바르트는 기사단을 맡겠다고 나설 수 있다.\n\n장면 제약: 사람들의 동의를 마법이나 협박으로 얻지 않는다. 기억을 바치는 것은 각자의 자유이며 거절하는 사람도 존중한다.",
        "required": true,
        "sequence": 17,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "r2e06_tenth",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "r2e05_pledge-c1",
            "description": "주인공이 첫 번째 용사의 등불에 대해 사람들 앞에서 이야기한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e05_pledge-c2",
            "description": "등외구 사람들이 기억을 내놓겠다고 약속한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e05_pledge-c3",
            "description": "기사단, 신전 사제, 상층원 귀족 중 적어도 한 집단의 대답이 장면에서 정해진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e05_pledge-constraints",
            "description": "사람들의 동의를 마법이나 협박으로 얻지 않는다. 기억을 바치는 것은 각자의 자유이며 거절하는 사람도 존중한다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "등외구의 약속",
        "summary": "첫 번째 용사의 등불을 밝히려면 많은 사람이 자기 기억을 한 조각씩 내놓아야 한다. 가장 행복했던 날 하나, 소중한 이름 하나, 처음 본 바다. 사람들은 쉽게 내주지 않는다. 상층원의 귀족들은 비웃고, 신전의 사제들은 흔들리고, 기사들은 망설인다.\n가장 먼저 손을 든 것은 빛을 가장 적게 받던 등외구 사람들이다. 피오의 할머니가 자장가를 부르며 앞장선다. 주인공은 성도의 사람들을 설득해야 한다. 누구에게, 무엇을, 어떻게 부탁할지는 주인공의 몫이다. 세라는 신전 사제들을, 바르트는 기사단을 맡겠다고 나설 수 있다.\n\n장면 제약: 사람들의 동의를 마법이나 협박으로 얻지 않는다. 기억을 바치는 것은 각자의 자유이며 거절하는 사람도 존중한다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 첫 번째 용사의 등불에 대해 사람들 앞에서 이야기한다.\n\n등외구 사람들이 기억을 내놓겠다고 약속한다.\n\n기사단, 신전 사제, 상층원 귀족 중 적어도 한 집단의 대답이 장면에서 정해진다.",
          "selectionScope": "",
          "constraints": "사람들의 동의를 마법이나 협박으로 얻지 않는다. 기억을 바치는 것은 각자의 자유이며 거절하는 사람도 존중한다.",
          "success": "",
          "unmet": "설득이 충분하지 않더라도, 피오와 할머니를 중심으로 등외구 사람들만은 약속한다.",
          "closureConditions": [
            {
              "id": "r2e05_pledge-c1",
              "text": "주인공이 첫 번째 용사의 등불에 대해 사람들 앞에서 이야기한다."
            },
            {
              "id": "r2e05_pledge-c2",
              "text": "등외구 사람들이 기억을 내놓겠다고 약속한다."
            },
            {
              "id": "r2e05_pledge-c3",
              "text": "기사단, 신전 사제, 상층원 귀족 중 적어도 한 집단의 대답이 장면에서 정해진다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "r2e05_pledge-constraints",
            "description": "사람들의 동의를 마법이나 협박으로 얻지 않는다. 기억을 바치는 것은 각자의 자유이며 거절하는 사람도 존중한다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "r2e06_tenth",
        "name": "열 번째 소환",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공이 다온에게 닿을 방법을 찾지 못하면, 세라가 등불 기도로 소환진의 빛을 잠시 묶어 시간을 번다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "약속의 날을 기다리던 밤, 카시안이 먼저 움직인다. 신전 지하의 소환진에 불이 들어오고, 대성등이 비명을 지르듯 흔들린다. 소환진 너머로 아주 익숙한 목소리가 들린다. \"오빠… 어디 있어…\" 스마트폰 속 음성 메시지로 수없이 다시 들었던 바로 그 목소리다.\n주인공은 소환진을 멈춰야 한다. 카시안과 의식을 지키는 사제들을 넘어서야 하고, 무엇보다 저편에서 부르는 목소리가 멈춰야 한다. 다온에게 이제 그만 부르라고 말해야 한다. 그것은 지금 이 세상에서 가장 하기 싫은 부탁이다. 스마트폰에 배터리가 남아 있다면 그 목소리에 닿을 수 있을지도 모른다. 남아 있지 않다면, 다른 방법이 필요하다.\n\n이 장면에서 회수할 복선: 피오가 훔친 스마트폰을 함부로 누르다 재생된 다온의 음성 메시지('오빠, 오늘도 늦어? 엄마 또 강 갔대. 빨리 와.').\n회수: 열 번째 소환진 너머에서 같은 목소리가 오빠를 부른다.\n\n장면 제약: 다온은 이 세계로 넘어오지 않는다. 카시안은 죽지 않는다(체포되거나 물러난다).",
        "required": true,
        "sequence": 18,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "r2e07a_call",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "r2e06_tenth-c1",
            "description": "카시안이 열 번째 소환을 시작하고, 소환진 너머에서 다온의 목소리가 들린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e06_tenth-c2",
            "description": "주인공이 소환진에 이르러 카시안이나 의식을 지키는 사제들과 맞선다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e06_tenth-c3",
            "description": "주인공이 저편의 다온에게 닿을 방법을 찾아 시도한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e06_tenth-constraints",
            "description": "다온은 이 세계로 넘어오지 않는다. 카시안은 죽지 않는다(체포되거나 물러난다).",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "열 번째 소환",
        "summary": "약속의 날을 기다리던 밤, 카시안이 먼저 움직인다. 신전 지하의 소환진에 불이 들어오고, 대성등이 비명을 지르듯 흔들린다. 소환진 너머로 아주 익숙한 목소리가 들린다. \"오빠… 어디 있어…\" 스마트폰 속 음성 메시지로 수없이 다시 들었던 바로 그 목소리다.\n주인공은 소환진을 멈춰야 한다. 카시안과 의식을 지키는 사제들을 넘어서야 하고, 무엇보다 저편에서 부르는 목소리가 멈춰야 한다. 다온에게 이제 그만 부르라고 말해야 한다. 그것은 지금 이 세상에서 가장 하기 싫은 부탁이다. 스마트폰에 배터리가 남아 있다면 그 목소리에 닿을 수 있을지도 모른다. 남아 있지 않다면, 다른 방법이 필요하다.\n\n이 장면에서 회수할 복선: 피오가 훔친 스마트폰을 함부로 누르다 재생된 다온의 음성 메시지('오빠, 오늘도 늦어? 엄마 또 강 갔대. 빨리 와.').\n회수: 열 번째 소환진 너머에서 같은 목소리가 오빠를 부른다.\n\n장면 제약: 다온은 이 세계로 넘어오지 않는다. 카시안은 죽지 않는다(체포되거나 물러난다).",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "카시안이 열 번째 소환을 시작하고, 소환진 너머에서 다온의 목소리가 들린다.\n\n주인공이 소환진에 이르러 카시안이나 의식을 지키는 사제들과 맞선다.\n\n주인공이 저편의 다온에게 닿을 방법을 찾아 시도한다.",
          "selectionScope": "",
          "constraints": "다온은 이 세계로 넘어오지 않는다. 카시안은 죽지 않는다(체포되거나 물러난다).",
          "success": "",
          "unmet": "주인공이 다온에게 닿을 방법을 찾지 못하면, 세라가 등불 기도로 소환진의 빛을 잠시 묶어 시간을 번다.",
          "closureConditions": [
            {
              "id": "r2e06_tenth-c1",
              "text": "카시안이 열 번째 소환을 시작하고, 소환진 너머에서 다온의 목소리가 들린다."
            },
            {
              "id": "r2e06_tenth-c2",
              "text": "주인공이 소환진에 이르러 카시안이나 의식을 지키는 사제들과 맞선다."
            },
            {
              "id": "r2e06_tenth-c3",
              "text": "주인공이 저편의 다온에게 닿을 방법을 찾아 시도한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "r2e06_tenth-constraints",
            "description": "다온은 이 세계로 넘어오지 않는다. 카시안은 죽지 않는다(체포되거나 물러난다).",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "r2e07a_call",
        "name": "다온에게 거는 전화",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 통화가 중간에 끊기면, 다온이 마지막으로 보낸 '알았어. 기다릴게. 1004'라는 메시지가 화면에 남으며 소환진이 꺼진다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "신호 한 칸. 얼마 남지 않은 배터리. 소환진의 빛 한가운데에서 전화가 연결된다. 서른 날 넘게 울며 오빠를 부르던 동생에게, 주인공은 이제 그만 부르라고 말해야 한다. 기다리라고. 반드시 돌아갈 테니까.\n그 말이 닿으면 실은 느슨해지고 소환진은 다온을 붙잡지 못한다. 다온은 울면서도 약속한다. \"알았어. 기다릴게. 1004.\" 그러나 느슨해진 그 실은, 언젠가 주인공이 돌아갈 길이기도 하다. 통화가 끊기고, 소환진의 빛이 꺼진다.\n\n장면 제약: 다온은 이 세계로 넘어오지 않는다. 통화는 짧고, 끊어진 뒤 다시 이어지지 않는다.",
        "required": true,
        "sequence": 19,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "r2e08_kindle",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "r2e07a_call-c1",
            "description": "주인공과 다온의 목소리가 소환진을 사이에 두고 연결된다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e07a_call-c2",
            "description": "주인공이 다온에게 자신을 부르는 것을 멈추고 기다려 달라고 부탁한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e07a_call-c3",
            "description": "소환진의 빛이 꺼지고 카시안의 의식이 실패한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e07a_call-constraints",
            "description": "다온은 이 세계로 넘어오지 않는다. 통화는 짧고, 끊어진 뒤 다시 이어지지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "다온에게 거는 전화",
        "summary": "신호 한 칸. 얼마 남지 않은 배터리. 소환진의 빛 한가운데에서 전화가 연결된다. 서른 날 넘게 울며 오빠를 부르던 동생에게, 주인공은 이제 그만 부르라고 말해야 한다. 기다리라고. 반드시 돌아갈 테니까.\n그 말이 닿으면 실은 느슨해지고 소환진은 다온을 붙잡지 못한다. 다온은 울면서도 약속한다. \"알았어. 기다릴게. 1004.\" 그러나 느슨해진 그 실은, 언젠가 주인공이 돌아갈 길이기도 하다. 통화가 끊기고, 소환진의 빛이 꺼진다.\n\n장면 제약: 다온은 이 세계로 넘어오지 않는다. 통화는 짧고, 끊어진 뒤 다시 이어지지 않는다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공과 다온의 목소리가 소환진을 사이에 두고 연결된다.\n\n주인공이 다온에게 자신을 부르는 것을 멈추고 기다려 달라고 부탁한다.\n\n소환진의 빛이 꺼지고 카시안의 의식이 실패한다.",
          "selectionScope": "",
          "constraints": "다온은 이 세계로 넘어오지 않는다. 통화는 짧고, 끊어진 뒤 다시 이어지지 않는다.",
          "success": "",
          "unmet": "통화가 중간에 끊기면, 다온이 마지막으로 보낸 '알았어. 기다릴게. 1004'라는 메시지가 화면에 남으며 소환진이 꺼진다.",
          "closureConditions": [
            {
              "id": "r2e07a_call-c1",
              "text": "주인공과 다온의 목소리가 소환진을 사이에 두고 연결된다."
            },
            {
              "id": "r2e07a_call-c2",
              "text": "주인공이 다온에게 자신을 부르는 것을 멈추고 기다려 달라고 부탁한다."
            },
            {
              "id": "r2e07a_call-c3",
              "text": "소환진의 빛이 꺼지고 카시안의 의식이 실패한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "r2e07a_call-constraints",
            "description": "다온은 이 세계로 넘어오지 않는다. 통화는 짧고, 끊어진 뒤 다시 이어지지 않는다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "r2e07b_lullaby",
        "name": "강 건너의 자장가",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 노래가 닿지 않으면, 대성등 안에 남은 이모의 불씨가 마지막 힘으로 소환진을 끊어 준다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "화면은 켜지지 않는다. 남은 것은 목소리뿐이다. 주인공은 소환진 너머를 향해 노래를 부른다. 엄마가 불러 주던, 이모가 좋아하던, 등외구 사람들이 이백 년 동안 이어 불러 온 그 자장가. 세라가, 피오가, 등외구 사람들이 따라 부른다.\n노래가 실을 타고 건너가면, 저편의 다온은 알아차린다. 엄마의 노래다. 오빠가 살아 있다. 다온은 부르기를 멈추고, 대신 그 노래를 따라 부른다. 부르는 목소리가 기다리는 목소리로 바뀌는 순간, 소환진은 다온을 붙잡지 못한다.\n\n장면 제약: 다온은 이 세계로 넘어오지 않는다. 노랫말은 전래 자장가의 짧은 구절만 쓴다.",
        "required": true,
        "sequence": 20,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "r2e08_kindle",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "r2e07b_lullaby-c1",
            "description": "주인공이 소환진을 향해 자장가를 부른다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e07b_lullaby-c2",
            "description": "주변 사람들이 노래를 따라 부르며 소환진의 빛이 흔들린다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e07b_lullaby-c3",
            "description": "저편의 다온이 부르기를 멈추고, 소환진의 빛이 꺼지며 카시안의 의식이 실패한다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e07b_lullaby-constraints",
            "description": "다온은 이 세계로 넘어오지 않는다. 노랫말은 전래 자장가의 짧은 구절만 쓴다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "강 건너의 자장가",
        "summary": "화면은 켜지지 않는다. 남은 것은 목소리뿐이다. 주인공은 소환진 너머를 향해 노래를 부른다. 엄마가 불러 주던, 이모가 좋아하던, 등외구 사람들이 이백 년 동안 이어 불러 온 그 자장가. 세라가, 피오가, 등외구 사람들이 따라 부른다.\n노래가 실을 타고 건너가면, 저편의 다온은 알아차린다. 엄마의 노래다. 오빠가 살아 있다. 다온은 부르기를 멈추고, 대신 그 노래를 따라 부른다. 부르는 목소리가 기다리는 목소리로 바뀌는 순간, 소환진은 다온을 붙잡지 못한다.\n\n장면 제약: 다온은 이 세계로 넘어오지 않는다. 노랫말은 전래 자장가의 짧은 구절만 쓴다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "주인공이 소환진을 향해 자장가를 부른다.\n\n주변 사람들이 노래를 따라 부르며 소환진의 빛이 흔들린다.\n\n저편의 다온이 부르기를 멈추고, 소환진의 빛이 꺼지며 카시안의 의식이 실패한다.",
          "selectionScope": "",
          "constraints": "다온은 이 세계로 넘어오지 않는다. 노랫말은 전래 자장가의 짧은 구절만 쓴다.",
          "success": "",
          "unmet": "노래가 닿지 않으면, 대성등 안에 남은 이모의 불씨가 마지막 힘으로 소환진을 끊어 준다.",
          "closureConditions": [
            {
              "id": "r2e07b_lullaby-c1",
              "text": "주인공이 소환진을 향해 자장가를 부른다."
            },
            {
              "id": "r2e07b_lullaby-c2",
              "text": "주변 사람들이 노래를 따라 부르며 소환진의 빛이 흔들린다."
            },
            {
              "id": "r2e07b_lullaby-c3",
              "text": "저편의 다온이 부르기를 멈추고, 소환진의 빛이 꺼지며 카시안의 의식이 실패한다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "r2e07b_lullaby-constraints",
            "description": "다온은 이 세계로 넘어오지 않는다. 노랫말은 전래 자장가의 짧은 구절만 쓴다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "r2e08_kindle",
        "name": "천 개의 등불",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 빛이 모자라면, 주인공과 동료들이 자신의 소중한 기억을 더 내놓아 등불을 채운다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "약속의 날. 대성등 탑 아래 광장에 사람들이 모인다. 첫 번째 용사의 설계도대로 다시 짠 등불 앞에서, 한 사람씩 기억 한 조각을 내놓는다. 가장 행복했던 날, 소중한 이름, 처음 본 바다. 기억이 빛이 되어 오를 때마다 대성등 안에 남아 있던 이모의 불씨는 조금씩 자유로워진다. 지난밤 감옥에서 숨을 거둔 오르텐의 부탁을 주인공이 받아들였다면, 그의 영혼도 마지막으로 등불에 보태진다.\n새 등불이 충분히 밝을지는 사람들이 얼마나 함께했는지(모인 기억)에 달려 있다. 모자라면 주인공과 동료들이 자신의 소중한 기억을 더 내놓아야 한다. 그리고 풀려난 이모와 마지막으로 이야기할 수 있는 시간.\n\n장면 제약: 기억을 바친 사람은 그 기억을 되찾지 못한다. 누구의 영혼도 통째로 태우지 않는다(스스로 원한 오르텐의 영혼만 예외).",
        "required": true,
        "sequence": 21,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "nextEventId": "r2e09_1004",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "r2e08_kindle-c1",
            "description": "사람들이 한 사람씩 기억을 내놓아 새 등불에 빛이 오른다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e08_kindle-c2",
            "description": "대성등 안에 남아 있던 이모의 불씨가 풀려나 주인공과 마지막 대화를 나눈다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e08_kindle-c3",
            "description": "새 등불이 대성등을 대신해 성도를 밝힌다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e08_kindle-constraints",
            "description": "기억을 바친 사람은 그 기억을 되찾지 못한다. 누구의 영혼도 통째로 태우지 않는다(스스로 원한 오르텐의 영혼만 예외).",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "천 개의 등불",
        "summary": "약속의 날. 대성등 탑 아래 광장에 사람들이 모인다. 첫 번째 용사의 설계도대로 다시 짠 등불 앞에서, 한 사람씩 기억 한 조각을 내놓는다. 가장 행복했던 날, 소중한 이름, 처음 본 바다. 기억이 빛이 되어 오를 때마다 대성등 안에 남아 있던 이모의 불씨는 조금씩 자유로워진다. 지난밤 감옥에서 숨을 거둔 오르텐의 부탁을 주인공이 받아들였다면, 그의 영혼도 마지막으로 등불에 보태진다.\n새 등불이 충분히 밝을지는 사람들이 얼마나 함께했는지(모인 기억)에 달려 있다. 모자라면 주인공과 동료들이 자신의 소중한 기억을 더 내놓아야 한다. 그리고 풀려난 이모와 마지막으로 이야기할 수 있는 시간.\n\n장면 제약: 기억을 바친 사람은 그 기억을 되찾지 못한다. 누구의 영혼도 통째로 태우지 않는다(스스로 원한 오르텐의 영혼만 예외).",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "사람들이 한 사람씩 기억을 내놓아 새 등불에 빛이 오른다.\n\n대성등 안에 남아 있던 이모의 불씨가 풀려나 주인공과 마지막 대화를 나눈다.\n\n새 등불이 대성등을 대신해 성도를 밝힌다.",
          "selectionScope": "",
          "constraints": "기억을 바친 사람은 그 기억을 되찾지 못한다. 누구의 영혼도 통째로 태우지 않는다(스스로 원한 오르텐의 영혼만 예외).",
          "success": "",
          "unmet": "빛이 모자라면, 주인공과 동료들이 자신의 소중한 기억을 더 내놓아 등불을 채운다.",
          "closureConditions": [
            {
              "id": "r2e08_kindle-c1",
              "text": "사람들이 한 사람씩 기억을 내놓아 새 등불에 빛이 오른다."
            },
            {
              "id": "r2e08_kindle-c2",
              "text": "대성등 안에 남아 있던 이모의 불씨가 풀려나 주인공과 마지막 대화를 나눈다."
            },
            {
              "id": "r2e08_kindle-c3",
              "text": "새 등불이 대성등을 대신해 성도를 밝힌다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "r2e08_kindle-constraints",
            "description": "기억을 바친 사람은 그 기억을 되찾지 못한다. 누구의 영혼도 통째로 태우지 않는다(스스로 원한 오르텐의 영혼만 예외).",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      },
      {
        "id": "r2e09_1004",
        "name": "1004",
        "kind": "event",
        "type": "Conditional",
        "visibility": "Hidden",
        "status": "Planned",
        "conditions": "",
        "cancelConditions": "",
        "participants": "",
        "effects": "",
        "onSuccess": "",
        "onFailure": "종결조건 미충족 시 허용된 대체 종결: 주인공의 선택이 늦어지면 실이 조금씩 가늘어지고, 동료들이 각자의 방식으로 마지막 인사를 건네며 주인공의 결정을 기다린다.\n이 전개로 수습되면 사건을 전환하며 생략·포기·대체한 목표를 다시 강제하지 않는다. 이 전개로도 수습되지 않은 의무만 다음 사건으로 이월한다.",
        "followUp": "",
        "description": "새 등불이 타오른 밤. 대성등은 더 이상 아무도 태우지 않는다. 다온이 부르던 목소리가 남긴 실은 이제 아무것도 삼키지 않고, 오직 집으로 이어진다. 이모는 마지막 인사를 남기고 그 실을 따라 먼저 떠난다.\n그리고 주인공 앞에도 길이 열린다. 돌아갈 것인가, 남을 것인가. 돌아가면 세라와 동료들, 이 세계의 새 등불과 작별해야 한다. 남으면 엄마와 다온은 계속 기다려야 한다. 어느 쪽이든 쉬운 길은 아니다.\n어느 쪽을 고르든, 10월 4일의 강가에서 누군가는 오래 기다린 숫자를 받게 된다. 엄마의 서랍 속, 건전지가 닳은 지 오래인 낡은 삐삐에 불이 들어온다. '1004'.\n\n이 장면에서 회수할 복선: '빨리빨리'를 들은 주인공이 떠올리는 엄마 서랍 속 이모의 낡은 삐삐와 숫자 암호(1004 천사, 8282 빨리빨리).\n회수: 마지막 장면, 건전지가 닳은 지 오래인 그 삐삐에 불이 들어와 '1004'가 뜬다.\n\n이 장면에서 회수할 복선: 오르텐이 들려주는 신전의 교리. '귀환문은 그대를 부르는 목소리를 따라 열린다.' 처음에는 그럴듯한 설교로만 들린다.\n회수: 그것은 첫 번째 용사가 남긴 진짜 원리였다. 다온이 부르는 목소리가 남긴 실을 따라, 진짜 귀환의 길이 열린다.\n\n장면 제약: 주인공의 선택을 대신 정하지 않는다. 어느 쪽을 골라도 이별과 재회가 함께 있는 결말로 쓴다.",
        "required": true,
        "sequence": 22,
        "completionSignals": "",
        "requiredItems": "",
        "requiredDialogue": "",
        "requiredSpeakerId": "",
        "appliesTo": [],
        "rules": [],
        "beats": [],
        "alternateBeats": [],
        "sceneMarkers": [],
        "canonLocation": "",
        "act": "ACT1",
        "failureConditions": "",
        "requiredFunctions": [
          {
            "id": "r2e09_1004-c1",
            "description": "이모의 마지막 불씨가 주인공에게 작별 인사를 남기고 실을 따라 떠난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e09_1004-c2",
            "description": "주인공이 돌아갈지 남을지를 스스로 선택하고, 그 선택이 장면에서 이루어진다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e09_1004-c3",
            "description": "한국의 강가나 집에서 엄마 또는 다온이 '1004'라는 신호를 받는 장면으로 이야기가 끝난다.",
            "type": "READER_UNDERSTANDING",
            "required": true,
            "alternatives": []
          },
          {
            "id": "r2e09_1004-constraints",
            "description": "주인공의 선택을 대신 정하지 않는다. 어느 쪽을 골라도 이별과 재회가 함께 있는 결말로 쓴다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false,
            "alternatives": []
          }
        ],
        "revealTerms": [],
        "title": "1004",
        "summary": "새 등불이 타오른 밤. 대성등은 더 이상 아무도 태우지 않는다. 다온이 부르던 목소리가 남긴 실은 이제 아무것도 삼키지 않고, 오직 집으로 이어진다. 이모는 마지막 인사를 남기고 그 실을 따라 먼저 떠난다.\n그리고 주인공 앞에도 길이 열린다. 돌아갈 것인가, 남을 것인가. 돌아가면 세라와 동료들, 이 세계의 새 등불과 작별해야 한다. 남으면 엄마와 다온은 계속 기다려야 한다. 어느 쪽이든 쉬운 길은 아니다.\n어느 쪽을 고르든, 10월 4일의 강가에서 누군가는 오래 기다린 숫자를 받게 된다. 엄마의 서랍 속, 건전지가 닳은 지 오래인 낡은 삐삐에 불이 들어온다. '1004'.\n\n이 장면에서 회수할 복선: '빨리빨리'를 들은 주인공이 떠올리는 엄마 서랍 속 이모의 낡은 삐삐와 숫자 암호(1004 천사, 8282 빨리빨리).\n회수: 마지막 장면, 건전지가 닳은 지 오래인 그 삐삐에 불이 들어와 '1004'가 뜬다.\n\n이 장면에서 회수할 복선: 오르텐이 들려주는 신전의 교리. '귀환문은 그대를 부르는 목소리를 따라 열린다.' 처음에는 그럴듯한 설교로만 들린다.\n회수: 그것은 첫 번째 용사가 남긴 진짜 원리였다. 다온이 부르는 목소리가 남긴 실을 따라, 진짜 귀환의 길이 열린다.\n\n장면 제약: 주인공의 선택을 대신 정하지 않는다. 어느 쪽을 골라도 이별과 재회가 함께 있는 결말로 쓴다.",
        "cortexDesign": {
          "schema": "STUDIO_EVENT_DESIGN_V2",
          "occurrenceEnabled": false,
          "otherViewpoint": false,
          "viewpoint": "",
          "occurrence": "",
          "closure": "이모의 마지막 불씨가 주인공에게 작별 인사를 남기고 실을 따라 떠난다.\n\n주인공이 돌아갈지 남을지를 스스로 선택하고, 그 선택이 장면에서 이루어진다.\n\n한국의 강가나 집에서 엄마 또는 다온이 '1004'라는 신호를 받는 장면으로 이야기가 끝난다.",
          "selectionScope": "",
          "constraints": "주인공의 선택을 대신 정하지 않는다. 어느 쪽을 골라도 이별과 재회가 함께 있는 결말로 쓴다.",
          "success": "",
          "unmet": "주인공의 선택이 늦어지면 실이 조금씩 가늘어지고, 동료들이 각자의 방식으로 마지막 인사를 건네며 주인공의 결정을 기다린다.",
          "closureConditions": [
            {
              "id": "r2e09_1004-c1",
              "text": "이모의 마지막 불씨가 주인공에게 작별 인사를 남기고 실을 따라 떠난다."
            },
            {
              "id": "r2e09_1004-c2",
              "text": "주인공이 돌아갈지 남을지를 스스로 선택하고, 그 선택이 장면에서 이루어진다."
            },
            {
              "id": "r2e09_1004-c3",
              "text": "한국의 강가나 집에서 엄마 또는 다온이 '1004'라는 신호를 받는 장면으로 이야기가 끝난다."
            }
          ]
        },
        "policyConstraints": [
          {
            "id": "r2e09_1004-constraints",
            "description": "주인공의 선택을 대신 정하지 않는다. 어느 쪽을 골라도 이별과 재회가 함께 있는 결말로 쓴다.",
            "type": "NEGATIVE_CONSTRAINT",
            "required": false
          }
        ],
        "eventPolicy": {
          "schema": "CORTEX_STUDIO_EVENT_POLICY_V2",
          "occurrenceEnabled": false,
          "occurrence": "",
          "otherViewpoint": false,
          "viewpoint": "",
          "required": true,
          "mainBeats": 3,
          "earlyClosureMinBeats": 2,
          "extensionBeats": 2,
          "unmetOutcome": "TRANSITION",
          "carryover": "ONLY_IF_AUTHORED_RECOVERY_UNRESOLVED",
          "selection": "EXPLICIT_NEXT_THEN_ARRAY_ORDER",
          "priority": "DISABLED"
        }
      }
    ],
    "hiddenEventClocks": [],
    "hiddenForeshadowings": [
      {
        "id": "FSH_01_1004",
        "title": "상태창 맨 아래 한순간 스친 뭉개진 숫자 '1004'. 엄마가 편지 끝에 쓰던 숫자와 같다.\n「빛의 연회」에서 [8282], [도망쳐]와 함께 다시 나타난다.\n회수: 바르트가 여덟 번째 용사가 자기를 '천사(1004)'라 불렀다고 말한다. 상태창에 끼어든 것이 그녀였음을 짐작하게 된다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e01_summon",
        "reinforcementPlan": "",
        "payoffConditions": "e06_angel",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_02_CANDY",
        "title": "오르텐이 건네는 노란 꿀사탕('옛 용사님께 배운 맛이라네'), 그리고 도하 주머니 속 엄마가 챙겨 준 꿀사탕 두 개('이모가 좋아하던 거').\n회수: 안개의 왕이 꿀사탕 냄새에 멈칫한다. 도하가 엄마의 꿀사탕을 건네면 그녀는 처음으로 웃는다. 오르텐이 그 맛을 누구에게 배웠는지도 함께 드러난다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e01_summon",
        "reinforcementPlan": "",
        "payoffConditions": "e08_heart",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_03_NOTEBOOK",
        "title": "세라가 무엇이든 받아 적는 작은 가죽 수첩('용사님 관찰 일지예요!'). 밤마다 수첩을 들고 어딘가로 가는 모습이 한두 번 비친다.\n회수: 그 수첩은 매일 밤 오르텐에게 올라가던 보고서였다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e01_summon",
        "reinforcementPlan": "",
        "payoffConditions": "e09_ledger",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_04_GAUGE",
        "title": "상태창의 '귀환 게이지 0%'. 잔향을 벨수록 차오르는, 집으로 가는 진행도처럼 보이는 수치.\n회수: 연회에서 게이지 위로 '연소 준비도'라는 진짜 이름이 겹쳐 보인다. 「세라의 수첩」의 장부 '숙성도 60에 이르면 즉시 점화'로 의미가 확정된다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e01_summon",
        "reinforcementPlan": "",
        "payoffConditions": "e07_feast",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_05_LULLABY",
        "title": "등외구에서 피오의 할머니가 부르는 '용사의 자장가'. 엄마가 불러 주던 전래 자장가와 같은 가락이다.\n회수: 안개의 왕이 같은 자장가를 흥얼거린다. 두 번째 이야기에서 첫 번째 용사가 가르친 노래였음이 밝혀지고, 「강 건너의 자장가」에서 다온에게 닿는 목소리가 된다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e02_phone",
        "reinforcementPlan": "",
        "payoffConditions": "e08_heart",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_06_DRAIN",
        "title": "피오가 사라지는 옛 배수로 지하 통로. '신전 놈들도 까먹은 길'.\n회수: 그 통로는 대성등 탑 밑까지 이어진다. 의식 날 피오가 그 길로 동료들을 이끌거나 주인공을 빼낸다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e02_phone",
        "reinforcementPlan": "",
        "payoffConditions": "e11_gate",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_07_DAON_VOICE",
        "title": "피오가 훔친 스마트폰을 함부로 누르다 재생된 다온의 음성 메시지('오빠, 오늘도 늦어? 엄마 또 강 갔대. 빨리 와.').\n회수: 열 번째 소환진 너머에서 같은 목소리가 오빠를 부른다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e02_phone",
        "reinforcementPlan": "",
        "payoffConditions": "r2e06_tenth",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_08_BARTH_KOREAN",
        "title": "바르트가 겁먹은 주인공에게 던지는 번역되지 않은 말 '괜찮아', 다급할 때 외치는 '빨리빨리'.\n회수: 여덟 번째 용사에게 배운 말이었다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e03_fog",
        "reinforcementPlan": "",
        "payoffConditions": "e06_angel",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_09_VOICES",
        "title": "기사들에게는 짐승 울음, 주인공에게만 한국어로 들리는 잔향의 목소리('엄마…', '추워…', '집에 갈래…').\n회수: 성등 결정 속에도 같은 말이 한글로 새겨져 있다. 잔향과 결정은 같은 것이 타고 남은 두 얼굴이다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e03_fog",
        "reinforcementPlan": "",
        "payoffConditions": "e04_crystal",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_10_GIRL_RUMOR",
        "title": "원정에서 돌아오는 기사들의 수군거림. '안개의 왕은 이상한 옷을 입은 소녀 모양이었다.'\n회수: 그 '이상한 옷'은 1990년대 한국 여고 교복이다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e03_fog",
        "reinforcementPlan": "",
        "payoffConditions": "e08_heart",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_11_PAGER",
        "title": "'빨리빨리'를 들은 주인공이 떠올리는 엄마 서랍 속 이모의 낡은 삐삐와 숫자 암호(1004 천사, 8282 빨리빨리).\n회수: 마지막 장면, 건전지가 닳은 지 오래인 그 삐삐에 불이 들어와 '1004'가 뜬다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e03_fog",
        "reinforcementPlan": "",
        "payoffConditions": "r2e09_1004",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_12_OLD_HANGUL",
        "title": "아주 오래된 결정 조각에 새겨진, 아래아(ㆍ)가 섞인 옛 한글.\n회수: 첫 번째 용사는 이백여 년 전 조선의 등롱장이 강막손이었다. 무덤의 잔향은 조선 말투로 말한다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e04_crystal",
        "reinforcementPlan": "",
        "payoffConditions": "r2e04_grave",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_13_NINTH_LINE",
        "title": "금서고 장부의 아홉 번째 줄에 이미 적혀 있는 주인공의 이름과 '귀환 예정일'(소환 40일째).\n회수: 연회에서 오르텐이 발표한 의식 날짜가 그 날짜와 정확히 같다. 처음부터 정해져 있었다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e05_archive",
        "reinforcementPlan": "",
        "payoffConditions": "e07_feast",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_14_FIRST_HERO",
        "title": "다른 용사들은 모두 '빛이 되어 돌아가다'인데, 첫 번째 용사의 줄만 '안개를 건너와 스스로 불이 되다'. 사람들은 '대성등을 밝혔다'는 비유로 읽는다.\n회수: 첫 번째 용사만은 소환된 것이 아니라 스스로 등불이 되었고, 원래는 아무도 태우지 않는 등불을 설계했다는 사실을 오르텐이 털어놓는다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e05_archive",
        "reinforcementPlan": "",
        "payoffConditions": "r2e02_prison",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_15_HAIRPIN",
        "title": "바르트가 건네는 하트 모양 플라스틱 머리핀. 사진 속 이모가 꽂고 있던 것과 같다.\n회수: 안개의 왕의 머리, 머리핀이 있어야 할 자리가 비어 있다. 주인공이 머리핀을 내밀면 그녀는 자신이 누구였는지 떠올린다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e06_angel",
        "reinforcementPlan": "",
        "payoffConditions": "e08_heart",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_16_CASSIAN",
        "title": "연회에서 부신관 카시안이 차갑게 내뱉는 말. '등불에 감정은 사치입니다.' 오르텐의 꿀사탕을 못마땅하게 보는 시선.\n회수: 오르텐이 갇힌 뒤, 카시안은 감정 없이 열 번째 소환진을 그린다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e07_feast",
        "reinforcementPlan": "",
        "payoffConditions": "r2e03_circle",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_17_ORTEN_COUGH",
        "title": "오르텐이 기침을 감추는 손수건의 잿빛 얼룩, 살짝 잿빛인 손가락 끝.\n회수: 그는 폐가 잿빛으로 굳는 병으로 죽어 가고 있었고, 그래서 의식을 서둘렀다. 감옥에서 자신의 영혼을 등불에 보태 달라고 부탁한다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e07_feast",
        "reinforcementPlan": "",
        "payoffConditions": "r2e02_prison",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_18_FOUND",
        "title": "소환 직전 강가에서 들린 아주 반가운 목소리. '……찾았다.' 주인공은 처음에 소환진을 그린 신전의 목소리라고 생각한다.\n회수: 그것은 대성등 안에서 언니 가족의 부름을 듣고 손을 뻗은 이모의 목소리였다. '내가 너를 불렀어. 미안해.'",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e01_summon",
        "reinforcementPlan": "",
        "payoffConditions": "e08_heart",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_19_LETTER",
        "title": "반쯤 타다 남은 엄마의 편지. '혹시 길을 잃었다면 불빛을 따라 와. 언니는 아직 그 집에 산다. 1004'.\n회수: 길을 잃은 이모는 정말로 불빛(대성등)을 따라왔다가 갇혔다. 귀환문에서 편지를 읽은 이모는 '이번엔 내가 불빛이 되어 줄게'라며 스스로 등불에 들어간다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e01_summon",
        "reinforcementPlan": "",
        "payoffConditions": "e11_gate",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      },
      {
        "id": "FSH_20_DOCTRINE",
        "title": "오르텐이 들려주는 신전의 교리. '귀환문은 그대를 부르는 목소리를 따라 열린다.' 처음에는 그럴듯한 설교로만 들린다.\n회수: 그것은 첫 번째 용사가 남긴 진짜 원리였다. 다온이 부르는 목소리가 남긴 실을 따라, 진짜 귀환의 길이 열린다.",
        "visibility": "Hidden",
        "status": "Planned",
        "earliestDate": "",
        "latestDate": "",
        "plantingScene": "e01_summon",
        "reinforcementPlan": "",
        "payoffConditions": "r2e09_1004",
        "payoffResult": "",
        "relatedEntities": "",
        "misdirection": "",
        "notes": ""
      }
    ],
    "hiddenImageTriggers": [],
    "hiddenRisks": "",
    "gmLedger": {
      "worldTruthLedger": "[숨은 진실 — 대성등의 연료]\n대성등은 영혼을 태워 빛을 낸다. 이 세계 사람의 영혼은 며칠밖에 타지 않지만, 다른 세계에서 온 영혼은 '두 세계의 기억'을 품고 있어 스물여덟 해 가까이 탄다. 그래서 신전은 빛이 약해질 때마다 이세계에서 사람을 소환한다. 귀환문은 대성등 탑 꼭대기의 화로로 이어지는 문이며, 귀환 의식은 용사를 산 채로 대성등에 들여보내는 의식이다. 귀환 다음 날 대성등이 다시 밝아지는 이유가 그것이다. 여덟 명의 용사 중 집에 돌아간 사람은 없다. 신전 상층부(오르텐, 카시안 등 극소수)만 이 사실을 안다.\n\n[역대 용사]\n제1대 강막손(1802년 조선 순조 연간의 등롱장이. 소환된 것이 아니라 등불을 들고 안개를 건너왔다. 스스로 대성등을 만들고 스스로 불이 되었다) / 제2대 1830년 / 제3대 1858년 / 제4대 1886년 / 제5대 1914년 / 제6대 1942년 / 제7대 1970년 / 제8대 1998년 한소이 / 제9대 2026년 윤도하. 모두 한국(조선)에서 왔다. 소환은 직전 용사의 인연을 따라가기 때문이다.\n\n[귀환 게이지의 정체]\n축복의 창은 대성등의 빛으로 작동하는 감시·계량 장치다. 귀환 게이지의 진짜 이름은 '연소 준비도'다. 잔향을 베어 정화하면 그 잔향(옛 용사가 타고 남은 기억)을 용사가 흡수하고, 영혼이 '두 세계의 무게'를 더 얻어 더 밝게 탄다. 게이지가 60%를 넘으면 신전은 의식을 서두를 수 있고, 손등에 등불 같은 금빛 무늬가 비치기 시작한다. 한 사건에서 여러 번 베어도 게이지는 그 사건에서 한 번만 오른다(잔향의 기억은 한 덩어리로 흡수된다). 본문에서 상태창 수치를 쓸 때는 독자 HUD의 현재값만 인용한다.\n잔향을 베지 않고 한국어로 대답해 주거나 애도하면, 잔향은 기억의 장면 하나(불타는 문, 화로의 열기, 탑 꼭대기에서 내려다본 도시 같은 것)를 남기고 조용히 흩어진다. 이때 게이지는 오르지 않는다.\n\n[잔향과 안개의 왕]\n대성등에 탄 영혼의 기억은 재가 되어 바람을 타고 안개 속에 떨어진다. 그 재가 뭉친 것이 잔향이다. 잔향은 집에 가고 싶다는 마지막 생각을 되풀이하며 한국어로 중얼거린다(\"엄마\", \"추워\", \"집에 갈래\" 등). 이 세계 사람에게는 짐승 울음으로 들린다. 안개가 깊을수록 오래된 용사의 잔향이라, 심부의 잔향은 일제강점기나 조선시대 말투를 쓴다.\n'안개의 왕'은 여덟 번째 용사 한소이의 잔향이 스물몇 해 동안 쌓이며 다른 용사들의 잔향을 끌어모아, 최근 몇 년 사이에야 형체를 갖춘 존재다. 한소이의 생명은 지금도 대성등 안에서 타고 있고, 기억과 의지는 안개 속에서 왕의 모습을 하고 있다. 그래서 그녀는 대성등의 빛으로 작동하는 축복의 창에 잡음처럼 끼어들 수 있다(상태창의 '1004', '8282', '도망쳐' 같은 깨진 글자). 그녀는 신전 원정대를 공격해 다음 용사를 막으려 했지만, 대성등이 꺼지면 30만 명이 죽는다는 것도 알기에 등불 자체는 부수지 못했다.\n\n[소환의 원리 — 부르는 목소리]\n소환진은 대성등 안에서 타고 있는 직전 용사의 영혼에 남은 '인연의 실'을 붙잡아, 그 용사를 가장 간절히 부르는 목소리가 있는 곳으로 문을 연다. 2026년 10월 4일 밤, 도하가 강가에서 이모에게 쓴 엄마의 편지를 태우며 \"이모\"를 부른 순간, 대성등 안의 한소이가 그 목소리를 듣고 반가움에 \"찾았다\" 하고 손을 뻗었다. 그 손길이 실이 되어 도하가 소환됐다. 한소이는 이것을 깊이 자책한다.\n교리 '귀환문은 부르는 목소리를 따라 열린다'는 원래 첫 번째 용사가 남긴 진짜 원리다. 신전은 이것을 소환에만 써 왔다. 반대로, 다른 세계에서 이쪽의 누군가를 간절히 부르는 목소리가 있고 대성등이 그 실을 삼키지 않는다면, 그 실을 따라 진짜로 돌아갈 길이 열린다(두 번째 이야기의 핵심).\n\n[첫 번째 용사와 버려진 설계]\n강막손은 원래 '많은 사람이 기억을 한 조각씩 나누어 태우는 등불'을 설계했다. 누구의 영혼도 통째로 태우지 않지만 모두의 동의가 필요했다. 당시 신전과 귀족들은 자기 기억을 내놓기를 거부했고, 강막손은 스스로 불이 되어 왕국을 살렸다. 이후 신전은 '한 사람을 태우는' 쉬운 방식을 제도로 만들었다. 설계도는 안개 심부 그의 무덤에 묻혔다. 등외구의 '용사의 자장가'는 그가 가르친 전래 자장가 '자장자장 우리 아가'다. 도하의 엄마도, 이모도 같은 노래를 불렀다.\n\n[오르텐의 진심]\n대신관 오르텐은 모든 것을 안다. 1999년 한소이의 의식을 직접 집전했다. 그는 '한 사람과 30만 명'을 저울질했고 매번 30만 명을 택했다. 잔인하지만 악의는 없다. 그는 폐가 잿빛으로 굳는 병으로 1년을 넘기기 어렵고, 죽기 전에 다음 스물여덟 해를 확보하려 서두른다. 꿀사탕은 한소이에게 배운 것이며 그는 그녀를 손녀처럼 아꼈다. 그래서 더 끔찍하다. 그의 장부에는 용사가 '아홉 번째 연료'로 기록되어 있다.\n\n[공개 조건 — 정사 진행표]\n- 「아홉 번째 등불」「도둑맞은 스마트폰」: 진실의 어떤 부분도 공개하지 않는다. 상태창의 '1004' 잡음이 한 번 스칠 뿐이다.\n- 「안개 속에서 들린 말」: 잔향이 한국어로 말한다는 것까지만. 잔향이 옛 용사라는 사실은 누구도 확정하지 않는다.\n- 「결정 속의 글씨」: 성등 결정 속 한글, 결정이 '무언가가 타고 남은 것'이라는 메이블의 가설까지.\n- 「금서고의 아홉 번째 줄」: 역대 용사 기록의 규칙과 아홉 번째 줄. '태운다'는 말은 아직 아무도 확언하지 않는다.\n- 「천사라고 불러 줘」: 여덟 번째 용사가 1998년에 온 한국 소녀이고 '천사(1004)'라 불렸으며 귀환문 앞에서 비명을 질렀다는 것. 이름은 바르트가 끝내 말하지 않는다.\n- 「빛의 연회」: 상태창의 '연소 준비도' 글자, 의식 날짜 발표.\n- 「안개의 심장」: 안개의 왕이 이모 한소이라는 사실, 귀환문이 집으로 가는 문이 아니라는 경고. 이 사건부터 '한소이'라는 이름을 본문에 쓸 수 있다.\n- 「세라의 수첩」: 오르텐의 장부 '아홉 번째 연료'. 대성등이 영혼을 태운다는 진실의 확정.\n- 「귀환문」: 모든 진실과 첫 번째 이야기의 결말.\n- 두 번째 이야기: 첫 번째 용사, 버려진 설계, 진짜 귀환의 원리.\n\n[첫 번째 이야기의 결말 — 고정된 줄기와 변주]\n고정: 의식은 멈추고 주인공은 타지 않는다. 의식이 무너지며 대성등이 크게 흔들리고 등외구 쪽으로 안개가 밀려든다. 안개의 왕(한소이)은 의식장에 나타나 조카를 지키고, 무너진 불을 대신하기 위해 남은 자신을 스스로 대성등에 바친다(대략 백 일의 빛). 오르텐은 체포된다. 모든 것이 끝난 밤, 이세계에서 통신이 될 리 없는 스마트폰이 진동하며 화면이 저절로 켜지고(배터리가 0%여도 이 한 번은 켜진다) 다온의 메시지가 도착한다: \"오빠 어디야. 엄마가 오늘도 강에 갔어. 제발 대답해.\"\n변주(현재 수치와 지난 선택을 따른다):\n- 진실의 조각 5 이상: 주인공이 모은 증거(결정 속 한글, 장부, 바르트의 증언, 스마트폰 녹음 등)로 의식장의 시민들 앞에서 진실을 증명한다. 오르텐은 군중 앞에서 스스로 지팡이를 내려놓는다. 4 이하: 진실은 의식장의 소수만 목격하고, 신전은 '용사의 광란'이라는 소문으로 덮으려 하지만 바르트가 오르텐을 체포한다. 성도에는 엇갈린 소문이 퍼진다.\n- 귀환 게이지 60 이상: 문이 열리는 순간 주인공의 손등부터 실제로 금빛 불이 번지기 시작한다. 안개의 왕이 그 불을 자기 쪽으로 끌어당겨 대신 타며, 주인공의 오른손에는 등불 모양 흉터가 남는다. 60 미만: 문은 주인공을 끌어당기지 못하고, 오르텐은 '아직 덜 익었다'는 사실에 처음으로 당황한다.\n- 세라의 신뢰가 높았고 「등불을 끄는 밤」을 지났다면: 세라가 귀환가 대신 '용사의 자장가'를 부르며 의식을 멈추는 데 앞장선다. 「철창 속의 용사」를 지났다면: 세라는 귀환가를 부르다 끝내 목이 메어 노래를 멈추고, 울며 주인공에게 달려와 사과한다.\n- 주인공이 꿀사탕·머리핀·편지 중 무엇을 이모에게 건넸는지에 따라 마지막 대화가 달라진다.\n\n[두 번째 이야기의 출발점]\n첫 번째 이야기의 결말에서 서른 날 뒤. 대성등은 한소이가 남긴 마지막 불씨로 타고 있으며 빛의 원이 매일 조금씩 줄어든다(메이블의 계산으로 남은 날 약 일흔). 오르텐은 지하 감옥에 있고 신전은 부신관 카시안이 이끈다. 세라는 사제복을 벗고 주인공 곁에 있다. 성도는 진실을 믿는 사람과 믿지 않는 사람으로 갈라졌다. 의식이 무너진 날 축복의 창의 게이지는 0%로 돌아갔다. 대성등 가까이에서는 스마트폰에 아주 드물게 신호 한 칸이 뜬다. 다온이 매일 밤 오빠를 부르며 보내는 메시지가 소환의 실을 타고 오는 것이다. 카시안은 주인공의 실을 닻으로 삼아 열 번째 용사를 부르려 한다. 그 소환진은 주인공을 가장 간절히 부르는 목소리, 즉 다온에게 닿는다.\n\n[실패와 악화 규칙]\n- 주인공이 신전에 대놓고 의심을 드러내면 오르텐은 부드럽게 넘기지만 감시가 늘고 세라의 보고가 길어진다. 신전은 주인공을 의식 전에 해치지 않는다(연료이기 때문이다).\n- 귀환 게이지가 높을수록 상태창의 잡음은 선명해지고 오르텐은 의식을 서두른다.\n- 스마트폰 배터리가 0%가 되면 기기는 켜지지 않지만 사라지거나 부서지지 않는다.\n- 다온은 어떤 경우에도 이 세계로 넘어오지 않는다.",
      "hiddenTimeline": "",
      "secretResources": "",
      "plannedTwists": "",
      "forbiddenDisclosures": "",
      "failureEscalationRules": "",
      "continuityNotes": ""
    }
  }
}
~~~