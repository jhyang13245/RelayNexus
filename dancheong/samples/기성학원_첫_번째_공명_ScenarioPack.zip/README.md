# 기성학원: 첫 번째 공명 ScenarioPack v0.6

ChatGPT에는 CHATGPT_IMPORT.md를 업로드한 뒤 /패키지불러오기를 입력하십시오.