# RELAY NOVEL SCENARIO PACKAGE

PACKAGE_VERSION: 0.6
ENGINE_VERSION: 1.4
PACKAGE_ID: RN-AI-KI-ACADEMY-001
TITLE: 기성학원: 첫 번째 공명
DIFFICULTY: NORMAL
RANDOM_SEED: 20420302

## IMPORT INSTRUCTION

이 파일은 범용 릴레이 소설 시뮬레이터 v0.5 실행 패키지다.
1. 세계관·인물·세력·사건을 정사 우선순위에 따라 검증한다.
2. HIDDEN_GM_DATA는 감독자 전용이며 플레이어에게 직접 공개하거나 요약하지 않는다.
3. 관계 수치는 방향성이 있으며 반대 방향을 자동으로 복제하지 않는다.
4. 사건 시계와 복선 장부를 매 턴 갱신하되 공개 범위를 준수한다.
5. TURN_PRESENTATION 설정에 따라 매 턴 최하단에 추천 행동과 장면 이미지를 출력한다.
6. 추천 행동은 자유 입력을 제한하지 않으며 숨은 정보를 이용하거나 성공을 보장하지 않는다.
7. 이미지 생성 기능이 없으면 생성했다고 주장하지 말고 [SCENE IMAGE PROMPT]를 출력한다.
8. 검증 완료 후 공개 초기 상태표를 만들고 제1턴을 시작한다.

사용자 명령: /패키지불러오기

## SCENARIO

~~~json
{
  "title": "기성학원: 첫 번째 공명",
  "genre": "현대 초능력 학교물·성장·액션·로맨스·미스터리",
  "worldType": "근미래 대체현대",
  "startDate": "2042-03-02",
  "startLocation": "대한민국 국립기성학원 중등부, 능력설계실",
  "tone": "밝고 풋풋한 학원생활을 중심으로 하되, 능력자 사회의 계급과 국가권력급 인물의 정치적 긴장이 서서히 드러나는 청춘 성장극",
  "playStyle": "자유 행동형 장기 시뮬레이션. 수업·동아리·친구·연애·대회·실전훈련·학교 비밀 조사를 병행한다.",
  "author": "ChatGPT AI Scenario Builder",
  "notes": "사용자 아이디어를 바탕으로 생성한 AI 설계 프로젝트. 주인공의 최종 능력은 첫 장면에서 마스터 교사와 상담한 뒤 플레이어가 선택한다. 추천 행동 3개와 장면 이미지 생성은 기본 활성화한다.\n[AI 생성 요약] 기 수치에 따라 선발된 학생들이 국가 유일의 초능력 학교에서 능력을 설계하고 성장하는 현대 학원물. 주인공 윤시우는 입학 첫날 희귀한 이중 공명 파형을 가진 채 마스터 한세린과 자신의 능력 방향을 선택한다.\n[AI 추론 전제] 배경 연도는 기 연구와 교육제도가 충분히 정착한 2042년으로 설정했다. / 대한민국의 초능력 학교 명칭은 '국립기성학원'으로 설정했다. / 주인공의 입학 기 수치는 12,480으로 설정했으며 국가권력급은 아니다. / 주인공의 능력은 플레이어 선택권을 위해 미확정으로 유지했다. / 학원 일상, 우정, 라이벌, 풋풋한 로맨스와 학교 비밀 미스터리를 함께 구성했다. / 미성년자 등장인물의 로맨스는 건전한 청춘물 범위로 제한했다.",
  "difficultyProfile": {
    "difficulty": "NORMAL",
    "protagonistProtection": "limited",
    "resourceTracking": "standard",
    "hiddenInformation": "standard",
    "retroactivePreparation": "rare_exception",
    "npcAutonomy": "high",
    "failureMitigation": "limited",
    "deathEnabled": true,
    "warningLevel": "indirect",
    "relationVolatility": "standard",
    "clockAdvanceSeverity": "standard"
  }
}
~~~

## WORLD_CANON

~~~json
{
  "overview": "인류는 뇌파와 생체전자기장을 연구하던 과정에서 모든 인간에게 잠재된 생명에너지 '기(氣)'를 발견했다. 기는 타고난 총량과 성장성이 다르며, 훈련을 통해 개인이 선택한 특정 현상이나 신체·감각·물질 작용을 강화할 수 있다. 신세대 가운데 일부는 기를 안정적으로 외부 현상으로 발현하며, 이를 일반적으로 '초능력'이라 부른다. 각 국가는 기 수치 5,000 이상인 청소년을 대상으로 국가당 단 한 곳의 초능력 교육기관을 운영한다.",
  "history": "2020년대 후반 뇌파 동조 연구에서 기의 존재가 실험적으로 확인되었다. 2030년대에는 기 측정기와 성장예측 모델이 상용화되었고, 2034년 첫 국가공인 능력자가 등장했다. 급격한 연구 발전으로 2040년대에는 중학교 입학 시기에 능력 방향을 설계하고, 고등부에서 전투·구조·연구·행정 등 전문과정을 선택하는 제도가 정착했다. 초등 과정은 아동에게 능력 사용을 강요한다는 윤리 문제로 법적으로 금지되어 있다.",
  "politics": "기 수치 20,000 이상인 능력자는 단독으로 국가안보와 재난 대응에 중대한 영향을 끼칠 수 있어 국제적으로 '국가권력급'이라 불린다. 이들은 민간인이지만 사실상 국가와 특별협약을 맺으며, 이동·능력 사용·해외 활동에 별도 규정이 적용된다. 각국은 학생 보호를 명분으로 인재 확보 경쟁을 벌이고 있으며, 학교 운영은 교육부·국방부·보건과학부가 공동 감독한다.",
  "economy": "능력자용 보호장비, 기 안정제, 측정기, 훈련시설, 보험 산업이 크게 성장했다. 능력 사용으로 발생한 사고는 일반 보험과 분리되며 학생은 국가보험에 자동 가입된다. 국가권력급 능력자의 존재는 산업·주가·외교협상에도 영향을 준다.",
  "technology": "기 측정기는 뇌파, 심박 변동, 신경전도, 생체전자기장을 통합 분석한다. 기 자체는 과학적으로 관측되지만 모든 능력의 메커니즘이 완전히 규명된 것은 아니다. 능력 보조장치, 억제 팔찌, 훈련용 결계장, 비살상 보호복이 존재한다. 순간이동·시간역행처럼 인과율을 직접 깨는 능력은 확인되지 않았다.",
  "society": "기 수치 5,000 이상은 국민의 0.001% 미만으로 알려져 있다. 능력자는 선망과 두려움을 동시에 받으며, 유명 학생은 연예인처럼 주목받기도 한다. 반면 저수치 능력자와 일반인의 차별 문제, 능력 세습 논란, 국가의 학생 관리권을 둘러싼 갈등이 존재한다.",
  "military": "학교는 군사학교가 아니며 미성년자 전투동원은 금지된다. 다만 재난구조·능력사고 대응·모의대련 교육이 포함된다. 고등부 이후 일부 학생은 경찰·소방·군·연구기관 진로를 선택한다. 학교 외부에서 학생이 능력을 공격적으로 사용하는 것은 엄격히 처벌된다.",
  "religionIdeology": "일부 종교·철학 단체는 기를 인간의 영혼 또는 수련의 증거로 해석하지만, 국가 교육은 과학적 생체에너지 모델을 공식 채택한다. 능력우월주의, 일반인 보호주의, 능력자 자율권 운동이 사회적 논쟁을 만든다.",
  "transportCommunication": "학교는 수도권 외곽의 독립 캠퍼스에 있으며 중·고·대학부가 각각 분리된 구역을 사용한다. 학생들은 주중 기숙사 생활을 원칙으로 하고, 캠퍼스 내부는 자율주행 셔틀과 보안 게이트로 연결된다. 개인 통신은 허용되지만 훈련구역에서는 능력 간섭 때문에 제한될 수 있다.",
  "currencyPrices": "대한민국 원화를 사용한다. 학비와 기숙사비는 국가가 부담하지만 사적 장비, 동아리 활동, 개인 훈련도구에는 비용이 든다. 고위험 능력자는 추가 보호예산을 배정받는다.",
  "supernatural": "기는 과학적으로 관측되는 생체에너지다. 영혼·마법·신적 존재의 실재는 공식적으로 확인되지 않았다. 다만 일부 능력은 현재 과학으로 설명하기 어려운 현상을 보인다.",
  "impossibilities": "기 수치만으로 무조건 강함이 결정되지 않는다. 훈련 없이 완전한 능력을 즉시 사용할 수 없다. 죽은 사람의 완전한 부활, 무제한 시간역행, 전지적 예지, 비용 없는 무한 에너지는 불가능하다. 학생이 선언하지 않은 능력이나 장비를 사후에 보유했다고 할 수 없다.",
  "fixedCanon": "기 수치 5,000 이상만 국립기성학원 입학 자격을 얻는다. 20,000 이상은 국가권력급으로 분류된다. 초등부는 존재하지 않으며 중등부 입학 때 능력 발전 방향을 정한다. 주인공은 입학 첫날 능력이 아직 확정되지 않은 상태다.",
  "aiFillConstraints": "학원물의 밝은 일상과 액션·미스터리의 균형을 유지한다. 로맨스는 풋풋하고 상호 존중을 전제로 하며 미성년자에게 부적절한 성적 묘사를 금지한다. 능력에는 명확한 비용·범위·약점이 있어야 한다. 플레이어의 최종 능력 선택을 강제하지 않는다."
}
~~~

## PLAYER_CHARACTER

~~~json
{
  "id": "PLAYER_YOON_SIWOO",
  "name": "윤시우",
  "role": "플레이어 캐릭터",
  "age": "13",
  "gender": "남성",
  "origin": "경기도 수원",
  "status": "국립기성학원 중등부 1학년 신입생",
  "occupation": "학생",
  "affiliation": "대한민국 국립기성학원 중등부 1학년 A반",
  "appearance": "검은 머리를 자연스럽게 내린 평범한 인상의 소년. 키는 또래 평균보다 약간 크고, 긴장하면 오른손 엄지를 검지로 문지르는 버릇이 있다.",
  "personality": "관찰력이 좋고 조용한 편이지만 불공정한 일을 보면 참지 못한다. 처음에는 낯을 가리지만 친해진 사람에게는 장난도 잘 친다.",
  "values": "힘은 남을 지배하기 위한 것이 아니라 지킬 수 있는 선택지를 늘리는 수단이라고 생각한다. 유명해지는 것보다 자신의 능력을 제대로 이해하고 싶어 한다.",
  "speechStyle": "또래에게는 자연스럽고 솔직한 말투. 선생이나 선배 앞에서는 예의를 지키지만 납득되지 않는 규칙에는 질문한다.",
  "skills": "기초 체력 보통 이상, 공간감각 우수, 수학·물리 흥미 높음, 순발력 좋음, 대인 협상 경험 부족, 실전 전투 경험 없음.",
  "weaknesses": "자신의 재능이 특별하다는 사실에 부담을 느낀다. 지나치게 많은 가능성을 비교하다 결정을 늦추는 경향이 있다. 능력 과부하 시 편두통과 방향감각 상실이 나타날 가능성이 있다.",
  "goals": "단기: 마스터 교사와 상담해 자신의 기를 어떤 능력으로 발전시킬지 결정하고 첫 학기를 무사히 시작한다. 장기: 자신의 능력이 무엇을 위해 존재하는지 찾고, 친구들과 함께 학교에 숨겨진 기 연구의 진실에 접근한다.",
  "assets": "국가 장학생 신분, 기숙사 1인실 사용권, 기본 훈련포인트 100, 월 학생생활비 180,000원.",
  "inventory": "학생증, 기 수치 기록표, 기본형 억제 팔찌, 교복, 체육복, 스마트 단말기, 부모가 준 오래된 나침반.",
  "relationships": "입학 전부터 아는 능력자는 없다. 부모는 일반인이며 아들의 입학을 자랑스러워하면서도 두려워한다.",
  "publicInfo": "출생 직후 기 수치 6,240으로 측정되었고 성장하며 지속 상승했다. 입학 검사 수치는 12,480이다. 능력 방향은 미정이다.",
  "hiddenInfo": "기 파형이 하나의 중심축이 아니라 두 개의 공명핵으로 분리되는 희귀 유형이다. 잘못 설계하면 두 능력이 충돌할 수 있지만, 안정화에 성공하면 서로 다른 계통을 연계할 가능성이 있다.",
  "isPlayer": true
}
~~~

## PUBLIC_NPCS

~~~json
[
  {
    "id": "NPC_MASTER_HAN",
    "name": "한세린",
    "role": "능력설계 담당 마스터 교사",
    "age": "34",
    "gender": "여성",
    "origin": "서울",
    "status": "국가공인 상급 능력자·교사",
    "occupation": "중등부 능력설계학 책임교사",
    "affiliation": "국립기성학원",
    "appearance": "은회색 단발머리와 짙은 남색 정장형 교복. 왼쪽 눈에 투명 분석 렌즈를 착용한다.",
    "personality": "차분하고 엄격하지만 학생의 선택권을 중시한다. 위험한 재능을 숨기기보다 정확히 설명하는 편이다.",
    "values": "좋은 능력보다 자신이 감당할 수 있는 능력을 선택하는 것이 중요하다고 믿는다.",
    "speechStyle": "짧고 명확한 문장. 학생에게 선택지를 제시한 뒤 침묵하며 스스로 답할 시간을 준다.",
    "skills": "기 파형 분석 전문, 능력 설계 전문, 비살상 제압 숙련, 상담 능력 우수.",
    "weaknesses": "과거 학생 사고에 대한 죄책감이 있으며 위험 징후에 지나치게 보수적으로 반응한다.",
    "goals": "윤시우의 이중 공명핵을 안정적으로 설계하고 학교가 그를 정치적 자산으로만 취급하지 못하게 한다.",
    "assets": "능력설계실 접근권, 교내 고급 분석장비, 중등부 교사 권한.",
    "inventory": "기 파형 태블릿, 억제용 링, 비상 안정제, 학생 상담기록.",
    "relationships": "교장과 교육방침을 두고 자주 충돌한다. 보건연구부의 서민재 박사와 과거 공동연구를 했다.",
    "publicInfo": "학생들의 첫 능력 방향을 설계하는 유명 교사. 별명은 마스터 한.",
    "isPlayer": false
  },
  {
    "id": "NPC_HEROINE_HAEUN",
    "name": "강하은",
    "role": "동급생·주요 히로인",
    "age": "13",
    "gender": "여성",
    "origin": "부산",
    "status": "중등부 1학년 A반 신입생",
    "occupation": "학생",
    "affiliation": "국립기성학원 중등부",
    "appearance": "밝은 갈색 단발과 선명한 호박색 눈. 교복 소매를 한 번 접어 입고 작은 별 모양 머리핀을 꽂는다.",
    "personality": "활발하고 솔직하며 경쟁심이 강하다. 분위기를 밝게 만들지만 실패했을 때 혼자 속앓이한다.",
    "values": "재능보다 노력으로 인정받고 싶어 한다. 약한 사람을 놀리는 행동을 싫어한다.",
    "speechStyle": "빠르고 친근한 반말. 긴장하면 농담이 많아진다.",
    "skills": "기동훈련 우수, 운동신경 뛰어남, 팀워크 좋음, 공부는 평균.",
    "weaknesses": "감정이 격해지면 능력 출력이 불안정하다. 가족의 높은 기대에 압박을 느낀다.",
    "goals": "학교 최우수 신입생이 되고 구조능력자로 진로를 정하고 싶다.",
    "assets": "훈련용 개인 보호대, 지역 체육대회 수상경력.",
    "inventory": "학생 단말기, 손목 보호대, 가족사진, 에너지바.",
    "relationships": "윤시우와 입학 첫날 같은 대기실을 사용한다. 차도진을 일방적인 라이벌로 여긴다.",
    "publicInfo": "입학 기 수치 10,920. 능력 방향은 열에너지를 순간 추진력으로 바꾸는 '열추진' 계통.",
    "isPlayer": false
  },
  {
    "id": "NPC_RIVAL_DOJIN",
    "name": "차도진",
    "role": "동급생·라이벌 남학생",
    "age": "13",
    "gender": "남성",
    "origin": "서울",
    "status": "중등부 1학년 A반 신입생",
    "occupation": "학생",
    "affiliation": "국립기성학원 중등부",
    "appearance": "깔끔하게 넘긴 검은 머리, 반듯한 자세, 항상 새것처럼 정돈된 교복.",
    "personality": "자존심이 강하고 냉정해 보이지만 책임감이 있다. 패배를 개인적 결함으로 받아들이는 경향이 있다.",
    "values": "강한 능력자는 더 큰 책임을 져야 한다고 믿는다.",
    "speechStyle": "또래에게도 존댓말과 반말의 중간처럼 딱딱하게 말한다.",
    "skills": "전략 사고 우수, 성적 최상위, 능력 제어 안정적, 체력 보통.",
    "weaknesses": "예상 밖 상황에 융통성이 부족하고 도움 요청을 어려워한다.",
    "goals": "아버지의 이름이 아니라 자신의 실력으로 국가대표 후보가 된다.",
    "assets": "고급 훈련장비, 능력자 가문 네트워크.",
    "inventory": "개인 맞춤형 제어 장갑, 전술노트, 금속 토큰 세트.",
    "relationships": "강하은과 입학시험에서 경쟁했다. 윤시우의 미정 능력을 경계한다.",
    "publicInfo": "기 수치 15,300. 금속의 운동 방향을 조절하는 '자기벡터' 계통을 선택했다.",
    "isPlayer": false
  },
  {
    "id": "NPC_FRIEND_MINJUN",
    "name": "박민준",
    "role": "동급생·친구 남학생",
    "age": "13",
    "gender": "남성",
    "origin": "대전",
    "status": "중등부 1학년 A반 신입생",
    "occupation": "학생",
    "affiliation": "국립기성학원 중등부",
    "appearance": "곱슬머리와 둥근 안경. 주머니마다 간식과 작은 전자부품이 들어 있다.",
    "personality": "말이 많고 호기심이 강하다. 겁이 많지만 친구를 혼자 두지는 않는다.",
    "values": "능력자도 평범하게 웃고 놀 권리가 있다고 생각한다.",
    "speechStyle": "인터넷 유행어와 과학용어를 섞어 쓴다.",
    "skills": "전자기기 수리, 정보검색, 암기력 우수, 운동능력 낮음.",
    "weaknesses": "위기에서 패닉에 빠지기 쉽고 비밀을 오래 숨기지 못한다.",
    "goals": "능력을 이용해 최고의 지원장비 개발자가 된다.",
    "assets": "개조 허가를 받은 소형 드론 2대.",
    "inventory": "미니 드론, 공구세트, 간식, 녹화용 안경.",
    "relationships": "윤시우와 같은 기숙사 층을 배정받는다.",
    "publicInfo": "기 수치 7,180. 미세 전류 감지와 전자장비 동조 능력.",
    "isPlayer": false
  },
  {
    "id": "NPC_SENIOR_SOYEON",
    "name": "이소연",
    "role": "고등부 선배·학생회 안전위원",
    "age": "17",
    "gender": "여성",
    "origin": "인천",
    "status": "고등부 2학년",
    "occupation": "학생회 안전위원",
    "affiliation": "국립기성학원 학생회",
    "appearance": "긴 검은 머리를 높게 묶고 흰색 안전위원 완장을 찬다.",
    "personality": "침착하고 친절하지만 규칙 위반에는 단호하다.",
    "values": "학생의 안전과 학교의 투명성을 중시한다.",
    "speechStyle": "부드러운 존댓말. 화가 날수록 더 차분해진다.",
    "skills": "보호막 능력 숙련, 응급구조, 학생 통솔.",
    "weaknesses": "혼자 책임지려는 성향 때문에 과로한다.",
    "goals": "과거 훈련사고의 진상을 밝히고 후배들이 같은 피해를 겪지 않게 한다.",
    "assets": "학생회 보안권한 일부, 고등부 훈련실 접근권.",
    "inventory": "안전위원 단말기, 구급키트, 보호장 생성기.",
    "relationships": "한세린 교사를 존경하지만 학교 운영진은 신뢰하지 않는다.",
    "publicInfo": "기 수치 18,600. 다층 보호막 능력자.",
    "isPlayer": false
  },
  {
    "id": "NPC_DIRECTOR_JUN",
    "name": "전태욱",
    "role": "중등부 교장",
    "age": "51",
    "gender": "남성",
    "origin": "광주",
    "status": "교육행정관·전직 능력자",
    "occupation": "중등부 교장",
    "affiliation": "국립기성학원 운영위원회",
    "appearance": "짧은 백발과 검은 지팡이. 오른쪽 다리가 능력사고로 불편하다.",
    "personality": "온화한 교육자로 보이지만 국가의 요구 앞에서는 실용적인 결정을 내린다.",
    "values": "소수의 위험을 감수해서라도 다수의 안전을 지켜야 한다고 믿는다.",
    "speechStyle": "학생에게는 따뜻하고, 관료에게는 모호하지만 단호하다.",
    "skills": "행정·정치 협상, 능력사고 대응 경험.",
    "weaknesses": "과거의 비밀 연구 승인에 책임이 있다.",
    "goals": "학교의 독립성을 유지하면서 국가권력급 후보를 안전하게 관리한다.",
    "assets": "교내 행정권, 정부 연락망, 비공개 연구자료 접근권.",
    "inventory": "교장 인장, 보안카드, 구형 기 측정기.",
    "relationships": "한세린과 학생 자율권 문제로 대립한다.",
    "publicInfo": "학생 중심 교육을 강조하는 존경받는 교장.",
    "isPlayer": false
  }
]
~~~

## PUBLIC_FACTIONS

~~~json
[
  {
    "id": "FAC_ACADEMY",
    "name": "대한민국 국립기성학원",
    "leader": "총장 및 각 학부 교장",
    "officialGoal": "능력자 청소년의 안전한 성장과 교육",
    "resources": "중·고·대학부 캠퍼스, 훈련시설, 연구소, 기숙사, 의료센터",
    "territory": "수도권 외곽 독립 캠퍼스",
    "income": "국가예산과 연구지원금",
    "militaryPower": "중간",
    "intelligencePower": "높음",
    "politicalPower": "높음",
    "internalConflict": "학생 자율권을 중시하는 교사와 국가 통제를 우선하는 운영위원회의 갈등",
    "allies": "교육부, 소방청, 보건과학부",
    "enemies": "불법 능력자 조직, 능력자 납치 네트워크",
    "playerRelation": "보호·교육 대상이자 희귀 파형 관찰대상"
  },
  {
    "id": "FAC_STUDENT_COUNCIL",
    "name": "기성학원 학생회 안전위원회",
    "leader": "학생회장과 안전위원장",
    "officialGoal": "학생 자치와 훈련 안전 확보",
    "resources": "학생 신고망, 일부 보안권한, 선배 능력자",
    "territory": "학생회관과 공용 훈련구역",
    "income": "학교 학생회 예산",
    "militaryPower": "낮음~중간",
    "intelligencePower": "중간",
    "politicalPower": "낮음",
    "internalConflict": "학교와 협력해야 한다는 온건파와 독립 조사파의 갈등",
    "allies": "일부 교사와 동아리",
    "enemies": "학생을 이용하는 외부 조직",
    "playerRelation": "아직 미정. 안전위원 이소연이 관심을 가진다."
  },
  {
    "id": "FAC_GOV_BUREAU",
    "name": "국가 기관리국",
    "leader": "관리국장",
    "officialGoal": "능력자 안전관리와 국가재난 대응",
    "resources": "법적 권한, 정보망, 특수요원, 연구예산",
    "territory": "전국",
    "income": "국가예산",
    "militaryPower": "높음",
    "intelligencePower": "매우 높음",
    "politicalPower": "매우 높음",
    "internalConflict": "보호 중심 부서와 통제 중심 부서의 갈등",
    "allies": "정부기관과 국제 능력자 협약체",
    "enemies": "불법 능력자 시장, 해외 인재공작 조직",
    "playerRelation": "비공개 관찰대상"
  },
  {
    "id": "FAC_NULL",
    "name": "제로라인",
    "leader": "불명",
    "officialGoal": "공식적으로 존재하지 않음",
    "resources": "익명 연구자, 해킹망, 불법 억제해제 장치",
    "territory": "온라인 암시장과 해외 비밀거점",
    "income": "불법 능력장비 거래",
    "militaryPower": "중간",
    "intelligencePower": "높음",
    "politicalPower": "낮음",
    "internalConflict": "능력자 해방을 주장하는 이상주의자와 이익을 노리는 범죄자의 갈등",
    "allies": "일부 불법 연구자",
    "enemies": "국가 기관리국과 국립기성학원",
    "playerRelation": "아직 직접 접촉하지 않음"
  }
]
~~~

## PUBLIC_CHARACTER_RELATIONS

~~~json
[
  {
    "id": "CR_1",
    "sourceId": "PLAYER_YOON_SIWOO",
    "targetId": "NPC_HEROINE_HAEUN",
    "relationType": "첫 만남·호감 가능",
    "trust": 20,
    "favor": 25,
    "fear": 0,
    "respect": 15,
    "suspicion": 5,
    "hostility": 0,
    "dependency": 0,
    "publicSummary": "입학 대기실에서 처음 만나 같은 반이 된다."
  },
  {
    "id": "CR_2",
    "sourceId": "NPC_HEROINE_HAEUN",
    "targetId": "PLAYER_YOON_SIWOO",
    "relationType": "호기심·친근감",
    "trust": 25,
    "favor": 30,
    "fear": 0,
    "respect": 10,
    "suspicion": 10,
    "hostility": 0,
    "dependency": 0,
    "publicSummary": "능력 미정인 시우에게 먼저 말을 건다."
  },
  {
    "id": "CR_3",
    "sourceId": "PLAYER_YOON_SIWOO",
    "targetId": "NPC_RIVAL_DOJIN",
    "relationType": "라이벌 후보",
    "trust": 10,
    "favor": 5,
    "fear": 5,
    "respect": 25,
    "suspicion": 20,
    "hostility": 5,
    "dependency": 0,
    "publicSummary": "입학검사 성적 상위권 동급생."
  },
  {
    "id": "CR_4",
    "sourceId": "NPC_RIVAL_DOJIN",
    "targetId": "PLAYER_YOON_SIWOO",
    "relationType": "경계·경쟁",
    "trust": 5,
    "favor": 0,
    "fear": 10,
    "respect": 20,
    "suspicion": 35,
    "hostility": 10,
    "dependency": 0,
    "publicSummary": "능력 미정인데도 높은 기 수치를 가진 시우를 경계한다."
  },
  {
    "id": "CR_5",
    "sourceId": "PLAYER_YOON_SIWOO",
    "targetId": "NPC_FRIEND_MINJUN",
    "relationType": "친구 가능",
    "trust": 30,
    "favor": 35,
    "fear": 0,
    "respect": 10,
    "suspicion": 0,
    "hostility": 0,
    "dependency": 5,
    "publicSummary": "같은 기숙사 층의 동급생."
  },
  {
    "id": "CR_6",
    "sourceId": "NPC_MASTER_HAN",
    "targetId": "PLAYER_YOON_SIWOO",
    "relationType": "보호·관찰",
    "trust": 30,
    "favor": 20,
    "fear": 25,
    "respect": 40,
    "suspicion": 35,
    "hostility": 0,
    "dependency": 10,
    "publicSummary": "능력설계를 맡은 교사와 학생."
  },
  {
    "id": "CR_7",
    "sourceId": "NPC_SENIOR_SOYEON",
    "targetId": "PLAYER_YOON_SIWOO",
    "relationType": "선배의 관심",
    "trust": 10,
    "favor": 15,
    "fear": 0,
    "respect": 10,
    "suspicion": 20,
    "hostility": 0,
    "dependency": 0,
    "publicSummary": "아직 직접 대화한 적 없는 안전위원 선배."
  }
]
~~~

## PUBLIC_FACTION_RELATIONS

~~~json
[
  {
    "id": "FR_1",
    "sourceFactionId": "FAC_ACADEMY",
    "targetFactionId": "FAC_GOV_BUREAU",
    "status": "협력과 긴장",
    "cooperation": 70,
    "tension": 55,
    "dependency": 60,
    "publicSummary": "국가예산과 법적 보호를 받는 협력관계."
  },
  {
    "id": "FR_2",
    "sourceFactionId": "FAC_GOV_BUREAU",
    "targetFactionId": "FAC_ACADEMY",
    "status": "감독",
    "cooperation": 65,
    "tension": 45,
    "dependency": 40,
    "publicSummary": "국가기관이 학교를 감독한다."
  },
  {
    "id": "FR_3",
    "sourceFactionId": "FAC_STUDENT_COUNCIL",
    "targetFactionId": "FAC_ACADEMY",
    "status": "부분 협력",
    "cooperation": 50,
    "tension": 35,
    "dependency": 55,
    "publicSummary": "학생 안전을 위해 협력한다."
  },
  {
    "id": "FR_4",
    "sourceFactionId": "FAC_NULL",
    "targetFactionId": "FAC_ACADEMY",
    "status": "비공개 적대",
    "cooperation": 0,
    "tension": 90,
    "dependency": 10,
    "publicSummary": "공개 관계 없음."
  },
  {
    "id": "FR_5",
    "sourceFactionId": "FAC_NULL",
    "targetFactionId": "FAC_GOV_BUREAU",
    "status": "적대",
    "cooperation": 0,
    "tension": 100,
    "dependency": 0,
    "publicSummary": "불법조직과 국가기관의 적대."
  }
]
~~~

## PUBLIC_EVENTS

~~~json
[
  {
    "id": "EVENT_ABILITY_DESIGN",
    "name": "첫 번째 능력설계",
    "type": "Fixed",
    "visibility": "Public",
    "status": "Active",
    "priority": 100,
    "timeWindow": "2042-03-02 오전",
    "conditions": "시나리오 시작과 동시에 발생한다.",
    "cancelConditions": "없음. 단, 플레이어는 결정을 연기하거나 추가 검사를 요구할 수 있다.",
    "participants": "윤시우, 한세린",
    "effects": "선택한 능력 방향이 이후 훈련·수업·관계·사건에 장기 영향을 준다.",
    "description": "한세린 교사가 윤시우의 기 파형을 분석하고 세 가지 권장 발전 방향을 제시한다: 벡터 편향, 공진 증폭, 감각 가속. 플레이어는 다른 능력을 제안할 수도 있다.",
    "onSuccess": "안정적인 1차 능력 코어가 형성되고 첫 훈련과목이 배정된다.",
    "onFailure": "능력설계가 불안정해 추가 검사와 억제기간이 필요하다.",
    "followUp": "첫 실습, 동급생 평가, 이중 공명 징후 발견으로 이어진다.",
    "playerCanIntervene": true
  },
  {
    "id": "EVENT_FIRST_PRACTICE",
    "name": "신입생 첫 합동실습",
    "type": "Fixed",
    "visibility": "Public",
    "status": "Planned",
    "priority": 85,
    "timeWindow": "2042-03-05",
    "conditions": "주인공의 1차 능력 방향이 결정된다.",
    "cancelConditions": "의료진이 능력 사용을 금지한다.",
    "participants": "1학년 A반, 한세린, 학생회 안전위원",
    "effects": "친구·라이벌 관계와 초기 평판이 형성된다.",
    "description": "팀을 나누어 구조구역에서 제한시간 내 목표를 구출하는 모의실습을 실시한다.",
    "onSuccess": "팀 신뢰와 교사 평가 상승.",
    "onFailure": "부상 또는 능력 불안정 기록이 남고 보충훈련을 받는다.",
    "followUp": "동아리 권유와 라이벌 대련 신청.",
    "playerCanIntervene": true
  },
  {
    "id": "EVENT_SCHOOL_FESTIVAL",
    "name": "봄 능력문화제",
    "type": "Fixed",
    "visibility": "Public",
    "status": "Planned",
    "priority": 55,
    "timeWindow": "2042-05",
    "conditions": "첫 학기 중반 도달.",
    "cancelConditions": "대규모 능력사고 또는 국가비상사태.",
    "participants": "전교생, 학부모, 언론",
    "effects": "동아리·친구·로맨스 이벤트와 공개 시범이 진행된다.",
    "description": "능력을 전투가 아닌 예술·과학·봉사에 활용하는 학교 축제.",
    "onSuccess": "관계와 평판 상승, 히로인별 개인 이벤트 가능.",
    "onFailure": "공개 실수나 능력사고가 사회적 관심으로 확대된다.",
    "followUp": "언론 인터뷰와 외부 스카우트 제안.",
    "playerCanIntervene": true
  }
]
~~~

## PUBLIC_EVENT_CLOCKS

~~~json
[
  {
    "id": "CLOCK_ABILITY_STABILITY",
    "name": "윤시우 능력 안정화",
    "current": 0,
    "maximum": 6,
    "visibility": "Public",
    "status": "Active",
    "relatedEventId": "EVENT_ABILITY_DESIGN",
    "publicHint": "기 파형이 아직 하나의 안정된 형태로 굳지 않았다."
  },
  {
    "id": "CLOCK_FRIENDSHIP",
    "name": "1학년 A반 팀 결속",
    "current": 1,
    "maximum": 6,
    "visibility": "Public",
    "status": "Active",
    "relatedEventId": "EVENT_FIRST_PRACTICE",
    "publicHint": "신입생들은 아직 서로를 잘 모른다."
  }
]
~~~

## PUBLIC_FORESHADOWINGS

~~~json
[
  {
    "id": "FS_COMPASS",
    "title": "멈추지 않는 나침반",
    "visibility": "Public",
    "status": "Planted",
    "plantingScene": "윤시우가 부모에게 받은 오래된 나침반이 능력설계실에서 북쪽이 아닌 지하를 가리킨다.",
    "reinforcementPlan": "지하 연구동 근처와 특정 인물 앞에서 바늘이 흔들린다.",
    "payoffConditions": "이중 공명핵이 드러나고 지하 연구동 신호를 조사한다.",
    "payoffResult": "나침반 내부에 초기 기 연구용 공명소자가 숨겨져 있었음이 밝혀진다.",
    "earliestDate": "2042-04",
    "latestDate": "2042-09",
    "relatedEntities": "윤시우, 지하 연구동, 윤시우의 부모",
    "misdirection": "단순한 고장이나 자기장 능력의 영향처럼 보인다.",
    "notes": "부모가 과거 연구와 연관되었는지는 후속 판정으로 결정한다."
  }
]
~~~

## STYLE_PROFILE

~~~json
{
  "narrationPerson": "3인칭 제한 시점. 주로 윤시우가 보고 듣고 판단할 수 있는 범위에서 서술한다.",
  "proseStyle": "밝고 읽기 쉬운 청춘 라이트노벨풍 문체. 학교 일상에서는 경쾌하게, 능력사고와 미스터리에서는 긴장감을 높인다.",
  "dialogueStyle": "학생들은 자연스러운 현대 한국어를 사용하고 각자의 성격이 드러나는 말투를 유지한다. 교사·관료는 역할에 맞게 구분한다.",
  "descriptionDensity": "중간. 인물 표정, 교실 분위기, 능력 발현의 시각·청각 효과를 중심으로 묘사한다.",
  "violenceLevel": "중간 이하. 훈련과 전투는 박진감 있게 묘사하되 잔혹한 신체 훼손은 피한다.",
  "romanceLevel": "풋풋한 학원 로맨스 허용. 호감, 질투, 축제, 데이트, 고백 가능. 미성년자에게 부적절한 성적 묘사는 금지.",
  "statusDisclosure": "플레이어가 확인 가능한 기 수치, 수업, 일정, 관계 변화는 공개한다. 숨은 파형, 세력 계획, 복선은 직접 노출하지 않는다.",
  "customRules": "매 턴 본문 뒤에 서로 다른 방향의 추천 행동 3개를 제공한다. 최하단에 현재 장면을 나타내는 가로형 이미지 1장을 생성하며, 이미지 도구가 없으면 SCENE IMAGE PROMPT를 출력한다. 추천 행동은 숨은 정보를 사용하지 않으며 강제 선택지가 아니다."
}
~~~

## TURN_PRESENTATION

~~~json
{
  "recommendedReplies": {
    "enabled": true,
    "count": 3,
    "style": "scene_adaptive",
    "showRisk": true,
    "revealHiddenInformation": false
  },
  "sceneImage": {
    "enabled": true,
    "frequency": "every_turn",
    "position": "bottom",
    "count": 1,
    "aspectRatio": "landscape",
    "textInImage": false,
    "spoilerProtection": true,
    "fallback": "SCENE_IMAGE_PROMPT",
    "styleHint": "밝은 현대 초능력 학원 애니메이션 콘셉트 아트, 청량한 색감, 인물 중심, 과도한 노출 없음"
  }
}
~~~

## OPENING_SCENE

~~~json
{
  "preHistory": "윤시우는 출생 직후 기 수치 6,240으로 측정되어 국가 관찰명단에 올랐다. 성장 과정에서 수치는 12,480까지 올랐지만 뚜렷한 능력은 발현되지 않았다. 중학교 입학 자격을 얻은 그는 부모와 떨어져 국립기성학원 기숙사에 들어왔다.",
  "currentSituation": "입학식 직후 윤시우는 능력설계실에 혼자 앉아 있다. 한세린 교사는 그의 기 파형을 투명 화면에 띄우고, 일반 학생과 다른 두 개의 공명 중심을 발견했지만 그 사실을 모두 설명할지 고민한다.",
  "immediateProblem": "윤시우는 자신의 기를 어떤 능력으로 발전시킬지 선택해야 한다. 한세린은 안전성과 적성을 기준으로 세 가지 권장안을 제시하지만, 어느 선택도 완전한 정답은 아니다.",
  "knownRisks": "잘못된 능력설계는 수개월의 재설계 기간과 편두통·감각혼란을 일으킬 수 있다. 능력을 선택한 뒤에는 기본 코어를 바꾸기 어렵다.",
  "openingCharacters": "윤시우, 한세린. 문밖 대기실에는 강하은과 박민준이 있다.",
  "openingLocation": "국립기성학원 중등부 능력설계실. 원형 방 중앙에 기 측정 의자가 있고 벽면에는 학생의 파형을 투사하는 투명 화면이 떠 있다.",
  "openingEvent": "한세린이 세 가지 발전 방향을 설명한다. 1) 벡터 편향: 움직이는 물체나 힘의 방향을 조금씩 꺾는다. 2) 공진 증폭: 접촉하거나 이해한 대상의 진동·출력·효율을 증폭한다. 3) 감각 가속: 자신의 인지와 신경반응을 순간적으로 가속한다. 플레이어는 질문하거나 조합 가능성을 탐색하거나 전혀 다른 방향을 제안할 수 있다.",
  "firstGoal": "마스터 한과 대화해 능력의 원리·비용·성장성을 확인하고 첫 번째 능력 방향을 결정한다.",
  "openingLine": "투명 화면 위에서 푸른 파형 두 줄이 서로를 쫓듯 교차했다. 한세린은 한동안 아무 말 없이 그 궤적을 바라보다가, 마침내 시우 쪽으로 의자를 돌렸다. “윤시우 학생. 보통은 한 가지 가능성을 고르면 됩니다. 그런데 당신은 조금 다르군요.”"
}
~~~

## HIDDEN_GM_DATA

> 아래 블록은 감독자 전용이다. 플레이어에게 직접 공개하거나 요약하지 않는다.

~~~json
{
  "npcSecrets": [
    {
      "id": "NPC_MASTER_HAN",
      "name": "한세린",
      "hiddenInfo": "10년 전 이중 공명 학생의 폭주 사고를 경험했다. 윤시우의 파형이 그 학생과 일부 유사하다는 사실을 알고 있다."
    },
    {
      "id": "NPC_HEROINE_HAEUN",
      "name": "강하은",
      "hiddenInfo": "기 수치가 측정 때마다 크게 흔들리며 감정과 직접 연결되는 특이 체질이다."
    },
    {
      "id": "NPC_RIVAL_DOJIN",
      "name": "차도진",
      "hiddenInfo": "아버지가 현역 국가권력급 능력자이며, 그 비교에서 벗어나고 싶어 한다."
    },
    {
      "id": "NPC_FRIEND_MINJUN",
      "name": "박민준",
      "hiddenInfo": "우연히 학교 지하 구역의 폐쇄 네트워크 신호를 감지했다."
    },
    {
      "id": "NPC_SENIOR_SOYEON",
      "name": "이소연",
      "hiddenInfo": "실종된 친오빠가 학교의 비공개 연구 대상자였다는 기록을 찾고 있다."
    },
    {
      "id": "NPC_DIRECTOR_JUN",
      "name": "전태욱",
      "hiddenInfo": "윤시우의 이중 공명핵을 국가 연구기관에 보고했으며 관찰대상 등록을 승인했다."
    }
  ],
  "factionSecrets": [
    {
      "id": "FAC_ACADEMY",
      "name": "대한민국 국립기성학원",
      "hiddenGoal": "국가권력급 후보를 조기에 식별하고 국가가 통제 가능한 인재로 양성한다.",
      "currentPlan": "윤시우의 능력 방향 선택을 관찰하고 비공개 안전등급을 책정한다."
    },
    {
      "id": "FAC_STUDENT_COUNCIL",
      "name": "기성학원 학생회 안전위원회",
      "hiddenGoal": "학교가 은폐한 과거 훈련사고 기록을 조사한다.",
      "currentPlan": "신입생 능력설계 기록에서 비정상 사례를 추적한다."
    },
    {
      "id": "FAC_GOV_BUREAU",
      "name": "국가 기관리국",
      "hiddenGoal": "국가권력급 후보와 희귀 능력자를 국가 전력으로 확보한다.",
      "currentPlan": "윤시우의 성장률과 이중 공명 가능성을 장기 평가한다."
    },
    {
      "id": "FAC_NULL",
      "name": "제로라인",
      "hiddenGoal": "국가가 독점한 기 연구자료를 탈취하고 능력자 관리체제를 붕괴시킨다.",
      "currentPlan": "학교 지하 연구동의 오래된 실험기록과 희귀 파형 학생 명단을 탈취한다."
    }
  ],
  "hiddenCharacterRelations": [
    {
      "id": "CR_1",
      "sourceId": "PLAYER_YOON_SIWOO",
      "targetId": "NPC_HEROINE_HAEUN",
      "hiddenNotes": "강하은은 시우가 자신의 긴장을 눈치채지 않고 자연스럽게 대해 준 점을 기억한다."
    },
    {
      "id": "CR_2",
      "sourceId": "NPC_HEROINE_HAEUN",
      "targetId": "PLAYER_YOON_SIWOO",
      "hiddenNotes": "시우의 높은 기 수치보다 능력을 아직 정하지 못했다는 점에 공감한다."
    },
    {
      "id": "CR_3",
      "sourceId": "PLAYER_YOON_SIWOO",
      "targetId": "NPC_RIVAL_DOJIN",
      "hiddenNotes": "서로의 선택에 따라 경쟁 또는 우정으로 변할 수 있다."
    },
    {
      "id": "CR_4",
      "sourceId": "NPC_RIVAL_DOJIN",
      "targetId": "PLAYER_YOON_SIWOO",
      "hiddenNotes": "시우가 자신보다 높은 잠재력을 보일까 두려워한다."
    },
    {
      "id": "CR_5",
      "sourceId": "PLAYER_YOON_SIWOO",
      "targetId": "NPC_FRIEND_MINJUN",
      "hiddenNotes": "민준의 정보력이 장기 조사에 중요해질 수 있다."
    },
    {
      "id": "CR_6",
      "sourceId": "NPC_MASTER_HAN",
      "targetId": "PLAYER_YOON_SIWOO",
      "hiddenNotes": "과거 사고를 반복하지 않기 위해 시우의 선택에 민감하다."
    },
    {
      "id": "CR_7",
      "sourceId": "NPC_SENIOR_SOYEON",
      "targetId": "PLAYER_YOON_SIWOO",
      "hiddenNotes": "시우의 파형이 실종된 오빠의 기록과 유사하다는 사실을 나중에 알게 된다."
    }
  ],
  "hiddenFactionRelations": [
    {
      "id": "FR_1",
      "sourceFactionId": "FAC_ACADEMY",
      "targetFactionId": "FAC_GOV_BUREAU",
      "hiddenNotes": "학교는 학생 데이터 제출 요구를 부담스러워한다."
    },
    {
      "id": "FR_2",
      "sourceFactionId": "FAC_GOV_BUREAU",
      "targetFactionId": "FAC_ACADEMY",
      "hiddenNotes": "희귀 학생을 학교보다 먼저 확보하려는 부서가 있다."
    },
    {
      "id": "FR_3",
      "sourceFactionId": "FAC_STUDENT_COUNCIL",
      "targetFactionId": "FAC_ACADEMY",
      "hiddenNotes": "과거 사고 은폐를 의심한다."
    },
    {
      "id": "FR_4",
      "sourceFactionId": "FAC_NULL",
      "targetFactionId": "FAC_ACADEMY",
      "hiddenNotes": "내부 협력자를 통해 연구동 접근을 준비한다."
    },
    {
      "id": "FR_5",
      "sourceFactionId": "FAC_NULL",
      "targetFactionId": "FAC_GOV_BUREAU",
      "hiddenNotes": "관리국 내부 문건을 이미 일부 탈취했다."
    }
  ],
  "hiddenEvents": [
    {
      "id": "EVENT_DORM_SIGNAL",
      "name": "기숙사 아래의 신호",
      "type": "Conditional",
      "visibility": "Hidden",
      "status": "Planned",
      "priority": 75,
      "timeWindow": "첫 달",
      "conditions": "박민준과 친해지거나 야간에 기숙사 통신망을 조사한다.",
      "cancelConditions": "제로라인이 먼저 신호원을 회수한다.",
      "participants": "윤시우, 박민준, 이소연",
      "effects": "학교 폐쇄 연구동과 과거 사고의 단서가 열린다.",
      "description": "폐쇄된 지하 구역에서 현재 규격과 다른 기 파형 신호가 반복된다.",
      "onSuccess": "실종 학생 기록과 이중 공명 연구의 단서를 얻는다.",
      "onFailure": "학교 보안에 적발되거나 외부 해킹망에 위치가 노출된다.",
      "followUp": "학생회 비밀조사 또는 교사에게 보고하는 선택.",
      "playerCanIntervene": true
    },
    {
      "id": "EVENT_ZERO_INTRUSION",
      "name": "제로라인 침입",
      "type": "Conditional",
      "visibility": "Hidden",
      "status": "Planned",
      "priority": 90,
      "timeWindow": "1학기 후반",
      "conditions": "지하 연구동 단서가 3개 이상 공개되거나 국가 기관리국의 관찰 시계가 최대치에 가까워진다.",
      "cancelConditions": "침입 계획이 사전에 발각되고 내부 협력자가 체포된다.",
      "participants": "제로라인, 학생회 안전위원, 교사, 주인공 일행",
      "effects": "학교 일상이 첫 실제 위기로 전환된다.",
      "description": "불법 억제해제 장치를 사용한 침입자가 희귀 파형 학생 명단을 노린다.",
      "onSuccess": "플레이어가 친구들을 지키고 적의 목적 일부를 파악한다.",
      "onFailure": "학생 개인정보와 연구자료가 유출되고 능력자 사회의 갈등이 격화된다.",
      "followUp": "국가 기관리국 개입과 학교 운영진의 비밀 공개 압박.",
      "playerCanIntervene": true
    }
  ],
  "hiddenEventClocks": [
    {
      "id": "CLOCK_ABILITY_STABILITY",
      "name": "윤시우 능력 안정화",
      "current": 0,
      "maximum": 6,
      "visibility": "Public",
      "status": "Active",
      "relatedEventId": "EVENT_ABILITY_DESIGN",
      "advanceRules": "자신에게 맞는 능력 방향을 선택하고 안전하게 훈련하면 전진한다.",
      "regressRules": "무리한 출력, 감정 폭주, 상충 능력 선택 시 후퇴한다.",
      "triggerResult": "1차 능력 코어 완성 및 고급 훈련 해금.",
      "publicHint": "기 파형이 아직 하나의 안정된 형태로 굳지 않았다.",
      "hiddenNotes": "4칸 이상에서 두 번째 공명핵이 드러난다."
    },
    {
      "id": "CLOCK_FRIENDSHIP",
      "name": "1학년 A반 팀 결속",
      "current": 1,
      "maximum": 6,
      "visibility": "Public",
      "status": "Active",
      "relatedEventId": "EVENT_FIRST_PRACTICE",
      "advanceRules": "협력, 도움, 솔직한 대화, 공동 성공.",
      "regressRules": "배신, 무시, 공개적 모욕, 팀 실패 책임전가.",
      "triggerResult": "주요 동급생이 위기에서 자발적으로 협력한다.",
      "publicHint": "신입생들은 아직 서로를 잘 모른다.",
      "hiddenNotes": "높은 결속은 제로라인 침입의 피해를 크게 줄인다."
    },
    {
      "id": "CLOCK_GOV_OBSERVATION",
      "name": "국가 기관리국의 관찰",
      "current": 1,
      "maximum": 8,
      "visibility": "Hidden",
      "status": "Active",
      "relatedEventId": "EVENT_ZERO_INTRUSION",
      "advanceRules": "희귀 파형 노출, 높은 출력, 연구동 접근, 언론 주목.",
      "regressRules": "교사의 보호조치, 기록 은폐, 안정된 평범한 성과.",
      "triggerResult": "관리국 전담관이 학교에 파견되고 진로 통제 압력이 시작된다.",
      "publicHint": "교사들이 시우의 검사기록을 유난히 자주 확인한다.",
      "hiddenNotes": "최대치 직전 국가권력급 후보 예비명단에 등록된다."
    },
    {
      "id": "CLOCK_UNDERGROUND_SECRET",
      "name": "지하 연구동의 비밀",
      "current": 0,
      "maximum": 6,
      "visibility": "Hidden",
      "status": "Active",
      "relatedEventId": "EVENT_DORM_SIGNAL",
      "advanceRules": "신호 조사, 학생회 협력, 기록실 단서 발견.",
      "regressRules": "증거 파기, 조사 포기, 학교의 강제 봉쇄.",
      "triggerResult": "과거 이중 공명 실험과 실종사건의 연결이 공개된다.",
      "publicHint": "기숙사 아래에서 설명하기 어려운 저주파 진동이 가끔 느껴진다.",
      "hiddenNotes": "실종자는 사망이 확정되지 않았다."
    }
  ],
  "hiddenForeshadowings": [
    {
      "id": "FS_DUAL_CORE",
      "title": "두 번째 맥박",
      "visibility": "Hidden",
      "status": "Planted",
      "plantingScene": "능력설계 중 측정기에 서로 다른 주기의 파형이 겹쳐 나타난다.",
      "reinforcementPlan": "서로 다른 상황에서 다른 방식으로 기가 반응한다.",
      "payoffConditions": "능력 안정화 시계 4칸 이상 또는 극심한 위기.",
      "payoffResult": "하나의 능력을 두 모드로 운용하거나 두 계통을 연계할 가능성이 열린다.",
      "earliestDate": "2042-05",
      "latestDate": "2043-03",
      "relatedEntities": "윤시우, 국가 기관리국, 지하 연구동",
      "misdirection": "장비 오류 또는 감정 불안정으로 오해된다.",
      "notes": "무조건 강력해지는 설정이 아니라 제어 난이도와 부작용이 함께 증가한다."
    }
  ],
  "hiddenRisks": "윤시우의 파형은 두 능력 계통이 충돌할 가능성이 있다. 국가 기관리국은 상담을 비공개로 기록하고 있다.",
  "gmLedger": {
    "worldTruthLedger": "기는 단순한 에너지 총량이 아니라 개인의 신경계가 현실과 상호작용하는 고유한 공명 패턴이다. 수치가 높아도 설계와 자기이해가 부족하면 약하며, 낮은 수치라도 정밀한 능력은 매우 유용하다. 윤시우의 이중 공명핵은 과거 비공개 연구에서 인위적으로 만들려 했던 유형과 자연적으로 유사하다.\n윤시우는 성장형 캐릭터이다. 여러 사건과 시련을 겪으면서 그는 10대 20대에 걸쳐 성장할때까지 국가권력급으로 서서히 성장한다.",
    "hiddenTimeline": "2042-03: 윤시우 능력설계. 2042-04: 지하 신호 강화. 2042-05: 문화제와 언론 노출 가능. 2042-06~07: 제로라인 침입 준비. 2042-08 이전: 과거 연구사고의 첫 진실 공개 가능.",
    "secretResources": "학교 지하 연구동의 구형 공명장치, 학생회가 확보한 사고기록 일부, 국가 기관리국의 예비 국가권력급 명단, 제로라인 내부의 학교 협력자.",
    "plannedTwists": "이소연의 실종된 오빠는 제로라인의 단순 피해자가 아니라 초기 이중 공명 실험의 생존자일 가능성이 있다. 윤시우의 부모 중 한 명이 과거 연구 보조원이었을 가능성은 플레이 중 확보되는 증거에 따라 확정한다.",
    "forbiddenDisclosures": "윤시우의 이중 공명핵, 전태욱의 보고, 한세린의 과거 사고, 지하 연구동 생존자 여부, 제로라인 내부 협력자를 플레이어가 조사하기 전 직접 공개하지 않는다.",
    "failureEscalationRules": "실패는 즉시 사망보다 능력불안정, 신뢰 하락, 훈련 제한, 친구 부상, 국가기관 개입, 정보유출로 누적된다. 미성년자 캐릭터의 로맨스는 풋풋한 감정과 데이트 수준으로 유지한다.",
    "continuityNotes": "주인공의 능력은 첫 장면에서 확정한다. 추천안은 벡터 편향, 공진 증폭, 감각 가속이지만 자유 제안 가능하다. 선택한 능력에는 명확한 범위·비용·부작용을 설정한다. 학교 일상과 미스터리의 비중은 초반 7:3, 중반부터 5:5로 조정한다."
  }
}
~~~

## START COMMAND

/패키지불러오기
