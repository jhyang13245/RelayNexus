# Instant 계약 검증 CortexPack v1.5

Studio 2.2.0 / Cortex 1.42.0+

이 패키지는 Instant Story Runtime v2 제작·보존용입니다. 현재 공식 Cortex 1.42.0은 전용 설정을 실행하지 않으므로 Cortex 소비부 업데이트가 필요합니다. reports/cortex-compatibility.json에서 지원 한계를 확인하세요. project.json 최상위와 cortex/protagonist_invariants.json에 주인공 불변식을 함께 선언하고 instant_story_runtime_v2 계약을 사용합니다. 지능형 정사 전개 Runtime으로 폴백하거나 혼합 실행하면 안 됩니다.

Studio 편집 원본은 studio/project-snapshot.json에 있으며 런타임은 이 파일을 무시합니다.