# 기성학원 : 첫 번째 공명 ScenarioPack v1.5

Studio 1.7.1 / Engine 2.4

Asset-Once 원본은 assets/manifest.json의 assetRef·byteLength·SHA-256으로 검증합니다. Package 1.4 선택 확장은 rules/narrative_runtime.json에 있으며, Package 1.5에서는 routes/·loops/·state/ 계약을 동일한 의미로 상속합니다. 패키지 정사와 RevealPolicy는 AI 외부 지식보다 항상 우선합니다.

Instant Story Runtime은 rules/instant_story_runtime.json을 사용합니다. OpenAI 원시 delta는 서버 내부에서만 처리하고 공개 SSE에는 검사된 narration_commit만 전송해야 합니다. turn_abort는 표시 중인 임시 본문 전체를 제거하며, 파생 캐시의 sourcePackageSha256이 일치하지 않으면 일반 Package 1.5 경로로 폴백합니다.