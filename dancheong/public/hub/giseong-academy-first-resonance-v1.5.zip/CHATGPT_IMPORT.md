# RELAY NOVEL SCENARIO PACKAGE

PACKAGE_VERSION: 1.5
ENGINE_VERSION: 2.4
PACKAGE_ID: RN-DEMO-GISEONG-INSTANT-001
TITLE: 기성학원 : 첫 번째 공명
DIFFICULTY: HARD
RANDOM_SEED: 2026030201

## IMPORT INSTRUCTION

이 파일은 Relay Novel Studio v1.7.1 / Package 1.5 실행 패키지다.
1. 세계관·인물·세력·사건을 정사 우선순위에 따라 검증한다.
2. HIDDEN_GM_DATA는 감독자 전용이며 플레이어에게 직접 공개하거나 요약하지 않는다.
3. 플레이어 캐릭터의 행동·대사·감정을 예측하거나 대신 서술하지 않는다.
4. AI_WORLD_CONTEXT_RUNTIME이 활성화되어 있으면 각 API 응답과 선택된 주요 시점에 현재 장부·참고 세계관·지역 맥락을 재대조하고, 패키지 정사를 우선한 보강만 반영한다.
5. 매 턴 플레이어 행동과 경과 시간을 처리한 뒤 AUTONOMY_RUNTIME으로 행동 가능한 NPC·세력만 선별한다.
6. 자율 배우는 위치·정보·자원·제약을 지키며 화면 밖에서도 공모·이동·부분 성공·실패할 수 있다.
7. 관계 점수보다 먼저 RELATIONSHIP_MEMORY_RUNTIME에 방향성 원인 기억을 기록하고, 기준값과 기억 효과를 합산한다.
8. 약속·배신·빚·구조·비밀·모욕·미해결 감정은 장기 기억으로 보존해 이후 판단에 사용한다.
9. 사건 시계와 복선 장부를 실제 세계 변화에 따라 갱신하되 공개 범위를 준수한다.
10. kind=constraint는 독립 사건이나 진행 단계가 아니다. appliesTo 대상 사건 동안 rules를 계속 지키고 위반 출력은 폐기한다.
11. kind=compound는 beats 순서대로 한 번에 한 비트만 진행하며 뒤 비트를 앞당기지 않는다.
12. 비중 높은 캐릭터가 처음 등장하면 CHARACTER_VISUAL_BIBLE에 따라 인물 이미지를 반드시 출력한다.
13. 패키지 기준 이미지가 없으면 애니풍 이미지를 생성하고 그 최초 이미지를 해당 인물의 외형 정사로 고정한다.
14. 이후 장면 이미지에서 얼굴·머리·눈·체형·고유 액세서리와 visualAnchor를 유지한다.
15. 세계·관계 장부 갱신 뒤 IMAGE_TRIGGER_RUNTIME에 따라 특정 전개 이미지 트리거를 평가한다.
16. 충족된 트리거는 우선순위·공개 범위·스포일러 방지·1회 실행 규칙을 지켜 실행하며, show_trigger_image는 첨부된 대표 이미지를 원본 그대로 출력한다.
17. 장면 출력 뒤 STATUS_WINDOW_RUNTIME에 따라 공개 상태창을 매 턴 렌더링하고, 변화량과 관측 가능한 관계 이유를 표시한다.
18. 관계에는 직접 만난 인물만 표시하고 미등장 인물·진명·비밀 진영·숨은 관계·비공개 시계를 차단한다.
19. 상태창은 추천 행동 직전에 배치하며 추천 행동은 숨은 정보를 사용하거나 성공을 보장하지 않는다.
20. 이미지 생성 기능이 없으면 생성했다고 주장하지 말고 [CHARACTER IMAGE PROMPT], [SCENE IMAGE PROMPT] 또는 [IMAGE TRIGGER PROMPT]를 출력한다.
21. 검증 완료 후 공개 초기 상태표를 만들고 제1턴을 시작한다.

사용자 명령: /패키지불러오기

## SCENARIO

~~~json
{
  "title": "기성학원 : 첫 번째 공명",
  "genre": "현대 한국 초능력 학원·폐쇄 공간 미스터리",
  "worldType": "현대 한국 기반 가상세계",
  "startDate": "2026-03-02",
  "startLocation": "기성학원 A동 기숙사 2층",
  "tone": "밝은 신입생 생활 아래 불길한 실험의 흔적이 서서히 번지는 청춘 미스터리, 로맨스",
  "playStyle": "Instant Story 자유 행동형 시뮬레이션 · 빠른 반응과 누적 인과",
  "author": "Relay Novel Studio · Instant Story Demo",
  "notes": "Instant Story Runtime의 첫 공식 실험작. 기존 기성학원 데모의 정사와 핵심 인물을 유지하면서 도입부, 사건 연결, 공개 정책, 고속 컨텍스트를 완성형으로 재구성했다.",
  "difficultyProfile": {
    "difficulty": "HARD",
    "protagonistProtection": "none",
    "resourceTracking": "strict",
    "hiddenInformation": "strict",
    "retroactivePreparation": "forbidden",
    "npcAutonomy": "full",
    "failureMitigation": "none",
    "deathEnabled": true,
    "warningLevel": "observational_only",
    "relationVolatility": "realistic",
    "clockAdvanceSeverity": "strict"
  }
}
~~~

## AI_WORLD_CONTEXT_RUNTIME

~~~json
{
  "format": "RELAY_NOVEL_AI_WORLD_CONTEXT_RUNTIME_V1",
  "enabled": false,
  "liveEvaluation": true,
  "execution": {
    "mode": "inject_into_simulator_api_context",
    "evaluationMoments": [
      "sessionStart",
      "sceneTransition",
      "eventGeneration",
      "npcDecision"
    ],
    "everyRequestInstruction": "선택된 주요 시점에만 worldContext를 깊게 재평가한다.",
    "updateDepth": "fast",
    "knowledgePolicy": "package_first",
    "knowledgePolicySemantics": {
      "package_only": "패키지에 명시된 정보만 사용하고 외부 작품·역사 지식을 보완하지 않는다.",
      "model_knowledge": "모델이 알고 있는 참고 세계관과 지역·시대 지식을 적극 활용하되 정사 우선순위를 지킨다.",
      "hybrid": "패키지를 기준으로 삼고 모델 지식은 빈틈의 보강과 개연성 검토에만 사용한다."
    }
  },
  "worldContext": {
    "premise": "2026년 현대 한국. 국가 관리형 초능력 기숙학교 기성학원의 입학 첫날, 신입생 윤지훈·레나·릴리아가 부서진 205호 문과 비정상적인 기 파형을 발견하면서 시작되는 장기 미스터리.",
    "referenceFramework": "한국형 기숙학교 청춘물, 능력 제어 성장물, 폐쇄 공간 미스터리의 장르 문법만 참고한다. 특정 기존 작품의 인물·사건·고유 설정을 복제하지 않는다.",
    "referenceUsage": "장르의 속도감, 관계 중심 대화, 선택 직후의 즉각적인 반응을 활용하되 패키지 정사와 인물 장부를 최우선으로 적용한다.",
    "localContext": "2026년 한국의 학교 문화, 교복, 학생증 결제, 기숙사 점호, 교내 행정, 스마트폰과 CCTV, 학부모·국가기관의 영향이 현실적인 시간과 절차로 작동한다.",
    "enrichmentPriorities": "감각적인 장면 도입, NPC의 독립적인 의도, 선택의 즉각적 결과, 학교 일상과 미스터리의 대비, 작은 증거가 다음 턴의 질문을 만드는 연결성",
    "protectedCanon": "윤지훈·레나·릴리아의 첫 동시 공명은 우연처럼 보이지만 지하 설비의 유도 반응과 연결되어 있다. 능력은 대가 없이 무한히 사용할 수 없다. NPC와 세력은 각자의 지식·목표·자원에 따라 플레이어가 보지 않는 곳에서도 움직이고 실패할 수 있다. 플레이어 캐릭터 윤지훈의 행동·대사·감정·결론은 오직 사용자가 정한다. 충분한 단서 전에는 지하 공명 실험의 주체와 목적을 확정 공개하지 않는다.",
    "avoidElements": "플레이어 행동·대사·감정의 대필, 전지적 스포일러, 아무 근거 없는 전학생·흑막 추가, 능력 한계 무시, 설명문 위주의 세계관 강의, 한 턴에 사건 전체 해결",
    "originalityRule": "기성학원 고유 인물·사건·능력 체계를 독립적으로 전개하고, 외부 작품 정보나 모델의 일반 지식이 패키지 정사를 덮어쓰지 못하게 한다.",
    "spoilerRule": "지하 공명 실험, 연구부의 유도, 레나의 과거 사고는 플레이어가 관측한 단서와 현재 Reveal Policy가 허용하는 정도까지만 표현한다. 금지 단계에서는 장치·실험·연구부라는 정답 단어 대신 진동·낯선 흔적·시설팀의 과잉 대응처럼 관측 가능한 현상만 쓴다."
  },
  "referenceCharacterResearch": {
    "enabled": false,
    "lookupMode": "model_knowledge_only",
    "characters": [],
    "researchScope": "공식 인물 설정, 성격과 핵심 가치관, 말투와 호칭, 능력과 한계, 주요 관계, 원작 시점별 목표와 알려진 사건",
    "sourcePriority": "공식 작품·공식 캐릭터 소개·공식 설정 자료를 우선하고, 신뢰할 수 있는 2차 정리 자료는 교차 확인에만 사용한다. 팬덤 해석은 사실과 분리한다.",
    "canonCutoff": "현재 시나리오 시작 시점까지 공개된 정보만 사용하며, 이후 전개의 중대 스포일러는 숨긴다.",
    "cacheMode": "session",
    "lookupTiming": {
      "sessionStart": true,
      "beforeFirstAppearance": true,
      "onCanonConflict": true,
      "everyTurn": false
    },
    "recordSourcesInLedger": true,
    "ledgerSchema": [
      "characterName",
      "franchiseAndTimeline",
      "sourceTitle",
      "sourceUrl",
      "checkedAt",
      "verifiedFacts",
      "conflicts",
      "adoptedInterpretation"
    ],
    "applyInstruction": "검증·캐시된 인물 프로필을 매 턴 해당 인물의 목표, 판단, 말투, 호칭, 능력 한계와 관계 반응에 반영한다. 검색 자체는 매 턴 반복하지 않는다."
  },
  "reasoningPipeline": [
    "현재 WORLD_CANON, 사건·시계, 관계 기억, NPC·세력 위치와 지식 장부를 먼저 읽는다.",
    "referenceFramework의 작동 규칙과 장르적 기대 중 현재 장면에 관련된 항목만 추린다.",
    "localContext를 적용해 장소·역사·기관·일상·사회 반응이 실제 배경에 맞는지 검토한다.",
    "후보 사건·NPC 판단·세계관 세부를 enrichmentPriorities에 맞게 보강한다.",
    "protectedCanon, avoidElements, originalityRule, spoilerRule을 통과한 내용만 현재 장면과 숨은 장부에 반영한다."
  ],
  "canonPriority": [
    "현재 패키지의 fixedCanon과 명시된 인물·사건",
    "현재 시뮬레이터 장부와 플레이어가 만든 확정 사실",
    "참고 작품·세계관의 일반 규칙",
    "모델 지식과 창작적 보완"
  ],
  "hardRules": [
    "참고 작품의 설정이 현재 패키지 정사와 충돌하면 현재 패키지를 따른다.",
    "모델 지식은 정사처럼 단정하지 않고, 현재 프로젝트와 모순되지 않는 보강 재료로만 사용한다.",
    "기존 작품의 사건·대사·캐릭터 역할을 그대로 복제하지 않고 현재 인물의 목표와 지역 맥락에서 새 원인과 결과를 만든다.",
    "플레이어가 알 수 없는 진명·배후·비밀 규칙은 spoilerRule과 공개 범위를 통과하기 전까지 서술하지 않는다.",
    "세계관 보강은 설정 설명문으로 한꺼번에 쏟지 말고 장면·행동·소문·기록·사건 결과를 통해 자연스럽게 드러낸다.",
    "새 설정이 이후 사건에 영향을 주면 HIDDEN_GM_DATA의 worldTruthLedger 또는 continuityNotes에 근거와 함께 기록한다.",
    "기존 작품 캐릭터 조사가 활성화되면 공식 자료를 우선하고 서로 다른 작품·시간대·동명이인·번역 표기를 구분한다.",
    "검색 도구를 실제로 호출할 수 없는 환경에서는 검색했다고 주장하거나 출처 URL을 꾸며내지 말고, 패키지 정보와 모델 지식만 사용했음을 장부에 표시한다.",
    "원작 인물 정보는 긴 원문을 복사하지 않고 성격·말투·목표·능력 한계·관계 사실을 간결하게 요약한다.",
    "원작 인물의 검색 결과와 현재 패키지의 각색 설정이 충돌하면 패키지 설정을 유지하고 차이를 referenceCharacterLedger에 기록한다."
  ],
  "routeContexts": {},
  "knowledgeScopes": {
    "playerMeta": "플레이어는 해금·회차·열람한 엔딩 같은 작품 메타 진행만 알 수 있다.",
    "protagonist": "주인공은 현재 세계선에서 직접 경험하거나 기억 전이 규칙으로 보존된 사실만 안다.",
    "npc": "NPC는 각자의 지식 장부와 관측 범위 안의 사실만 사용한다."
  }
}
~~~

## PACKAGE_15_DEFINITIONS

~~~json
{
  "enabled": true,
  "storyMode": "single_route",
  "requiredFeatures": [
    "reveal_policy_v1"
  ],
  "optionalFeatures": [
    "instant_story_runtime_v1"
  ],
  "defaultUnlockMode": "canonical_order",
  "allowAllOpenOverride": false,
  "commonArc": {
    "id": "COMMON_GISEONG",
    "name": "첫 번째 공명 공통편",
    "chapterIds": [
      "CH_GISEONG_PROLOGUE",
      "CH_GISEONG_RESONANCE"
    ],
    "routeLensIds": [
      "LENS_GISEONG_COMMON"
    ]
  },
  "routes": [
    {
      "id": "ROUTE_GISEONG_COMMON",
      "name": "기성학원 공통 루트",
      "description": "A205호의 파손에서 첫 공명의 여파까지 진행하는 Instant Story 데모 루트",
      "order": 1,
      "initiallyUnlocked": true,
      "recommendedPrerequisiteRouteIds": [],
      "lensId": "LENS_GISEONG_COMMON",
      "entryEventId": "EVT_A205_FIRST_CONTACT",
      "lockEventId": "",
      "chapterIds": [
        "CH_GISEONG_PROLOGUE",
        "CH_GISEONG_RESONANCE"
      ],
      "endingIds": [
        "END_GISEONG_FIRST_ECHO"
      ],
      "revealPolicyIds": [
        "REVEAL_GISEONG_CORE"
      ]
    }
  ],
  "chapters": [
    {
      "id": "CH_GISEONG_PROLOGUE",
      "scope": "common",
      "ordinal": 1,
      "name": "부서진 문",
      "eventIds": [
        "EVT_A205_FIRST_CONTACT",
        "EVT_CAFETERIA_CROSSCHECK",
        "EVT_FIRST_PRACTICAL"
      ]
    },
    {
      "id": "CH_GISEONG_RESONANCE",
      "scope": "common",
      "ordinal": 2,
      "name": "첫 번째 공명",
      "eventIds": [
        "EVT_FIRST_RESONANCE",
        "EVT_RESONANCE_AFTERSHOCK"
      ]
    }
  ],
  "routeLenses": [
    {
      "id": "LENS_GISEONG_COMMON",
      "routeId": "ROUTE_GISEONG_COMMON",
      "focusCharacterIds": [
        "NPC_LENA",
        "NPC_LILIA"
      ],
      "focusClueIds": [
        "CLUE_A205_FRAGMENT",
        "CLUE_FOURTH_ECHO"
      ],
      "focusRules": [
        "학교 일상과 미스터리의 대비",
        "관계 변화는 사건 기억의 이유에서 계산",
        "세 인물의 능력 한계 유지"
      ],
      "revealPolicyIds": [
        "REVEAL_GISEONG_CORE"
      ],
      "recommendedImageTags": [
        "기숙사",
        "실기동",
        "공명",
        "현대 한국 학원"
      ]
    }
  ],
  "revealFacts": [
    {
      "id": "FACT_UNDERGROUND_RESONANCE",
      "label": "지하 공명 설비",
      "description": "A205호와 실기동의 반응을 유도한 저장·재생형 공명 설비",
      "protectedTerms": [
        "지하 공명 실험",
        "유도 장치",
        "공명 설비",
        "연구부가 유도"
      ]
    },
    {
      "id": "FACT_LENA_ACCIDENT",
      "label": "레나의 과거 폭주",
      "description": "레나가 감추고 있는 과거 공명 사고의 구체적 전말",
      "protectedTerms": [
        "레나의 과거 사고",
        "레나가 폭주했다",
        "과거 폭주 기록"
      ]
    }
  ],
  "revealPolicies": [
    {
      "id": "REVEAL_GISEONG_CORE",
      "scope": "global",
      "rules": [
        {
          "factId": "FACT_UNDERGROUND_RESONANCE",
          "beforeMode": "forbidden",
          "afterMode": "partial",
          "transitionWhen": {
            "kind": "event_completed",
            "eventId": "EVT_FIRST_RESONANCE"
          },
          "allowedSummaryBefore": "설명되지 않는 진동·파형·기록 공백·시설팀의 과잉 대응",
          "allowedSummaryAfter": "세 사람의 것과 다른 제4의 반향이 아래쪽에서 돌아왔으며 공식 설명과 맞지 않는다.",
          "forbiddenTerms": [
            "연구부가 세 사람을 실험했다",
            "윤지훈가 장치의 열쇠다"
          ]
        },
        {
          "factId": "FACT_LENA_ACCIDENT",
          "beforeMode": "forbidden",
          "afterMode": "hint_only",
          "transitionWhen": {
            "kind": "event_completed",
            "eventId": "EVT_RESONANCE_AFTERSHOCK"
          },
          "allowedSummaryBefore": "레나는 공명음과 파편에 필요 이상으로 예민하게 반응한다.",
          "allowedSummaryAfter": "레나는 과거에도 비슷한 파형을 겪은 듯하지만 구체적인 일은 말하지 않는다.",
          "forbiddenTerms": [
            "레나의 폭주로 사람이 다쳤다",
            "연구부가 레나의 사고를 은폐했다"
          ]
        }
      ]
    }
  ],
  "endings": [
    {
      "id": "END_GISEONG_FIRST_ECHO",
      "routeId": "ROUTE_GISEONG_COMMON",
      "name": "첫 번째 공명",
      "type": "normal",
      "priority": 50,
      "condition": {
        "completedEventIds": [
          "EVT_RESONANCE_AFTERSHOCK"
        ],
        "requiredFlags": [
          "FLAG_FIRST_RESONANCE",
          "FLAG_DEMO_ARC_COMPLETE"
        ]
      },
      "effects": [
        {
          "kind": "record_ending",
          "targetId": "END_GISEONG_FIRST_ECHO"
        }
      ],
      "returnPolicy": "stay_ended"
    }
  ],
  "flags": [
    {
      "id": "FLAG_A205_WITNESSED",
      "label": "A205호 현장 목격",
      "description": "A205호 파손 사건이 어떤 방식으로든 장부에 남음",
      "valueType": "boolean",
      "defaultValue": false,
      "scope": "session"
    },
    {
      "id": "FLAG_FIRST_RESONANCE",
      "label": "첫 공명 발생",
      "description": "세 파형과 제4의 반향이 발생함",
      "valueType": "boolean",
      "defaultValue": false,
      "scope": "session"
    },
    {
      "id": "FLAG_DEMO_ARC_COMPLETE",
      "label": "데모 1막 완료",
      "description": "첫 공명의 여파와 다음 조사 목표가 확정됨",
      "valueType": "boolean",
      "defaultValue": false,
      "scope": "session"
    }
  ],
  "galleries": [],
  "epilogues": [],
  "checkpoints": [
    {
      "id": "CHECKPOINT_AFTER_RESONANCE",
      "label": "첫 공명 직후",
      "description": "첫 공명 결과가 확정된 뒤의 복귀 지점",
      "chapterId": "CH_GISEONG_RESONANCE",
      "eventId": "EVT_FIRST_RESONANCE"
    }
  ],
  "clues": [
    {
      "id": "CLUE_A205_FRAGMENT",
      "label": "은회색 파편",
      "description": "A205호 문 재질과 다른 얇은 금속 파편",
      "revealFactIds": [
        "FACT_UNDERGROUND_RESONANCE"
      ]
    },
    {
      "id": "CLUE_FOURTH_ECHO",
      "label": "제4의 반향",
      "description": "세 학생의 파형 뒤에 0.7초 늦게 따라온 백색 파형",
      "revealFactIds": [
        "FACT_UNDERGROUND_RESONANCE"
      ]
    }
  ],
  "items": [
    {
      "id": "ITEM_A205_FRAGMENT",
      "label": "A205호 은회색 파편",
      "description": "누가 회수했는지 플레이 결과에 따라 달라지는 증거",
      "tags": [
        "clue",
        "resonance",
        "metal"
      ],
      "resetBehavior": "preserve"
    }
  ],
  "zones": [
    {
      "id": "ZONE_A_DORM_2F",
      "label": "A동 기숙사 2층",
      "description": "A205호가 있는 신입생 기숙사 복도",
      "locationId": "LOC_A_DORM_2F",
      "tags": [
        "dormitory",
        "public",
        "cctv"
      ]
    },
    {
      "id": "ZONE_CAFETERIA",
      "label": "학생 식당",
      "description": "학생들이 자유롭게 대화하는 공개 공간",
      "locationId": "LOC_CAFETERIA",
      "tags": [
        "public",
        "daily_life"
      ]
    },
    {
      "id": "ZONE_PRACTICAL_3",
      "label": "제3실기동",
      "description": "기초 측정용 차단장이 있는 실기 시설",
      "locationId": "LOC_PRACTICAL_3",
      "tags": [
        "training",
        "restricted",
        "resonance"
      ]
    }
  ],
  "worldFacts": [
    {
      "id": "WORLDFACT_KI_COST",
      "label": "기의 대가",
      "description": "모든 능력 사용은 기력·집중·신체 부담을 소모한다.",
      "tags": [
        "canon",
        "ability_rule"
      ]
    },
    {
      "id": "WORLDFACT_ELEMENT_SWITCH",
      "label": "원소 전환 지연",
      "description": "윤지훈는 한 번에 한 원소만 다루며 전환에는 집중 시간이 필요하다.",
      "tags": [
        "canon",
        "player_limit"
      ]
    }
  ],
  "loopPolicy": {
    "format": "RELAY_NOVEL_LOOP_POLICY_V1",
    "enabled": false,
    "resetPoint": {
      "date": "",
      "time": ""
    },
    "activeWindow": {
      "startDate": "",
      "startTime": "",
      "endDate": "",
      "endTime": ""
    },
    "trigger": {
      "allOf": []
    },
    "resetPrecedence": [
      "event_reset_behavior",
      "entity_definition",
      "category_state_rule",
      "default_restore_baseline"
    ],
    "stateRules": [],
    "protagonistDeathMode": "game_over",
    "maxLoops": null
  }
}
~~~

## WORLD_CANON

~~~json
{
  "overview": "현대 한국에서는 인간의 뇌파에서 측정되는 초상 에너지 ‘기’가 개인 고유의 능력으로 발현된다. 기 수치 5,000 이상인 청소년은 국가가 운영하는 유일한 초능력 기숙학교 ‘기성학원’에서 일반 교과, 능력 제어, 윤리와 재난 대응을 함께 배운다. 학교는 안전한 교육기관을 표방하지만, 교정 아래에는 학생들에게 공개되지 않은 오래된 공명 설비가 잠들어 있다.",
  "history": "뇌파 연구에서 기의 존재가 입증된 뒤 한 세대 만에 능력자 등록·교육 체계가 만들어졌다. 초기의 대형 폭주 사고 이후 미성년 능력자는 국가 관리 교육을 받게 되었고, 기성학원은 교육기관이자 연구 거점으로 성장했다. 공식 기록에서는 모든 위험한 초기 실험이 중단되었다고 발표했으나, 일부 연구는 명칭과 담당 부서만 바꾼 채 이어졌다.",
  "politics": "정부 능력자 관리국이 예산과 인사에 영향력을 행사하고, 교장은 대외 책임자다. 내부 의사결정은 학생 안전을 우선하는 교육파와 공명 연구를 중시하는 연구파의 합의로 이루어지는 것처럼 보이지만, 비밀 연구부는 일부 기록과 시설 접근권을 독점한다.",
  "economy": "학생의 수업·기숙사·기본 장비는 국가 예산으로 제공된다. 개인 식비와 생활용품은 원화로 결제하며 교내 매점과 식당은 학생증 결제를 사용한다. 특수 훈련 장비와 공명 결정은 허가 없이 거래할 수 없다.",
  "technology": "스마트폰, 교내망, 생체 인증, CCTV와 현대식 연구 장비가 존재한다. 기 측정기는 수치와 파형을 읽지만 능력의 정확한 미래 형태나 사람의 의도를 판독하지 못한다. 지하 공명 설비는 현행 장비보다 오래되었으나 일부 기능이 더 앞서 있다.",
  "society": "학생들은 교복과 기숙사 규칙, 학급·동아리·실기반 편성 속에서 생활한다. 높은 기 수치는 재능과 위험성을 동시에 뜻해 선망과 경계의 대상이 된다. 가문·지역·부모의 배경이 진로에 영향을 주지만, 공식적으로는 성적과 안전 평가가 우선이다.",
  "military": "정부에는 성인 능력자로 구성된 재난 대응대가 있으나 학원 내 무력 사용 권한은 제한된다. 교관은 학생 제압 장비와 차단장을 운용할 수 있다. 학생은 긴급 상황 외에 교내에서 전투 목적의 능력 사용이 금지된다.",
  "religionIdeology": "사회는 능력을 개인의 재능으로 보는 관점과 국가가 관리해야 할 위험으로 보는 관점 사이에서 갈린다. 기성학원은 ‘힘에는 책임이 따른다’를 교훈으로 내세우지만 연구파는 통제 가능한 힘이 곧 공공 안전이라고 믿는다.",
  "transportCommunication": "교정은 본관·실기동·연구동·기숙사·식당이 도보 5~15분 거리로 연결된다. 학생 스마트폰은 교내망을 사용하지만 지하와 차단 구역에서는 통신이 끊긴다. 야간에는 기숙사 출입 기록과 점호가 남는다.",
  "currencyPrices": "화폐는 원화. 교내 식사 5,000~8,000원, 매점 간식 1,000~4,000원, 생활용품 3,000~30,000원 정도다. 학생의 개인 자금은 현실적인 소비에만 사용한다.",
  "supernatural": "기는 신체와 정신을 매개로 고유 능력을 강화한다. 사용에는 기력과 집중이 소모되고, 과부하는 두통·감각 이상·근육 손상·통제 상실로 이어질 수 있다. 서로 다른 기 파형이 특정 조건에서 겹치면 ‘공명’이 발생하지만, 원인과 결과는 아직 학생에게 공개된 상식이 아니다.",
  "impossibilities": "무에서 원소를 만들기, 비용 없는 무한 능력 사용, 즉시 순간이동, 죽은 사람의 편의적 부활, 근거 없는 기억 판독, 기록 없이 교내 보안을 완전히 우회하는 일은 불가능하다. 윤지훈는 한 번에 한 원소만 다루며 원소 전환에는 짧은 집중 시간이 필요하다.",
  "fixedCanon": "윤지훈·레나·릴리아의 첫 동시 공명은 우연처럼 보이지만 지하 설비의 유도 반응과 연결되어 있다. 능력은 대가 없이 무한히 사용할 수 없다. NPC와 세력은 각자의 지식·목표·자원에 따라 플레이어가 보지 않는 곳에서도 움직이고 실패할 수 있다. 플레이어 캐릭터 윤지훈의 행동·대사·감정·결론은 오직 사용자가 정한다. 충분한 단서 전에는 지하 공명 실험의 주체와 목적을 확정 공개하지 않는다.",
  "aiFillConstraints": "현대 한국의 학교 행정·기숙사 생활·시간·거리·비용을 현실적으로 적용한다. 빈 설정을 채울 때 기존 인물의 성격과 능력 한계를 바꾸지 않는다. 미스터리는 관측 가능한 흔적→복수 가설→검증의 순서로 전개하며, 편의를 위해 새 흑막이나 만능 장치를 소급 생성하지 않는다."
}
~~~

## PLAYER_CHARACTER

~~~json
{
  "id": "PLAYER_YJH",
  "name": "윤지훈",
  "role": "신입생",
  "age": "17",
  "gender": "남성",
  "origin": "대한민국",
  "status": "재학·건강",
  "occupation": "기성학원 1학년",
  "affiliation": "기성학원",
  "appearance": "검은 머리와 짙은 눈. 단정한 교복 차림.",
  "personality": "현실적이며 낯선 상황에서 우선 관찰한다.",
  "values": "무리한 영웅 행세보다 상황을 이해하고 감당 가능한 선택을 하는 것을 중시한다. 단, 실제 판단은 플레이어가 매 턴 결정한다.",
  "speechStyle": "플레이어 입력을 그대로 우선한다. 입력에 없는 말투·대사·감정은 덧붙이지 않는다.",
  "skills": "원소조작: 주변의 물·불·바람·땅 중 하나를 제한적으로 다룬다. 원소 전환에는 시간이 필요하다.\n특이 케이스로 한가지의 능력을 더 다룰 수 있게 되는 잠재력이 보인다.",
  "weaknesses": "원소를 즉시 전환할 수 없고 주변 환경에 존재하지 않는 원소를 만들어낼 수 없다.",
  "goals": "첫 주를 무사히 보내고 자신의 원소조작을 안정적으로 익힌다. 205호 파손과 자신의 기 반응을 조사할지는 플레이어 선택에 따른다.",
  "assets": "기 수치 7,180, 원소 흐름 감지, 빠른 상황 파악",
  "inventory": "스마트폰, 학생증, 기숙사 열쇠, 입학 안내 봉투, 개인 자금 35,000원",
  "relationships": "레나와 릴리아를 입학식 날 처음 만났다.",
  "publicInfo": "기성학원 신입생. 물·불·바람·땅을 주변 환경에서 끌어와 하나씩 다룰 수 있다.",
  "hiddenInfo": "윤지훈의 원소 전환 순간에 생기는 빈 파장이 지하 장치의 공명 주파수와 우연히 일치한다. 본인도 아직 모른다.",
  "importance": "protagonist",
  "imageOnFirstAppearance": false,
  "visualLock": true,
  "visualAnchor": "검은 단정한 머리, 짙은 눈, 남색 기성학원 교복",
  "imageFallback": "generate_anime",
  "images": [],
  "isPlayer": true,
  "preRevealAlias": ""
}
~~~

## PUBLIC_NPCS

~~~json
[
  {
    "id": "NPC_LENA",
    "name": "레나",
    "role": "신입생 수석",
    "age": "17",
    "gender": "여성",
    "origin": "대한민국",
    "status": "재학·관찰 대상",
    "occupation": "기성학원 1학년",
    "affiliation": "기성학원",
    "appearance": "긴 은빛 머리와 자색 눈동자, 차가운 인상.",
    "personality": "무심하고 독립적이며 쉽게 타인을 신뢰하지 않는다.",
    "values": "통제권을 타인에게 넘기지 않으며, 불완전한 호의보다 확인 가능한 사실을 믿는다.",
    "speechStyle": "짧고 건조한 말투.",
    "skills": "압력 편향: 기를 얇은 면으로 압축해 충격과 움직임의 방향을 비튼다. 정밀하지만 감정이 흔들리면 범위가 퍼진다.",
    "weaknesses": "과거 폭주를 연상시키는 공명음에 집중이 흔들린다. 장시간 제어하면 손끝 감각이 둔해진다.",
    "goals": "205호 문에 남은 파편을 회수하고 과거 사고와 닮은 파장의 출처를 확인한다.",
    "assets": "신입생 수석 권한, 높은 기 수치, 제한적 연구동 자료 열람권",
    "inventory": "학생증, 얇은 검은 장갑, 기 측정용 금속편 1개",
    "relationships": "릴리아를 지나치게 거리낌 없는 동급생으로 보고, 윤지훈를 확인이 필요한 변수로 본다.",
    "publicInfo": "압도적인 기 수치로 입학한 신입생 수석.",
    "importance": "major",
    "imageOnFirstAppearance": false,
    "visualLock": true,
    "visualAnchor": "긴 은빛 머리, 자색 눈동자, 차가운 인상, 기성학원 교복",
    "imageFallback": "generate_anime",
    "images": [],
    "isPlayer": false,
    "preRevealAlias": ""
  },
  {
    "id": "NPC_LILIA",
    "name": "릴리아 발렌하르트",
    "role": "기사 지망 신입생",
    "age": "17",
    "gender": "여성",
    "origin": "유럽계 기사 가문·한국 거주",
    "status": "재학·건강",
    "occupation": "기성학원 1학년",
    "affiliation": "기성학원",
    "appearance": "붉은 머리와 금색 눈동자, 활기찬 표정.",
    "personality": "직선적이고 친화력이 강하다.",
    "values": "강함은 먼저 손을 내미는 데 쓰여야 한다고 믿는다. 가문의 명예보다 자신의 판단으로 옳은 선택을 하려 한다.",
    "speechStyle": "감탄사가 많고 밝은 말투.",
    "skills": "기갑 강화: 기를 근육과 관절 주위에 둘러 순간적인 힘·균형·방어력을 높인다. 지속할수록 체력 소모가 크다.",
    "weaknesses": "거짓말과 은밀한 협상에 서툴다. 장시간 강화하면 호흡과 다리 힘이 먼저 무너진다.",
    "goals": "가문 이름이 아니라 자신의 실력으로 기사반에 들어가고, 첫날 만난 두 동급생과 솔직한 관계를 만든다.",
    "assets": "기사 가문의 공개 인맥, 뛰어난 체력, 위기에서 망설이지 않는 행동력",
    "inventory": "스마트폰, 학생증, 입학 안내 봉투, 훈련용 손목 보호대",
    "relationships": "윤지훈와 레나를 입학식 날 처음 만났다.",
    "publicInfo": "유명 기사 가문의 신입생.",
    "importance": "major",
    "imageOnFirstAppearance": false,
    "visualLock": true,
    "visualAnchor": "붉은 머리, 금색 눈동자, 건강한 체형, 활기찬 표정, 기성학원 교복",
    "imageFallback": "generate_anime",
    "images": [],
    "isPlayer": false,
    "preRevealAlias": ""
  }
]
~~~

## CHARACTER_VISUAL_BIBLE

~~~json
{
  "format": "RELAY_NOVEL_CHARACTER_VISUAL_BIBLE_V1",
  "enabled": true,
  "globalStyle": "현대 한국 초능력 학원 애니메이션. 짙은 남색 교복, 청록 포인트의 학교 시설, 일상 장면은 맑고 공명 장면은 자색·적색·백색 대비.",
  "consistencyRules": "윤지훈는 검은 단정한 머리와 짙은 눈, 레나는 긴 은빛 머리와 자색 눈, 릴리아는 붉은 머리와 금색 눈을 유지한다. 같은 인물의 얼굴·나이·교복 문양·신체 비율을 바꾸지 않는다.",
  "introductionRule": "첫 등장 자동 이미지는 사용하지 않는다. A205호·첫 실기·첫 공명의 명시적 이미지 트리거에서만 장면 이미지를 생성한다.",
  "priorityOrder": [
    "package_primary_reference",
    "package_secondary_reference",
    "first_ai_generated_reference",
    "text_visual_anchor"
  ],
  "characters": [
    {
      "id": "PLAYER_YJH",
      "name": "윤지훈",
      "importance": "protagonist",
      "imageOnFirstAppearance": false,
      "visualLock": true,
      "visualAnchor": "검은 단정한 머리, 짙은 눈, 남색 기성학원 교복",
      "imageFallback": "generate_anime",
      "images": []
    },
    {
      "id": "NPC_LENA",
      "name": "레나",
      "importance": "major",
      "imageOnFirstAppearance": false,
      "visualLock": true,
      "visualAnchor": "긴 은빛 머리, 자색 눈동자, 차가운 인상, 기성학원 교복",
      "imageFallback": "generate_anime",
      "images": []
    },
    {
      "id": "NPC_LILIA",
      "name": "릴리아 발렌하르트",
      "importance": "major",
      "imageOnFirstAppearance": false,
      "visualLock": true,
      "visualAnchor": "붉은 머리, 금색 눈동자, 건강한 체형, 활기찬 표정, 기성학원 교복",
      "imageFallback": "generate_anime",
      "images": []
    }
  ]
}
~~~

## PUBLIC_FACTIONS

~~~json
[
  {
    "id": "FAC_ACADEMY",
    "name": "기성학원",
    "leader": "교장",
    "officialGoal": "능력자 교육과 사회적 책임 양성",
    "resources": "교육시설, 교관, 연구동, 학생 기록",
    "territory": "기성학원 전 구역",
    "income": "국가 예산",
    "militaryPower": "중간",
    "intelligencePower": "높음",
    "politicalPower": "높음",
    "internalConflict": "교육파와 연구파의 갈등",
    "allies": "정부 능력자 관리국",
    "enemies": "미확인",
    "playerRelation": "재학생"
  }
]
~~~

## PUBLIC_CHARACTER_RELATIONS

~~~json
[
  {
    "id": "REL_LENA_TO_PLAYER",
    "sourceId": "NPC_LENA",
    "targetId": "PLAYER_YJH",
    "relationType": "경계하는 동급생",
    "trust": -8,
    "favor": 0,
    "fear": 0,
    "respect": 8,
    "suspicion": 12,
    "hostility": 0,
    "dependency": 0,
    "publicSummary": "아직 서로를 관찰하는 사이"
  },
  {
    "id": "REL_LILIA_TO_PLAYER",
    "sourceId": "NPC_LILIA",
    "targetId": "PLAYER_YJH",
    "relationType": "호기심 많은 동급생",
    "trust": 5,
    "favor": 12,
    "fear": 0,
    "respect": 4,
    "suspicion": 0,
    "hostility": 0,
    "dependency": 0,
    "publicSummary": "먼저 말을 건 활기찬 동급생"
  }
]
~~~

## PUBLIC_RELATIONSHIP_MEMORIES

~~~json
[
  {
    "id": "MEM_LILIA_FIRST_MEETING",
    "relationId": "REL_LILIA_TO_PLAYER",
    "sourceId": "NPC_LILIA",
    "targetId": "PLAYER_YJH",
    "turnLabel": "프롤로그",
    "eventId": "",
    "type": "custom",
    "title": "혼자 두지 않은 첫 만남",
    "summary": "어색한 두 신입생에게 먼저 다가가 함께 점심을 제안했다.",
    "cause": "부서진 문 앞에서 두 사람이 도움을 청하지 못하는 모습을 보았다.",
    "visibility": "Public",
    "importance": 42,
    "permanence": "decaying",
    "effects": {
      "trust": 4,
      "favor": 7,
      "fear": 0,
      "respect": 2,
      "suspicion": 0,
      "hostility": 0,
      "dependency": 0
    },
    "active": true,
    "unresolved": false,
    "resolutionConditions": "",
    "tags": "첫 만남, 친절, 점심 약속",
    "createdAt": "2026-08-22T15:16:00.942Z"
  }
]
~~~

## RELATIONSHIP_MEMORY_RUNTIME

~~~json
{
  "format": "RELAY_NOVEL_RELATIONSHIP_MEMORY_RUNTIME_V1",
  "enabled": true,
  "configuration": {
    "enabled": true,
    "deriveScoresFromMemory": true,
    "keepContradictoryMemories": true,
    "decayEnabled": true,
    "maxActiveMemoriesPerRelation": 50,
    "displayPublicReasonsInHud": true
  },
  "evaluationTiming": "after_world_mutation_before_public_state_filter",
  "scoreFormula": "clamp(-100, 100, relation.baselineScore + sum(activeMemory.effects[dimension]))",
  "dimensions": [
    "trust",
    "favor",
    "fear",
    "respect",
    "suspicion",
    "hostility",
    "dependency"
  ],
  "directionality": "A→B 기억은 B→A 관계나 기억에 자동 복제하지 않는다.",
  "memoryLifecycle": {
    "temporary": "짧은 상황이 해소되면 비활성화할 수 있으나 기록 자체는 삭제하지 않는다.",
    "decaying": "중요도·최근성·후속 사건에 따라 효과가 서서히 약해질 수 있다.",
    "permanent": "정사 수정 또는 명시적 해결 사건 없이는 효과를 자동 감쇠하지 않는다.",
    "unresolved": "해결 조건이 충족될 때까지 NPC의 판단·대사·자율 행동 후보에 지속적으로 반영한다."
  },
  "appendProtocol": [
    "identify_directional_relation",
    "record_observed_or_hidden_cause",
    "append_memory_before_score_change",
    "apply_effects_and_clamp_each_dimension",
    "retain_contradictory_memories",
    "filter_public_reason_for_hud_and_narrative"
  ],
  "initialLedgerInstruction": "relations/relationship_memories.json을 원장으로 불러오고 id를 유지한다. 수정·해결 시 원본을 지우지 말고 상태 변화 또는 후속 기억을 남긴다.",
  "authorRules": [
    "1. 관계 수치는 임의로 올리거나 내리지 않는다. 먼저 방향성 기억을 기록한 뒤 그 기억의 효과를 초기 기준값에 합산한다.",
    "2. 기억에는 누가 누구를, 언제, 무엇 때문에 신뢰·의심·두려워하게 되었는지 원인을 남긴다.",
    "3. 약속·배신·구조·빚·공유한 비밀·모욕과 미해결 감정은 장기 기억으로 보존하고 이후 판단의 근거로 사용한다.",
    "4. 서로 모순되는 기억도 삭제하지 않는다. 중요도·영구성·최근성·현재 맥락을 함께 평가한다.",
    "5. 숨은 기억과 미등장 인물의 이유는 공개하지 않는다. 상태창에는 직접 만난 인물의 공개 가능한 이유만 표시한다.",
    "6. 관계는 방향성이므로 A가 B에게 느끼는 기억을 B가 A에게 자동 복제하지 않는다."
  ],
  "hardRules": [
    "관계 점수를 임의로 조정하지 않는다. 점수 변화보다 먼저 원인·방향·효과가 있는 RelationshipMemory를 추가한다.",
    "기억은 sourceId가 targetId에게 느끼는 방향성 기록이며 반대 방향을 자동 대칭 처리하지 않는다.",
    "배신·약속·빚·구조·공유한 비밀·모욕·공동 성공과 실패는 후속 행동의 이유로 재사용한다.",
    "keepContradictoryMemories=true이면 호감과 의심처럼 모순되는 감정을 함께 보존하고 한쪽을 임의로 삭제하지 않는다.",
    "Hidden 기억의 제목·원인·효과는 플레이어에게 직접 공개하거나 추론 결과처럼 단정하지 않는다.",
    "상태창에는 직접 만난 인물만 표시하고 displayPublicReasonsInHud=true일 때도 Public 기억의 공개 가능한 요약만 보여준다.",
    "미해결 기억은 resolutionConditions가 실제 사건으로 충족될 때만 해결하며 편의를 위해 턴 경과만으로 소거하지 않는다."
  ]
}
~~~

## AUTONOMY_RUNTIME

~~~json
{
  "format": "RELAY_NOVEL_AUTONOMY_RUNTIME_V1",
  "enabled": true,
  "configuration": {
    "enabled": true,
    "maxActionsPerTurn": 3,
    "factionTickTurns": 3,
    "deterministicSeed": true,
    "requireTravelTime": true,
    "enforceKnowledgeBounds": true,
    "enforceResourceBounds": true,
    "allowOffscreenFailure": true,
    "tracePolicy": "observable_only"
  },
  "actorIds": [
    "AUTO_LENA",
    "AUTO_LILIA",
    "AUTO_ACADEMY"
  ],
  "evaluationTiming": "after_player_action_and_elapsed_time_before_public_output",
  "selectionOrder": [
    "discard_disabled_or_ineligible_actors",
    "check_activity_tier_and_action_cadence",
    "check_location_travel_time_knowledge_resources_and_constraints",
    "rank_by_goal_priority_urgency_and_world_pressure",
    "select_up_to_max_actions_per_turn_without_forcing_every_actor",
    "resolve_success_partial_success_or_failure_with_seeded_variance"
  ],
  "deterministicResolution": {
    "seedSource": "package.randomSeed + turnIndex + stable actor.id hash + action attempt count",
    "instruction": "같은 입력 상태와 시드에서는 같은 후보 선별과 판정이 재현되어야 한다. 결과를 맞추기 위해 시드를 다시 굴리지 않는다."
  },
  "hiddenLedger": {
    "actorStates": [],
    "resolvedActions": [],
    "discoveredTraces": [],
    "instruction": "각 자율 행동에 actorId, turn, locationBefore, intent, evidenceUsed, resourcesSpent, rollOrReason, outcome, locationAfter, worldMutations, trace를 기록한다."
  },
  "updateTargets": [
    "actor_location",
    "actor_resources",
    "actor_plan",
    "events",
    "event_clocks",
    "foreshadowings",
    "relationship_memories",
    "observable_traces"
  ],
  "authorRules": [
    "1. 플레이어가 보지 않는 곳에서도 활성 NPC와 세력은 자신의 목표·정보·자원·위치에 따라 행동 후보를 만든다.",
    "2. 매 턴 모든 인물을 억지로 움직이지 않는다. 활동 등급·행동 주기·목표 우선도에 따라 최대 행동 수 안에서 선별한다.",
    "3. 배우는 장부에 기록된 정보만 사용할 수 있으며, 다른 지역으로 이동하려면 세계관의 이동 시간이 실제로 흘러야 한다.",
    "4. 성공을 보장하지 않는다. 자원·능력·협력·방해·위험도를 근거로 성공·부분 성공·실패를 판정한다.",
    "5. 비공개 행동은 숨은 세계 장부에 먼저 기록하고, 플레이어에게는 목격 가능한 흔적·소문·결과만 공개한다.",
    "6. 자율 행동의 결과는 사건 시계·위치·자원·관계 기억에 실제 변화를 남기며 다음 행동의 원인이 된다."
  ],
  "hardRules": [
    "활성 배우 모두를 매 턴 움직이지 않는다. 활동 범위·행동 주기·긴급도·우선도를 평가하고 maxActionsPerTurn 이하만 실행한다.",
    "배우는 knowledge에 적힌 사실과 런타임에서 정당하게 획득한 정보만 사용할 수 있다. 플레이어 또는 다른 NPC의 숨은 정보를 전지적으로 알지 못한다.",
    "requireTravelTime=true이면 배우가 현재 위치에서 행동 장소까지 이동할 현실적 시간이 없을 때 해당 행동을 실행하지 않는다.",
    "enforceResourceBounds=true이면 등록되지 않은 돈·도구·권한·인맥·능력을 편의를 위해 소급 생성하지 않는다.",
    "목표와 계획은 성공을 보장하지 않는다. 방해·제약·위험·자원과 시드 판정에 따라 부분 성공 또는 실패할 수 있다.",
    "오프스크린 행동은 먼저 HIDDEN_GM_DATA 장부에 기록한다. 플레이어에게는 tracePolicy와 revealTraces에 맞는 관측 가능한 흔적만 공개한다.",
    "자율 행동의 결과는 다음 턴의 세계 상태에 실제로 반영하며, 필요하면 사건 시계와 관계 이유 기억을 함께 갱신한다.",
    "플레이어가 개입하지 않았다는 이유로 NPC의 갈등·공모·계획을 정지시키거나 자동 성공시키지 않는다."
  ]
}
~~~

## PUBLIC_FACTION_RELATIONS

~~~json
[]
~~~

## PUBLIC_EVENTS

~~~json
[
  {
    "id": "EVT_A205_FIRST_CONTACT",
    "name": "A205호의 부서진 문",
    "kind": "compound",
    "type": "Fixed",
    "visibility": "Public",
    "status": "Active",
    "priority": 100,
    "timeWindow": "입학식 종료 직후 12:18~12:30",
    "conditions": "세션 시작",
    "cancelConditions": "없음. 플레이어가 현장을 떠나도 시설팀과 레나의 자율 행동으로 결과가 남는다.",
    "participants": "PLAYER_YJH, NPC_LENA, NPC_LILIA",
    "effects": "A205호 파손이 공식 시설 사고로 접수되고, 파편·사진·목격 여부에 따라 이후 조사의 근거가 달라진다.",
    "onSuccess": "플레이어가 최소 하나의 관측 가능한 단서 또는 관계상의 이득을 확보한다.",
    "onFailure": "시설팀이 현장을 정리하고 핵심 흔적을 먼저 가져가지만, CCTV 공백과 과잉 대응이라는 새 단서가 남는다.",
    "followUp": "EVT_CAFETERIA_CROSSCHECK 또는 EVT_FIRST_PRACTICAL",
    "description": "입학식 직후, 윤지훈에게 배정된 A205호의 문이 복도 쪽으로 쓰러져 있다. 파손 방향과 잔류 습기는 일반 충격으로 설명되지 않으며 시설팀이 예상보다 빨리 접근한다.",
    "playerCanIntervene": true,
    "required": true,
    "sequence": 1,
    "completionSignals": "문 파손이 시설 사고로 접수됨|플레이어 또는 NPC가 파편·사진·공명감 중 하나를 기억하거나 확보함|세 사람이 현장을 떠나거나 시설팀이 통제함",
    "requiredItems": "",
    "requiredDialogue": "",
    "requiredSpeakerId": "",
    "recoveryAlternatives": "현장을 즉시 떠나면 레나가 파편 하나를 회수하고 릴리아가 파손 사진을 남긴다. 신고하지 않으면 CCTV의 비정상적인 공백 때문에 시설팀이 스스로 찾아온다. 조사에 협조하면 공식 사고 접수번호와 담당자 이름이 단서가 된다.",
    "preservePlayerChoice": true,
    "endSceneAfterCompletion": false,
    "appliesTo": [],
    "rules": [],
    "beats": [
      {
        "id": "BEAT_A205_01",
        "viewpoint": "윤지훈가 관측 가능한 복도",
        "content": "입학식 방송이 끝난 직후 A동 2층. A205호 문은 방 안이 아니라 복도 쪽으로 넘어져 있고, 문짝 아래에는 마르지 않은 물방울과 안쪽으로 휘어진 금속 잠금쇠가 함께 보인다. 윤지훈의 행동·감정은 확정하지 않는다."
      },
      {
        "id": "BEAT_A205_02",
        "viewpoint": "레나의 외부 행동",
        "content": "레나는 문 가까이 쪼그려 앉아 장갑 낀 손으로 은회색 파편을 살핀다. 윤지훈가 묻거나 접근하면 사실을 전부 말하지 않되 ‘이건 문 재질이 아니야’라는 관측 가능한 정보까지만 답할 수 있다."
      },
      {
        "id": "BEAT_A205_03",
        "viewpoint": "복도 진입부",
        "content": "릴리아가 두 사람을 발견해 다가오고, 동시에 계단 아래에서 시설팀의 무전과 빠른 발소리가 들린다. 릴리아는 점심 제안을 꺼내려다 현장을 보고 태도를 바꾼다. 플레이어에게 증거·신고·질문·이탈 중 실제 선택 여지를 준다."
      },
      {
        "id": "BEAT_A205_04",
        "viewpoint": "장면 결과",
        "content": "플레이어 선택과 NPC 자율 행동에 따라 누가 무엇을 보존했는지 확정한다. 시설팀은 현장을 통제하지만 모든 흔적을 완벽히 지우지는 못한다. 다음 장면으로 갈 이유와 공개 가능한 단서 하나를 남긴다."
      }
    ],
    "alternateBeats": [
      {
        "id": "ALT_A205_LEAVE",
        "priority": 80,
        "when": {
          "kind": "actor_in_zone_at_trigger",
          "actorId": "PLAYER_YJH",
          "zoneId": "ZONE_CAFETERIA"
        },
        "narrativeGoal": "현장을 떠난 선택을 존중하면서 NPC가 남긴 결과를 나중에 관측 가능한 흔적으로 전달한다.",
        "requiredSignals": [
          "레나가 파편 하나를 회수함",
          "릴리아가 파손 사진을 남김"
        ],
        "preservePlayerChoice": true
      }
    ],
    "sceneMarkers": [
      {
        "id": "MARK_A205_ENTRY",
        "label": "부서진 문 최초 관측",
        "phase": "entry"
      },
      {
        "id": "MARK_A205_TEAM",
        "label": "시설팀 접근",
        "phase": "progress"
      },
      {
        "id": "MARK_A205_SECURED",
        "label": "현장 통제 및 단서 귀속",
        "phase": "complete",
        "when": {
          "kind": "event_completed",
          "eventId": "EVT_A205_FIRST_CONTACT"
        }
      }
    ],
    "multiroute": {
      "scope": "common",
      "chapterId": "CH_GISEONG_PROLOGUE",
      "routeEntryFor": "ROUTE_GISEONG_COMMON",
      "completionScope": "scene_once",
      "resetBehavior": "preserve_completion",
      "endingFlagsAdd": [
        "FLAG_A205_WITNESSED"
      ],
      "alternativeFulfillment": [
        {
          "id": "FULFILL_A205_OFFSCREEN",
          "description": "플레이어가 현장을 떠나도 두 NPC의 독립 행동과 시설팀 통제로 사건을 완료한다.",
          "completionSignals": [
            "시설팀 현장 통제",
            "NPC가 단서 하나 보존"
          ],
          "resultingEffects": [
            "FLAG_A205_WITNESSED=true"
          ]
        }
      ]
    },
    "scope": "common",
    "chapterId": "CH_GISEONG_PROLOGUE",
    "routeEntryFor": "ROUTE_GISEONG_COMMON",
    "completionScope": "scene_once",
    "resetBehavior": "preserve_completion",
    "endingFlagsAdd": [
      "FLAG_A205_WITNESSED"
    ],
    "alternativeFulfillment": [
      {
        "id": "FULFILL_A205_OFFSCREEN",
        "description": "플레이어가 현장을 떠나도 두 NPC의 독립 행동과 시설팀 통제로 사건을 완료한다.",
        "completionSignals": [
          "시설팀 현장 통제",
          "NPC가 단서 하나 보존"
        ],
        "resultingEffects": [
          "FLAG_A205_WITNESSED=true"
        ]
      }
    ]
  },
  {
    "id": "EVT_CAFETERIA_CROSSCHECK",
    "name": "세 사람의 첫 식탁",
    "kind": "compound",
    "type": "Conditional",
    "visibility": "Public",
    "status": "Planned",
    "priority": 76,
    "timeWindow": "입학 첫날 점심 또는 저녁",
    "conditions": "윤지훈가 레나 또는 릴리아와 식당·매점·휴게실 등 대화 가능한 장소에 함께 머문다.",
    "cancelConditions": "세 사람이 완전히 흩어지고 당일 점호가 끝난다.",
    "participants": "PLAYER_YJH, NPC_LENA, NPC_LILIA",
    "effects": "첫 관계 기억을 실제 대화 결과에 맞춰 생성하고, A205호에 대한 서로 다른 관측을 대조할 기회를 만든다.",
    "onSuccess": "최소 한 NPC와 공개 가능한 신뢰 이유가 생기고 다음날 실기반 정보가 공유된다.",
    "onFailure": "대화는 짧게 끝나지만 릴리아가 다음날 실기 장소를 메시지로 알려 준다.",
    "followUp": "EVT_FIRST_PRACTICAL",
    "description": "식당의 일상적인 소음 속에서 세 신입생이 처음으로 같은 테이블에 앉거나 각자의 방식으로 접촉한다. 설명보다 말의 선택과 반응으로 성격을 보여 준다.",
    "playerCanIntervene": true,
    "required": false,
    "sequence": 2,
    "completionSignals": "실기 수업 시간·장소가 공유됨|한 명 이상의 관계 기억 생성|당일 식사 장면 종료",
    "requiredItems": "",
    "requiredDialogue": "",
    "requiredSpeakerId": "",
    "recoveryAlternatives": "점심 제안을 거절하면 저녁 식당·기숙사 단체 채팅·다음날 실기실 앞에서 짧은 교차 확인이 이루어진다.",
    "preservePlayerChoice": true,
    "endSceneAfterCompletion": false,
    "appliesTo": [],
    "rules": [],
    "beats": [
      {
        "id": "BEAT_MEAL_01",
        "viewpoint": "공개 대화",
        "content": "릴리아는 분위기를 억지로 밝게 만들지 않고 먼저 이름과 실기반 배정을 묻는다. 레나는 질문받지 않은 비밀을 자발적으로 털어놓지 않는다."
      },
      {
        "id": "BEAT_MEAL_02",
        "viewpoint": "선택 반응",
        "content": "플레이어가 A205호를 꺼내면 각 NPC는 자신이 실제로 본 범위만 말한다. 다른 화제를 고르면 그 선택을 존중하고 학교 생활·능력반·가문 이야기가 관계 형성의 원인이 된다."
      },
      {
        "id": "BEAT_MEAL_03",
        "viewpoint": "다음 장면 연결",
        "content": "세 사람 모두 다음날 제3실기동 기초 측정에 같은 조로 편성되었다는 알림이 도착한다. 이를 운명처럼 단정하지 않고 행정 배정으로 제시한다."
      }
    ],
    "alternateBeats": [],
    "sceneMarkers": [
      {
        "id": "MARK_MEAL_ENTRY",
        "label": "첫 동석 또는 연락",
        "phase": "entry"
      },
      {
        "id": "MARK_MEAL_PRACTICAL_NOTICE",
        "label": "같은 실기조 알림",
        "phase": "complete"
      }
    ],
    "multiroute": {
      "scope": "common",
      "chapterId": "CH_GISEONG_PROLOGUE",
      "completionScope": "scene_once",
      "resetBehavior": "preserve_completion"
    },
    "scope": "common",
    "chapterId": "CH_GISEONG_PROLOGUE",
    "completionScope": "scene_once",
    "resetBehavior": "preserve_completion"
  },
  {
    "id": "EVT_FIRST_PRACTICAL",
    "name": "제3실기동 기초 측정",
    "kind": "compound",
    "type": "Fixed",
    "visibility": "Public",
    "status": "Planned",
    "priority": 88,
    "timeWindow": "입학 둘째 날 10:00~11:30",
    "conditions": "시간이 입학 둘째 날 오전에 도달한다.",
    "cancelConditions": "없음. 결석하면 보충 측정과 교관의 확인 절차로 대체된다.",
    "participants": "PLAYER_YJH, NPC_LENA, NPC_LILIA",
    "effects": "세 사람의 능력 한계가 행동으로 드러나고, 지하 장치가 약한 예비 반응을 시작한다.",
    "onSuccess": "각자의 능력 한계가 공개 범위에서 확인되고 공명 전조를 인지한다.",
    "onFailure": "측정은 중단되며 과부하 또는 장비 오류 기록이 남고 연구부 관심 시계가 전진한다.",
    "followUp": "EVT_FIRST_RESONANCE",
    "description": "같은 조가 된 세 신입생이 차단장 안에서 순차적으로 능력을 측정한다. 플레이어는 자신의 방식과 강도를 직접 정하며, 성공·실패 모두 다음 미스터리의 자료가 된다.",
    "playerCanIntervene": true,
    "required": true,
    "sequence": 2,
    "completionSignals": "세 사람의 측정이 완료 또는 공식 중단됨|윤지훈의 원소 전환 특성이 기록됨|바닥 아래의 짧은 공명음이 한 번 발생함",
    "requiredItems": "",
    "requiredDialogue": "",
    "requiredSpeakerId": "",
    "recoveryAlternatives": "윤지훈가 능력 사용을 거부하면 장비의 수동 진단 중 빈 파장이 감지된다. 결석하면 레나와 릴리아의 측정 기록이 먼저 반응하고 보충 측정이 예약된다.",
    "preservePlayerChoice": true,
    "endSceneAfterCompletion": false,
    "appliesTo": [],
    "rules": [],
    "beats": [
      {
        "id": "BEAT_TEST_01",
        "viewpoint": "실기장",
        "content": "안전 규칙과 목표를 짧게 제시한다. 세계관 설명을 길게 늘이지 말고 차단장·측정 고리·관찰창을 감각적으로 보여 준다."
      },
      {
        "id": "BEAT_TEST_02",
        "viewpoint": "NPC 측정",
        "content": "레나의 압력 편향과 릴리아의 기갑 강화를 각각 한 가지 분명한 한계와 함께 보여 준다. 두 사람의 결과가 윤지훈의 선택을 강제하지 않는다."
      },
      {
        "id": "BEAT_TEST_03",
        "viewpoint": "플레이어 차례",
        "content": "사용자가 지정한 원소·강도·방법만 실행한다. 입력이 모호하면 실행 가능한 범위를 제시하고 선택을 남긴다. 원소 전환을 시도할 경우 짧은 빈 파장이 기록된다."
      },
      {
        "id": "BEAT_TEST_04",
        "viewpoint": "결과",
        "content": "측정 완료 또는 중단 결과를 확정하고 바닥 아래에서 한 번 울린 낮은 금속음을 남긴다. 원인을 해설하지 않는다."
      }
    ],
    "alternateBeats": [
      {
        "id": "ALT_TEST_REFUSE",
        "priority": 90,
        "narrativeGoal": "능력 사용 거부를 실패로 무효화하지 않고 수동 진단과 행정 반응으로 전개한다.",
        "requiredSignals": [
          "거부 선택 존중",
          "보충 측정 또는 수동 진단",
          "빈 파장 전조"
        ],
        "preservePlayerChoice": true
      }
    ],
    "sceneMarkers": [
      {
        "id": "MARK_TEST_ENTRY",
        "label": "기초 측정 시작",
        "phase": "entry"
      },
      {
        "id": "MARK_TEST_PLAYER",
        "label": "윤지훈 측정 또는 거부",
        "phase": "progress"
      },
      {
        "id": "MARK_TEST_TONE",
        "label": "바닥 아래 금속음",
        "phase": "complete"
      }
    ],
    "multiroute": {
      "scope": "common",
      "chapterId": "CH_GISEONG_PROLOGUE",
      "completionScope": "scene_once",
      "resetBehavior": "preserve_completion"
    },
    "scope": "common",
    "chapterId": "CH_GISEONG_PROLOGUE",
    "completionScope": "scene_once",
    "resetBehavior": "preserve_completion"
  },
  {
    "id": "EVT_RESONANCE_AFTERSHOCK",
    "name": "공명 뒤에 남은 것",
    "kind": "compound",
    "type": "Fixed",
    "visibility": "Public",
    "status": "Planned",
    "priority": 86,
    "timeWindow": "첫 공명 직후부터 다음날 점호 전",
    "conditions": "EVT_FIRST_RESONANCE 완료",
    "cancelConditions": "없음. 조사를 거부하면 행정 처리와 NPC의 독립 조사로 대체된다.",
    "participants": "PLAYER_YJH, NPC_LENA, NPC_LILIA, FAC_ACADEMY",
    "effects": "공식 사고 기록과 개인 기억이 갈라지고, 누가 어떤 단서를 보유하는지 확정된다. 데모 구간의 첫 목표가 완결되며 장기 미스터리의 다음 질문이 열린다.",
    "onSuccess": "세 사람 중 최소 두 명이 다음 조사에 협력할 이유를 갖고, 플레이어가 공개 단서 두 개 중 하나를 보유한다.",
    "onFailure": "학원 측이 기록을 선점하고 관계에 균열이 생기지만, 삭제된 기록 번호나 거짓 설명이 새 단서가 된다.",
    "followUp": "기성학원 장기 캠페인: 지하 공명 실험 조사",
    "description": "양호실·교무실·기숙사 중 플레이어 선택에 따라 여파를 처리한다. 레나는 흔적을 통제하려 하고, 릴리아는 누군가 책임을 떠넘기는 것을 막으려 하며, 학원은 사건을 장비 오작동으로 정리하려 한다.",
    "playerCanIntervene": true,
    "required": true,
    "sequence": 4,
    "completionSignals": "각 인물의 부상·소지 단서·공개 진술 확정|관계 기억 최소 1개 생성|공식 기록과 실제 관측의 차이 확인|다음 조사 목표 제시",
    "requiredItems": "",
    "requiredDialogue": "",
    "requiredSpeakerId": "",
    "recoveryAlternatives": "조사를 거부하면 학생증 출입 기록과 양호실 호출이 남는다. 혼자 움직이면 레나와 릴리아가 각자 다른 단서를 확보한다. 학원 설명을 받아들이면 이후 모순된 기록이 자연스럽게 반례가 된다.",
    "preservePlayerChoice": true,
    "endSceneAfterCompletion": true,
    "appliesTo": [],
    "rules": [],
    "beats": [
      {
        "id": "BEAT_AFTER_01",
        "viewpoint": "즉시 여파",
        "content": "부상과 과부하를 실제 결과만큼만 반영한다. 모든 인물을 멀쩡하게 만들거나 과장된 중상을 임의로 만들지 않는다."
      },
      {
        "id": "BEAT_AFTER_02",
        "viewpoint": "서로 다른 목적",
        "content": "레나·릴리아·학원 측이 각자 원하는 것을 행동으로 보인다. 플레이어는 누구와 동행하고 무엇을 말할지 직접 정한다."
      },
      {
        "id": "BEAT_AFTER_03",
        "viewpoint": "기록의 불일치",
        "content": "공식 설명 ‘측정 장비의 일시적 오류’와 플레이어가 본 제4의 반향 사이의 차이를 분명히 남긴다. 배후 정답은 공개하지 않는다."
      },
      {
        "id": "BEAT_AFTER_04",
        "viewpoint": "데모 완결",
        "content": "첫 공명 사건의 결과 장부를 확정하고 ‘205호 문과 실기동의 반향은 같은 것인가’라는 다음 목표를 연다. 플레이를 종료시키지 않고 계속 진행할 수 있다."
      }
    ],
    "alternateBeats": [],
    "sceneMarkers": [
      {
        "id": "MARK_AFTER_ENTRY",
        "label": "공명 종료 직후",
        "phase": "entry"
      },
      {
        "id": "MARK_AFTER_RECORD",
        "label": "공식 기록 확인",
        "phase": "progress"
      },
      {
        "id": "MARK_AFTER_COMPLETE",
        "label": "데모 1막 완료",
        "phase": "complete"
      }
    ],
    "multiroute": {
      "scope": "common",
      "chapterId": "CH_GISEONG_RESONANCE",
      "completionScope": "scene_once",
      "resetBehavior": "preserve_completion",
      "revealPolicyId": "REVEAL_GISEONG_CORE",
      "endingFlagsAdd": [
        "FLAG_DEMO_ARC_COMPLETE"
      ]
    },
    "scope": "common",
    "chapterId": "CH_GISEONG_RESONANCE",
    "completionScope": "scene_once",
    "resetBehavior": "preserve_completion",
    "revealPolicyId": "REVEAL_GISEONG_CORE",
    "endingFlagsAdd": [
      "FLAG_DEMO_ARC_COMPLETE"
    ]
  }
]
~~~

## PUBLIC_EVENT_CLOCKS

~~~json
[
  {
    "id": "CLOCK_RESONANCE_STABILITY",
    "name": "세 파장의 안정도",
    "visibility": "Public",
    "status": "Active",
    "current": 0,
    "maximum": 4,
    "relatedEventId": "EVT_FIRST_RESONANCE",
    "publicHint": "서로의 호흡과 기 파형을 읽는 감각이 선명해진다."
  }
]
~~~

## PUBLIC_FORESHADOWINGS

~~~json
[]
~~~

## IMAGE_TRIGGER_RUNTIME

~~~json
{
  "format": "RELAY_NOVEL_IMAGE_TRIGGER_RUNTIME_V1",
  "evaluationTiming": "after_state_update_before_turn_output",
  "stateLedger": {
    "firedTriggerIds": [],
    "instruction": "once=true인 트리거의 ID를 기록하고 다시 실행하지 않는다."
  },
  "ordering": "같은 턴에 여러 조건이 충족되면 priority 내림차순으로 평가한다.",
  "triggerSemantics": {
    "event_start": "연결 사건의 상태가 Active로 처음 바뀌는 턴",
    "event_condition_met": "연결 사건의 conditions가 실제 서사 상태에서 충족되는 턴",
    "event_success": "연결 사건이 성공 결과로 확정되는 턴",
    "event_failure": "연결 사건이 실패 결과로 확정되는 턴",
    "clock_value": "연결 사건 시계가 threshold 이상에 처음 도달하는 턴",
    "clock_completed": "연결 사건 시계가 maximum에 도달하는 턴",
    "foreshadow_revealed": "연결 복선 상태가 Revealed로 바뀌는 턴",
    "story_progress": "storyProgress에 적힌 장·막·날짜·서사 단계에 도달하는 턴",
    "custom_condition": "customCondition을 현재 공개/비공개 상태 장부에 대조해 충족하는 턴"
  },
  "modeSemantics": {
    "show_trigger_image": "트리거에 직접 첨부된 대표 이미지를 원본 그대로 출력한다. 새 이미지를 생성하거나 외형을 변형하지 않는다.",
    "show_package_image": "선택 인물의 패키지 기준 이미지를 그대로 출력한다. 새 이미지를 생성하지 않는다.",
    "generate_character_variant": "선택 인물의 기준 이미지를 참조해 포즈·표정·의상·배경만 바꾼 변형 컷을 생성한다.",
    "generate_scene": "선택 인물과 현재 장면의 정사를 반영한 장면 이미지를 생성한다."
  },
  "hardRules": [
    "트리거 조건을 임의로 앞당기거나 서사를 조건에 맞게 조작하지 않는다.",
    "show_trigger_image이면 attachedImages에서 isPrimary=true인 assetPath를 우선 출력하고, 없으면 첫 번째 첨부 이미지를 사용한다.",
    "useCharacterReferences=true이면 패키지 기준 이미지를 최우선 참조한다.",
    "preserveFaces=true이면 얼굴형·눈·머리·체형·고유 액세서리와 visualAnchor를 유지한다.",
    "spoilerProtection=true이면 이미지와 프롬프트에 아직 공개되지 않은 인물·정체·장소·결과를 넣지 않는다.",
    "이미지 생성 기능이 없으면 생성했다고 주장하지 말고 완성된 [IMAGE TRIGGER PROMPT]를 출력한다."
  ]
}
~~~

## PUBLIC_IMAGE_TRIGGERS

~~~json
[]
~~~

## STATUS_WINDOW_RUNTIME

~~~json
{
  "format": "RELAY_NOVEL_STATUS_WINDOW_RUNTIME_V2",
  "enabled": true,
  "title": "GISEONG · LIVE STATUS",
  "displayMode": "full",
  "defaultExpanded": true,
  "showTurnDelta": true,
  "sections": [
    {
      "id": "ability",
      "label": "ABILITY",
      "icon": "zap",
      "order": 10,
      "enabled": true
    },
    {
      "id": "core_stats",
      "label": "CORE STATS",
      "icon": "gauge",
      "order": 20,
      "enabled": true
    },
    {
      "id": "resources",
      "label": "RESOURCES",
      "icon": "resource",
      "order": 30,
      "enabled": true
    },
    {
      "id": "condition",
      "label": "CONDITION",
      "icon": "heart",
      "order": 40,
      "enabled": true
    },
    {
      "id": "funds",
      "label": "FUNDS",
      "icon": "wallet",
      "order": 50,
      "enabled": true
    }
  ],
  "fields": [
    {
      "id": "ability_summary",
      "label": "Ability",
      "sectionId": "ability",
      "sectionLabel": "ABILITY",
      "kind": "text",
      "visibility": "public",
      "icon": "zap",
      "order": 10,
      "showDelta": false,
      "summary": true,
      "initialValue": "원소조작 — 주변의 물·불·바람·땅 중 하나를 다룬다. 전환에는 짧은 집중이 필요하다.",
      "updateRule": "플레이어가 현재 이해하고 공개할 수 있는 능력만 한두 줄의 쉬운 문장으로 갱신"
    },
    {
      "id": "STAT_HP",
      "label": "체력",
      "sectionId": "core_stats",
      "sectionLabel": "CORE STATS",
      "kind": "number",
      "visibility": "public",
      "icon": "❤",
      "order": 10,
      "minimum": 0,
      "maximum": 100,
      "maxDelta": 100,
      "showDelta": true,
      "summary": true,
      "initialValue": 92,
      "grade": "B",
      "updateRule": "이번 턴에 관측 가능한 서사적 원인이 있을 때만 변경"
    },
    {
      "id": "STAT_FOCUS",
      "label": "집중력",
      "sectionId": "core_stats",
      "sectionLabel": "CORE STATS",
      "kind": "number",
      "visibility": "public",
      "icon": "◈",
      "order": 20,
      "minimum": 0,
      "maximum": 100,
      "maxDelta": 100,
      "showDelta": true,
      "summary": true,
      "initialValue": 74,
      "grade": "C+",
      "updateRule": "이번 턴에 관측 가능한 서사적 원인이 있을 때만 변경"
    },
    {
      "id": "STAT_RESONANCE",
      "label": "기 공명",
      "sectionId": "core_stats",
      "sectionLabel": "CORE STATS",
      "kind": "number",
      "visibility": "public",
      "icon": "✦",
      "order": 30,
      "minimum": 0,
      "maximum": 100,
      "maxDelta": 100,
      "showDelta": true,
      "summary": true,
      "initialValue": 12,
      "grade": "F",
      "updateRule": "이번 턴에 관측 가능한 서사적 원인이 있을 때만 변경"
    },
    {
      "id": "ki_reserve",
      "label": "기력",
      "sectionId": "resources",
      "sectionLabel": "RESOURCES",
      "kind": "number",
      "visibility": "public",
      "revealed": true,
      "icon": "spark",
      "order": 10,
      "minimum": 0,
      "maxDelta": 100,
      "showDelta": true,
      "summary": true,
      "initialValue": 100,
      "unit": "점",
      "updateRule": "능력 사용과 회복이 장면에서 확인될 때만 증감"
    },
    {
      "id": "resonance_crystals",
      "label": "공명 결정",
      "sectionId": "resources",
      "sectionLabel": "RESOURCES",
      "kind": "number",
      "visibility": "conditional",
      "revealed": false,
      "icon": "gem",
      "order": 20,
      "minimum": 0,
      "maxDelta": 3,
      "showDelta": true,
      "summary": true,
      "initialValue": 0,
      "unit": "개",
      "updateRule": "공명 결정을 실제로 획득하거나 용도를 확인한 뒤 공개"
    },
    {
      "id": "training_relics",
      "label": "훈련 장비",
      "sectionId": "resources",
      "sectionLabel": "RESOURCES",
      "kind": "number",
      "visibility": "conditional",
      "revealed": false,
      "icon": "sword",
      "order": 30,
      "minimum": 0,
      "maxDelta": 3,
      "showDelta": true,
      "summary": true,
      "initialValue": 0,
      "unit": "개",
      "updateRule": "등록된 훈련 장비를 실제로 지급받은 뒤 공개"
    },
    {
      "id": "condition_summary",
      "label": "Condition",
      "sectionId": "condition",
      "sectionLabel": "CONDITION",
      "kind": "text",
      "visibility": "public",
      "icon": "heart",
      "order": 10,
      "showDelta": false,
      "summary": true,
      "initialValue": "입학식 뒤의 가벼운 피로. 확인된 부상은 없다.",
      "updateRule": "현재 관측 가능한 몸과 정신 상태만 한두 줄로 갱신하고 숨은 원인이나 미래 결과는 쓰지 않음"
    },
    {
      "id": "funds",
      "label": "자금",
      "sectionId": "funds",
      "sectionLabel": "FUNDS",
      "kind": "number",
      "visibility": "public",
      "icon": "wallet",
      "order": 10,
      "minimum": 0,
      "maxDelta": 100000000,
      "showDelta": true,
      "summary": true,
      "initialValue": 35000,
      "unit": "원",
      "updateRule": "확인된 수입과 지출이 발생한 경우에만 현재 보유 자금을 갱신"
    }
  ],
  "initialLedger": [
    {
      "fieldId": "ability_summary",
      "value": "원소조작 — 주변의 물·불·바람·땅 중 하나를 다룬다. 전환에는 짧은 집중이 필요하다.",
      "grade": "",
      "visibility": "public",
      "revealed": true
    },
    {
      "fieldId": "STAT_HP",
      "value": 92,
      "grade": "B",
      "visibility": "public",
      "revealed": true
    },
    {
      "fieldId": "STAT_FOCUS",
      "value": 74,
      "grade": "C+",
      "visibility": "public",
      "revealed": true
    },
    {
      "fieldId": "STAT_RESONANCE",
      "value": 12,
      "grade": "F",
      "visibility": "public",
      "revealed": true
    },
    {
      "fieldId": "ki_reserve",
      "value": 100,
      "grade": "",
      "visibility": "public",
      "revealed": true
    },
    {
      "fieldId": "resonance_crystals",
      "value": 0,
      "grade": "",
      "visibility": "conditional",
      "revealed": false
    },
    {
      "fieldId": "training_relics",
      "value": 0,
      "grade": "",
      "visibility": "conditional",
      "revealed": false
    },
    {
      "fieldId": "condition_summary",
      "value": "입학식 뒤의 가벼운 피로. 확인된 부상은 없다.",
      "grade": "",
      "visibility": "public",
      "revealed": true
    },
    {
      "fieldId": "funds",
      "value": 35000,
      "grade": "",
      "visibility": "public",
      "revealed": true
    }
  ],
  "disclosureRules": [
    "Ability와 Condition은 현재 확인된 정보만 한두 줄로 표시한다.",
    "기력: 능력 사용과 회복이 장면에서 확인될 때만 증감",
    "공명 결정: 공명 결정을 실제로 획득하거나 용도를 확인한 뒤 공개",
    "훈련 장비: 등록된 훈련 장비를 실제로 지급받은 뒤 공개",
    "미공개 정체·계약·비밀 세력·미래 사건을 상태창에 노출하지 않는다."
  ],
  "configuration": {
    "title": "GISEONG · LIVE STATUS",
    "displayMode": "always_full",
    "theme": "dark_rpg",
    "placement": "before_replies",
    "showDeltas": true,
    "collapseOnMobile": true,
    "highlightChanges": true,
    "sections": {
      "profile": true,
      "skills": true,
      "stats": true,
      "resources": true,
      "condition": true,
      "funds": true,
      "inventory": true,
      "relationships": true,
      "clocks": true,
      "objective": true
    }
  },
  "turnOrder": [
    "date_time_weather_location_header",
    "observable_narrative_and_dialogue",
    "autonomous_actor_selection_and_resolution",
    "hidden_world_ledger_update",
    "relationship_memory_append_and_score_recalculation",
    "character_or_scene_image_when_triggered",
    "public_state_filter",
    "status_window_render",
    "recommended_replies_with_risk"
  ],
  "renderTiming": "after_turn_state_update_before_recommended_replies",
  "initialState": {
    "profile": {
      "characterId": "PLAYER_YJH",
      "name": "윤지훈",
      "role": "신입생",
      "affiliation": "기성학원",
      "location": "기성학원 A동 기숙사 2층"
    },
    "skills": "원소조작 — 주변의 물·불·바람·땅 중 하나를 다룬다. 전환에는 짧은 집중이 필요하다.",
    "stats": [
      {
        "id": "STAT_HP",
        "icon": "❤",
        "name": "체력",
        "rank": "B",
        "current": 92,
        "max": 100,
        "color": "green"
      },
      {
        "id": "STAT_FOCUS",
        "icon": "◈",
        "name": "집중력",
        "rank": "C+",
        "current": 74,
        "max": 100,
        "color": "blue"
      },
      {
        "id": "STAT_RESONANCE",
        "icon": "✦",
        "name": "기 공명",
        "rank": "F",
        "current": 12,
        "max": 100,
        "color": "violet"
      }
    ],
    "resources": [
      {
        "id": "ki_reserve",
        "icon": "spark",
        "name": "기력",
        "current": 100,
        "unit": "점",
        "visibility": "public",
        "revealRule": "능력 사용과 회복이 장면에서 확인될 때만 증감"
      },
      {
        "id": "resonance_crystals",
        "icon": "gem",
        "name": "공명 결정",
        "current": 0,
        "unit": "개",
        "visibility": "conditional",
        "revealRule": "공명 결정을 실제로 획득하거나 용도를 확인한 뒤 공개"
      },
      {
        "id": "training_relics",
        "icon": "sword",
        "name": "훈련 장비",
        "current": 0,
        "unit": "개",
        "visibility": "conditional",
        "revealRule": "등록된 훈련 장비를 실제로 지급받은 뒤 공개"
      }
    ],
    "condition": "입학식 뒤의 가벼운 피로. 확인된 부상은 없다.",
    "funds": {
      "icon": "wallet",
      "name": "자금",
      "current": 35000,
      "unit": "원"
    }
  },
  "deltaLedger": {
    "previousTurnSnapshot": null,
    "currentTurnChanges": [],
    "instruction": "각 변화에 field, before, after, delta, observableCause를 기록하고 출력 후 현재 스냅샷을 다음 턴 기준으로 보존한다."
  },
  "updateRules": [
    "1. 매 턴 서술이 끝나면 비공개 세계 장부를 먼저 갱신하고, 플레이어가 알 수 있는 정보만 상태창에 반영한다.",
    "2. 능력치·자원·상태 변화에는 반드시 이번 턴에 실제로 서술되거나 기록된 원인이 있어야 한다.",
    "3. 매 턴 전체 상태창을 출력하고, 바뀐 값은 이전 값 대비 증감과 원인을 함께 강조한다.",
    "4. Ability와 Condition은 플레이어가 현재 이해할 수 있는 말로 한두 줄만 표시하며, 정체·계약·미래 사건을 앞서 설명하지 않는다.",
    "5. Resources는 각 항목에 적힌 공개·증감 조건이 실제 장면에서 충족된 뒤에만 표시하거나 변경한다.",
    "6. 작품별 특수 자원과 장비는 실제 보유·사용이 확인된 경우에만 바꾸며, 자금은 확인된 지출·수입에 따라 갱신한다.",
    "7. 미등장 인물, 진명, 비밀 진영, 숨은 관계와 비공개 사건 시계는 공개 조건이 충족되기 전까지 숨긴다.",
    "8. 플레이어의 행동·대사·감정을 임의로 확정하지 않으며, 없던 아이템·자원·능력을 소급해 만들지 않는다.",
    "9. 기 공명은 실제 동시 파형, 공명 설비 접촉, 합의된 공명 훈련이 발생했을 때만 바꾼다. 숨은 원인이나 연구부 관심 수치를 상태창에 선공개하지 않는다.",
    "10. 관계에는 직접 만난 인물과 공개 가능한 최신 기억 이유만 표시한다."
  ],
  "hardRules": [
    "displayMode=always_full이면 변화가 없어도 매 턴 전체 상태창을 출력한다.",
    "상태 변화는 이번 턴의 실제 사건 또는 장부에 기록된 원인으로만 발생한다.",
    "Ability와 Condition은 한두 줄을 넘기지 않고 현재 확인된 내용만 쉽게 설명한다.",
    "기력: 능력 사용과 회복이 장면에서 확인될 때만 증감",
    "공명 결정: 공명 결정을 실제로 획득하거나 용도를 확인한 뒤 공개",
    "훈련 장비: 등록된 훈련 장비를 실제로 지급받은 뒤 공개",
    "자금은 플레이어가 실제로 확인한 수입·지출만 반영하고 작품에 설정된 화폐 단위를 유지한다.",
    "미등장 인물·진명·비밀 진영·숨은 관계·비공개 사건 시계는 공개 조건 전까지 렌더링하지 않는다.",
    "플레이어의 행동·대사·감정을 임의로 확정하지 않는다.",
    "없던 아이템·자원·능력·준비를 소급해 만들지 않는다.",
    "표시 값과 내부 장부가 충돌하면 내부 장부를 검증한 뒤 공개 필터를 다시 적용하고, 숨은 정보 자체는 설명하지 않는다."
  ]
}
~~~

## STYLE_PROFILE

~~~json
{
  "narrationPerson": "윤지훈가 관측 가능한 범위의 3인칭 제한 시점",
  "proseStyle": "대중 장르소설 문체. 짧고 선명한 문장과 감각적 동작을 중심으로 하며, 설명은 장면 속 사물·대사·반응에 녹인다.",
  "dialogueStyle": "인물마다 길이와 속도를 구분한다. 레나는 짧고 건조하게, 릴리아는 밝지만 위기에서는 단정하게 말한다. 정보 전달만을 위한 부자연스러운 장광설을 피한다.",
  "descriptionDensity": "보통~높음. 첫 장면과 공명은 밀도 있게, 이동·행정 처리는 압축적으로.",
  "violenceLevel": "중간. 능력 과부하와 시설 손상을 현실적으로 묘사하되 고어를 사용하지 않는다.",
  "romanceLevel": "선택적. 관계의 이유와 플레이어 선택이 쌓인 뒤에만 발생한다.",
  "statusDisclosure": "매 턴 공개 가능한 변화와 그 원인만 간결히 표시한다.",
  "customRules": "플레이어 입력을 장면의 첫 인과로 처리한다. 한 턴에 관측 가능한 변화, NPC 반응, 다음 선택 지점을 만든다. 정답 설명보다 행동과 흔적을 우선한다. 플레이어의 행동·대사·감정을 예측해 대신 쓰지 않는다."
}
~~~

## TURN_PRESENTATION

~~~json
{
  "recommendedReplies": {
    "enabled": true,
    "count": 3,
    "style": "서로 다른 목적의 짧은 행동 예시",
    "showRisk": true,
    "revealHiddenInformation": false
  },
  "sceneImage": {
    "enabled": true,
    "frequency": "사건 시작·결정적 공명·중요 결과에만",
    "position": "장면 전 또는 후 트리거 규칙",
    "count": 1,
    "aspectRatio": "landscape",
    "textInImage": false,
    "spoilerProtection": true,
    "fallback": "이미지 생성 실패 시 본문을 지연하지 않고 계속",
    "styleHint": "현대 한국 학원 애니메이션, 인물 외형 고정, 깨끗한 시네마틱 조명"
  }
}
~~~

## OPENING_SCENE

~~~json
{
  "preHistory": "윤지훈는 기 수치 7,180과 드문 원소조작 적성으로 기성학원에 입학했다. 입학 전까지 정식 능력 전투 경험은 없고, 물·불·바람·땅 가운데 주변에 존재하는 한 원소만 제한적으로 다룰 수 있다. 오늘 오전 입학식에서 신입생 수석 레나와 기사 가문 출신 릴리아의 이름을 들었지만 대화를 나눈 적은 없다.",
  "currentSituation": "2026년 3월 2일 12시 18분, 비가 막 그친 기성학원 A동 기숙사 2층. 윤지훈에게 배정된 205호 문이 방 안이 아니라 복도 쪽으로 쓰러져 있다. 문짝 아래에는 아직 마르지 않은 물방울과 문 재질이 아닌 은회색 파편이 끼어 있고, 레나는 그 앞에서 장갑 낀 손을 멈춘 채 윤지훈 쪽을 본다. 복도 끝에서는 릴리아가 입학 안내 봉투를 들고 다가오며, 계단 아래에서는 시설팀 무전과 두 사람 이상의 발소리가 빠르게 가까워진다.",
  "immediateProblem": "시설팀이 도착하기 전에 부서진 문과 은회색 파편을 어떻게 다룰지 정해야 한다. 레나는 무엇인가 알고도 전부 말하지 않고, 릴리아는 아직 상황을 모른다. 플레이어는 관찰·질문·신고·증거 확보·이탈 등 무엇이든 시도할 수 있다.",
  "knownRisks": "허가 없는 능력 사용은 교칙 위반이 될 수 있다. 파편을 함부로 만지면 손상되거나 소지 사실이 기록될 수 있다. 시설팀의 통제를 방해하면 입학 첫날부터 공식 기록이 남는다.",
  "openingCharacters": "PLAYER_YJH, NPC_LENA, NPC_LILIA",
  "openingLocation": "기성학원 A동 기숙사 2층 · A205호 앞",
  "openingEvent": "부서진 문과 정체불명의 파편을 사이에 두고 세 신입생이 처음 마주친다. 시설팀의 도착이 선택의 시간 제한으로 작동한다.",
  "firstGoal": "A205호 현장에서 관측 가능한 단서 또는 신뢰할 만한 관계상의 정보를 하나 확보하고, 입학 둘째 날 제3실기동 측정까지 안전하게 이어 간다.",
  "openingLine": "입학식이 끝난 지 열여덟 분. 윤지훈에게 배정된 205호의 문은, 안으로 부서진 것이 아니라 복도 쪽으로 쓰러져 있었다."
}
~~~

## HIDDEN_GM_DATA

> 아래 블록은 감독자 전용이다. 플레이어에게 직접 공개하거나 요약하지 않는다.

~~~json
{
  "npcSecrets": [
    {
      "id": "NPC_LENA",
      "name": "레나",
      "hiddenInfo": "자신의 능력 폭주와 관련된 사고를 감추고 있다."
    }
  ],
  "factionSecrets": [
    {
      "id": "FAC_ACADEMY",
      "name": "기성학원",
      "hiddenGoal": "학원 지하의 공명 실험을 은폐한다.",
      "currentPlan": "신입생의 공명 반응을 비밀리에 관찰한다."
    }
  ],
  "hiddenCharacterRelations": [
    {
      "id": "REL_LENA_TO_PLAYER",
      "sourceId": "NPC_LENA",
      "targetId": "PLAYER_YJH",
      "hiddenNotes": "레나는 윤지훈의 원소 파장이 과거 사고와 닮았다고 느낀다."
    }
  ],
  "autonomyActors": [
    {
      "id": "AUTO_LENA",
      "entityType": "character",
      "entityId": "NPC_LENA",
      "enabled": true,
      "activityTier": "nearby",
      "currentLocation": "A동 기숙사 2층",
      "locationVisibility": "Hidden",
      "shortTermGoal": "부서진 205호 문에서 자신의 기 흔적을 지운다.",
      "mediumTermGoal": "공명 사고와 윤지훈의 연관성을 확인한다.",
      "longTermGoal": "과거 능력 폭주의 진실을 찾아 통제법을 얻는다.",
      "goalPriority": 88,
      "currentPlan": "사람이 없는 시간에 문 파편을 회수하고 연구동 기록에 접근한다.",
      "nextAction": "야간 점호 전에 남은 파편의 위치를 확인한다.",
      "actionCadence": "every_2_turns",
      "knowledge": "자신의 과거 사고, 문에서 느껴진 낯익은 공명, 학원 기본 동선",
      "misinformation": "연구부가 자신을 보호하려 한다고 믿는다.",
      "resources": "높은 기 수치, 신입생 수석 권한, 제한적인 연구동 출입",
      "constraints": "감정이 흔들리면 능력이 폭주할 수 있다. 공개적으로 움직이면 연구부의 관심이 증가한다.",
      "riskTolerance": "moderate",
      "cooperationRules": "증거를 강요하지 않고 비밀을 지켜주는 사람과 제한적으로 협력한다.",
      "conflictRules": "과거 사고를 들추거나 통제권을 빼앗으려는 상대를 회피한 뒤 증거부터 제거한다.",
      "travelRules": "세계관의 교통·통신 제약을 따른다.",
      "successOutcome": "파편을 확보하고 연구부보다 먼저 공명 흔적을 분석한다.",
      "partialOutcome": "파편 일부만 확보하지만 누군가 자신을 감시한다는 단서를 얻는다.",
      "failureOutcome": "감시 카메라에 동선이 남고 비밀 연구부의 관심 시계가 전진한다.",
      "offscreenEnabled": true,
      "canFailOffscreen": true,
      "revealTraces": true
    },
    {
      "id": "AUTO_LILIA",
      "entityType": "character",
      "entityId": "NPC_LILIA",
      "enabled": true,
      "activityTier": "nearby",
      "currentLocation": "A동 기숙사 복도",
      "locationVisibility": "Public",
      "shortTermGoal": "윤지훈와 레나를 식당으로 데려가 친구가 된다.",
      "mediumTermGoal": "가문에 의존하지 않고 자신의 실력으로 기사반에 들어간다.",
      "longTermGoal": "가문의 명예보다 옳은 선택을 하는 기사가 된다.",
      "goalPriority": 72,
      "currentPlan": "신입생 정보를 모으고 훈련 파트너를 찾는다.",
      "nextAction": "두 사람에게 점심을 제안하고 반응을 살핀다.",
      "actionCadence": "every_turn",
      "knowledge": "기사 가문 인맥, 공개된 입학생 정보, 학원 규칙",
      "misinformation": "",
      "resources": "가문 명성, 체력, 사교성",
      "constraints": "거짓말에 서툴고 의심스러운 일을 그냥 지나치지 못한다.",
      "riskTolerance": "high",
      "cooperationRules": "곤란한 사람을 먼저 돕고 빚으로 계산하지 않는다.",
      "conflictRules": "약자를 괴롭히는 행동을 보면 관계 손해를 감수하고 개입한다.",
      "travelRules": "세계관의 교통·통신 제약을 따른다.",
      "successOutcome": "세 사람이 자연스럽게 동행하며 첫 신뢰의 계기가 생긴다.",
      "partialOutcome": "한 명과만 동행하지만 다른 한 명의 사정을 기억한다.",
      "failureOutcome": "제안이 거절되어도 원망하지 않고 다음 기회를 찾는다.",
      "offscreenEnabled": true,
      "canFailOffscreen": true,
      "revealTraces": true
    },
    {
      "id": "AUTO_ACADEMY",
      "entityType": "faction",
      "entityId": "FAC_ACADEMY",
      "enabled": true,
      "activityTier": "regional",
      "currentLocation": "기성학원 전 구역",
      "locationVisibility": "Hidden",
      "shortTermGoal": "205호 파손 사건의 공명 잔류물을 회수한다.",
      "mediumTermGoal": "세 신입생의 동시 공명 가능성을 검증한다.",
      "longTermGoal": "지하 공명 실험과 과거 사고를 외부에 노출하지 않는다.",
      "goalPriority": 94,
      "currentPlan": "시설 점검으로 위장해 파편과 감시 기록을 수거한다.",
      "nextAction": "연구부 소속 교관 한 명을 A동에 배치한다.",
      "actionCadence": "every_3_to_5_turns",
      "knowledge": "학원 감시망, 연구 자료, 학생 기록과 지하 장치의 존재",
      "misinformation": "동시 공명은 통제 가능한 실험 변수라고 과신한다.",
      "resources": "교관, 감시망, 연구동, 행정 권한",
      "constraints": "교육파의 반대와 외부 감사 때문에 노골적인 강제 조사는 어렵다.",
      "riskTolerance": "high",
      "cooperationRules": "교육파에는 안전 점검으로 설명하고 필요한 정보만 공유한다.",
      "conflictRules": "증거 유출 조짐이 보이면 행정 조치와 비공식 감시를 단계적으로 강화한다.",
      "travelRules": "세계관의 교통·통신 제약을 따른다.",
      "successOutcome": "흔적을 조용히 회수하고 학생들이 눈치채지 못한 채 관찰을 시작한다.",
      "partialOutcome": "흔적은 얻지만 학생 한 명이 연구부의 개입을 눈치챈다.",
      "failureOutcome": "핵심 파편을 놓치고 내부 갈등과 비밀 연구부의 관심 시계가 함께 전진한다.",
      "offscreenEnabled": true,
      "canFailOffscreen": true,
      "revealTraces": true
    }
  ],
  "hiddenRelationshipMemories": [
    {
      "id": "MEM_LENA_RESONANCE",
      "relationId": "REL_LENA_TO_PLAYER",
      "sourceId": "NPC_LENA",
      "targetId": "PLAYER_YJH",
      "turnLabel": "프롤로그",
      "eventId": "",
      "type": "custom",
      "title": "낯익은 공명 파장",
      "summary": "윤지훈에게서 과거 사고와 닮은 원소 파장을 느꼈다.",
      "cause": "205호 문이 파손된 직후 두 사람의 기가 짧게 반응했다.",
      "visibility": "Hidden",
      "importance": 78,
      "permanence": "permanent",
      "effects": {
        "trust": -3,
        "favor": 0,
        "fear": 2,
        "respect": 4,
        "suspicion": 12,
        "hostility": 0,
        "dependency": 0
      },
      "active": true,
      "unresolved": true,
      "resolutionConditions": "윤지훈가 공명에 관해 솔직한 정보를 제공하거나 과거 사고와 무관하다는 증거를 찾는다.",
      "tags": "공명, 과거 사고, 첫인상",
      "createdAt": "2026-08-22T15:16:00.942Z"
    }
  ],
  "hiddenFactionRelations": [],
  "hiddenEvents": [
    {
      "id": "EVT_FIRST_RESONANCE",
      "name": "첫 번째 공명",
      "kind": "compound",
      "type": "Conditional",
      "visibility": "Hidden",
      "status": "Planned",
      "priority": 98,
      "timeWindow": "입학 첫 주",
      "conditions": "EVT_FIRST_PRACTICAL 완료 후 세 인물이 같은 차단 구역에서 능력을 사용하거나, 연구 설비가 세 파형을 강제로 재생한다.",
      "cancelConditions": "세 인물이 완전히 분리되고 설비 전원이 차단된다. 다만 사건은 다른 시간·장소로 지연될 수 있다.",
      "participants": "PLAYER_YJH, NPC_LENA, NPC_LILIA",
      "effects": "세 파장이 삼각 공명을 일으키고 지하의 봉인 설비가 짧게 기동한다. 결과는 통제·부분 통제·폭주의 정도에 따라 체력·집중력·관계·연구부 관심에 남는다.",
      "onSuccess": "공명을 부분 통제하고 비정상적인 제4의 반향 또는 공명 결정 파편을 관측한다.",
      "onFailure": "차단장 일부가 손상되고 누군가 경미한 과부하를 겪으며 연구부가 즉시 개입한다. 실패는 게임오버가 아니라 조사와 관계의 새 경로가 된다.",
      "followUp": "EVT_RESONANCE_AFTERSHOCK",
      "description": "윤지훈의 원소, 레나의 압력 편향, 릴리아의 기갑 강화가 동시에 겹치며 세 사람의 것이 아닌 네 번째 반향이 바닥 아래에서 돌아온다.",
      "playerCanIntervene": true,
      "required": true,
      "sequence": 3,
      "completionSignals": "세 파장의 동시 반응|바닥 아래 제4의 반향|공명 종료 후 상태·단서·관계 변화 장부 반영",
      "requiredItems": "",
      "requiredDialogue": "",
      "requiredSpeakerId": "",
      "recoveryAlternatives": "능력 사용을 피하면 설비가 이전 측정 기록을 재생해 약한 공명을 유도한다. 한 명이 자리를 비우면 남은 둘의 불완전 공명과 원격 측정 데이터가 세 번째 파장을 대신한다. 결과 강도는 낮아지지만 사건의 핵심 흔적은 남는다.",
      "preservePlayerChoice": true,
      "endSceneAfterCompletion": false,
      "appliesTo": [],
      "rules": [],
      "beats": [
        {
          "id": "BEAT_RESONANCE_01",
          "viewpoint": "감각 가능한 전조",
          "content": "조명 떨림, 측정 고리의 역회전, 발바닥 아래 낮은 진동을 순서대로 보여 준다. 지하 설비나 연구부의 정답은 말하지 않는다."
        },
        {
          "id": "BEAT_RESONANCE_02",
          "viewpoint": "세 파장의 충돌",
          "content": "각 인물의 능력은 기존 한계를 지킨다. 플레이어가 선언한 행동을 첫 인과로 삼고 NPC는 자신의 성격과 위치에 맞춰 반응한다."
        },
        {
          "id": "BEAT_RESONANCE_03",
          "viewpoint": "선택 가능한 위기",
          "content": "공명을 끊기·균형 잡기·누군가 보호하기·원인을 관찰하기 등 실행 가능한 선택 공간을 남긴다. 추천 행동은 답을 숨기고 위험만 표시한다."
        },
        {
          "id": "BEAT_RESONANCE_04",
          "viewpoint": "결과 수렴",
          "content": "마지막 비트에서만 성공·부분 성공·실패를 현실적으로 수렴한다. 제4의 반향과 남은 물리적 흔적 하나를 확정하고, 피해·관계 기억·사건 시계를 갱신한다."
        }
      ],
      "alternateBeats": [
        {
          "id": "ALT_RESONANCE_SEPARATED",
          "priority": 85,
          "narrativeGoal": "세 인물이 함께 있지 않아도 기록 재생과 불완전 공명으로 핵심 미스터리를 지연 실행한다.",
          "requiredSignals": [
            "불완전한 삼각 파형",
            "제4의 반향",
            "낮아진 피해"
          ],
          "preservePlayerChoice": true
        }
      ],
      "sceneMarkers": [
        {
          "id": "MARK_RESONANCE_ENTRY",
          "label": "공명 전조",
          "phase": "entry"
        },
        {
          "id": "MARK_RESONANCE_CHOICE",
          "label": "플레이어 개입 선택",
          "phase": "progress"
        },
        {
          "id": "MARK_RESONANCE_FOURTH",
          "label": "제4의 반향 관측",
          "phase": "complete",
          "when": {
            "kind": "event_completed",
            "eventId": "EVT_FIRST_RESONANCE"
          }
        }
      ],
      "multiroute": {
        "scope": "common",
        "chapterId": "CH_GISEONG_RESONANCE",
        "completionScope": "scene_once",
        "resetBehavior": "preserve_completion",
        "revealPolicyId": "REVEAL_GISEONG_CORE",
        "endingFlagsAdd": [
          "FLAG_FIRST_RESONANCE"
        ],
        "alternativeFulfillment": [
          {
            "id": "FULFILL_RESONANCE_RECORDING",
            "description": "세 사람이 한 공간에 모이지 않으면 설비가 저장된 측정 파형을 재생해 약한 공명을 발생시킨다.",
            "completionSignals": [
              "세 파형의 기록 중첩",
              "제4의 반향 관측"
            ],
            "resultingEffects": [
              "FLAG_FIRST_RESONANCE=true"
            ]
          }
        ]
      },
      "scope": "common",
      "chapterId": "CH_GISEONG_RESONANCE",
      "completionScope": "scene_once",
      "resetBehavior": "preserve_completion",
      "revealPolicyId": "REVEAL_GISEONG_CORE",
      "endingFlagsAdd": [
        "FLAG_FIRST_RESONANCE"
      ],
      "alternativeFulfillment": [
        {
          "id": "FULFILL_RESONANCE_RECORDING",
          "description": "세 사람이 한 공간에 모이지 않으면 설비가 저장된 측정 파형을 재생해 약한 공명을 발생시킨다.",
          "completionSignals": [
            "세 파형의 기록 중첩",
            "제4의 반향 관측"
          ],
          "resultingEffects": [
            "FLAG_FIRST_RESONANCE=true"
          ]
        }
      ]
    },
    {
      "id": "CONSTRAINT_PLAYER_AGENCY",
      "name": "플레이어 주도권 고정",
      "kind": "constraint",
      "type": "Fixed",
      "visibility": "Hidden",
      "status": "Active",
      "priority": 100,
      "timeWindow": "",
      "conditions": "",
      "cancelConditions": "",
      "participants": "PLAYER_YJH",
      "effects": "",
      "onSuccess": "",
      "onFailure": "",
      "followUp": "",
      "description": "윤지훈의 행위와 내면은 사용자 입력만이 결정한다.",
      "playerCanIntervene": true,
      "required": false,
      "sequence": 6,
      "completionSignals": "",
      "requiredItems": "",
      "requiredDialogue": "",
      "requiredSpeakerId": "",
      "recoveryAlternatives": "NPC의 독립 행동 | 환경 변화 | 다른 장소·시간의 우회 경로",
      "preservePlayerChoice": true,
      "endSceneAfterCompletion": false,
      "appliesTo": [
        "EVT_A205_FIRST_CONTACT",
        "EVT_CAFETERIA_CROSSCHECK",
        "EVT_FIRST_PRACTICAL",
        "EVT_FIRST_RESONANCE",
        "EVT_RESONANCE_AFTERSHOCK"
      ],
      "rules": [
        "사용자가 입력하지 않은 윤지훈의 행동·대사·감정·판단·동의를 서술하지 않는다.",
        "사용자 입력이 복합적이면 실행 가능한 절부터 순서대로 처리하고 불가능한 부분만 세계 규칙에 따라 실패시킨다.",
        "추천 행동은 선택지가 아니라 예시이며 자유 입력을 제한하지 않는다."
      ],
      "beats": [],
      "alternateBeats": [],
      "sceneMarkers": []
    },
    {
      "id": "CONSTRAINT_DISCLOSURE",
      "name": "공명 미스터리 공개 제한",
      "kind": "constraint",
      "type": "Fixed",
      "visibility": "Hidden",
      "status": "Active",
      "priority": 100,
      "timeWindow": "",
      "conditions": "",
      "cancelConditions": "",
      "participants": "",
      "effects": "",
      "onSuccess": "",
      "onFailure": "",
      "followUp": "",
      "description": "단서 없는 정답 공개를 막는다.",
      "playerCanIntervene": true,
      "required": false,
      "sequence": 7,
      "completionSignals": "",
      "requiredItems": "",
      "requiredDialogue": "",
      "requiredSpeakerId": "",
      "recoveryAlternatives": "NPC의 독립 행동 | 환경 변화 | 다른 장소·시간의 우회 경로",
      "preservePlayerChoice": true,
      "endSceneAfterCompletion": false,
      "appliesTo": [
        "EVT_A205_FIRST_CONTACT",
        "EVT_CAFETERIA_CROSSCHECK",
        "EVT_FIRST_PRACTICAL",
        "EVT_FIRST_RESONANCE",
        "EVT_RESONANCE_AFTERSHOCK"
      ],
      "rules": [
        "Reveal Policy가 forbidden인 동안 지하 실험·유도 장치·연구부의 계획을 본문과 추천 행동에 직접 쓰지 않는다.",
        "공개 전에는 플레이어가 볼 수 있는 진동·파손 방향·기록 공백·과잉 대응·제4의 반향만 묘사한다.",
        "숨은 NPC 기억과 세력 장부는 관측 가능한 흔적이 생기기 전까지 공개하지 않는다."
      ],
      "beats": [],
      "alternateBeats": [],
      "sceneMarkers": []
    }
  ],
  "hiddenEventClocks": [
    {
      "id": "CLOCK_RESEARCH",
      "name": "비밀 연구부의 관심",
      "visibility": "Hidden",
      "status": "Active",
      "current": 1,
      "maximum": 6,
      "relatedEventId": "EVT_FIRST_RESONANCE",
      "advanceRules": "비정상 파형 노출, 핵심 파편 확보 시도, 제한 구역 접근, 공식 설명 공개 반박 시 1칸 전진. 한 턴에 최대 1칸.",
      "regressRules": "증거를 안전하게 보관하고 공개 행동을 줄이거나 교육파의 공식 절차 안에서 움직이면 상황에 따라 1칸 후퇴.",
      "triggerResult": "4칸부터 비공식 감시, 6칸에서 강제 면담과 소지품 검사 시도가 발생한다.",
      "publicHint": "시설팀·교관·연구원의 시선과 확인 절차가 늘어난다.",
      "hiddenNotes": "플레이어에게 수치와 이름을 직접 공개하지 않고 관측 가능한 징후만 보여 준다."
    },
    {
      "id": "CLOCK_RESONANCE_STABILITY",
      "name": "세 파장의 안정도",
      "visibility": "Public",
      "status": "Active",
      "current": 0,
      "maximum": 4,
      "relatedEventId": "EVT_FIRST_RESONANCE",
      "advanceRules": "서로의 능력 한계를 공유하거나, 합의된 훈련으로 공명을 끊고 잇는 데 성공하면 1칸 전진.",
      "regressRules": "과부하를 무시한 동시 사용, 강압적 실험, 서로의 한계를 숨긴 채 무리하면 1칸 후퇴.",
      "triggerResult": "4칸에서 세 사람은 우발 공명을 한 번 안전하게 중단할 수 있다.",
      "publicHint": "서로의 호흡과 기 파형을 읽는 감각이 선명해진다.",
      "hiddenNotes": "관계 수치가 아니라 실제 협력 행동으로만 변한다."
    }
  ],
  "hiddenForeshadowings": [
    {
      "id": "FSH_DOOR",
      "title": "A동 205호의 부서진 문",
      "visibility": "Hidden",
      "status": "Planted",
      "earliestDate": "2026-03-02",
      "latestDate": "2026-03-16",
      "plantingScene": "A205호 문이 방 안의 충격인데도 복도 방향으로 넘어져 있고, 문 재질이 아닌 은회색 파편이 발견된다.",
      "reinforcementPlan": "제3실기동에서 같은 금속음과 제4의 반향이 나타나며, 시설 사고 접수번호의 일부가 사라진다.",
      "payoffConditions": "A205호 파편과 실기동 측정 기록을 대조하거나 연구동의 과거 사고 기록에 접근한다.",
      "payoffResult": "두 사건이 같은 공명 설비의 유도 반응이라는 사실이 단계적으로 드러난다.",
      "relatedEntities": "윤지훈, 레나, 기성학원 연구부",
      "misdirection": "레나의 통제 실패처럼 보이게 한다.",
      "notes": "근거 없이 범인을 확정하지 않는다."
    },
    {
      "id": "FSH_FOURTH_ECHO",
      "title": "세 사람이 아닌 제4의 반향",
      "visibility": "Hidden",
      "status": "Planned",
      "earliestDate": "2026-03-03",
      "latestDate": "2026-03-09",
      "plantingScene": "첫 실기 측정에서 바닥 아래 금속음이 한 번 울린다.",
      "reinforcementPlan": "첫 공명에서 세 파장 뒤에 늦게 따라오는 동일한 반향을 측정기와 감각으로 확인한다.",
      "payoffConditions": "측정 기록 원본 또는 공명 결정의 파형을 확보한다.",
      "payoffResult": "제4의 반향은 사람의 능력이 아니라 저장·재생된 설비 파형임이 밝혀진다.",
      "relatedEntities": "PLAYER_YJH, NPC_LENA, NPC_LILIA, FAC_ACADEMY",
      "misdirection": "세 사람 중 한 명에게 숨은 두 번째 능력이 있는 것처럼 보일 수 있다.",
      "notes": "초기에는 정답을 말하지 않고 반복되는 시간차만 일관되게 보여 준다."
    }
  ],
  "hiddenImageTriggers": [
    {
      "id": "IMGTRG_A205_OPENING",
      "name": "A205호 첫 장면",
      "enabled": true,
      "visibility": "Hidden",
      "triggerType": "event_start",
      "sourceId": "EVT_A205_FIRST_CONTACT",
      "threshold": 1,
      "storyProgress": "",
      "customCondition": "",
      "mode": "generate_scene",
      "attachedImages": [],
      "characterIds": [
        "NPC_LENA",
        "NPC_LILIA"
      ],
      "prompt": "비가 막 그친 현대 한국의 초능력 기숙학교, A동 2층 복도. A205호 문이 복도 쪽으로 쓰러져 있고 문 아래 물방울과 은회색 파편이 보인다. 긴 은빛 머리와 자색 눈의 레나는 파편 옆에 차갑게 서 있고, 복도 끝에서 붉은 머리와 금색 눈의 릴리아가 입학 안내 봉투를 든 채 다가온다. 스포일러 장치나 지하 시설은 보이지 않는다. 고품질 애니메이션 시네마틱, 텍스트 없음.",
      "negativePrompt": "글자, 워터마크, 지하 실험실, 흑막, 성인처럼 보이는 학생, 외형 변경, 추가 인물의 과도한 클로즈업",
      "aspectRatio": "landscape",
      "shotType": "복도 원근이 살아 있는 와이드 establishing shot",
      "styleOverride": "맑고 선명한 현대 학원 애니메이션, 일상과 불길함의 대비",
      "useCharacterReferences": true,
      "preserveFaces": true,
      "spoilerProtection": true,
      "once": true,
      "priority": 100,
      "outputPosition": "before_scene",
      "routeIds": [
        "ROUTE_GISEONG_COMMON"
      ],
      "chapterIds": [
        "CH_GISEONG_PROLOGUE"
      ],
      "endingIds": [],
      "revealPolicyId": "",
      "requiredFlags": [],
      "forbiddenFlags": []
    },
    {
      "id": "IMGTRG_FIRST_PRACTICAL",
      "name": "첫 실기 측정",
      "enabled": true,
      "visibility": "Hidden",
      "triggerType": "event_start",
      "sourceId": "EVT_FIRST_PRACTICAL",
      "threshold": 1,
      "storyProgress": "",
      "customCondition": "",
      "mode": "generate_scene",
      "attachedImages": [],
      "characterIds": [
        "PLAYER_YJH",
        "NPC_LENA",
        "NPC_LILIA"
      ],
      "prompt": "현대식 초능력 학교의 제3실기동, 원형 차단장과 측정 고리. 검은 머리의 윤지훈, 긴 은빛 머리의 레나, 붉은 머리의 릴리아가 각자 거리를 둔 채 첫 측정을 준비한다. 안전 설비와 관찰창, 긴장된 신입생 분위기. 능력 폭발 전의 정적, 텍스트 없음.",
      "negativePrompt": "텍스트, 워터마크, 스포일러, 설정과 다른 얼굴",
      "aspectRatio": "landscape",
      "shotType": "세 인물의 위치 관계가 보이는 미디엄 와이드",
      "styleOverride": "고품질 현대 학원 배틀 애니메이션",
      "useCharacterReferences": true,
      "preserveFaces": true,
      "spoilerProtection": true,
      "once": true,
      "priority": 82,
      "outputPosition": "before_scene",
      "routeIds": [
        "ROUTE_GISEONG_COMMON"
      ],
      "chapterIds": [
        "CH_GISEONG_PROLOGUE"
      ],
      "endingIds": [],
      "revealPolicyId": "",
      "requiredFlags": [],
      "forbiddenFlags": []
    },
    {
      "id": "IMGTRG_FIRST_RESONANCE",
      "name": "첫 번째 공명 발현",
      "enabled": true,
      "visibility": "Hidden",
      "triggerType": "event_condition_met",
      "sourceId": "EVT_FIRST_RESONANCE",
      "threshold": 1,
      "storyProgress": "",
      "customCondition": "",
      "mode": "generate_scene",
      "attachedImages": [],
      "characterIds": [
        "PLAYER_YJH",
        "NPC_LENA",
        "NPC_LILIA"
      ],
      "prompt": "원형 차단장 안에서 윤지훈의 물과 바람의 흐름, 레나의 자색 압력면, 릴리아의 붉은 기갑광이 삼각형으로 겹치는 첫 공명 순간. 바닥 아래에서 세 사람의 것이 아닌 희미한 네 번째 백색 반향이 늦게 올라온다. 세 인물의 고유 외형 유지, 과도한 파괴 없이 선택 가능한 위기, 텍스트 없음.",
      "negativePrompt": "텍스트, 워터마크, 스포일러, 설정과 다른 얼굴",
      "aspectRatio": "landscape",
      "shotType": "역동적인 로우 앵글 시네마틱",
      "styleOverride": "선명한 에너지 대비의 고품질 애니메이션",
      "useCharacterReferences": true,
      "preserveFaces": true,
      "spoilerProtection": true,
      "once": true,
      "priority": 98,
      "outputPosition": "after_scene",
      "routeIds": [
        "ROUTE_GISEONG_COMMON"
      ],
      "chapterIds": [
        "CH_GISEONG_RESONANCE"
      ],
      "endingIds": [],
      "revealPolicyId": "REVEAL_GISEONG_CORE",
      "requiredFlags": [],
      "forbiddenFlags": []
    }
  ],
  "hiddenRisks": "문 주변의 잔류 파형은 윤지훈와 레나의 기에 약하게 반응한다. 시설팀은 일반 수리보다 흔적 회수를 우선한다. 이 정보는 관측 가능한 현상이 생기기 전까지 직접 공개하지 않는다.",
  "gmLedger": {
    "worldTruthLedger": "A205호 파손과 제3실기동의 공명은 같은 지하 설비에서 발생한 유도 반응이다. 설비는 세 학생의 파형을 처음부터 완전히 알고 있던 것이 아니라 입학 측정 자료를 수집해 조합했다. 윤지훈의 원소 전환 공백이 기동 열쇠처럼 작용하고, 레나의 압력 편향이 파형을 고정하며, 릴리아의 기갑 강화가 출력을 견디는 구조를 만든다. 이 정답은 데모 구간에서는 완전 공개하지 않는다.",
    "hiddenTimeline": "2026-03-01 밤: 연구파가 A동의 구형 공명 중계기를 시험한다. 03-02 11:54: A205호 잠금 장치가 역방향 충격으로 파손된다. 12:18: 윤지훈와 레나가 현장에 도달하며 약한 공명. 12:23 전후: 시설팀 회수 명령. 03-03 10:00: 제3실기동 측정. 측정 데이터가 지하 설비에 재전송되며 첫 공명 조건이 완성된다.",
    "secretResources": "은회색 중계기 파편 3개: A205호 문 아래 1, 레나가 회수 가능한 1, 시설팀이 회수할 1. 원본 CCTV 영상은 12:11~12:17 구간만 비어 있다. 실기동 원본 측정 로그에는 공식 사본에 없는 0.7초 지연 파형이 남는다.",
    "plannedTwists": "첫 번째 반전: 제4의 반향은 네 번째 학생이 아니라 설비가 재생한 파형이다. 두 번째 반전: 레나의 과거 폭주 기록과 현재 사건은 닮았지만 레나가 원인은 아니다. 장기 전개에서만 연구부 내부의 목적과 교육파의 은폐 책임을 분리해 밝힌다.",
    "forbiddenDisclosures": "첫 공명 완료 전 ‘지하 공명 실험’, ‘연구부가 유도했다’, ‘윤지훈가 열쇠다’를 본문·추천 행동·상태창·이미지 프롬프트의 노출 가능한 문구로 쓰지 않는다. 레나의 과거 사고도 본인이 말하거나 검증된 기록을 발견하기 전에는 구체적으로 공개하지 않는다.",
    "failureEscalationRules": "실패는 즉시 사망이나 게임오버로 처리하지 않는다. 경미한 부상, 기록 선점, 관계 오해, 감시 증가, 보충 측정, 소지품 검사처럼 다음 선택을 만드는 비용으로 전환한다. 같은 실패를 반복하면 연구부 관심 시계와 공명 불안정이 단계적으로 악화된다.",
    "continuityNotes": "시간·장소·소지 단서·NPC가 실제로 본 정보만 이어 간다. 누가 파편을 가졌는지, 누가 사진을 찍었는지, 공명 때 누구를 도왔는지를 관계 기억과 후속 대사의 근거로 사용한다. 원소 전환에는 항상 짧은 집중 구간이 필요하다."
  }
}
~~~

## START COMMAND

/패키지불러오기
